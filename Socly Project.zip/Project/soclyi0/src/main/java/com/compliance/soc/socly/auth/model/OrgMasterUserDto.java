package com.compliance.soc.socly.auth.model;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Component
/**
 * {@link OrgMasterUserDto} is a POJO class to handle {@link Organization}
 * and {@link User} registration.
 */
public class OrgMasterUserDto {

    private String orgName;

    private String description;

    private String email;

    private String phone;

    private String name;
    // different framework client subscribes to (iso/soc2...)
    private String[] frameworkSubscribed;

}
