package com.compliance.soc.socly.cloud.aws.service;

import com.compliance.soc.socly.auth.config.TokenProvider;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.cloud.aws.exception.UserNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CredentialUtil {

    @Autowired
    protected TokenProvider jwtTokenUtil;
    @Autowired
    private UserService userService;

    // retrieve org name from token
    public String retrieveOrganization(String token) throws UserNotFoundException {
        String organizationName = null;
        String username = jwtTokenUtil.getUsernameFromToken(token);
        log.info("Username extracted from token is: {}", username);
        User user = userService.findOne(username);
        if (null == user) {
            throw new UserNotFoundException("Unique user not found for username " + username);
        }
        organizationName = user.getOrganization().getOrgName();
        return organizationName;
    }

}
