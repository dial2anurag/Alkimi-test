package com.compliance.soc.socly.auth.service;

import com.compliance.soc.socly.auth.entity.UserRole;
import com.compliance.soc.socly.auth.exception.UserRoleException;
import org.springframework.stereotype.Service;

@Service
/**
 * This is an interface for the user service implementation.
 */

public interface UserRoleService {
    /**
     * this interfqce for fetching by userId and roleid useed in auditperiodService.
     * @param userId
     * @param roleId
     * @return
     */
    UserRole findByUserIdAndRoleId(long userId, long roleId)throws UserRoleException;
}
