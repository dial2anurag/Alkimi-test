package com.compliance.soc.socly.saas.configuration.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SaasConfigurationDto {

    private String saasId;
    private long orgId;
    private int frameworkId;
    private String name;
    private String configurationValue;
}
