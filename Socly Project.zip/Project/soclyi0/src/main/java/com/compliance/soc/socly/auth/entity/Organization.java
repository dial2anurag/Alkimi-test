package com.compliance.soc.socly.auth.entity;

import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.organization.entity.Framework;
import com.compliance.soc.socly.organization.entity.OrgDetails;
import com.compliance.soc.socly.saas.configuration.entity.SaasConfiguration;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
/**
 * OrgMaster is an entity class and properties from the ORG_MASTER table
 */
@Table(name = "ORG_MASTER")
public class Organization {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @Column(name = "org_name", unique = true)
    private String orgName;

    @Column
    private String description;

    @Column(name = "registered_date_time", nullable = false)
    private Date registeredDateTime = new Date();

    @Column(name = "is_detail_filled")
    private boolean isDetailFilled;

    @Column(nullable = false)
    private String status = "ACTIVE";

    @Column(name = "parent_id")
    private long parentId;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "org_framework",
            joinColumns = {
                    @JoinColumn(name = "org_id", referencedColumnName = "id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "framework_id", referencedColumnName = "id")})
    @JsonIgnoreProperties("organizations")
    private Set<Framework> frameworks;

    /**
     * one organization can have multiple SaasMaster mappings and vice versa
     * hence, a list of SaasMaster objects : saasMasterList
     */
    @ManyToMany(mappedBy = "organizations")
    @JsonIgnoreProperties("organizations")
    private List<SaasMaster> saasMasters;

    @OneToMany(mappedBy = "organization")
    @JsonIgnoreProperties("organization")
    private List<User> users;

    @OneToMany(targetEntity = AuditPeriod.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "organization")
    private List<AuditPeriod> auditPeriods;

    /**
     * one organization can have multiple saasConfiguration
     * hence, a list of SaasConfiguration objects : saasConfigurations
     */
    @OneToMany(targetEntity = SaasConfiguration.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private List<SaasConfiguration> saasConfigurations;

    /**
     * one organization can have multiple orgDetails
     * hence, a list of OrgDetails objects : orgDetails
     */
    @OneToMany(targetEntity = OrgDetails.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private List<OrgDetails> orgDetails;
}