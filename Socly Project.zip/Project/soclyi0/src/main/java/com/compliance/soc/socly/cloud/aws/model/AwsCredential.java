package com.compliance.soc.socly.cloud.aws.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Arrays;

@Getter
@Setter
@Component
/**
 * It is request body for the Aws credential.
 */
public class AwsCredential {
    @NotNull(message = "AccessKey must be provided")
    @NotBlank(message = "A valid accessKey value must be provided")
    private String accessKey;
    @NotNull(message = "SecretKey must be provided")
    @NotBlank(message = "A valid secretKey value must be provided")
    private String secretKey;
    @NotNull(message = "Account admin names must be provided")
    @NotEmpty(message = "At least 1 admin name is required")
    private String[] account_admins;
    @NotNull(message="region must be provided")
    @NotBlank(message="A valid regional value must be provided")
    private  String region;

    @Override
    public String toString() {
        return "{" +
                "accessKey='" + accessKey + '\'' +
                ", secretKey='" + secretKey + '\'' +
                ", account_admins=" + Arrays.toString(account_admins) +
                ", region='" +region +'\''+
                '}';
    }


}
