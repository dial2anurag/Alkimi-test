package com.compliance.soc.socly.cloud.aws.controller;


import com.compliance.soc.socly.alert.entity.OrgSaas;
import com.compliance.soc.socly.alert.service.AlertService;
import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.SuperUser;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.auth.service.impl.SuperUserServiceImpl;
import com.compliance.soc.socly.cloud.aws.exception.AccountAdminException;
import com.compliance.soc.socly.cloud.aws.exception.UserNotFoundException;
import com.compliance.soc.socly.cloud.aws.model.AwsCredential;
import com.compliance.soc.socly.cloud.aws.service.EncryptionService;
import com.compliance.soc.socly.cloud.aws.service.SecurityHub;
import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.SaasProvider;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import com.compliance.soc.socly.saas.service.OrgSaasService;
import com.compliance.soc.socly.saas.service.SaasMasterService;
import com.compliance.soc.socly.util.PathUtil;
import com.compliance.soc.socly.util.SecretManager;
import com.compliance.soc.socly.util.secrets.ClientSecretsUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/aws")
public class CloudController extends BaseController {

    public static final String defaultRegion = "eu-north-1";    //"ap-south-1"

    @Value("${cloud.aws.accessKey}")
    private String accessKey;

    @Value("${cloud.aws.secretKey}")
    private String secretKey;

    @Autowired
    private EncryptionService encryptionService;

    @Autowired
    private SecurityHub securityService;

    @Autowired
    private ClientSecretsUtil clientSecretsUtil;

    @Autowired
    private SecretManager secretManager;

    @Autowired
    private OrgMasterService orgMasterService;

    @Autowired
    private UserService userService;

    @Autowired
    private SuperUserServiceImpl superUserServiceImpl;

    @Autowired
    private AlertService alertService;

    @Autowired
    private SaasMasterService saasMasterService;

    @Autowired
    private OrgSaasService orgSaasService;

    @Autowired
    private PathUtil pathUtil;


    /**
     * API method to register for the AWS.
     *
     * @param awsCredential
     * @param request
     */
    @PreAuthorize("hasRole('ORG_BUSINESS_ADMIN')")
    @PostMapping("/credentials")
    public ResponseEntity storeCredential(@Valid @RequestBody AwsCredential awsCredential, HttpServletRequest request) {
        String[] adminList = awsCredential.getAccount_admins();
        if (adminList[0].trim().isEmpty()) {
            throw new AccountAdminException("Account admin name cannot be empty");
        }
        String awsAdmins = String.join(",", adminList);
        String header = request.getHeader(HEADER_STRING);
        String authToken = header.replace(TOKEN_PREFIX, "");
        String username = jwtTokenUtil.getUsernameFromToken(authToken);
        log.info("Username extracted from token is: {}", username);
        User user;
        try {
            user = userService.findOne(username);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            throw new UserNotFoundException("Unique user not found for username " + username);
        }
        String organizationName = user.getOrganization().getOrgName();
        SuperUser superUserDB = superUserServiceImpl.getSuperUser(organizationName);
        if (superUserDB == null) {
            SuperUser superUser = new SuperUser();
            superUser.setCompanyName(organizationName);
            superUser.setCloudAwsAdmins(awsAdmins);
            superUserServiceImpl.addSuperUser(superUser);
        } else {
            superUserServiceImpl.updateSuperUser(awsAdmins, superUserDB);
        }
        ObjectMapper Obj = new ObjectMapper();
        HttpStatus status;
        String message;
        try {
            String s = secretManager.addOrUpdateSecretsToAWS(organizationName, awsCredential);
            message = s;
            orgMasterService.update(username);
            // update the org - saas records
            final Organization organization = orgMasterService.getOrganization(organizationName);
            final long orgId = organization.getId();
            log.info("OrgId of logged in user : {}", orgId);
            final SaasMaster saasMaster = saasMasterService.getSaasMaster(SaasProvider.AWS.name());
            OrgSaas orgSaas = orgSaasService.getOrgSaasNullable(organization, saasMaster);
            if (null == orgSaas) {
                orgSaas = new OrgSaas();
                orgSaas.setOrganization(organization);
                orgSaas.setSaasMaster(saasMaster);
            }
            final OrgSaas savedOrgSaas = orgSaasService.saveAuditDataFromDate(orgSaas, null);
            log.info("Saved OrgSaas record : {}", savedOrgSaas);
            status = HttpStatus.OK;
        } catch (Exception e) {
            message = e.toString();
            log.error(message);
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return new ResponseEntity(message, status);
    }

    @GetMapping("/healthCheck")
    public String checkHealth() {
        return "App is UP";
    }

    /**
     * AWS API to fetch the 1. real time compliances 2. Store response on S3 bucket folder based on compliance type
     * and 3. store PDFs in S3 Compliance folder under organizational bucket based on complianceType
     * Compliance Type is decided based on the url
     * <p>
     * TODO : change the @PathVariable("framework") String framework > enum based and remove the framework validation code.
     * if (!(FRAMEWORK.equals("ISO") || FRAMEWORK.equals("SOC2"))) {
     *             return new ResponseEntity<>("URI path not valid", HttpStatus.NOT_FOUND);
     *         }
     *
     * @param request
     * @return
     */
    @GetMapping({"/{framework}/compliance"})
    public ResponseEntity<Object> security(@PathVariable("framework") String framework, final HttpServletRequest request) {
        final String FRAMEWORK = framework.toUpperCase();
        if (!(FRAMEWORK.equals("ISO") || FRAMEWORK.equals("SOC2"))) {
            return new ResponseEntity<>("URI path not valid", HttpStatus.NOT_FOUND);
        }
        String header = request.getHeader(HEADER_STRING);
        String authToken = header.replace(TOKEN_PREFIX, "");
        String username = jwtTokenUtil.getUsernameFromToken(authToken);
        log.info("username " + username);
        final User user = userRepository.findByUsername(username);
        String organizationName = user.getOrganization().getOrgName();
        // getting organizationName from user table by passing username and username we get from token
        // use organizationName in super_user table to get list of admins
        SuperUser superUser = superUserServiceImpl.getSuperUser(organizationName);
        // TODO : Replace the "aws" with enum and null check for secretFromAws
        Object secretFromAws = secretManager.getSecretsFromAws("aws", organizationName);
        SaasProvider saas;
        String saasRegion = "ap-south-1";
        if (secretFromAws instanceof AwsCredential) {
            AwsCredential awsCredential = (AwsCredential) secretFromAws;
            accessKey = awsCredential.getAccessKey();
            secretKey = awsCredential.getSecretKey();
            saas = SaasProvider.AWS;
            saasRegion = awsCredential.getRegion();
            log.info("accessKey and secret key fetched");
            log.info("AccessKey and Secret fetched successfully for {} of the {}", SaasProvider.AWS.name(), organizationName);
        } else {
            return new ResponseEntity<>(secretFromAws, HttpStatus.NOT_FOUND);
        }
        try {
            final ComplianceResponse complianceResponse = securityService.security(accessKey, secretKey, saasRegion, superUser, organizationName, FRAMEWORK);
            // put the response in the particular folder under organizational bucket
            this.persistsJSONResponse(organizationName, complianceResponse, FRAMEWORK);
            //to populate the data from AWS
            alertService.populateData(complianceResponse, saas.name());
            return new ResponseEntity<>(complianceResponse, HttpStatus.OK);
        } catch (final Exception e) {
            final String returnMessage = e.getMessage();
            log.error(returnMessage);
            return new ResponseEntity<>(returnMessage, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * @param clientId           : bucket Name
     * @param complianceResponse : Response to be persists
     * @param framework          : framework of the request
     */
    private void persistsJSONResponse(final String clientId, final ComplianceResponse complianceResponse, String framework) {
        final String keyName = pathUtil.getSaasProviderKeyName(clientId, SaasProvider.AWS.name());
        final String folderName = pathUtil.getSaasProviderFolderPath(framework, SaasProvider.AWS.name());
        final DataUpload2FolderRequest dataUpload2FolderRequest = new DataUpload2FolderRequest();
        dataUpload2FolderRequest.setBucketName(clientId.toLowerCase());
        log.info("PDF saved in folder " + folderName);
        dataUpload2FolderRequest.setFolderName(folderName);
        dataUpload2FolderRequest.setData(complianceResponse);
        dataUpload2FolderRequest.setKey(keyName);
        storageService.uploadUnderFolder(dataUpload2FolderRequest);
    }
}
