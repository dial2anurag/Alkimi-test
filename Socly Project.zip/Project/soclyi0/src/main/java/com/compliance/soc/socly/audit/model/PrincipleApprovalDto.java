package com.compliance.soc.socly.audit.model;

import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * PrincipleApprovalDto is a Dto class used for post or get values of selected properties
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PrincipleApprovalDto {
    /**
     * the  id is primary key of this table
     */
    private Integer id;

    /**
     * the status which shows auditStatus
     */
    private char status;

    /**
     * the principleId which is reference of MetricsMaster(metricsId)
     */
    private Integer principleId;

    /**
     * the createdDate shows on which date it is created
     */
    private Date createdDate;

    /**
     * the modifiedDate shows on which date it is modified
     */
    private Date modifiedDate;

    /**
     * the createdBy shows from which user it is being created
     */
    private Long createdBy;

    /**
     * the modifiedBy shows from which user it is being modified
     */
    private Long modifiedBy;

    /**
     * the auditNote is to write audit comment while approving File
     */
    private String auditNote;

    /**
     * In this mapping is done through Organization and PrincipleApproval with reference of orgId
     */
    @JsonIgnore
    private OrganizationDto organizationDto;

    /**
     * In this mapping is done through AuditPeriod and PrincipleApproval with reference of auditId
     */
    private AuditPeriodDto auditPeriod;
}
