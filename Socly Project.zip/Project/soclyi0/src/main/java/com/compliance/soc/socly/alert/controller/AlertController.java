package com.compliance.soc.socly.alert.controller;

import com.compliance.soc.socly.alert.model.AlertDto;
import com.compliance.soc.socly.alert.service.AlertService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/alerts")
@Slf4j
public class AlertController extends BaseController{

    @Autowired
    private AlertService alertService;

    /**
     * Api method is use fetch the history of Alerts with in the date range of given complianceId
     * which are stored in the saasCompliance table which are getting from Bitbucket and Gsuite
     *
     * @param cName
     * @param sDate
     * @param eDate
     * @return
     */
    @GetMapping(value = "/history/all/compliance")
    public ResponseEntity<?> getComplianceAlerts(@RequestParam String cName,
                                                 @RequestParam @DateTimeFormat(pattern = "dd/MM/yyyy") Date sDate,
                                                 @RequestParam @DateTimeFormat(pattern = "dd/MM/yyyy") Date eDate) {
        try {
            Organization organization = userService.getCurrentUser().getOrganization();
            List<AlertDto> alertDtos = alertService.fetchAlertStatus(cName, sDate, eDate, organization.getId());
            if (alertDtos != null && !alertDtos.isEmpty()) {
                return ResponseEntity.ok(alertDtos);
            } else {
                return ResponseEntity.badRequest().body("No alerts found for compliance: " + cName +" and org: "+ organization.getOrgName()
                        + " between " + DateUtils.getDate(sDate) + " and " +
                        DateUtils.getDate(eDate));
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(exception.getMessage());
        }
    }
}
