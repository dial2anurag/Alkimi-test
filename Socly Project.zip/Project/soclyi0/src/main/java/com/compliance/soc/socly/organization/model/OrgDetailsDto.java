package com.compliance.soc.socly.organization.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * OrgDetails Model
 */
public class OrgDetailsDto {

    private long id;

    private Long orgId;

    private String name;

    private String value;
}
