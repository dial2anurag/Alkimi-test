package com.compliance.soc.socly.auth.service;

public interface SuperUserService {
}
