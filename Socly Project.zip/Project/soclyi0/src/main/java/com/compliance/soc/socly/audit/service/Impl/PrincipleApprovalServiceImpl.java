package com.compliance.soc.socly.audit.service.Impl;

import com.compliance.soc.socly.audit.Exceptions.PrincipleApprovalException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.entity.PrincipleApproval;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.PrincipleApprovalDto;
import com.compliance.soc.socly.audit.model.PrincipleApprovalID;
import com.compliance.soc.socly.audit.model.PrincipleApprovalRequest;
import com.compliance.soc.socly.audit.repository.AuditPeriodRepository;
import com.compliance.soc.socly.audit.repository.PrincipleApprovalRepository;
import com.compliance.soc.socly.audit.service.PrincipleApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class PrincipleApprovalServiceImpl implements PrincipleApprovalService {

    @Autowired
    PrincipleApprovalRepository principleApprovalRepository;

    @Autowired
    private AuditPeriodRepository auditPeriodRepository;

    @Autowired
    private MappingService mappingService;

    /**
     * method to save PrincipleApproval data in principle_approval table
     *
     * @param principleApprovalRequest and User objects
     * @return PrincipleApproval data
     * @throws PrincipleApprovalException (custom exception)
     */
    @Override
    public PrincipleApprovalDto save(PrincipleApprovalRequest principleApprovalRequest, User user) throws PrincipleApprovalException {
        try {
            final Framework framework = new Framework();
            framework.setId(principleApprovalRequest.getFramework().getId());
            AuditPeriod auditPeriod = auditPeriodRepository.findOneByOrganizationAndStatusAndFramework(user.getOrganization(), "O", framework);
            if (auditPeriod == null) {
                throw new PrincipleApprovalException("AuditPeriod not found for this Principle");
            }
            final PrincipleApprovalID principleApprovalID = new PrincipleApprovalID();
            principleApprovalID.setPrincipleId(principleApprovalRequest.getPrincipleId());
            principleApprovalID.setClientId(user.getOrganization().getId());
            Optional<PrincipleApproval> searchPrincipleApproval = principleApprovalRepository.findById(principleApprovalID);
            PrincipleApproval principleApproval = new PrincipleApproval();
            if (!searchPrincipleApproval.isPresent()) {
                principleApproval.setStatus(principleApprovalRequest.getStatus());
                principleApproval.setPrincipleId(principleApprovalRequest.getPrincipleId());
                principleApproval.setAuditPeriod(auditPeriod);
                principleApproval.setClientId(user.getOrganization().getId());
                principleApproval.setCreatedBy(user.getId());
                principleApproval.setAuditNote(principleApprovalRequest.getAuditNote());
                principleApproval.setCreatedDate(new Date());
            } else {
                principleApproval = searchPrincipleApproval.get();
                principleApproval.setModifiedBy(user.getId());
                principleApproval.setModifiedDate(new Date());
                principleApproval.setStatus(principleApprovalRequest.getStatus());
                principleApproval.setAuditNote(principleApprovalRequest.getAuditNote());

            }
            return convert2Dto(principleApprovalRepository.save(principleApproval), user);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new PrincipleApprovalException(exception.getMessage());
        }
    }

    /**
     * This method is to convert Entity objects to Dto objects by set and get the each properties.
     *
     * @param save
     * @param user
     * @return
     */
    private PrincipleApprovalDto convert2Dto(PrincipleApproval save, User user) {
        final PrincipleApprovalDto principleApprovalDto = new PrincipleApprovalDto();
        principleApprovalDto.setId(save.getId());
        principleApprovalDto.setStatus(save.getStatus());
        principleApprovalDto.setOrganizationDto(mappingService.getOrgDtoFromEntity(user.getOrganization()));
        principleApprovalDto.setPrincipleId(save.getPrincipleId());
        principleApprovalDto.setCreatedBy(save.getCreatedBy());
        principleApprovalDto.setAuditNote(save.getAuditNote());
        principleApprovalDto.setModifiedBy(save.getModifiedBy());
        principleApprovalDto.setModifiedDate(save.getModifiedDate());
        principleApprovalDto.setCreatedDate(save.getCreatedDate());

        AuditPeriod auditPeriod = save.getAuditPeriod();
        AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
        auditPeriodDto.setAuditId(auditPeriod.getAuditId());
        auditPeriodDto.setPeriod(auditPeriod.getPeriod());
        auditPeriodDto.setStatus(auditPeriod.getStatus());
        auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
        auditPeriodDto.setStartDate(auditPeriod.getStartDate());
        auditPeriodDto.setEndDate(auditPeriod.getEndDate());
        auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
        auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
        auditPeriodDto.setOrgId(auditPeriod.getOrganization().getId());
        auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
        principleApprovalDto.setAuditPeriod(auditPeriodDto);

        return principleApprovalDto;
    }

    /**
     * This method is to get records of PrincipleApproval by PrincipleId.
     *
     * @param principleId
     * @return
     */
    @Override
    public List<PrincipleApproval> findByPrincipleId(Integer principleId) throws PrincipleApprovalException {
        try {
            return principleApprovalRepository.findByPrincipleId(principleId);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new PrincipleApprovalException(exception.getMessage());
        }
    }
}