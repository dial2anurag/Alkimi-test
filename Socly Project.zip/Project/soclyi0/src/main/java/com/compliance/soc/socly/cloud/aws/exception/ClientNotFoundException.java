package com.compliance.soc.socly.cloud.aws.exception;

public class ClientNotFoundException extends RuntimeException{

String message;
    ClientNotFoundException(String message){
        super(message);
        this.message=message;
    }
    @Override
    public String toString() {
        return message;
    }
}
