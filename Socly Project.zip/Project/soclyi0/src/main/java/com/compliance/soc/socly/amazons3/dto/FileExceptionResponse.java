package com.compliance.soc.socly.amazons3.dto;

public class FileExceptionResponse {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public FileExceptionResponse(String message) {
        this.message = message;
    }
}
