package com.compliance.soc.socly.policycenter.exception;

/**
 *  OrgPolicyException is exception class to handle separately with others
 */
public class OrgPolicyException extends Exception {

    public OrgPolicyException(final Exception ex) {
        super(ex);
    }

    public OrgPolicyException(final String errorMsg) {
        super(errorMsg);
    }
}
