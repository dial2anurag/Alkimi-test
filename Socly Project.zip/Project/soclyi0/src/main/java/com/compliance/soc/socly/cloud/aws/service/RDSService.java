package com.compliance.soc.socly.cloud.aws.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.rds.AmazonRDS;
import com.amazonaws.services.rds.AmazonRDSClientBuilder;
import com.amazonaws.services.rds.model.DBInstance;
import com.amazonaws.services.rds.model.DBParameterGroupStatus;
import com.amazonaws.services.rds.model.DescribeDBInstancesResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class RDSService {
	/**
	 * DB instance and the basic aws credential for the db region.
	 * @param accessKey
	 * @param secretKey
	 * @param defaultRegion
	 * @return
	 */
	

public DBInstance rds(String accessKey, String secretKey, String defaultRegion){
	
	BasicAWSCredentials aswCreds = new BasicAWSCredentials(accessKey, secretKey);
	// we need to know the region where database is present then only we can call ?????? option we have is iterate over all the regions
	AmazonRDS rds = AmazonRDSClientBuilder.standard().withRegion(defaultRegion).withCredentials(new AWSStaticCredentialsProvider(aswCreds)).build();

	DescribeDBInstancesResult dbInstances = rds.describeDBInstances();
	List<DBInstance> dbInstanceList = dbInstances.getDBInstances();
	DBInstance dbInstance = dbInstanceList.get(0);
	List<DBParameterGroupStatus> dbGroup = dbInstance.getDBParameterGroups();
	DBParameterGroupStatus params = dbGroup.get(0);
	String str = params.toString();
	
	log.info(str);
	log.info("hellooooooooooooooooooo");
	boolean b = dbInstance.getStorageEncrypted();
	return dbInstance;
}

	
}
