package com.compliance.soc.socly.cloud.azure.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@Component
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class AzureResponseMetadata {
    private String name;
    private AzureProperties properties;
}