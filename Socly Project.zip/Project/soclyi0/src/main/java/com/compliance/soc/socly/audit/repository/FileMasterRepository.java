package com.compliance.soc.socly.audit.repository;

import com.compliance.soc.socly.audit.entity.FileMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileMasterRepository extends JpaRepository<FileMaster, Integer> {

    FileMaster save(FileMaster master);
    FileMaster findByFileName(String fileName);


}
