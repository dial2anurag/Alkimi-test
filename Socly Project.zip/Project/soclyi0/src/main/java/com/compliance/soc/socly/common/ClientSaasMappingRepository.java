package com.compliance.soc.socly.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface ClientSaasMappingRepository extends JpaRepository<ClientSaasMapping, Integer> {

    ClientSaasMapping findByOrganizationNameAndSaasId(String organizationName, String saasId);

    ClientSaasMapping[] findByOrganizationNameAndIsActive(String organizationName, String isActive);
}
