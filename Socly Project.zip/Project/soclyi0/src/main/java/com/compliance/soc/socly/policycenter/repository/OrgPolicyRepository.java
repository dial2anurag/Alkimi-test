package com.compliance.soc.socly.policycenter.repository;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.enums.PolicyStatus;
import com.compliance.soc.socly.policycenter.entity.OrgPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * OrgPolicyRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface OrgPolicyRepository extends JpaRepository<OrgPolicy, Integer> {
    /**
     * Jpa method to check whether to check file name is exist or not
     * @param filename
     * @return
     */
    Boolean existsByFilename(String filename);

    /**
     * jpa method to retrieve records with the given filename and organization
     * @param filename
     * @param organization
     * @return OrgPolicy object
     */
    OrgPolicy findByFilenameAndOrganization(String filename, Organization organization);

    /**
     * jpa method to retrieve records with the given organization and status
     * @param organization
     * @param status
     * @return List<OrgPolicy> ; list of OrgPolicy objects
     */
    List<OrgPolicy> findByOrganizationAndPolicyStatus(Organization organization, String status);

    /**
     * jpa method to fetch record using id from org_policy
     * @param id
     * @return
     */
    OrgPolicy findById(int id);



}
