package com.compliance.soc.socly.alert.repository;

import com.compliance.soc.socly.alert.entity.OrgSaas;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import com.compliance.soc.socly.saas.exception.SaasException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgSaasRepository extends JpaRepository<OrgSaas, Integer> {
    OrgSaas findByOrganizationAndSaasMaster(Organization organization, SaasMaster saasMaster) throws SaasException;
}
