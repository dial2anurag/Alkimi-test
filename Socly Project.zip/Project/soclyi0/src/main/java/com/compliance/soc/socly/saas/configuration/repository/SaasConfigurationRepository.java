package com.compliance.soc.socly.saas.configuration.repository;

import com.compliance.soc.socly.saas.configuration.entity.SaasConfigId;
import com.compliance.soc.socly.saas.configuration.entity.SaasConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SaasConfigurationRepository extends JpaRepository<SaasConfiguration, SaasConfigId> {

    SaasConfiguration findBySaasIdIgnoreCaseAndOrgIdAndFrameworkIdAndNameIgnoreCase(String saasId, Long orgId, Integer frameworkId, String name);
    List<SaasConfiguration> findBySaasIdIgnoreCaseAndOrgIdAndFrameworkId(String saasId, Long orgId, Integer frameworkId);
    List<SaasConfiguration> findBySaasIdIgnoreCaseAndOrgId(String saasId, Long orgId);

}
