package com.compliance.soc.socly.amazons3.dto;

public class ComplianceApprovalExceptionResponse {

	private String errorMsg;
	private String statuscode;
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public ComplianceApprovalExceptionResponse(String errorMsg, String statuscode) {
		super();
		this.errorMsg = errorMsg;
		this.statuscode = statuscode;
	}
	
	
	
}
