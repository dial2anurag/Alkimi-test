package com.compliance.soc.socly.cloudservice.service.impl;

import com.compliance.soc.socly.cloudservice.dto.CloudServiceDto;
import com.compliance.soc.socly.cloudservice.dto.ServiceProviderDto;
import com.compliance.soc.socly.cloudservice.entity.CloudService;
import com.compliance.soc.socly.cloudservice.entity.ServiceProvider;
import com.compliance.soc.socly.cloudservice.repository.ServiceRepository;
import com.compliance.soc.socly.cloudservice.service.ServiceManager;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@org.springframework.stereotype.Service
public class ServiceManagerImpl implements ServiceManager {

    @Autowired
    private ServiceRepository serviceRepository;

    /**
     * get all the cloud services
     * @return cloud services
     */
    @Override
    public List<CloudServiceDto> getAllServices() {
        return serviceRepository.findAllByActive("Y")
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     *
     * @param cloudService
     * @return clodServiceDto
     */

    private CloudServiceDto toDto(CloudService cloudService) {
        CloudServiceDto cloudServiceDto = new CloudServiceDto();
        cloudServiceDto.setId(cloudService.getId());
        cloudServiceDto.setName(cloudService.getName());
        cloudServiceDto.setProviders(toDto(cloudService.getProviders().stream().filter(sp -> sp.getActive().equals("Y")).collect(Collectors.toList())));
        return cloudServiceDto;
    }

    /**
     *
     * @param serviceProviders
     * @return service providers Dto
     */


    private List<ServiceProviderDto> toDto(List<ServiceProvider> serviceProviders) {
        return serviceProviders
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * seting new service provider
     * @param serviceProvider
     */

    private ServiceProviderDto toDto(ServiceProvider serviceProvider) {
        ServiceProviderDto serviceProviderDto = new ServiceProviderDto();
        serviceProviderDto.setId(serviceProvider.getId());
        serviceProviderDto.setName(serviceProvider.getName());
        return serviceProviderDto;
    }
}
