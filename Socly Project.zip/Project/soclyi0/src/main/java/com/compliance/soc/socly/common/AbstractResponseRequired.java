package com.compliance.soc.socly.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class AbstractResponseRequired {

    String principle;
    String module;
    String complianceCheck;
    Integer total;
    Integer acceptedComplianceScore ;
    Integer rejectedComplianceScore;
    Double percentComplianceScore;
    String recommended_remediation;
    List<EntityCompliance> entityCompliance;

}
