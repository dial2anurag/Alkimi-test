package com.compliance.soc.socly.enums;

/**
 * it is a enum class for evidence file type systemGenerated and manual type.
 */
public enum EvidenceFileType {
    SG,
    M,
}
