package com.compliance.soc.socly.cloud.aws.exception;

/**
 * Cloud Integration exception
 */
public class CloudIntegrationException extends Exception {
    public CloudIntegrationException(final Exception ex) {
        super(ex);
    }

    public CloudIntegrationException(final String errorMsg) {
        super(errorMsg);
    }
}
