package com.compliance.soc.socly.amazons3.exception;

import com.compliance.soc.socly.amazons3.dto.FileExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class FileExceptionAdvisor extends ResponseEntityExceptionHandler {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<FileExceptionResponse> handleMaxSizeException(MaxUploadSizeExceededException exc) {
        String message = "One or more files exceed maximum allowed size.";
        return ResponseEntity
                .status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body(new FileExceptionResponse(message));
    }

    @ExceptionHandler(FileTypeNotAllowedException.class)
    public ResponseEntity<FileExceptionResponse> handleFileTypeNotAllowedException(FileTypeNotAllowedException exc) {
        return ResponseEntity
                .status(HttpStatus.EXPECTATION_FAILED)
                .body(new FileExceptionResponse(exc.getMessage()));
    }

    @ExceptionHandler(FileNotFoundException.class)
    public ResponseEntity<FileExceptionResponse> handleFileNotFoundException(FileNotFoundException exc) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new FileExceptionResponse(exc.getMessage()));
    }

    @ExceptionHandler(ActiveAuditNotFoundException.class)
    public ResponseEntity<FileExceptionResponse> handleActiveAuditNotFoundException(ActiveAuditNotFoundException exc) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new FileExceptionResponse(exc.getMessage()));
    }

    @ExceptionHandler(S3BucketException.class)
    public ResponseEntity<FileExceptionResponse> handleS3BucketException(S3BucketException exc) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new FileExceptionResponse(exc.getMessage()));
    }
}
