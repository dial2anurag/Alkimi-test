package com.compliance.soc.socly.auth.model;

import lombok.Getter;

@Getter
public class PasswordDto {
    private String oldPassword;
    private String newPassword;
}
