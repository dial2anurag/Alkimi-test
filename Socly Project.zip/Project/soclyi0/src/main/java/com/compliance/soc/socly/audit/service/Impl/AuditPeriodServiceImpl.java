package com.compliance.soc.socly.audit.service.Impl;

import com.compliance.soc.socly.audit.Exceptions.AuditPeriodException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.repository.AuditPeriodRepository;
import com.compliance.soc.socly.audit.service.AuditPeriodService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.Role;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.entity.UserRole;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.auth.service.RoleService;
import com.compliance.soc.socly.auth.service.UserRoleService;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.organization.entity.Framework;
import com.compliance.soc.socly.organization.service.FrameworkService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AuditPeriodServiceImpl implements AuditPeriodService {

    @Autowired
    private AuditPeriodRepository auditPeriodRepository;

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserRoleService userRoleService;

    @Autowired
    private FrameworkService frameworkService;

    @Autowired
    private OrgMasterService orgMasterService;

    @Autowired
    private MappingService mappingService;


    /**
     * method to retrieve all data from audit_period table
     *
     * @return audit period data
     */
    @Override
    public List<AuditPeriodDto> getAudit(long orgId, String status) throws AuditPeriodException {
        try {
            final Organization organization = new Organization();
            organization.setId(orgId);
            List<AuditPeriod> auditPeriodList = null;
            if(status == null){
                status = "O";
            }
            auditPeriodList = auditPeriodRepository.findByOrganizationAndStatus(organization, status);
            if(auditPeriodList.isEmpty()){
                throw new AuditPeriodException("No records found for given orgId : "+ orgId+" and status : "+status);
            }
            List<AuditPeriodDto> auditPeriodDtoList = new ArrayList<>();
            for (AuditPeriod auditPeriod : auditPeriodList) {
                AuditPeriodDto auditPeriodDto = mappingService.populateAuditPeriodDto(auditPeriod);
                auditPeriodDtoList.add(auditPeriodDto);
            }
            return auditPeriodDtoList;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            throw new AuditPeriodException(e.getMessage());
        }
    }

    /**
     * method to save data in audit_period table
     *
     * @param audit
     * @param user
     * @return
     * @throws AuditPeriodException
     */
    @Override
    public AuditPeriodDto save(@Valid AuditPeriodDto audit, User user) throws AuditPeriodException {
        try {
            final Framework framework = new Framework();
            framework.setId(audit.getFramework().getId());
            final Organization organization = orgMasterService.findById(audit.getOrgId());
            final AuditPeriod auditPeriod = auditPeriodRepository.findOneByOrganizationAndStatusAndFramework(organization, "O", framework);
            if (auditPeriod == null) {
                AuditPeriod period = new AuditPeriod();
                period.setAuditId(audit.getAuditId());
                period.setStatus(audit.getStatus());
                period.setPeriod(audit.getPeriod());
                period.setOrganization(organization);
                period.setStartDate(audit.getStartDate());
                period.setEndDate(audit.getEndDate());
                period.setCreatedBy(user.getId());
                period.setAuditInitiateDate(audit.getAuditInitiateDate());
                period.setFramework(frameworkService.findById(audit.getFramework().getId()).get());
                period = auditPeriodRepository.save(period);
                return mappingService.populateAuditPeriodDto(period);
            }
            throw new AuditPeriodException("Audit period already exits for this client");
        } catch (final Exception exception) {
            log.error("Audit period already exits for this client");
            throw new AuditPeriodException(exception);
        }
    }

    /**
     * update method is used to update values of given param clientId and status and it also take values
     * from the user token and auto generation date.
     *
     * @param audit
     * @param user
     * @return
     * @throws AuditPeriodException
     */
    @Override
    public AuditPeriodDto update(@Valid AuditPeriodDto audit, User user) throws AuditPeriodException {
        try {
            AuditPeriod auditPeriod = auditPeriodRepository.findByAuditId(audit.getAuditId());
            Organization organization = orgMasterService.findById(audit.getOrgId());
            if (auditPeriod != null) {
                auditPeriod.setStatus(audit.getStatus());
                auditPeriod.setOrganization(organization);
                auditPeriod.setPeriod(audit.getPeriod());
                auditPeriod.setStartDate(audit.getStartDate());
                auditPeriod.setEndDate(audit.getEndDate());
                auditPeriod.setModifiedBy(user.getId());
                auditPeriod.setEndedBy(user.getId());
                auditPeriod.setAuditInitiateDate(audit.getAuditInitiateDate());
                if (audit.getFramework() != null) {
                    auditPeriod.setFramework(frameworkService.findById(audit.getFramework().getId()).get());
                }
                auditPeriod = auditPeriodRepository.save(auditPeriod);
                return mappingService.populateAuditPeriodDto(auditPeriod);
            }
            throw new AuditPeriodException("Audit period doesn't exist for this client");
        } catch (final Exception exception) {
            log.error("Audit period doesn't exist for this client");
            throw new AuditPeriodException(exception);
        }
    }

    /**
     * method to find if some user has AUDITOR role or not
     *
     * @param userId of user
     * @return true/false
     * @throws AuditPeriodException
     */
    @Override
    public boolean isAuditor(long userId) throws AuditPeriodException {
        try {
            boolean flag = true;
            Role role = roleService.findByName("AUDITOR");
            long auditorId = role.getId();
            UserRole userAuditorRole = userRoleService.findByUserIdAndRoleId(userId, auditorId);
            if (userAuditorRole == null) {
                flag = false;
            }
            return flag;
        } catch (final Exception ex) {
            log.error("Exception occured while getting the user role.");
            throw new AuditPeriodException(ex);
        }
    }

    /**
     * this method is for find AuditPeriod records by Organization and status
     *
     * @param organization
     * @param status
     * @return
     * @throws AuditPeriodException
     */
    @Override
    public List<AuditPeriod> findByOrganizationAndStatus(Organization organization, String status) throws AuditPeriodException {
        try {
            List<AuditPeriod> auditPeriod = auditPeriodRepository.findByOrganizationAndStatus(organization, status);
            return auditPeriod;
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new AuditPeriodException(exception.getMessage());
        }
    }

    /**
     * method to find the Active audit with framework
     *
     * @param status
     * @param frameworkId
     * @return
     */
    @Override
    public List<AuditPeriod> findByStatusAndFrameworkId(String status, Integer frameworkId) throws AuditPeriodException {
        try {
            List<AuditPeriod> auditPeriod = auditPeriodRepository.findByStatusAndFrameworkId(status, frameworkId);
            return auditPeriod;
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new AuditPeriodException(exception.getMessage());
        }
    }

}
