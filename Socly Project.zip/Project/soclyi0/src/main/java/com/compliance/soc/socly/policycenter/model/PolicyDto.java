package com.compliance.soc.socly.policycenter.model;

import lombok.Builder;
import lombok.Getter;
/**
 *It is a model class for an policyObject.
 */
@Builder
@Getter
public class PolicyDto {
    String name;
    String id;
}
