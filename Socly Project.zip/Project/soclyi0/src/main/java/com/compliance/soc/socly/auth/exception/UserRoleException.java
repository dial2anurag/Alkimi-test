package com.compliance.soc.socly.auth.exception;

/**
 * it is a exception class to handle the UserRoleException.
 */
public class UserRoleException extends Exception{
    public UserRoleException(final Exception ex) {
        super(ex);
    }
    public UserRoleException(final String errorMsg) {
        super(errorMsg);
    }
}