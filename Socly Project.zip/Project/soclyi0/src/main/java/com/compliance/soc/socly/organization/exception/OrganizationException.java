package com.compliance.soc.socly.organization.exception;

public class OrganizationException extends Exception {
    public OrganizationException(final Exception ex) {

        super(ex);

    }


    public OrganizationException(final String errorMsg) {

        super(errorMsg);

    }
}
