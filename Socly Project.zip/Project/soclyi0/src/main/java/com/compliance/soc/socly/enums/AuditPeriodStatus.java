package com.compliance.soc.socly.enums;

public enum AuditPeriodStatus {
    O,
    I,
    C;
}
