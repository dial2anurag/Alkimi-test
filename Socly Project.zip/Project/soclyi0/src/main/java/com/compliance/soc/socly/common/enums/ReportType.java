package com.compliance.soc.socly.common.enums;

/**
 * enumerations for saas providers.
 */
public enum ReportType {
    TYPE1, TYPE2;
}