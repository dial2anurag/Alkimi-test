package com.compliance.soc.socly.cloud.aws.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.BucketPolicy;
import com.amazonaws.services.s3.model.GetBucketEncryptionResult;
import com.amazonaws.services.s3.model.ServerSideEncryptionByDefault;
import com.amazonaws.services.s3.model.ServerSideEncryptionConfiguration;
import com.amazonaws.services.s3.model.ServerSideEncryptionRule;
import com.compliance.soc.socly.cloud.aws.model.EncryptionStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Slf4j
@Service
public class EncryptionService {
	/**
	 * To get the clientside and server side encryption in S3 bucket.
	 * @param accessKey
	 * @param secretKey
	 * @param defaultRegion
	 * @return
	 */
	public List<EncryptionStatusResponse> bucketEncryption(String accessKey, String secretKey, String defaultRegion) {
		List<EncryptionStatusResponse> responseList = new ArrayList();
		AmazonS3 s3 = null;
List<String> encryptionList = new ArrayList<String>();
List<String> transferEncryptionList = new ArrayList<>();
		BasicAWSCredentials aswCreds = new BasicAWSCredentials(accessKey, secretKey);
		s3 = AmazonS3ClientBuilder.standard().withRegion(defaultRegion).withCredentials(new AWSStaticCredentialsProvider(aswCreds)).build();

		List<Bucket> bucketList = s3.listBuckets(); // can be called from any region		// imp 
		log.info("Number of Buckets:  {}", bucketList.size());
		for (Bucket bucket : bucketList) {
			String bucketRegion = s3.getBucketLocation(bucket.getName());
			
			String s3Region = s3.getRegionName();
	//		System.out.println("Default "+defaultRegion +" BucketRegion "+bucketRegion+" s3Region "+s3Region);
			if (!s3Region.equalsIgnoreCase(bucketRegion)) {
				s3 = AmazonS3ClientBuilder.standard().withRegion(bucketRegion).withCredentials(new AWSStaticCredentialsProvider(aswCreds)).build();
	//			System.out.println("Inside If Block "+bucketRegion);
			}
			GetBucketEncryptionResult bucketEncryption=null;
			BucketPolicy bucketPolicy = null;
			try {
			    bucketPolicy = s3.getBucketPolicy(bucket.getName());
			    String bucketPolicyText = bucketPolicy.getPolicyText();
			    if(null!= bucketPolicyText && bucketPolicyText.contains("\"aws:SecureTransport\":\"false\"")){
			    	log.info("For "+bucket.getName()+" Only HTTPS allowed");
			    	transferEncryptionList.add("Only HTTPS allowed");
			    }
			    else {
			    	log.info("For "+bucket.getName()+" HTTP allowed too");
			    	transferEncryptionList.add("HTTP allowed too");
			    }
			    bucketEncryption = s3.getBucketEncryption(bucket.getName());
			    ServerSideEncryptionConfiguration serverSideEncryption = bucketEncryption.getServerSideEncryptionConfiguration();
				List<ServerSideEncryptionRule> list = serverSideEncryption.getRules();
				ServerSideEncryptionRule encryptionRule = list.get(0);
				ServerSideEncryptionByDefault serverEncryption = encryptionRule.getApplyServerSideEncryptionByDefault();
				String s = serverEncryption.getSSEAlgorithm();
				encryptionList.add(s);
			}
			catch (AmazonS3Exception e){
	//			System.out.println("AmazonS3Exception "+e.getErrorCode());
				log.info(e.getLocalizedMessage());
				encryptionList.add("No Encryption");
			}
			catch (Exception e){
				log.error("Exception "+e);
				encryptionList.add("No Encryption");
			}
			
		}
		int encryptionPassed = (int)encryptionList.stream().filter(a -> !a.equalsIgnoreCase("No Encryption")).count();
		EncryptionStatusResponse statusResponse = new EncryptionStatusResponse();
		statusResponse.setComplianceCheck("Encryption At Rest");
		statusResponse.setCompliancePoint(encryptionList.size());
		statusResponse.setAcceptedComplianceScore(encryptionPassed);
		statusResponse.setPercentComplianceScore((encryptionPassed * 100.0)/encryptionList.size());
		statusResponse.setRejectedComplianceScore(encryptionList.size() - encryptionPassed);
		responseList.add(statusResponse);
		
		int transferEncryptionPassed = (int)transferEncryptionList.stream().filter(a -> a.equalsIgnoreCase("Only HTTPS allowed")).count();
		EncryptionStatusResponse transferStatusResponse = new EncryptionStatusResponse();
		transferStatusResponse.setComplianceCheck("Encryption At Transfer");
		transferStatusResponse.setCompliancePoint(transferEncryptionList.size());
		transferStatusResponse.setAcceptedComplianceScore(transferEncryptionPassed);
		transferStatusResponse.setPercentComplianceScore((transferEncryptionPassed * 100.0)/transferEncryptionList.size());
		transferStatusResponse.setRejectedComplianceScore(transferEncryptionList.size() - transferEncryptionPassed);
		responseList.add(transferStatusResponse);
		
		
		return responseList;

	}
}
