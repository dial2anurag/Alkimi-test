package com.compliance.soc.socly.auth.service.impl;

import com.compliance.soc.socly.auth.entity.Role;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.RoleException;
import com.compliance.soc.socly.auth.model.RoleDto;
import com.compliance.soc.socly.auth.model.UserDto;
import com.compliance.soc.socly.auth.repository.RoleRepository;
import com.compliance.soc.socly.auth.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service(value = "roleService")
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    /**
     *
     * @param name
     * @return roles
     */
    @Override
    public Role findByName(String name) {
        Role role = roleRepository.findRoleByName(name);
        return role;
    }

    /**
     * To fetch the active roles by the orgView.
     * @param orgView
     * @return  roles
     */

    @Override
    public List<RoleDto> findAllByOrgView(Boolean orgView) throws RoleException {
        List<Role> roles;
        if(orgView!=null)
            roles= roleRepository.findAllByOrgView(orgView);
        else
            roles= roleRepository.findAll();
        roles.removeIf(role -> (role.getSuperAdmin()!=null &&role.getSuperAdmin())
                ||(role.getStatus()!=null && !role.getStatus().equalsIgnoreCase("Active"))
                    );
        List<RoleDto> roleListDtos=new ArrayList<>(roles.size());
        for (Role role:roles
             ) {
            roleListDtos.add(getFromRole(role));
        }
        return roleListDtos;
    }

    /**
     * It is a response method for fetching the roles.
     * @param role
     * @return
     */
    private RoleDto getFromRole(Role role)throws RoleException {
        RoleDto roleListDto=new RoleDto();
        roleListDto.setId(role.getId());
        roleListDto.setDescription(role.getDescription());
        roleListDto.setName(role.getName());
        roleListDto.setOrgView(role.getOrgView());
        roleListDto.setStatus(role.getStatus());
        roleListDto.setSuperAdmin(role.getSuperAdmin());
        List<UserDto> userDtos=new ArrayList<>();
        role.getUsers().forEach(user -> userDtos.add(fromUser(user)));
        roleListDto.setUsers(userDtos);
        return roleListDto;
    }

    /**
     * it is a method for response to fetch the list of roles.to get the uses list
     * @param user
     * @return
     */
    private UserDto fromUser(User user){
        UserDto userDto=new UserDto();
        userDto.setName(user.getName());
        userDto.setEmail(user.getEmail());
        userDto.setBusinessTitle(user.getBusinessTitle());
        userDto.setOrganizationName(user.getOrganizationName());
        userDto.setPhone(user.getPhone());
        userDto.setUsername(user.getUsername());
        return userDto;
    }
}
