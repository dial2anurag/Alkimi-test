package com.compliance.soc.socly.audit.entity;

import com.compliance.soc.socly.audit.model.ComplianceApprovalID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;


/**
 * ComplianceApproval is an entity class and properties from the ComplianceApproval table
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "compliance_approval")
@IdClass(ComplianceApprovalID.class)
public class ComplianceApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * the status which shows auditStatus
     */
    @Column(name = "status")
    private char status;
    /**
     * the complianceId which is reference of Metrics(complianceId)
     */
    @Id
    @Column(name = "compliance_id")
    private String complianceId;
    /**
     * the clientId  is an organization id and which is taken from user
     */
    @Id
    @Column(name = "client_id")
    private long clientId;
    /**
     * the principleId which is reference of MetricsMaster(metricsId)
     */
    @Id
    @Column(name = "principle_id")
    private Integer principleId;
    /**
     * the createdDate shows on which date it is created
     */
    @Column(name = "created_date")
    private Date createdDate = new Date();
    /**
     * the modifiedDate shows on which date it is modified
     */
    @Column(name = "modified_date")
    private Date modifiedDate;
    /**
     * the createdBy shows from which user it is being created
     */
    @Column(name = "created_by")
    private Long createdBy;
    /**
     * the modifiedBy shows from which user it is being modified
     */
    @Column(name = "modified_by")
    private Long modifiedBy;
    /**
     * the auditId shows the id of an audit
     */
    @Column(name = "audit_id", insertable = false, updatable = false)
    private Integer auditId;
    /**
     * the auditNote is to write audit comment while approving Compliance
     */
    @Column(name = "audit_note", columnDefinition = "Text")
    private String auditNote;
    /**
     * In this mapping is done through AuditPeriod and ComplianceApproval with reference of auditId
     */
    @ManyToOne(targetEntity = AuditPeriod.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "audit_id", referencedColumnName = "id")
    private AuditPeriod period;


}
