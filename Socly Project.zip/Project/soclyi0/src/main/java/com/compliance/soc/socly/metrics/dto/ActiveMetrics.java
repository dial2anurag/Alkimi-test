package com.compliance.soc.socly.metrics.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ActiveMetrics {
    private String complianceId;
    private String controlName;
    private String description;

    private Integer metricsId ;
    private String principle ;
    private String title;
    private String flag;
    private String status;
    private Integer principleId;
    private BigInteger clientId;
    private Character auditStatus ;
    private Integer auditId;
}
