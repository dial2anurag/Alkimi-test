package com.compliance.soc.socly.enums;

public enum FileApprovalStatus {
    A,
    R,
    N;
}
