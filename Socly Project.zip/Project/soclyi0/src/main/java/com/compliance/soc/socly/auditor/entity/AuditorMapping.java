package com.compliance.soc.socly.auditor.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * AuditorMapping is an entity class and properties from the auditor_mapping table
 */
@Entity
@Getter
@Setter
@Table(name = "auditor_mapping")
public class AuditorMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @OneToOne(targetEntity = Auditor.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "auditor_id", referencedColumnName = "id")
    private Auditor auditor;

    @OneToOne(targetEntity = Organization.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private Organization organization;

    @OneToOne(targetEntity = Framework.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "framework_id", referencedColumnName = "id")
    private Framework framework;

}
