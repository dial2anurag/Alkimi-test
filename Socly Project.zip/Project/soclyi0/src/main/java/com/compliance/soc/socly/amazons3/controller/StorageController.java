package com.compliance.soc.socly.amazons3.controller;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.compliance.soc.socly.amazons3.dto.FileListResponse;
import com.compliance.soc.socly.amazons3.dto.FileUploadResponse;
import com.compliance.soc.socly.amazons3.service.StorageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/file")
public class StorageController {

    @Autowired
    private StorageService service;

    /**
     * API to upload multiple files (pdf, jpeg, png) into "compliance_pdf" folder  of corresponding
     * logged-in user's organization in AWS s3 bucket.
     *
     * @param source
     * @param complianceId
     * @param multipartFiles
     * @return FileUploadResponse (containing filename, filesize, type of file) OR Exception in case of
     * wrong format
     */
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam String source, @RequestParam String complianceId, @RequestParam(value = "files") MultipartFile[] multipartFiles) {
        try {
            List<FileUploadResponse> fileUploadResponses = service.uploadFile(source, complianceId, multipartFiles);
            if (fileUploadResponses == null || fileUploadResponses.size() == 0) {
                log.info("No files uploaded.");
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                        .body("No files uploaded.");
            }
            log.info("Files uploaded are :");
            for (FileUploadResponse file : fileUploadResponses) {
                log.info(file.getFilename());
            }
            return ResponseEntity.status(HttpStatus.OK)
                    .body(fileUploadResponses);
        } catch (final AmazonServiceException e) {
            log.error("Amazon service exception occurred while while uploading file." +
                    " Request was successfully sent to the AWS service but couldn't be successfully processed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        } catch (final AmazonClientException e) {
            log.error("Amazon client exception occurred while uploading file. No service calls made to AWS services.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }

    /**
     * API to download file from "compliance_pdf" folder  of corresponding
     * logged-in user's organization in AWS s3 bucket.
     *
     * @param filename
     * @return ByteArray (file content)
     */
    @GetMapping("/{framework}/download")
    public ResponseEntity<?> downloadFile(@RequestParam String filename, @PathVariable String framework) {
        try {
            byte[] data = service.downloadFile(filename, framework);
            ByteArrayResource resource = new ByteArrayResource(data);
            return ResponseEntity
                    .ok()
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", "attachment; filename=\"" + filename + "\"")
                    .body(resource);
        } catch (final AmazonServiceException e) {
            log.error("Amazon service exception occurred while while downloading file." +
                    " Request was successfully sent to the AWS service but couldn't be successfully processed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        } catch (final AmazonClientException e) {
            log.error("Amazon client exception occurred while downloading file. No service calls made to AWS services.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        } catch (final Exception e) {
            log.error("Exception occurred while downloading file. No service calls made to AWS services.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }

    /**
     * API to fetch list of latest files based on complianceId from "compliance_pdf" folder of corresponding
     * logged-in user's organization in AWS s3 bucket. The files are fetched based on modified date
     * and audit initiate date.
     *
     * @param complianceId
     * @param principleId
     * @return FileListResponse (containing filename, complianceId, principleId, clientId, auditId, auditStatus)
     */
    @GetMapping("/list")
    public ResponseEntity<?> getListOfFiles(@RequestParam String complianceId, @RequestParam int principleId) {
        try {
            List<FileListResponse> fileListResponses = service.listFiles(complianceId, principleId);
            if (fileListResponses == null || fileListResponses.size() == 0) {
                log.info("No files found with complianceId : {}", complianceId);
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
                        .body("No files found.");
            } else {
                log.info("Files requested for :");
                for (FileListResponse file : fileListResponses) {
                    log.info(file.getFileName());
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(fileListResponses);
        } catch (final AmazonServiceException e) {
            log.error("Amazon service exception occurred while while uploading file." +
                    " Request was successfully sent to the AWS service but couldn't be successfully processed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        } catch (final AmazonClientException e) {
            log.error("Amazon client exception occurred while uploading file. No service calls made to AWS services.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }
}