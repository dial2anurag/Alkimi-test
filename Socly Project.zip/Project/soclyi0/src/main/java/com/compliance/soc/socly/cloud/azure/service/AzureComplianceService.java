package com.compliance.soc.socly.cloud.azure.service;

import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.cloud.azure.exception.AzureException;
import com.compliance.soc.socly.cloud.aws.exception.SecretNotFoundException;
import com.compliance.soc.socly.cloud.azure.exception.AzureServiceException;
import com.compliance.soc.socly.cloud.azure.integration.AzureComplianceApi;
import com.compliance.soc.socly.cloud.azure.model.AzureCredential;
import com.compliance.soc.socly.cloud.azure.model.AzureResponse;
import com.compliance.soc.socly.cloud.azure.model.AzureResponseMetadata;
import com.compliance.soc.socly.cloud.aws.service.ControlMapping;
import com.compliance.soc.socly.common.EntityCompliance;
import com.compliance.soc.socly.common.SaasProvider;
import com.compliance.soc.socly.common.Constant;
import com.compliance.soc.socly.common.AbstractResponse;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.enums.Environment;
import com.compliance.soc.socly.saas.configuration.entity.SaasConfiguration;
import com.compliance.soc.socly.saas.configuration.service.SaasConfigurationService;
import com.compliance.soc.socly.saas.exception.SaasException;
import com.compliance.soc.socly.util.PathUtil;
import com.compliance.soc.socly.util.SecretManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class AzureComplianceService {

    // Review : make this concurrent hash map or thread safe
    private final static Map<String, AzureResponseMetadata> azureComplianceDescriptionMap = new HashMap();
    private final static Map<String, String> complianceIDMap = new HashMap();
    @Autowired
    protected StorageService storageService;

    @Autowired
    private AzureComplianceApi azureComplianceApi;

    @Autowired
    private SecretManager secretManager;

    @Autowired
    private PathUtil pathUtil;

    @Autowired
    private SaasConfigurationService saasConfigurationService;

    /**
     * this method parse the response into EntityCompliance object nothing but final model to be sent and saved in PDF
     *
     * @param azureResponseList
     * @param azureResponseMetadataMap
     * @param framework
     */
    private List<EntityCompliance> populateEntityCompliance(List<AzureResponse> azureResponseList, Map<String, AzureResponseMetadata> azureResponseMetadataMap, String framework) throws AzureServiceException {
        List<EntityCompliance> entityComplianceList = new ArrayList<>();
        for (AzureResponse azureResponse : azureResponseList) {
            EntityCompliance entityCompliance = new EntityCompliance();
            try {
                AzureResponseMetadata azureResponseMetadata = azureResponseMetadataMap.get(azureResponse.getName());
                entityCompliance.setComplianceID(complianceIDMap.get(azureResponse.getName()));
                entityCompliance.setComplianceTitle(azureResponse.getProperties().getDisplayName());
                if (azureResponse.getProperties().getStatus().getCode().equalsIgnoreCase("Healthy")) {
                    entityCompliance.setComplianceStatus("PASSED");
                } else {
                    entityCompliance.setComplianceStatus("FAILED");
                }
                if (null != azureResponseMetadata) {
                    entityCompliance.setDescription(azureResponseMetadata.getProperties().getDescription());
                    entityCompliance.setRecommended_Remediation(azureResponseMetadata.getProperties().getRemediationDescription());
                }
                try {
                    entityCompliance.setEnvironment(deriveEnvironment(azureResponse.getName(), SaasProvider.AZURE.name(), framework, Constant.ARN));
                } catch (SaasException saasException) {
                    log.error("Unable to set environment " + saasException);
                }
                entityComplianceList.add(entityCompliance);
                log.info("azureResponse " + azureResponse);
                log.info("azureResponseMetadata " + azureResponseMetadata);
                log.info("entityCompliance " + entityCompliance);
            }
            catch (Exception exception){
                log.error("Error populating EntityCompliance"+entityCompliance +exception);
                throw new AzureServiceException("Error populating EntityCompliance- "+entityCompliance +exception);
            }
        }
        return entityComplianceList;
    }

    /**
     * this method is to get Azure secrets from AWS
     *
     * @param organizationName return AzureCredential
     */
    public AzureCredential getClientSecret(String organizationName) throws SecretNotFoundException {
        AzureCredential azureCredential = null;
        Object secretFromAws = secretManager.getSecretsFromAws("azure", organizationName);
        log.info("secretFromAws" + secretFromAws);
        if (secretFromAws instanceof AzureCredential) {
            azureCredential = (AzureCredential) secretFromAws;
            log.info("azureCredential fetched from secret manager" + azureCredential);
        } else {
            throw new SecretNotFoundException(secretFromAws.toString());
        }
        return azureCredential;
    }

    /**
     * this method is to get Azure access token
     *
     * @param azureCredential
     */
    public String getAccessToken(AzureCredential azureCredential) throws AzureException {
        return azureComplianceApi.azureToken(azureCredential);
    }

    /**
     * this method is to get Azure compliance as List<AzureResponse> and compliance metadata as Map<String, AzureResponseMetadata>
     * by making Azure api call and then finally mapping both response to get List<EntityCompliance>
     *
     * @param azureCredential
     * @param framework
     * return List<EntityCompliance>
     * throws AzureException
     */
    public List<EntityCompliance> fetchCompliance(AzureCredential azureCredential, String framework) throws AzureException, AzureServiceException {
        String accessToken=null;
        List<EntityCompliance> entityComplianceList = null;
        try {
            accessToken = getAccessToken(azureCredential);
        }
        catch (AzureException azureException) {
            log.error("Unable to get access token "+azureException);
            throw new AzureException(azureException);
        }
        try {
            if (null != accessToken) {
                List<AzureResponse> azureResponses = azureComplianceApi.getAzureCompliance(azureCredential.getSubscriptionId(), accessToken);
                log.info("Compliance response" + azureResponses);
                Map<String, AzureResponseMetadata> azureResponseMetadataMap = complianceMetadata(azureCredential);
                log.info("Compliance metadata" + azureResponseMetadataMap);
                if (complianceIDMap.size() == 0) {
                    prepareComplianceIDMap(azureResponseMetadataMap, framework);
                }
                entityComplianceList = populateEntityCompliance(azureResponses, azureResponseMetadataMap, framework);
            }
        }
        catch (Exception azureException) {
            log.error("Unable to get access token "+azureException);
            throw new AzureServiceException(azureException);
        }
        return entityComplianceList;
    }

    /**
     * this method does the complianceID mapping based on name of each compliance and stores in complianceIDMap
     * it is called only once and results are stored in Map
     *
     * @param azureResponseMetadataMap
     * @param framework
     */
    private static void prepareComplianceIDMap(Map<String, AzureResponseMetadata> azureResponseMetadataMap, String framework) {
        azureResponseMetadataMap.entrySet().stream().map(responseMetadataEntry -> complianceIDMap.put(responseMetadataEntry.getKey(),
        ControlMapping.displayNameToIdMapping(responseMetadataEntry.getValue().getProperties().getDisplayName().toLowerCase(), framework)));
    }

    /**
     * this method get compliance metadata for all the compliance
     *
     * @param azureCredential
     */
    private Map<String, AzureResponseMetadata> complianceMetadata(AzureCredential azureCredential) throws Exception {
        if (azureComplianceDescriptionMap.size() == 0) {
            String accessToken = getAccessToken(azureCredential);
            if (null != accessToken) {
                List<AzureResponseMetadata> azureResponseMetadataList = azureComplianceApi.getAzureComplianceMetadata(azureCredential.getSubscriptionId(), accessToken);
                azureMetaDataMapping(azureResponseMetadataList);
            }
        }
        return azureComplianceDescriptionMap;
    }

    /**
     * maps Iterate through each AzureResponseMetadata and put in map with respective names
     *
     * @param azureResponseMetadataList
     * @return void
     */
    private void azureMetaDataMapping(List<AzureResponseMetadata> azureResponseMetadataList) {
        for (AzureResponseMetadata azureResponseMetadata : azureResponseMetadataList) {
            azureComplianceDescriptionMap.put(azureResponseMetadata.getName(), azureResponseMetadata);
        }
    }

    /**
     * this method maps List<EntityCompliance> to ComplianceResponse which is finally sent to UI
     *
     * @param entityComplianceList
     * @return ComplianceResponse
     */
    public ComplianceResponse entityToComplianceResponse(List<EntityCompliance> entityComplianceList) {
        int totalComplianceCount = entityComplianceList.size();
        int compliancePassed = (int) entityComplianceList.stream().filter(compliance -> compliance.getComplianceStatus().equalsIgnoreCase("PASSED")).count();
        AbstractResponse abstractResponse = new AbstractResponse();
        abstractResponse.setModule("SecurityCenter | Microsoft Defender for Cloud");
        abstractResponse.setCompliancePoint(totalComplianceCount);
        abstractResponse.setEntityCompliance(entityComplianceList);
        abstractResponse.setAcceptedComplianceScore(compliancePassed);
        abstractResponse.setPercentComplianceScore((compliancePassed * 100.0) / totalComplianceCount);
        abstractResponse.setRejectedComplianceScore(totalComplianceCount - compliancePassed);

        ComplianceResponse complianceResponse = new ComplianceResponse();
        complianceResponse.setModule("Cloud_AZURE");
        complianceResponse.setTotalCompliancePoint(totalComplianceCount);
        complianceResponse.setTotalAcceptedComplianceScore(compliancePassed);
        complianceResponse.setPercentComplianceScore((compliancePassed * 100.0) / totalComplianceCount);
        complianceResponse.setTotalRejectedComplianceScore(totalComplianceCount - compliancePassed);
        complianceResponse.setAbstractResponse(Arrays.asList(abstractResponse));
        return complianceResponse;
    }

    /**
     * this method saves compliance responses into s3 folders
     *
     * @param clientId
     * @param complianceResponse
     * @param framework
     * @return ComplianceResponse
     */
    public void persistResponse(String clientId, ComplianceResponse complianceResponse, String framework) {
        final String keyName = pathUtil.getSaasProviderKeyName(clientId, SaasProvider.AZURE.name());
        final String folderName = pathUtil.getSaasProviderFolderPath(framework, SaasProvider.AZURE.name());
        DataUpload2FolderRequest dataUpload2FolderRequest = new DataUpload2FolderRequest();
        dataUpload2FolderRequest.setBucketName(clientId.toLowerCase());
        dataUpload2FolderRequest.setFolderName(folderName);
        dataUpload2FolderRequest.setData(complianceResponse);
        dataUpload2FolderRequest.setKey(keyName);
        storageService.uploadUnderFolder(dataUpload2FolderRequest);
        log.info("Azure PDF saved in folder " + folderName);
    }

    /**
     * this method derives environment based on comparision with provided PROD arns
     *
     * @param complianceArn
     * @param saasId
     * @param framework
     * @param arnName
     * @return Environment
     */
    public Environment deriveEnvironment(String complianceArn, String saasId, String framework, String arnName) throws SaasException {
        Environment environment = Environment.NON_PRODUCTION;
            SaasConfiguration saasConfiguration = saasConfigurationService.getConfiguration(saasId, framework, arnName);
            if (null != saasConfiguration) {
                String azureArn = saasConfiguration.getValue();
                String[] azureArns = azureArn.split(",");
                if (Arrays.stream(azureArns).anyMatch(dbArn -> dbArn.trim().equals(complianceArn)))
                    environment = Environment.PRODUCTION;
            }
        return environment;
    }
}
