package com.compliance.soc.socly.cloudservice.controller;

import com.compliance.soc.socly.cloudservice.dto.CloudServiceDto;
import com.compliance.soc.socly.cloudservice.service.ServiceManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/cloud")
public class ServiceController {

    @Autowired
    private ServiceManager serviceManager;

    /**
     * API method to fetch all the cloud services.
     * @return cloud services
     */
    @GetMapping
    public List<CloudServiceDto> getAllServices() {
        return this.serviceManager.getAllServices();
    }
}
