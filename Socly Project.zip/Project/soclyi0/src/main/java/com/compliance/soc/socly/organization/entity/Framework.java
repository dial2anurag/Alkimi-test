package com.compliance.soc.socly.organization.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.saas.configuration.entity.SaasConfiguration;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * Framework is an entity class and properties from the framework table
 */
@Entity
@Table(name = "framework")
@Setter
@Getter
public class Framework {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name", unique = true)
    private String name;

    @ManyToMany(mappedBy = "frameworks")
    @JsonIgnoreProperties("frameworks")
    private List<Organization> organizations;

    /**
     * one organization can have multiple saasConfiguration
     * hence, a list of SaasConfiguration objects : saasConfigurations
     */
    @OneToMany(targetEntity = SaasConfiguration.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "framework_id", referencedColumnName = "id")
    private List<SaasConfiguration> saasConfigurations;

}
