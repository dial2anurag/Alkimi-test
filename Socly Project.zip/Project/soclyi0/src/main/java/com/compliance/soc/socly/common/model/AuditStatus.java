package com.compliance.soc.socly.common.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * It is a Dto class for the Audit Status.
 */
public class AuditStatus {
    private int id;
}
