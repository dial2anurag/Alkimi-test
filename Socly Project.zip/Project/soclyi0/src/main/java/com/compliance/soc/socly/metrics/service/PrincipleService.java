package com.compliance.soc.socly.metrics.service;

import com.compliance.soc.socly.amazons3.dto.FileListResponse;
import com.compliance.soc.socly.amazons3.exception.ActiveAuditNotFoundException;
import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.entity.PrincipleApproval;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.PrincipleApprovalDto;
import com.compliance.soc.socly.audit.service.AuditPeriodService;
import com.compliance.soc.socly.audit.service.PrincipleApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.ComplianceFramework;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.enums.AuditPeriodStatus;
import com.compliance.soc.socly.metrics.dto.ActivePrincipleDto;
import com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse;
import com.compliance.soc.socly.metrics.dto.ComplianceDto;
import com.compliance.soc.socly.metrics.dto.ComplianceResponse;
import com.compliance.soc.socly.metrics.dto.PrincipleResponse;
import com.compliance.soc.socly.metrics.entity.Principle;
import com.compliance.soc.socly.metrics.exception.PrincipleException;
import com.compliance.soc.socly.metrics.repository.PrincipleRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.digester.ArrayStack;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Component
@Service
@Slf4j
public class PrincipleService {

    @Autowired
    private PrincipleRepository principleRepository;

    @Autowired
    private PrincipleApprovalService principleApprovalService;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private UserService userService;

    @Autowired
    private AuditPeriodService auditPeriodService;

    @Autowired
    private StorageService storageService;

    /**
     * API method to fetch list of active principles
     *
     * @param orgId
     * @return principles
     */
    public List<ActivePrinciplesResponse> getAllActivePrinciples(final long orgId) throws PrincipleException {
        try {
            return principleRepository.findActivePrinciples(orgId);
        } catch (Exception exception) {
            log.error("fetching list of active principles not found");
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * API method fetching list of ACtive principle by its type.
     *
     * @param type
     * @return principles
     */
    public List<PrincipleResponse> getAllActivePrinciplesByType(String type) throws PrincipleException {
        try {
            List<Principle> principleList = principleRepository.findByFlagAndStatus(type, "Active");
            List<PrincipleResponse> principleResponseList = new ArrayStack<>();
            for (Principle element : principleList) {
                PrincipleResponse principleResponse
                        = new PrincipleResponse(element.getMetricsId(), element.getPrinciple(),
                        element.getTitle(), element.getFlag(), element.getStatus());
                principleResponseList.add(principleResponse);
            }
            return principleResponseList;
        } catch (Exception exception) {
            log.error("fetching active principles by type is not found");
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * API method to get the compliance info from METRICS master table.
     *
     * @param principleId
     * @return compliances
     */
    public List<ComplianceResponse> getCompliancesByPrincipleId(int principleId) throws PrincipleException {
        try {
            final long orgId = userService.getCurrentUser().getOrganization().getId();
            return principleRepository.getCompliancesOnPrincipleAndOrganization(principleId, orgId);
        } catch (final Exception exception) {
            log.error("compliance info from principle is not found");
            throw new PrincipleException(exception.getMessage());
        }
    }


    /**
     * Method to get the compliance info, with attached evidences
     *
     * @param principleId (it is an id for principle)
     * @return compliances (list of compliances )
     * @throws PrincipleException,ActiveAuditNotFoundException
     */
    public List<ComplianceDto> getCompliancesAndFilesByPrincipleId(int principleId) throws PrincipleException, ActiveAuditNotFoundException {
        try {
            List<ComplianceResponse> complianceResponses;
            final List<ComplianceDto> complianceDtos = new ArrayList<>();
            final long orgId = userService.getCurrentUser().getOrganization().getId();
            complianceResponses = principleRepository.getCompliancesOnPrincipleAndOrganization(principleId, orgId);
            complianceResponses.forEach(n -> {
                final ComplianceDto complianceDto = populateComplianceDto(n);
                final List<FileListResponse> fileListResponses = storageService.listFiles(n.getComplianceId(), principleId);
                complianceDto.setFileListResponses(fileListResponses);
                complianceDtos.add(complianceDto);
            });
            return complianceDtos;
        } catch (final ActiveAuditNotFoundException ae) {
            log.error("Getting compliance's info for principle {} has failed ", principleId);
            throw new ActiveAuditNotFoundException(ae.getMessage());
        } catch (final Exception exception) {
            log.error("Getting compliance's info for principle {} has failed ", principleId);
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * Method used to transfer the ComplianceResponse data > ComplianceDto
     *
     * @param complianceResponse
     * @return
     */
    private ComplianceDto populateComplianceDto(final ComplianceResponse complianceResponse) {
        final ComplianceDto complianceDto = new ComplianceDto();
        complianceDto.setComplianceId(complianceResponse.getComplianceId());
        complianceDto.setControlName(complianceResponse.getControlName());
        complianceDto.setDescription(complianceResponse.getDescription());
        complianceDto.setTestProcedures(complianceResponse.getTestProcedures());
        complianceDto.setSampleFiles(complianceResponse.getSampleFiles());
        complianceDto.setStatus(complianceResponse.getStatus());
        complianceDto.setUploadType(complianceResponse.getUploadType());
        complianceDto.setAuditId(complianceResponse.getAuditId());
        complianceDto.setAuditStatus(complianceResponse.getAuditStatus());
        complianceDto.setOrgId(complianceResponse.getOrgId());
        complianceDto.setPrincipleId(complianceResponse.getPrincipleId());
        complianceDto.setAuditNote(complianceResponse.getAuditNote());
        return complianceDto;
    }

    /**
     * Method to get the all active principles based on complianceId from metrics master table
     *
     * @param complianceId
     * @return all active principles
     */
    public List<ActivePrinciplesResponse> getPrinciplesByCompianceId(String complianceId) throws PrincipleException {
        try {
            return principleRepository.getPrinciplesByCompianceId(userService.getCurrentUser().getOrganization().getId(), complianceId);
        } catch (Exception exception) {
            log.error("Get active principle and compliance from metrics not found");
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * In this method to fetch all principles by framework name like ex: iso/soc2
     *
     * @param framework
     * @return
     */
    public List<ActivePrincipleDto> getAllActivePrinciplesByFramework(String framework) throws PrincipleException {
        try {
            List<ActivePrincipleDto> principleResponseList = new ArrayList<>();
            User user = userService.getCurrentUser();
            if (framework.equalsIgnoreCase(ComplianceFramework.ISO.toString())) {
                List<Principle> list = principleRepository.findByFlagIgnoreCaseIn(new String[]{framework});
                for (Principle element : list) {
                    List<PrincipleApproval> principleApproval = principleApprovalService.findByPrincipleId(element.getMetricsId());
                    PrincipleApprovalDto principleApprovalDto = new PrincipleApprovalDto();
                    ActivePrincipleDto activePrincipleDto = new ActivePrincipleDto();
                    activePrincipleDto.setPrinciple(element.getPrinciple());
                    activePrincipleDto.setFlag(element.getFlag());
                    activePrincipleDto.setTitle(element.getTitle());
                    activePrincipleDto.setId(element.getMetricsId());
                    activePrincipleDto.setStatus(element.getStatus());
                    for (PrincipleApproval principle : principleApproval) {
                        principleApprovalDto.setPrincipleId(principle.getPrincipleId());
                        principleApprovalDto.setStatus(principle.getStatus());
                        principleApprovalDto.setModifiedBy(principle.getModifiedBy());
                        principleApprovalDto.setId(principle.getId());
                        principleApprovalDto.setCreatedBy(principle.getCreatedBy());
                        principleApprovalDto.setAuditNote(principle.getAuditNote());
                        principleApprovalDto.setCreatedDate(principle.getCreatedDate());
                        principleApprovalDto.setModifiedDate(principle.getModifiedDate());
                        principleApprovalDto.setOrganizationDto(mappingService.getOrgDtoFromEntity(user.getOrganization()));
                        List<AuditPeriod> auditPeriods = auditPeriodService.findByStatusAndFrameworkId(AuditPeriodStatus.O.toString(), 1);
                        for (AuditPeriod auditperiod : auditPeriods) {
                            if (principle.getAuditPeriod().getAuditId() == auditperiod.getAuditId()) {
                                AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
                                auditPeriodDto.setAuditId(auditperiod.getAuditId());
                                auditPeriodDto.setPeriod(auditperiod.getPeriod());
                                auditPeriodDto.setStatus(auditperiod.getStatus());
                                auditPeriodDto.setAuditInitiateDate(auditperiod.getAuditInitiateDate());
                                auditPeriodDto.setStartDate(auditperiod.getStartDate());
                                auditPeriodDto.setEndDate(auditperiod.getEndDate());
                                auditPeriodDto.setCreatedBy(auditperiod.getCreatedBy());
                                auditPeriodDto.setModifiedBy(auditperiod.getModifiedBy());
                                auditPeriodDto.setOrgId(auditperiod.getOrganization().getId());
                                auditPeriodDto.setEndedBy(auditperiod.getEndedBy());
                                principleApprovalDto.setAuditPeriod(auditPeriodDto);
                                activePrincipleDto.setPrincipleApproval(principleApprovalDto);
                            }
                        }
                        activePrincipleDto.setOrgId(principle.getClientId());
                        activePrincipleDto.setAuditId(principle.getId());
                        activePrincipleDto.setAuditStatus(principle.getStatus());
                    }
                    principleResponseList.add(activePrincipleDto);
                }
                return principleResponseList;
            }
            principleResponseList = this.handleSoc2(framework, user, principleResponseList);
            return principleResponseList;
        } catch (Exception exception) {
            log.error("Given framework not found in the principles");
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * @param framework
     * @param user
     * @param principleResponseList
     * @return
     * @throws PrincipleException
     */
    private List<ActivePrincipleDto> handleSoc2(String framework, User user, List<ActivePrincipleDto> principleResponseList) throws PrincipleException {
        try {
            if (framework.equalsIgnoreCase(ComplianceFramework.SOC2.toString())) {
                framework = ComplianceFramework.ISO.toString();
                List<Principle> notInList = principleRepository.findByFlagIgnoreCaseNotIn(new String[]{framework});
                for (Principle element : notInList) {
                    PrincipleApprovalDto principleApprovalDto = new PrincipleApprovalDto();
                    List<PrincipleApproval> principleApproval = principleApprovalService.findByPrincipleId(element.getMetricsId());
                    ActivePrincipleDto activePrincipleDto = new ActivePrincipleDto();
                    activePrincipleDto.setPrinciple(element.getPrinciple());
                    activePrincipleDto.setFlag(element.getFlag());
                    activePrincipleDto.setTitle(element.getTitle());
                    activePrincipleDto.setId(element.getMetricsId());
                    activePrincipleDto.setStatus(element.getStatus());
                    for (PrincipleApproval principle : principleApproval) {
                        principleApprovalDto.setPrincipleId(principle.getPrincipleId());
                        principleApprovalDto.setStatus(principle.getStatus());
                        principleApprovalDto.setModifiedBy(principle.getModifiedBy());
                        principleApprovalDto.setId(principle.getId());
                        principleApprovalDto.setCreatedBy(principle.getCreatedBy());
                        principleApprovalDto.setAuditNote(principle.getAuditNote());
                        principleApprovalDto.setCreatedDate(principle.getCreatedDate());
                        principleApprovalDto.setModifiedDate(principle.getModifiedDate());
                        principleApprovalDto.setOrganizationDto(mappingService.getOrgDtoFromEntity(user.getOrganization()));
                        List<AuditPeriod> auditPeriods = auditPeriodService.findByStatusAndFrameworkId(AuditPeriodStatus.O.toString(), 2);

                        for (AuditPeriod auditPeriod : auditPeriods) {
                            if (principle.getAuditPeriod().getAuditId() == auditPeriod.getAuditId()) {
                                AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
                                auditPeriodDto.setAuditId(auditPeriod.getAuditId());
                                auditPeriodDto.setPeriod(auditPeriod.getPeriod());
                                auditPeriodDto.setStatus(auditPeriod.getStatus());
                                auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
                                auditPeriodDto.setStartDate(auditPeriod.getStartDate());
                                auditPeriodDto.setEndDate(auditPeriod.getEndDate());
                                auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
                                auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
                                auditPeriodDto.setOrgId(auditPeriod.getOrganization().getId());
                                auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
                                principleApprovalDto.setAuditPeriod(auditPeriodDto);
                                activePrincipleDto.setPrincipleApproval(principleApprovalDto);
                            }
                        }
                        activePrincipleDto.setOrgId(principle.getClientId());
                        activePrincipleDto.setAuditId(principle.getId());
                        activePrincipleDto.setAuditStatus(principle.getStatus());
                    }
                    principleResponseList.add(activePrincipleDto);
                }
            }
            return principleResponseList;
        } catch (Exception exception) {
            log.error("Given framework not found in the principles");
            throw new PrincipleException(exception.getMessage());
        }
    }

    /**
     * method to get Principle records by principleId.
     *
     * @param principleId
     * @return
     * @throws PrincipleException
     */
    public Principle getPrincipleById(final Integer principleId) throws PrincipleException {
        try {
            return principleRepository.findByMetricsId(principleId);
        } catch (Exception exception) {
            log.error("fetching  principle by principleId not found");
            throw new PrincipleException(exception.getMessage());
        }
    }
}
