package com.compliance.soc.socly.auth.service;

import com.compliance.soc.socly.auth.entity.Role;
import com.compliance.soc.socly.auth.exception.RoleException;
import com.compliance.soc.socly.auth.model.RoleDto;

import java.util.List;

/**
 * Its an interface for the service layer of {link Role functionalities}.
 */
public interface RoleService {
    Role findByName(String name);

    List<RoleDto> findAllByOrgView(Boolean orgView)throws RoleException;
}
