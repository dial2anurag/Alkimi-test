package com.compliance.soc.socly.auditor.controller;

import com.compliance.soc.socly.auditor.model.AuditorDto;
import com.compliance.soc.socly.auditor.model.AuditorMappingDto;
import com.compliance.soc.socly.auditor.model.IdAndName;
import com.compliance.soc.socly.auditor.service.impl.AuditorServiceImpl;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.model.PasswordDto;
import com.compliance.soc.socly.auth.service.PasswordService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.enums.UserStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import java.util.Collections;
import java.util.List;


@Slf4j
@RestController
@RequestMapping("/auditor")
public class AuditorController {
    @Autowired
    private AuditorServiceImpl auditorService;
    @Autowired
    private PasswordService passwordService;
    @Autowired
    private UserService userService;
    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;

    /**
     * API to register an Auditor
     *
     * @param auditor (AuditorDto is accepted in the body and will have details about an Auditor)
     */
    @PostMapping("/save")
    public ResponseEntity<AuditorDto> saveAuditor(@RequestBody AuditorDto auditor) {
        try {
            return ResponseEntity.ok().body(auditorService.saveAuditor(auditor));
        } catch (Exception e) {
            log.error("Error while registering an Auditor {} with the error {}", auditor, e);
            return ResponseEntity.badRequest().body(null);
        }
    }
    /**
     * API to get the Auditors based on status passed or not passed
     * return List<IdAndName>
     */
    @GetMapping
    public ResponseEntity<List<IdAndName>> getAuditors(@RequestParam(value = "status", required = false) UserStatus status) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(null);//auditorService.getAuditors(status)
        } catch (Exception ex) {
            log.error("Error while getting Auditors for status {} with the error {}", status, ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
    /**
     * API to get an Auditor for the given auditorID
     *
     * @param id
     * @return ResponseEntity
     */
    @GetMapping("/{id}")
    public ResponseEntity<AuditorDto> getAuditor(@PathVariable("id") int id) {
        try {
            //AuditorDto auditorDto = auditorService.getAuditorById(id);
            return ResponseEntity.ok().body(null);//auditorDto
        }
        catch (Exception ex) {
            log.error("Unable to fetch Auditor with ID {} due to error {}",id,ex);
            return ResponseEntity.badRequest().body(null);
        }
    }
    /**
     * API to delete an Auditor for the given auditorID
     * @param id
     * @return ResponseEntity
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAuditor(@PathVariable("id") int id) {
        try {
            return ResponseEntity.ok().body(null);//auditorService.deleteAuditor(id)
        }
        catch (Exception ex) {
            log.error("Unable to delete Auditor with ID {} due to error",id,ex);
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
    /**
     * API to change/update Auditor password
     * @param passwordDto
     * @return
     */
    @PostMapping(value = "/password")
    public ResponseEntity<String> updatePassword(@RequestBody PasswordDto passwordDto) {
        try {
            User auditorUser = userService.getCurrentUser();
            if (!passwordService.isPasswordDtoValid(passwordDto)) {
                return ResponseEntity.badRequest().body("Password is invalid");
            }
            //auditorService.changeUserPassword(passwordDto, auditorUser);
            return ResponseEntity.ok("Password updated successfully");
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
    }
    /**
     * API to save auditor-mapping for an existing Auditor
     * return List<ResponseEntity>
     */
    @PostMapping("/mapping")
    public List<ResponseEntity> saveAuditorMapping(@RequestBody List<AuditorMappingDto> auditorMappingDtos) {
        try {
            if (auditorMappingDtos != null & auditorMappingDtos.size() > 0) {
                //return auditorService.saveAuditorMapping(auditorMappingDtos);
                return null;
            }
            else return (List<ResponseEntity>) ResponseEntity.badRequest().body("Auditor mapping is missing.");
        } catch (Exception ex) {
            return (List<ResponseEntity>) (ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to process request" + ex.getMessage()));
        }
    }
}
