package com.compliance.soc.socly.audit.service;

import com.compliance.soc.socly.audit.Exceptions.AuditPeriodException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;

/**
 * AuditPeriodService is an Interface create methods and implement methods in impl class
 */
@Service
public interface AuditPeriodService {
    /**
     * this interface for fetching the auditperiods by orgId.
     *
     * @param orgId
     * @return
     * @throws AuditPeriodException
     */
    List<AuditPeriodDto> getAudit(long orgId, String status) throws AuditPeriodException;

    /**
     * this interface for saveing the auditperiod.
     *
     * @param audit
     * @param user
     * @return
     * @throws AuditPeriodException
     */
    AuditPeriodDto save(@Valid AuditPeriodDto audit, User user) throws AuditPeriodException;

    /**
     * this interface for update the auditperiod.
     *
     * @param audit
     * @param user
     * @return
     * @throws AuditPeriodException
     */
    AuditPeriodDto update(@Valid AuditPeriodDto audit, User user) throws AuditPeriodException;

    /**
     * this interface is boolean to check whether is present or not.
     *
     * @param userId
     * @return
     * @throws AuditPeriodException
     */
    boolean isAuditor(long userId) throws AuditPeriodException;

    /**
     * this interface is for finding Active audit with framework
     *
     * @param status
     * @param frameworkId
     * @return
     */
    List<AuditPeriod> findByStatusAndFrameworkId(String status, Integer frameworkId) throws AuditPeriodException;

    /**
     * this interface is for find AuditPeriod records by Organization and status
     *
     * @param organization
     * @param status
     * @return
     */
    List<AuditPeriod> findByOrganizationAndStatus(Organization organization, String status) throws AuditPeriodException;
}
