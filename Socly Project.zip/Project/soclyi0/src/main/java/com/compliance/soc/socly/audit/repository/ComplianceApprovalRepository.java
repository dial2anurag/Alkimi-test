package com.compliance.soc.socly.audit.repository;

import com.compliance.soc.socly.audit.entity.ComplianceApproval;
import com.compliance.soc.socly.audit.model.ComplianceApprovalID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ComplianceApprovalRepository extends JpaRepository<ComplianceApproval, ComplianceApprovalID> {

    Optional<ComplianceApproval> findById(ComplianceApprovalID id);

    ComplianceApproval save(ComplianceApproval comp);

}
