package com.compliance.soc.socly.auth.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
    private Long id;
    private String username;
    private String email;
    private String phone;
    private String name;
    private String businessTitle;
    private String organizationName;
}