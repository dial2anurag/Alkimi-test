package com.compliance.soc.socly.audit.service;

import com.compliance.soc.socly.audit.Exceptions.PrincipleApprovalException;
import com.compliance.soc.socly.audit.entity.PrincipleApproval;
import com.compliance.soc.socly.audit.model.PrincipleApprovalDto;
import com.compliance.soc.socly.audit.model.PrincipleApprovalRequest;
import com.compliance.soc.socly.auth.entity.User;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;

/**
 * PrincipleApprovalService is an Interface create methods and implement methods in impl class
 */
@Service
public interface PrincipleApprovalService {

    /**
     * This method is to save the PrincipleApproval Records.
     *
     * @param princ
     * @param user
     * @return
     * @throws PrincipleApprovalException
     */
    PrincipleApprovalDto save(@Valid PrincipleApprovalRequest princ, User user) throws PrincipleApprovalException;

    /**
     * This method is to get records of PrincipleApproval by PrincipleId.
     *
     * @param principleId
     * @return
     */
    List<PrincipleApproval> findByPrincipleId(Integer principleId) throws PrincipleApprovalException;
}
