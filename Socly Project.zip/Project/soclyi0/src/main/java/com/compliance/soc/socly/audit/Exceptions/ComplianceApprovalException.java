package com.compliance.soc.socly.audit.Exceptions;

/**
 *  ComplianceApproval exception class to handle separately with others
 */
public class ComplianceApprovalException extends Exception{
    public ComplianceApprovalException(final Exception ex) {
        super(ex);
    }

    public ComplianceApprovalException(final String errorMsg) {
        super(errorMsg);
    }
}