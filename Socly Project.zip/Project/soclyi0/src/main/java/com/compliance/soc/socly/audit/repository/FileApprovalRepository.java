package com.compliance.soc.socly.audit.repository;

import com.compliance.soc.socly.audit.entity.FileApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileApprovalRepository extends JpaRepository<FileApproval, Integer> {
    List<FileApproval> findAll();
    FileApproval save(FileApproval activity);
    FileApproval findOneByFileIdAndComplianceIdAndPrincipleId(Integer fileId, String complianceId, Integer principleId);
}
