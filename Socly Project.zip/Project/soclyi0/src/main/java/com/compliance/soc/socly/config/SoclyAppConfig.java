package com.compliance.soc.socly.config;

import com.compliance.soc.socly.config.interceptors.APIRateLimitInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SoclyAppConfig implements WebMvcConfigurer {

    @Autowired
    private APIRateLimitInterceptor interceptor;

    @Bean
    public APIRateLimitInterceptor apiRateLimitInterceptor() {
        return new APIRateLimitInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(interceptor).addPathPatterns("/**");
    }
}
