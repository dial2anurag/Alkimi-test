package com.compliance.soc.socly.auditor.service.impl;

import com.compliance.soc.socly.auditor.entity.Auditor;
import com.compliance.soc.socly.auditor.exception.AuditorException;
import com.compliance.soc.socly.auditor.model.AuditorDto;
import com.compliance.soc.socly.auditor.repository.AuditorRepository;
import com.compliance.soc.socly.auditor.service.AuditorService;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.organization.service.FrameworkService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class AuditorServiceImpl implements AuditorService {

    @Autowired
    private AuditorRepository auditorRepository;
    @Autowired
    private OrgMasterService orgMasterService;
    @Autowired
    private FrameworkService frameworkService;
    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;
    @Autowired
    private UserService userService;

    /**
     * saves/updates Auditor details in database.
     * @param auditorDto
     * @return AuditorDto
     * @throws AuditorException
     */
    @Override
    public AuditorDto saveAuditor(AuditorDto auditorDto) throws AuditorException {
        try {
            Auditor auditor = auditorRepository.findByEmail(auditorDto.getEmail());
            if (auditor == null) {
                log.info("No Auditor with email : " + auditorDto.getEmail() + " exists. New Auditor to be created...");
                auditor = Auditor.builder()
                        .username(auditorDto.getUsername())
                        .email(auditorDto.getEmail())
                        .name(auditorDto.getName())
                        .description(auditorDto.getDescription())
                        .phone(auditorDto.getPhone())
                        .status("Active")
                        .passwordChanged(false)
                        .createdDate(new Date())
                        .password(auditorDto.getPassword())
                        .build();
            } else {
                log.info("Auditor " + auditor.getUsername() + " with email: " + auditor.getEmail() + " already exists. Record to be updated...");
                auditor = this.updateAuditorDetails(auditorDto, auditor);
            }
            Auditor registeredAuditor = auditorRepository.save(auditor);
            log.info("Auditor save/update successful.");
            auditorDto.setId(registeredAuditor.getId());
            return auditorDto;
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new AuditorException("Unable to save Auditor in database " + ex.getMessage());
        }
    }

    /**
     * Update Auditor details if auditor already exists in database with details from AuditorDto.
     *
     * @param auditorDto
     * @param auditor
     * @return
     * @throws AuthException
     */
    private Auditor updateAuditorDetails(AuditorDto auditorDto, Auditor auditor) throws AuthException {
        try {
            if (auditorDto.getDescription() != null) {
                auditor.setDescription(auditorDto.getDescription());
            }
            if (auditorDto.getPhone() != null) {
                auditor.setPhone(auditorDto.getPhone());
            }
            if (auditorDto.getStatus() != null) {
                auditor.setStatus(auditorDto.getStatus());
            }
            if (auditorDto.getPasswordChanged() != null) {
                auditor.setPasswordChanged(auditorDto.getPasswordChanged());
            }
            if(auditorDto.getPassword() != null) {
                auditor.setPassword(auditorDto.getPassword());
            }
            return auditor;
        } catch (Exception ex) {
            throw new AuthException(ex.getMessage());
        }
    }
}
