package com.compliance.soc.socly.amazons3.exception;

public class FileTypeNotAllowedException extends RuntimeException {

    private String message;

    public FileTypeNotAllowedException() {
    }

    public FileTypeNotAllowedException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
