package com.compliance.soc.socly.audit.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FileApprovalDto is a Dto class used for post or get values of selected properties
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FileApprovalRequest {

    private String fileName;

    private String auditStatus;

    private String complianceId;

    private Integer principleId;

    private String auditNote;

    private FrameworkDto framework;
}
