package com.compliance.soc.socly.cloud.aws.exception;

public class AccountAdminException extends RuntimeException {
    String message;

    public AccountAdminException(String m) {
        message = m;
    }

    @Override
    public String toString() {
        return message;
    }
}
