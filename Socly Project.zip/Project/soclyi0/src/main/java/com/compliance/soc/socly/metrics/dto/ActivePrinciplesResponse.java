package com.compliance.soc.socly.metrics.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ActivePrinciplesResponse {

    // provide the compliance list of principle
    // metrics id should be removed
    // because we are considering metrics id is principle id
    protected Integer id;
    protected String principle;
    protected String title;
    protected String flag;
    protected String status;
    protected Long orgId;
    protected Character auditStatus;
    protected Integer auditId;
}
