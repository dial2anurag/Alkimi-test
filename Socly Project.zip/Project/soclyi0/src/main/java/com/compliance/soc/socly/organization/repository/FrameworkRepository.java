package com.compliance.soc.socly.organization.repository;

import com.compliance.soc.socly.organization.entity.Framework;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FrameworkRepository extends JpaRepository<Framework, Integer> {
    Framework findByName( String name);
}
