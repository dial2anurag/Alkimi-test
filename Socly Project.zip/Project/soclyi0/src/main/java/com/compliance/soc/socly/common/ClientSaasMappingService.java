package com.compliance.soc.socly.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientSaasMappingService {

    @Autowired
    ClientSaasMappingRepository clientSaasMappingRepository;


    public void addClientSaasRecord(SaasProvider saasId, String organizationName, String status) {
        ClientSaasMapping clientSaasMappingFromDB = getClientSaasRecord(organizationName, saasId.toString());
        if (clientSaasMappingFromDB == null) {
            ClientSaasMapping clientSaasMapping = new ClientSaasMapping();
            clientSaasMapping.setSaasId(saasId.toString());
            clientSaasMapping.setOrganizationName(organizationName);
            clientSaasMapping.setActive(status);
            clientSaasMappingRepository.save(clientSaasMapping);
            System.out.println("ClientSaasRecord saved ");
        }

    }

    public ClientSaasMapping getClientSaasRecord(String organizationName, String saasId) {
        return clientSaasMappingRepository.findByOrganizationNameAndSaasId(organizationName, saasId);
    }

    public ClientSaasMapping[] getClientSaasRecordOnStatus(String organizationName, String isActive) {
        return clientSaasMappingRepository.findByOrganizationNameAndIsActive(organizationName, isActive);
    }

}
