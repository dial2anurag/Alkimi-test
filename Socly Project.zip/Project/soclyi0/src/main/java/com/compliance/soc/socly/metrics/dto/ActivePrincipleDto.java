package com.compliance.soc.socly.metrics.dto;

import com.compliance.soc.socly.audit.model.PrincipleApprovalDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ActivePrincipleDto extends ActivePrinciplesResponse {
    private PrincipleApprovalDto principleApproval;
    @JsonIgnore
    private Long orgId;
    @JsonIgnore
    private Character auditStatus;
    @JsonIgnore
    private Integer auditId;
}
