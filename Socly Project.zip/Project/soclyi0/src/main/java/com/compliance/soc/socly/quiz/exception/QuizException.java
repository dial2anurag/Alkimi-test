package com.compliance.soc.socly.quiz.exception;

public class QuizException extends Exception{

    public QuizException(final String msg){
        super(msg);
    }

    public QuizException(final Exception e){
        super(e);
    }
}
