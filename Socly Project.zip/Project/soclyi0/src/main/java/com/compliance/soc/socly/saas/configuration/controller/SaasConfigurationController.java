package com.compliance.soc.socly.saas.configuration.controller;

import com.compliance.soc.socly.saas.configuration.dto.SaasConfigurationDto;
import com.compliance.soc.socly.saas.configuration.dto.SaasConfigurationRequest;
import com.compliance.soc.socly.saas.configuration.service.SaasConfigurationService;
import com.compliance.soc.socly.saas.exception.SaasException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/saas/config")
@Slf4j
public class SaasConfigurationController {

    @Autowired
    private SaasConfigurationService saasConfigurationService;

    @PostMapping("/save")
    public ResponseEntity<?> saveConfiguration (@RequestBody List<SaasConfigurationRequest> saasConfigurationRequestList){
        List<SaasConfigurationDto> saasConfigurations = null;
        try {
            saasConfigurations = saasConfigurationService.saveConfiguration(saasConfigurationRequestList);
        } catch (SaasException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(saasConfigurations);
    }

    @GetMapping("/get")
    public ResponseEntity<?> getConfiguration (@RequestParam String saasId, @RequestParam(required = false) Integer frameworkId){
        List<SaasConfigurationDto> saasConfigurations = null;
        try {
            saasConfigurations = saasConfigurationService.getConfiguration(saasId, frameworkId);
        } catch (SaasException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(saasConfigurations);
    }
}
