package com.compliance.soc.socly.auth.model;


import com.compliance.soc.socly.organization.model.FrameworkDto;
import com.compliance.soc.socly.organization.model.OrgDetailsDto;
import com.compliance.soc.socly.saas.model.SaasMasterDto;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
/**
 * Organization Model
 */
public class OrganizationDto {
    private long clientId;
    private String orgName;
    private String description;
    private Date registeredDateTime;
    private boolean isDetailFilled;
    private String status;
    private long parentId;
    private List<FrameworkDto> frameworks;
    private List<SaasMasterDto> saasMasters;
    private List<OrgDetailsDto> orgDetails;
}