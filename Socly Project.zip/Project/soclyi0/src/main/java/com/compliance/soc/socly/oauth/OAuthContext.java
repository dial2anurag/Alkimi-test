package com.compliance.soc.socly.oauth;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class OAuthContext {

    private Map<String, String> gitHubAuthCode = new HashMap<>();
    private Map<String, String> jiraAuthCode = new HashMap<>();

    /**
     * geting the GitHub authcode
     * @param username
     * @return authcode
     */
    public String getGitHubAuthCode(String username) {
        return gitHubAuthCode.get(username);
    }

    public String getGitHubUsername() {
        String username = "";
        for (String key : gitHubAuthCode.keySet()) {
            username = key;
        }
        return username;
    }

    public void setGitHubAuthCode(String username, String authCode) {
        if (gitHubAuthCode.size() == 1) {
            gitHubAuthCode = new HashMap<>();
        }
        this.gitHubAuthCode.put(username, authCode);
    }

    /**
     * geting the jira Auth code.
     * @param username
     * @return Jira authcode
     */
    public String getJiraAuthCode(String username) {
        return this.jiraAuthCode.get(username);
    }

    /**
     * seting Jira Authcode and username
     * @param username
     * @param jiraAuthCode
     */
    public void setJiraAuthCode(String username, String jiraAuthCode) {
        this.jiraAuthCode.put(username, jiraAuthCode);
    }
}
