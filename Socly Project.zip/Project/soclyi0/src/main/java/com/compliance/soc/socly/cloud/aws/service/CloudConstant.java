package com.compliance.soc.socly.cloud.aws.service;

public class CloudConstant {
    public static final String AZURE_ENDPOINT = "https://management.azure.com/subscriptions";
    public static final String AZURE_ENDPOINT_BUILDER = "providers/Microsoft.Security/";
    public static final String AZURE_COMPLIANCE = "assessments";
    public static final String AZURE_COMPLIANCE_METADATA = "assessmentMetadata";
    public static final String AZURE_COMPLIANCE_NAME = "Azure-Security-Benchmark";    //  Azure-Security-Benchmark or PCI-DSS-3.2.1
    public static final String AZURE_ENDPOINT_APIVERSION = "?api-version=2020-01-01";
    public static final String AZURE_GRANT_TYPE = "client_credentials";
    public static final String AZURE_RESOURCE = "https://management.azure.com/";
    public static final String AZURE_BEARE_TOKEN_ENDPOINT = "https://login.microsoftonline.com/";
}
