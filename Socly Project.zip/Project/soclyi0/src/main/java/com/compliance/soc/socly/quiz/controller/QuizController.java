package com.compliance.soc.socly.quiz.controller;

import com.compliance.soc.socly.quiz.model.QuizDto;
import com.compliance.soc.socly.quiz.model.QuizResult;
import com.compliance.soc.socly.quiz.service.QuizService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/quiz")
@Component
@Slf4j
public class QuizController {

    @Autowired
    private QuizService quizService;

    /**
     * API method to store the result of security awareness test
     * @param quizResult
     * @return savedQuiz (QuizDto response)
     */
    @PostMapping(value = "/save")
    public ResponseEntity<?> saveQuizResult(@RequestBody @Valid QuizResult quizResult) {
        try {
            QuizDto savedQuiz = quizService.saveQuiz(quizResult);
            return ResponseEntity.ok(savedQuiz);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.getMessage());
        }
    }
}

