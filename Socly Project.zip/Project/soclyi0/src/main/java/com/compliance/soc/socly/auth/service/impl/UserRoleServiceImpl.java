package com.compliance.soc.socly.auth.service.impl;

import com.compliance.soc.socly.auth.entity.UserRole;
import com.compliance.soc.socly.auth.exception.UserRoleException;
import com.compliance.soc.socly.auth.repository.UserRoleRepository;
import com.compliance.soc.socly.auth.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserRoleServiceImpl implements UserRoleService {
    @Autowired
    private UserRoleRepository userRoleRepository;

    /**
     * role name  fetching by the userID and roleId.
     *
     * @param userId
     * @param roleId
     * @return {@link UserRole}
     * @throws UserRoleException
     */
    @Override
    public UserRole findByUserIdAndRoleId(long userId, long roleId) throws UserRoleException {
        try {
            return userRoleRepository.findByUserIdAndRoleId(userId, roleId);
        } catch (Exception e) {
            log.error("Unable to fetch the role with given userId " + userId, "roleId" + roleId);
            throw new UserRoleException(e);
        }
    }
}