package com.compliance.soc.socly.oauth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * Response class for Access Token.
 */
public class AccessTokenResponse {

    private String access_token;
    private int expires_in = Integer.MAX_VALUE;
    private long generatedOn;
    private String refresh_token;
    private String token_type;
    private String scope;
    private String error;
}
