package com.compliance.soc.socly.config.interceptors;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.ConsumptionProbe;
import io.github.bucket4j.Refill;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Interceptor class used for APIs rate limit
 */
public class APIRateLimitInterceptor implements HandlerInterceptor {

    private final static String webHooksUrl = "/push/notification";
    private final Map<String, Bucket> cache = new ConcurrentHashMap<>();
    @Value("${socly.api.rate.limit.bucket4j.capacity}")
    private int bucket4jCapacity;

    @Value("${socly.api.rate.limit.refill.rate.in.sec}")
    private int refillRate;

    public Bucket resolveBucket(final String apiKey) {
        return cache.computeIfAbsent(apiKey, this::newBucket);
    }

    private Bucket newBucket(String apiKey) {
        final Bandwidth limit = Bandwidth.classic(bucket4jCapacity, Refill.greedy(refillRate, Duration.ofSeconds(1)));
        return Bucket.builder()
                .addLimit(limit)
                .build();
    }

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, Object handler) throws Exception {
        final String apiKey = request.getHeader("X-api-key");
        if (apiKey == null || apiKey.isEmpty()) {
            final boolean webhook = pushNotification(request);
            if (webhook) {
                return webhook;
            }
            response.sendError(HttpStatus.BAD_REQUEST.value(), "Missing Header: X-api-key");
            return false;
        }

        final ConsumptionProbe probe = resolveBucket(apiKey).tryConsumeAndReturnRemaining(1);
        if (probe.isConsumed()) {
            response.addHeader("X-Rate-Limit-Remaining", String.valueOf(probe.getRemainingTokens()));
            return true;
        } else {
            long waitForRefill = probe.getNanosToWaitForRefill() / 1_000_000_000;
            response.addHeader("X-Rate-Limit-Retry-After-Seconds", String.valueOf(waitForRefill));
            response.sendError(HttpStatus.TOO_MANY_REQUESTS.value(),
                    "You have exhausted your API Request Quota");
            return false;
        }
    }

    /**
     * Method used to check whether Push notification request or not
     *
     * @param request
     * @return
     */
    private boolean pushNotification(final HttpServletRequest request) {
        return request.getRequestURL().toString().contains(APIRateLimitInterceptor.webHooksUrl);
    }
}