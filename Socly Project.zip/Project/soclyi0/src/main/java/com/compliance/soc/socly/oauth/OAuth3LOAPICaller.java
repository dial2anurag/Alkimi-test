package com.compliance.soc.socly.oauth;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Slf4j
public class OAuth3LOAPICaller extends OAuthAPICaller {

    private AccessTokenRequest accessTokenRequest;

    private OAuth3LOAPICaller(String accessTokenUrl, String clientId, String clientSecret, RestTemplate restTemplate) {
        super(accessTokenUrl, clientId, clientSecret, restTemplate);
        this.accessTokenRequest = new AccessTokenRequest();
    }

    /**
     * API method for get Refresh Token Based on API caller.
     *
     * @param accessTokenUrl
     * @param clientId
     * @param clientSecret
     * @param refreshToken
     * @param restTemplate
     * @return
     */
    public static OAuth3LOAPICaller getRefreshTokenBasedAPICaller(String accessTokenUrl, String clientId, String clientSecret, String refreshToken,
                                                                  RestTemplate restTemplate) {
        OAuth3LOAPICaller oAuth3LOAPICaller = new OAuth3LOAPICaller(accessTokenUrl, clientId, clientSecret, restTemplate);
        oAuth3LOAPICaller.accessTokenRequest.setRefresh_token(refreshToken);
        oAuth3LOAPICaller.accessTokenRequest.setClient_secret(clientSecret);
        oAuth3LOAPICaller.accessTokenRequest.setClient_id(clientId);
        oAuth3LOAPICaller.accessTokenRequest.setGrant_type("refresh_token");
        return oAuth3LOAPICaller;
    }

    /**
     * API method to get the Auth code based on the API caller.
     *
     * @param oAuthAPIRequest@return
     */
    public static OAuth3LOAPICaller getAuthCodeBasedAPICaller(final OAuthAPIRequest oAuthAPIRequest) {
        OAuth3LOAPICaller oAuth3LOAPICaller = new OAuth3LOAPICaller(oAuthAPIRequest.getAccessTokenUrl(), oAuthAPIRequest.getClientId(), oAuthAPIRequest.getClientSecret(), oAuthAPIRequest.getRestTemplate());
        oAuth3LOAPICaller.accessTokenRequest.setCode(oAuthAPIRequest.getAuthCode());
        oAuth3LOAPICaller.accessTokenRequest.setClient_secret(oAuthAPIRequest.getClientSecret());
        oAuth3LOAPICaller.accessTokenRequest.setClient_id(oAuthAPIRequest.getClientId());
        oAuth3LOAPICaller.accessTokenRequest.setGrant_type("authorization_code");
        oAuth3LOAPICaller.accessTokenRequest.setRedirect_uri(oAuthAPIRequest.getRedirectUri());
        // initializing secrete manager in the API caller class
        oAuth3LOAPICaller.setSecretManager(oAuthAPIRequest.getSecretManager());
        return oAuth3LOAPICaller;
    }

    /**
     * @param oAuthAPIRequest
     * @return
     */
    public static OAuthAPICaller getAuthCodeAndXxTokenBasedAPICaller(final OAuthAPIRequest oAuthAPIRequest) {
        final OAuth3LOAPICaller oAuth3LOAPICaller = OAuth3LOAPICaller.getAuthCodeBasedAPICaller(oAuthAPIRequest);
        if (oAuth3LOAPICaller.accessToken == null) {
            oAuth3LOAPICaller.accessToken = new AccessTokenResponse();
        }
        oAuth3LOAPICaller.accessToken.setAccess_token(oAuthAPIRequest.getSaasAccessToken());
        return oAuth3LOAPICaller;
    }

    /**
     * api method for Generating new access token
     *
     * @return token
     */
    @Override
    protected AccessTokenResponse generateNewAccessToken() {
        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity(this.accessTokenRequest, headers);
            final ResponseEntity<AccessTokenResponse> accessTokenResponseEntity =
                    this.restTemplate.exchange(this.accessTokenUrl, HttpMethod.POST, entity, AccessTokenResponse.class);
            final AccessTokenResponse response = accessTokenResponseEntity.getBody();
            response.setGeneratedOn(System.currentTimeMillis());
            return response;
        } catch (final Exception ex) {
            log.error("Failed to get access token for organization / token url : {} / {} ", this.accessTokenRequest.getClient_id(), this.accessTokenUrl);
            throw ex;
        }
    }

    /**
     * API method to get acces token using Refresh token.
     *
     * @return token
     */
    @Override
    protected AccessTokenResponse getAccessTokenUsingRefreshToken() throws Exception {
        return this.generateNewAccessToken();
    }
}
