package com.compliance.soc.socly.enums;

public enum UserManagementModule {
    // Need to add compliance type enum
}
