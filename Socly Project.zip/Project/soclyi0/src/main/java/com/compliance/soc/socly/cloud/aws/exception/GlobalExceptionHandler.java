package com.compliance.soc.socly.cloud.aws.exception;

import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Order(1)
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        Map m = new HashMap<>();
        List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.toList());
        m.put("Error", errors);
        m.put("Status", status.value());
        return new ResponseEntity<>(m, status);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity handleUserNotFoundException(UserNotFoundException exception) {
        Map m = new HashMap();
        m.put("Error", exception);
        return new ResponseEntity(m, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AccountAdminException.class)
    public ResponseEntity handleAccountAdminException(AccountAdminException exception) {
        return new ResponseEntity(exception.toString(), HttpStatus.NOT_ACCEPTABLE);
    }

}
