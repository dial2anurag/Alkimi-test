package com.compliance.soc.socly.audit.service.Impl;

import com.compliance.soc.socly.amazons3.dto.AuditPeriodResponse;
import com.compliance.soc.socly.amazons3.dto.ComplianceApprovalResponse;
import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.entity.ComplianceApproval;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.ComplianceApprovalDto;
import com.compliance.soc.socly.audit.model.ComplianceApprovalID;
import com.compliance.soc.socly.audit.model.ComplianceApprovalRequest;
import com.compliance.soc.socly.audit.repository.AuditPeriodRepository;
import com.compliance.soc.socly.audit.repository.ComplianceApprovalRepository;
import com.compliance.soc.socly.audit.repository.PrincipleApprovalRepository;
import com.compliance.soc.socly.audit.service.ComplianceApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.metrics.dto.PrincipleDto;
import com.compliance.soc.socly.metrics.entity.Principle;
import com.compliance.soc.socly.metrics.repository.PrincipleRepository;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.Date;
import java.util.Optional;

@Service
@Slf4j
public class ComplianceApprovalServiceImpl implements ComplianceApprovalService {

    @Autowired
    private ComplianceApprovalRepository complianceApprovalRepository;

    @Autowired
    private AuditPeriodRepository auditPeriodRepository;

    @Autowired
    private PrincipleApprovalRepository principleApprovalRepository;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private PrincipleRepository principleRepository;

    /**
     * method to save ComplianceApproval data in compliance_approval table
     *
     * @param comp and User objects
     * @return ComplianceApproval data
     */
    @Override
    public ComplianceApprovalDto save(@Valid ComplianceApprovalRequest comp, User user) throws ComplianceApprovalException {
        try {
            final Framework framework = new Framework();
            framework.setId(comp.getFramework().getId());
            AuditPeriod period = auditPeriodRepository.findOneByOrganizationAndStatusAndFramework(user.getOrganization(),
                    "O",framework);
            if (period == null) {
                throw new ComplianceApprovalException("No Active audit period for this organization  : "
                        + user.getOrganization().getOrgName());
            }
            final ComplianceApprovalID complianceApprovalID = new ComplianceApprovalID();
            complianceApprovalID.setPrincipleId(comp.getPrincipleId());
            complianceApprovalID.setComplianceId(comp.getComplianceId());
            complianceApprovalID.setClientId(period.getOrganization().getId());
            Optional<ComplianceApproval> searchedComplianceApproval = complianceApprovalRepository.findById(complianceApprovalID);
            ComplianceApproval complianceApproval = null;
            // if we dont have entry in Compliance table then insert new row otherwise
            // update the existing row
            if (!searchedComplianceApproval.isPresent()) {
                complianceApproval = new ComplianceApproval();
                complianceApproval.setComplianceId(comp.getComplianceId());
                complianceApproval.setStatus(comp.getAuditStatus());
                complianceApproval.setPrincipleId(comp.getPrincipleId());
                complianceApproval.setPeriod(period);
                complianceApproval.setClientId(user.getOrganization().getId());
                complianceApproval.setCreatedBy(user.getId());
                complianceApproval.setCreatedDate(new Date());
                complianceApproval.setAuditNote(comp.getAuditNote());
            } else {
                complianceApproval = searchedComplianceApproval.get();
                complianceApproval.setModifiedBy(user.getId());
                complianceApproval.setModifiedDate(new Date());
                complianceApproval.setStatus(comp.getAuditStatus());
                complianceApproval.setAuditNote(comp.getAuditNote());
            }
            return convert2DTO(complianceApprovalRepository.saveAndFlush(complianceApproval), user);
        } catch (final Exception ex) {
            log.error("Approving compliance {} failed due to this {} reason", comp.getComplianceId(), ex);
            throw new ComplianceApprovalException(ex);
        }
    }

    /**
     * This method is to convert Entity objects to Dto objects by set and get the each properties.
     *
     * @param saveAndFlush
     * @param user
     * @return
     */
    private ComplianceApprovalDto convert2DTO(ComplianceApproval saveAndFlush, User user) {
        final ComplianceApprovalDto complianceApprovalDto = new ComplianceApprovalDto();
        complianceApprovalDto.setId(saveAndFlush.getId());
        complianceApprovalDto.setComplianceId(saveAndFlush.getComplianceId());
        complianceApprovalDto.setStatus(saveAndFlush.getStatus());
        complianceApprovalDto.setOrganizationDto(mappingService.getOrgDtoFromEntity(user.getOrganization()));
        complianceApprovalDto.setCreatedBy(saveAndFlush.getCreatedBy());
        complianceApprovalDto.setCreatedDate(saveAndFlush.getCreatedDate());
        complianceApprovalDto.setAuditId(saveAndFlush.getAuditId());
        complianceApprovalDto.setAuditNote(saveAndFlush.getAuditNote());
        complianceApprovalDto.setModifiedBy(saveAndFlush.getModifiedBy());
        complianceApprovalDto.setModifiedDate(saveAndFlush.getModifiedDate());
        complianceApprovalDto.setPrincipleId(saveAndFlush.getPrincipleId());
        AuditPeriod auditPeriod = saveAndFlush.getPeriod();
        AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
        auditPeriodDto.setAuditId(auditPeriod.getAuditId());
        auditPeriodDto.setPeriod(auditPeriod.getPeriod());
        auditPeriodDto.setStatus(auditPeriod.getStatus());
        auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
        auditPeriodDto.setStartDate(auditPeriod.getStartDate());
        auditPeriodDto.setEndDate(auditPeriod.getEndDate());
        auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
        auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
        auditPeriodDto.setOrgId(auditPeriod.getOrganization().getId());
        auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
        complianceApprovalDto.setAuditPeriod(auditPeriodDto);


        return complianceApprovalDto;
    }

    /**
     * this method is used to find the compliance with the active audit period.
     *
     * @param comp
     * @param user
     * @return
     * @throws ComplianceApprovalException
     */
    @Override
    public ComplianceApproval findCompliance(final ComplianceApprovalRequest comp, final User user) throws ComplianceApprovalException {
        try {
            complianceApprovalRepository.flush();
            final AuditPeriod period = auditPeriodRepository.findOneByOrganizationAndStatus(user.getOrganization(),
                    'O');
            if (period == null) {
                throw new ComplianceApprovalException("No Active audit period for this organization  : "
                        + user.getOrganization().getOrgName());
            }
            final ComplianceApprovalID complianceApprovalID = new ComplianceApprovalID();
            complianceApprovalID.setPrincipleId(comp.getPrincipleId());
            complianceApprovalID.setComplianceId(comp.getComplianceId());
            complianceApprovalID.setClientId(period.getOrganization().getId());
            ComplianceApproval searchedComplianceApproval = complianceApprovalRepository.getOne(complianceApprovalID);
            return searchedComplianceApproval;
        } catch (final Exception ex) {
            log.error("Finding compliance {} failed due to this {} reason", comp.getComplianceId(), ex);
            throw new ComplianceApprovalException(ex);
        }
    }

    /**
     * @param compliance
     * @return
     */
    public ComplianceApprovalResponse populateComplianceApprovalResp(ComplianceApprovalDto compliance) {

        AuditPeriodResponse auditPeriodDTO = new AuditPeriodResponse();
        AuditPeriodDto auditPeriod = compliance.getAuditPeriod();
        auditPeriodDTO.setAuditId(auditPeriod.getAuditId());
        auditPeriodDTO.setStatus(auditPeriod.getStatus());
        auditPeriodDTO.setPeriod(auditPeriod.getPeriod());
        auditPeriodDTO.setClientId(auditPeriod.getOrgId());
        auditPeriodDTO.setStartDate(auditPeriod.getStartDate());
        auditPeriodDTO.setEndDate(auditPeriod.getEndDate());
        auditPeriodDTO.setCreatedBy(auditPeriod.getCreatedBy());
        auditPeriodDTO.setModifiedBy(auditPeriod.getModifiedBy());
        auditPeriodDTO.setEndedBy(auditPeriod.getEndedBy());
        auditPeriodDTO.setAuditDate(auditPeriod.getAuditInitiateDate());

        ComplianceApprovalResponse complianceApprovalResponse = new ComplianceApprovalResponse();
        complianceApprovalResponse.setId(compliance.getId());
        complianceApprovalResponse.setStatus(compliance.getStatus());
        complianceApprovalResponse.setComplianceDto(compliance);
        complianceApprovalResponse.setOrganizationDto(compliance.getOrganizationDto());
        Principle principle = principleRepository.findById(compliance.getPrincipleId()).get();
        if (principle != null) {
            PrincipleDto principleDto = new PrincipleDto();
            principleDto.setPrinciple(principle.getPrinciple());
            principleDto.setFlag(principle.getFlag());
            principleDto.setTitle(principle.getTitle());
            principleDto.setId(principle.getMetricsId());
            principleDto.setStatus(principle.getStatus());
            complianceApprovalResponse.setPrincipleDto(principleDto);
        }
        complianceApprovalResponse.setCreatedDate(compliance.getCreatedDate());
        complianceApprovalResponse.setModifiedDate(compliance.getModifiedDate());
        complianceApprovalResponse.setCreatedBy(compliance.getCreatedBy());
        complianceApprovalResponse.setId(compliance.getId());
        complianceApprovalResponse.setModifiedBy(compliance.getModifiedBy());
        complianceApprovalResponse.setAuditPeriod(auditPeriodDTO);
        complianceApprovalResponse.setAuditNote(compliance.getAuditNote());
        return complianceApprovalResponse;
    }

}
