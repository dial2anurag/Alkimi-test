package com.compliance.soc.socly.metrics.repository;

import com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse;
import com.compliance.soc.socly.metrics.dto.ComplianceResponse;
import com.compliance.soc.socly.metrics.entity.Principle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PrincipleRepository extends JpaRepository<Principle, Integer> {

    String query =
            "SELECT m.metrics_id as metricsId, me.compliance_id as complianceId, me.control_name as controlName, me.description as description, me.test_procedures as testProcedures, me.sample_files as sampleFiles, " +
                    "me.status as status, me.upload_type as uploadType, me.type as type, caap.audit_id as auditId, caap.status as auditStatus, caap.client_id as orgId, mcm.master_id as principleId,caap.audit_note as auditNote " +
                    "FROM metrics_master m " +
                    "JOIN metrics_compliance_mapping mcm on m.metrics_id = mcm.master_id " +
                    "JOIN metrics me on me.compliance_id = mcm.compliance " +
                    "LEFT JOIN (SELECT ca.audit_id , ca.status , ca.compliance_id, ca.client_id, ca.principle_id,ca.audit_note " +
                    "from compliance_approval ca " +
                    "JOIN audit_period ap  on ca.audit_id = ap.id  and ap.status ='O' " +
                    "where ca.client_id = :clientId) caap  on caap.compliance_id = me.compliance_id and caap.principle_id = m.metrics_id " +
                    "where mcm.master_id = :principleId";

    String queryForActiveMetrics = "select new com.compliance.soc.socly.metrics.dto.ActiveMetrics " +
            "( mm.metricsId,\n" +
            "    m1.complianceId, \n" +
            "    mm.principle, \n" +
            "    mm.title, \n" +
            "    mm.flag,\n" +
            "    m1.controlName,\n" +
            "    m1.description,\n" +
            "    ap.status as auditStatus,\n" +
            "    cp.period.auditId,\n" +
            "    cp.principleId,\n" +
            "    cp.clientId)" +
            "from MetricsComplianceMapping mcm, Principle mm, Metrics m1 " +
            " LEFT JOIN ComplianceApproval cp " +
            "on cp.complianceId = m1.complianceId " +
            " LEFT JOIN AuditPeriod ap on ap.auditId = cp.period.auditId and ap.status='O' " +
            " where mm.metricsId=mcm.masterId" +
            " and mcm.complianceId=m1.complianceId" +
            " and m1.complianceId=:complianceId" +
            " and mm.status='ACTIVE'" +
            " and m1.status='ACTIVE'";

    String queryForActivePrinciples = "select new com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse " +
            "( mm.metricsId as id,mm.principle,mm.title,mm.flag,mm.status,pa.clientId,pa.status ,pa.id as auditId) from Principle mm " +
            "            left join PrincipleApproval pa on pa.principleId=mm.metricsId and pa.clientId=?1" +
            "             where mm.status = 'Active'";

    String queryForActivePrinciplesBasedOnCompliance = "select new com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse " +
            "( mm.metricsId as id,mm.principle,mm.title,mm.flag,mm.status,pa.clientId,pa.status ,pa.id as auditId) " +
            " from Principle mm " +
            " inner join MetricsComplianceMapping mcm on mm.metricsId=mcm.masterId and mcm.complianceId=?2" +
            " left join PrincipleApproval pa on pa.principleId=mm.metricsId and pa.clientId=?1 " +
            " left join AuditPeriod ap on ap.id=pa.auditPeriod.id" +
            " where mm.status = 'Active'";

    /**
     * In this method to find all active principles with an HQL query
     *
     * @param clientId
     * @return
     */
    @Query(value = queryForActivePrinciples)
    List<ActivePrinciplesResponse> findActivePrinciples(long clientId);

    /**
     * SELECT p.*,pa.audit_id,pa.status audit_status FROM socly_db_dev1.metrics_master p
     * left join principle_approval pa on p.metrics_id= pa.principle_id;
     *
     * @param status
     * @return
     */
    List<Principle> findByStatus(String status);

    /**
     * It is a jpa method to find principles by flag and status
     *
     * @param flag
     * @param status
     * @return
     */
    List<Principle> findByFlagAndStatus(String flag, String status);

    /**
     * It is a jpa method to find principles by flag with ignore case and IN condition
     *
     * @param flag
     * @return
     */
    List<Principle> findByFlagIgnoreCaseIn(String[] flag);

    /**
     * It is a jpa method to find principles by flag with ignore case and NotIN condition
     *
     * @param flags
     * @return
     */
    List<Principle> findByFlagIgnoreCaseNotIn(String[] flags);

    /**
     * In this method to get complaince information from principles
     *
     * @param principleId
     * @param orgId
     * @return
     */
    @Query(value = query, nativeQuery = true)
    public List<ComplianceResponse> getCompliancesOnPrincipleAndOrganization(@Param("principleId") int principleId,
                                                                             @Param("clientId") long orgId);

    /**
     * In this method to get Active principles based on the compliance
     *
     * @param orgId
     * @param complianceId
     * @return
     */
    @Query(queryForActivePrinciplesBasedOnCompliance)
    public List<ActivePrinciplesResponse> getPrinciplesByCompianceId(@Param("clientId") long orgId, @Param("complianceId") String complianceId);

    /**
     * In this method to get Principle records by principleId.
     *
     * @param principleId
     * @return
     */
    Principle findByMetricsId(Integer principleId);

}

