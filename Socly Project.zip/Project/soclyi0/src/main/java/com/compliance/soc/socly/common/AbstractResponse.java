package com.compliance.soc.socly.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
/**
 * it is a response class
 */
public class AbstractResponse {

    String module;
    String complianceCheck;
    String complianceId;
    Integer compliancePoint;
    Integer acceptedComplianceScore;
    Integer rejectedComplianceScore;
    Double percentComplianceScore;
    List<EntityCompliance> entityCompliance;

    public Double getPercentComplianceScore() {
        if (percentComplianceScore == null) {
            percentComplianceScore = (acceptedComplianceScore * 100.00) / compliancePoint;
        }
        return percentComplianceScore;
    }
}
