package com.compliance.soc.socly.enums;
/*
enumeration for Task tracker controller
 */
public enum TaskTrackerModule {
    JIRA
}
