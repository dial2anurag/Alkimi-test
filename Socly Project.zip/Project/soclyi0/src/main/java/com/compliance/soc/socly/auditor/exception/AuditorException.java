package com.compliance.soc.socly.auditor.exception;

public class AuditorException extends Exception{
    String message;
   public AuditorException(String message) {
        super(message);
    }
}
