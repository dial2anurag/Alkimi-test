package com.compliance.soc.socly.audit.controller;

import com.compliance.soc.socly.audit.model.FileApprovalDto;
import com.compliance.soc.socly.audit.model.FileApprovalRequest;
import com.compliance.soc.socly.audit.service.FileApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping(value = "/audit")
public class FileAuditController extends AuditBaseController{

    @Autowired
    private FileApprovalService service;

    /**
     * method to save FileApproval data in file_approval table
     *
     * @param file class data
     * @return file approval data/ exception message and Http status
     */
    @PostMapping(value = "file_approval/save")
    public ResponseEntity<?> save(@RequestBody FileApprovalRequest file) {
        try {
            User user = userService.getCurrentUser();
            FileApprovalDto activity = service.save(file, user);
            return ResponseEntity.ok().body(activity);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return ResponseEntity.badRequest().body(exp.getMessage());
        }
    }
}
