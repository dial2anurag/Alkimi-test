package com.compliance.soc.socly.auth.service.impl;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.Role;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.model.AdminCreatedUser;
import com.compliance.soc.socly.auth.model.PasswordDto;
import com.compliance.soc.socly.auth.model.UserDetailsResponse;
import com.compliance.soc.socly.auth.model.UserDto;
import com.compliance.soc.socly.auth.model.UserUpdateDto;
import com.compliance.soc.socly.auth.repository.OrgMasterRepository;
import com.compliance.soc.socly.auth.repository.RoleRepository;
import com.compliance.soc.socly.auth.repository.UserRepository;
import com.compliance.soc.socly.auth.service.RoleService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.email.service.EmailService;
import com.compliance.soc.socly.email.service.OTPService;
import com.compliance.soc.socly.enums.UserRoles;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;

    @Autowired
    private OrgMasterRepository orgMasterRepository;

    @Autowired
    private OTPService otpService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private MappingService mappingService;

    /**
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            final User user = userRepository.findByUsername(username);
            if (user == null || !user.getStatus().equalsIgnoreCase(IS_ACTIVE)) {
                throw new UsernameNotFoundException("Invalid username or password.");
            }
            return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority(user));

        } catch (final Exception ex) {
            log.error("Failed to authenticate user {} with the following error {}", username, ex);
            throw new UsernameNotFoundException("Failed to authenticate user : " + username);
        }
    }

    /**
     * update user role, phone and status in User table
     *
     * @param userUpdateDto
     * @return updatedUserDetailsResponse
     * @throws UserDetailsException
     */
    @Override
    public UserDetailsResponse updateUser(UserUpdateDto userUpdateDto) throws UserDetailsException {
        try {
            String username = userUpdateDto.getUsername();
            User existingUser = userRepository.findByUsernameIgnoreCase(username);
            if (existingUser == null) {
                throw new UserDetailsException("No user found for given name : " + username + ".");
            }
            Set<Role> updatedRoles = this.updateRole(userUpdateDto, existingUser);
            String newPhone = userUpdateDto.getPhone();
            String newStatus = userUpdateDto.getStatus();
            if (updatedRoles != null) {
                existingUser.setRoles(updatedRoles);
            }
            if (newPhone != null) {
                existingUser.setPhone(newPhone);
            }
            if (newStatus != null) {
                existingUser.setStatus(newStatus);
            }
            User updatedUser = userRepository.save(existingUser);
            UserDetailsResponse updatedUserDetailsResponse = mappingService.userToUserDetailsResponse(updatedUser);
            return updatedUserDetailsResponse;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException(e.getMessage());
        }
    }

    /**
     * update role for a given user
     *
     * @param userUpdateDto
     * @param updateUser
     * @return
     */
    private Set<Role> updateRole(UserUpdateDto userUpdateDto, User updateUser) throws UserDetailsException {
        try {
            Long[] newRoleIds = userUpdateDto.getRoleIds();
            if (newRoleIds == null || newRoleIds.length == 0) {
                return null;
            }
            Set<Role> updateUserRoles = new HashSet<>();
            for (long newRoleId : newRoleIds) {
                Role newRole = roleRepository.findById(newRoleId);
                if (newRole == null) {
                    throw new UserDetailsException("Given role id : " + newRoleId + " does not exist. Unable to update user details.");
                }
                updateUserRoles.add(newRole);
            }
            return updateUserRoles;
        } catch (Exception e) {
            throw new UserDetailsException(e.getMessage());
        }
    }

    private Set<SimpleGrantedAuthority> getAuthority(User user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        user.getRoles().forEach(role -> {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));
        });
        return authorities;
    }

    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        userRepository.findAll().iterator().forEachRemaining(list::add);
        return list;
    }

    /**
     * finding the user through username.
     *
     * @param username
     * @return user
     */
    @Override
    public User findOne(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username");
        }
        user.setOrganizationName(user.getOrganization().getOrgName());
        user.setDetailsFilled(user.getOrganization().isDetailFilled());
        return user;
    }

    /**
     * method to change password of current logged-in user and return newly user info mapped
     * to UserDetailsResponse model class
     *
     * @param passwordDto
     * @return savedUserResponse
     * @throws UserDetailsException
     */
    @Override
    public UserDetailsResponse changeUserPassword(PasswordDto passwordDto) throws UserDetailsException {
        User user = this.getCurrentUser();
        user.setPassword(bcryptEncoder.encode(passwordDto.getNewPassword()));
        user.setPasswordChanged(true);
        User savedUser;
        try {
            savedUser = userRepository.save(user);
            UserDetailsResponse savedUserResponse = mappingService.userToUserDetailsResponse(savedUser);
            return savedUserResponse;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException("Unable to save user details");
        }
    }

    /**
     * finding the user with the Email.
     *
     * @param email
     * @return user
     */
    @Override
    public User getUserByEmail(String email) {
        return (User) this.userRepository.findByEmail(email);
    }

    /**
     * API method finding the user and seting the new password with existing password.
     *
     * @param userId
     * @param source
     */
    @Transactional
    public Optional<User> update(long userId, User source) {
        return userRepository.findById(userId).map(target -> {
            target.setPasswordChanged(source.isPasswordChanged());
            target.setPassword(source.getPassword());
            return target;
        });
    }

    /**
     * API method to get the details of the user from Dto
     *
     * @param userDto
     * @return user
     */
    @Override
    public User getUser(UserDto userDto) {
        final User user = new User();
        user.setUsername(userDto.getUsername());
        user.setEmail(userDto.getEmail());
        user.setPhone(userDto.getPhone());
        user.setName(userDto.getName());
        user.setBusinessTitle(userDto.getBusinessTitle());
        user.setOrganizationName(userDto.getOrganizationName());
        return user;
    }

    /**
     * API method to get UserDto from User
     *
     * @param user
     * @return userDto
     */
    @Override
    public UserDto getUserDto(User user) {
        final UserDto userDto = new UserDto();
        userDto.setId(user.getId());
        userDto.setUsername(user.getUsername());
        userDto.setEmail(user.getEmail());
        userDto.setName(user.getName());
        userDto.setPhone(user.getPhone());
        userDto.setBusinessTitle(user.getBusinessTitle());
        userDto.setOrganizationName(user.getOrganizationName());
        return userDto;
    }

    /**
     * registering the user
     *
     * @param userDto
     * @return user.
     */
    @Override
    public UserDetailsResponse save(UserDto userDto) throws UserDetailsException {
        try {
            User newUser = this.getUser(userDto);
            if (userRepository.existsByUsername(newUser.getUsername())) {
                throw new UserDetailsException("UserName with " + newUser.getUsername() +
                        " already exists.");
            }

            Organization organization = orgMasterRepository.findByOrgName(newUser.getOrganizationName());
            if (organization == null) {
                throw new UserDetailsException("The given organization \"" + newUser.getOrganizationName() + "\" is invalid.");
            } else {
                String businessTitle = newUser.getBusinessTitle();
                Role role = roleService.findByName(businessTitle);
                if (role == null) {
                    throw new UserDetailsException("No " + businessTitle + " role found.");
                }
                Set<Role> roleSet = new HashSet<>();
                roleSet.add(role);
                newUser.setRoles(roleSet);
                newUser.setPasswordChanged(false);
                newUser.setDetailsFilled(false);
                newUser.setPassword(bcryptEncoder.encode(this.generateAndSendOtp(newUser.getUsername(), newUser.getEmail()).toString()));
                newUser.setOrganization(organization);

                User savedUser = userRepository.save(newUser);
                UserDetailsResponse savedUserResponse = mappingService.userToUserDetailsResponse(savedUser);
                return savedUserResponse;
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException(e.getMessage() + ". Unable to save user details.");
        }

    }

    /**
     * method to register the user by the admin of the organization.
     *
     * @param adminCreatedUser
     * @return user
     */
    @Override
    public UserDetailsResponse saveUser(AdminCreatedUser adminCreatedUser) throws UserDetailsException {
        try {
            User admin = this.getCurrentUser();
            if (userRepository.existsByUsername(adminCreatedUser.getEmail())) {
                throw new UsernameNotFoundException("UserName with " + adminCreatedUser.getEmail() +
                        " already exists.");
            }
            User newUser = adminCreatedUser.getUserFromAdmin();
            newUser.setPasswordChanged(false);
            newUser.setDetailsFilled(false);
            newUser.setOrganizationName(admin.getOrganization().getOrgName());
            newUser.setOrganization(admin.getOrganization());
            newUser.setCreatedBy(admin.getId());
            newUser.setCreatedDate(new Date());
            newUser.setPassword(bcryptEncoder.encode(this.generateAndSendOtp(newUser.getUsername(), newUser.getEmail()).toString()));
            Role role = roleService.findByName(newUser.getBusinessTitle());
            if (role == null) {
                throw new UsernameNotFoundException("Given business " + newUser.getBusinessTitle() + " title is invalid");
            }
            Set<Role> roleSet = new HashSet<>();
            roleSet.add(role);

            // Have to add logic according to our need here
       /* if(newUser.getEmail()!=null && newUser.getEmail().split("@")[1].equals("socly.io")){
            role = roleService.findByName("ADMIN");
            roleSet.add(role);
        }*/

            newUser.setRoles(roleSet);
            User savedUser;
            savedUser = userRepository.save(newUser);
            UserDetailsResponse savedUserResponse = mappingService.userToUserDetailsResponse(savedUser);
            return savedUserResponse;
        } catch (
                Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException("Unable to save user details");
        }

    }

    /**
     * Saving the {@link User} with the given user role.
     * @param newUser  has required User fields.
     * @param userRole is the User {@link Role}
     * @return {@link User}
     */
    @Override
    public UserDetailsResponse saveUser(User newUser, String userRole) throws UserDetailsException {
        try {
            newUser.setPasswordChanged(false);
            newUser.setDetailsFilled(false);
            newUser.setPassword(bcryptEncoder.encode(this.generateAndSendOtp(newUser.getUsername(), newUser.getEmail()).toString()));
            Set<Role> roleSet = new HashSet<>();
            Role role;
            if (userRole == null || userRole.isEmpty() || userRole.isBlank()) {
                userRole = UserRoles.ORG_BUSINESS_OPS.name();
            }
            role = roleService.findByName(userRole);
            roleSet.add(role);
            newUser.setRoles(roleSet);
            User savedUser = userRepository.save(newUser);
            UserDetailsResponse savedUserResponse = mappingService.userToUserDetailsResponse(savedUser);
            return savedUserResponse;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException("Unable to save user details");
        }
    }

    /**
     * method to retrieve list of users and their info from current logged-in user's organization
     *
     * @return List<UserDetailsResponse> userDetails
     * @throws UserDetailsException
     */
    @Override
    public List<UserDetailsResponse> getUsersByOrganization(String status) throws UserDetailsException {
        Organization organization = this.getCurrentUser().getOrganization();
        try {
            List<User> users = null;
            if (status == null) {
                users = userRepository.findByOrganization(organization);
            } else {
                users = userRepository.findByOrganizationAndStatus(organization, status);
            }
            if (users.isEmpty() || users == null) {
                throw new UserDetailsException("Unable to retrieve users details");
            }
            List<UserDetailsResponse> userDetails = new ArrayList<>();
            users.forEach(user -> userDetails.add(mappingService.userToUserDetailsResponse(user)));
            return userDetails;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException(e.getMessage());
        }
    }

    /**
     * method to retrieve current logged-in user info and map it to UserDetailsResponse model class
     *
     * @return userDetailsResponse
     * @throws UserDetailsException
     */
    @Override
    public UserDetailsResponse getCurrentUserDetails() throws UserDetailsException {
        User user = this.getCurrentUser();
        if (user == null) {
            throw new UserDetailsException("Unable to retrieve user details");
        }
        UserDetailsResponse userDetailsResponse = mappingService.userToUserDetailsResponse(user);
        return userDetailsResponse;
    }

    /**
     * method to retrieve current logged-in user info
     *
     * @return User object
     */
    @Override
    public User getCurrentUser() throws UserDetailsException {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username;
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else {
            username = principal.toString();
        }
        try {
            User user = findOne(username);
            if (user == null) {
                throw new UserDetailsException("User info cannot be retrieved for username: " + username);
            }
            return user;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new UserDetailsException(e.getMessage());
        }
    }

    /**
     * Generating password for User and is sent to the registered {@link User#getEmail()}.
     *
     * @param username
     * @param email
     * @return password (one time 6 digit random password )
     */
    @Override
    public Integer generateAndSendOtp(String username, String email) throws AuthException {
        try {
            int password = 0;
            if (!(StringUtils.isBlank(username) || StringUtils.isBlank(email))) {
                //generating otp of 4 digit
                String name = username.substring(0, 1).toUpperCase() + username.substring(1);
                int otp = otpService.generateOTP(name);
                log.info("OTP generation successful.");
                //send otp to email...
                String subject = "OTP from SOCLY.io";
                String mail =
                        "<!doctype html>"
                                + "<html lang='en-US'>"

                                + "<body marginheight='0' topmargin='0' marginwidth='0' style='margin: 0px; background-color: #ffffff;' leftmargin='0'>"
                                + "	<table cellspacing='0' border='0' cellpadding='0' width='100%' bgcolor='#fffff' style='@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|OpenSans:300,400,600,700); font-family: ' Open Sans ', sans-serif;'>"
                                + "		<tr>"
                                + "			<td>"
                                + "				<table style='@import url(https: //fonts.googleapis.com/css?family=Rubik:300,400,500,700|OpenSans:300,400,600,700);' border='0' width='100%' cellspacing='0' cellpadding='0' bgcolor='#ffffff'>"
                                + "					<tbody>"
                                + "						<tr>"
                                + "							<td>"
                                + "								<table style='background-color: #ffffff; max-width: 670px; margin: 0 auto;' border='0' width='100%' cellspacing='0' cellpadding='0' align='center'>"
                                + "									<tbody>"
                                + "										<tr>"
                                + "											<td style='height: 80px;'>&nbsp;</td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td style='text-align: center;'><img title='logo' src='https://socly.io/wp-content/uploads/2021/09/cropped-cropped-cropped-cropped-SOCLY.IO_-3-1-1.png' alt='logo' height='80 width=' /></td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td style='height: 20px;'>&nbsp;</td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td>"
                                + "												<table style='max-width: 670px; background: #e6f5ff; border-radius: 3px; text-align: center; -webkit-box-shadow: 0 6px 18px 0 rgba(0,0,0,.06); -moz-box-shadow: 0 6px 18px 0 rgba(0,0,0,.06); box-shadow: 0 6px 18px 0 rgba(0,0,0,.06);' border='0' width='95%' cellspacing='0' cellpadding='0' align='center'>"
                                + "													<tbody>"
                                + "														<tr>"
                                + "															<td style='height: 40px;'>&nbsp;</td>"
                                + "														</tr>"
                                + "														<tr>"
                                + "															<td style='padding: 0 35px;'>"
                                + "																<p style='color: #455056; font-size: 15px; line-height: 14px;' align='left'>Hello "+ name+"!</p>"
                                + "																<p style='color: #455056; font-size: 15px; line-height: 19px;' align='left'>Please use the OTP given below for your first sign-in to SOCLY.io account <a href='https://www.appsocly.io'><strong>here</strong></a> :</p>"
                                + "																<br></br>"
                                + "																<h2 style='background: #00466a; margin : auto; width: max-content; padding: 10 10px; color: #fff; border-radius: 3px;'>" + otp + "</h2>"
                                + "																<br></br>"
                                + "																<p style='color: #455056; font-size: 15px; line-height: 34px; margin: 0;' align='left'>Regards,</p>"
                                + "																<p style='color: #455056; font-size: 15px; line-height: 18px; margin: 0;' align='left'>SOCLY.io</p>"
                                + "															</td>"
                                + "														</tr>"
                                + "														<tr>"
                                + "															<td style='height: 40px;'>&nbsp;</td>"
                                + "														</tr>"
                                + "													</tbody>"
                                + "												</table>"
                                + "											</td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td style='height: 20px;'>&nbsp;</td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td style='text-align: center;'>"
                                + "												<p style='font-size: 14px; color: rgba(69, 80, 86, 0.7411764705882353); line-height: 18px; margin: 0 0 0;'><strong>Copyright &copy; 2022 SOCLY.io</strong></p>"
                                + "											</td>"
                                + "										</tr>"
                                + "										<tr>"
                                + "											<td style='height: 80px;'>&nbsp;</td>"
                                + "										</tr>"
                                + "									</tbody>"
                                + "								</table>"
                                + "							</td>"
                                + "						</tr>"
                                + "					</tbody>"
                                + "				</table>"
                                + "</body>"
                                + "</html>";
                String to = email;
                emailService.sendMail(subject, mail, to);
                password = otp;
                log.info("Password is sent successfully");
            }

            return password;
        } catch (Exception e) {
            final String errorMessage = "Generated OTP not sent to email: "+email;
            log.error(errorMessage);
            throw new AuthException(errorMessage);
        }
    }
}