package com.compliance.soc.socly.audit.service;

import com.compliance.soc.socly.amazons3.dto.ComplianceApprovalResponse;
import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.entity.ComplianceApproval;
import com.compliance.soc.socly.audit.model.ComplianceApprovalDto;
import com.compliance.soc.socly.audit.model.ComplianceApprovalRequest;
import com.compliance.soc.socly.auth.entity.User;
import org.springframework.stereotype.Service;

import javax.validation.Valid;

/**
 * ComplianceApprovalService is an Interface create methods and implement methods in impl class
 */
@Service
public interface ComplianceApprovalService {
    ComplianceApprovalDto save(@Valid ComplianceApprovalRequest comp, User user) throws ComplianceApprovalException;

    ComplianceApproval findCompliance(@Valid ComplianceApprovalRequest comp, User user) throws ComplianceApprovalException;

    ComplianceApprovalResponse populateComplianceApprovalResp(ComplianceApprovalDto compliance) ;
    }
