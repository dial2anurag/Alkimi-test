package com.compliance.soc.socly.comment.exceptions;

/**
 *  CommentException is exception class to handle separately with others
 */
public class CommentException extends Exception {
    public CommentException(final Exception ex) {
        super(ex);
    }

    public CommentException(final String errorMsg) {
        super(errorMsg);
    }
}
