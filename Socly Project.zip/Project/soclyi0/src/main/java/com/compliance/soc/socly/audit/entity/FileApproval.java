package com.compliance.soc.socly.audit.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.enums.FileApprovalStatus;
import com.compliance.soc.socly.enums.validation.ValueOfEnum;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

/**
 * FileApproval is an entity class and properties from the FileApproval table
 */
@Entity
@Getter
@Setter
@Table(name = "file_approval")
public class FileApproval {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /*
     * the fileId  which is reference of AuditPeriod(fileId)
     */
    @Column(name = "file_id")
    private Integer fileId;
    /**
     * the status which shows auditStatus
     */
    @Column(name = "status")
    @ValueOfEnum(enumClass = FileApprovalStatus.class,  message = "Status should only be Approved/Rejected/NotYetEvaluated")
    private String status;
    /**
     * the complianceId which is reference of Metrics(complianceId)
     */
    @Column(name = "compliance_id")
    private String complianceId;
    /**
     * the principleId which is reference of MetricsMaster(metricsId)
     */
    @Column(name = "principle_id")
    private Integer principleId;
    /**
     * the createdDate shows on which date it is created
     */
    @Column(name = "created_date")
    private Date createdDate = new Date();
    /**
     * the modifiedDate shows on which date it is modified
     */
    @Column(name = "modified_date")
    private Date modifiedDate;
    /**
     * the createdBy shows from which user it is being created
     */
    @Column(name = "created_by")
    private Long createdBy;
    /**
     * the modifiedBy shows from which user it is being modified
     */
    @Column(name = "modified_by")
    private Long modifiedBy;
    /**
     * the auditNote is to write audit comment while approving File
     */
    @Column(name = "audit_note", columnDefinition = "Text")
    private String auditNote;
    /**
     * In this mapping is done through AuditPeriod and FileApproval with reference of auditId
     */
    @ManyToOne(targetEntity = AuditPeriod.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "audit_id", referencedColumnName = "id")
    private AuditPeriod auditPeriod;

    @ManyToOne(targetEntity = Organization.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "client_id", referencedColumnName = "id")
    private Organization organization;

}
