package com.compliance.soc.socly.policycenter.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.enums.PolicyStatus;
import com.compliance.soc.socly.enums.validation.ValueOfEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.Date;

/**
 * OrgPolicy is an entity class and properties from the org_policy table
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "org_policy",uniqueConstraints = { @UniqueConstraint(name = "UniqueFileNameAndOrgId",columnNames = { "file_name", "org_id" }) })
public class OrgPolicy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "file_name")
    private String filename;

    @Column(name = "status")
    @ValueOfEnum(enumClass = PolicyStatus.class,  message = "Status should only be InProgress, SendToApproval, Approved , Rejected, RequestChange")
    private String policyStatus;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "approved_on")
    private Date approvedOn;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Organization.class)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private Organization organization;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name = "created_by", referencedColumnName = "id")
    private User createdBy;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name = "approved_by", referencedColumnName = "id")
    private User approvedBy;

    @Column(name = "comments", columnDefinition = "Text")
    private String comments;
}
