package com.compliance.soc.socly.email.controller;

import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.impl.UserServiceImpl;
import com.compliance.soc.socly.email.dto.OtpResponse;
import com.compliance.soc.socly.email.service.DummyPasswordService;
import com.compliance.soc.socly.email.service.EmailService;
import com.compliance.soc.socly.email.service.OTPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;
import java.util.Random;

@Slf4j
@Controller
@RequestMapping("/forgotpassword")
public class ForgotPasswordController {
    Random random = new Random(1000);

    @Autowired
    private EmailService emailService;

    @Autowired
    private OTPService otpService;

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private DummyPasswordService dummyPasswordService;

    @Autowired
    private BCryptPasswordEncoder bcrypt;

    @PreAuthorize("hasRole('ORG_BUSINESS_OPS')")
    @RequestMapping("/forgot")
    public String openForgotPasswordPopUp() {
        return "forgot_password_form";
    }

    /**
     * API to send otp to specified mail in case user clicks on forgot password
     * @param email
     * @param session for current logged-in user details
     * @return otp sent/ not sent notification message
     */
    @PreAuthorize("hasRole('ORG_BUSINESS_OPS')")
    @PostMapping("/send-otp")
    public ResponseEntity<OtpResponse> sendOTP(@RequestParam("email") String email, HttpSession session) throws MessagingException {
        log.info("Otp to be sent to: {}",email);
        User user = this.userService.getUserByEmail(email);

        if (user == null) {
            //send error message
            session.setAttribute("message", "Please try with registered email id.");
            OtpResponse otpResponse = new OtpResponse("Please try with registered email id.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(otpResponse);
            //return "forgot_password_form";
        } else {
            //generating otp of 4 digit
            String username = user.getUsername();
            //int otp = random.nextInt(999999);
            int otp = this.otpService.generateOTP(username);
            log.info("otp will be sent to your email");
            //send otp to email...
            String subject = "OTP From Socly.io";
            String mail = ""
                    + "<div style='border:1px solid #e2e2e2; padding:20px'>"
                    + "<h2> Hi " + username + ",</h2>"
                    + "<br/>"
                    + "<h2> Your otp pin is " + otp + "</h2> "
                    + "<br/>"
                    + "Thanks, "
                    + "</div>";
            String to = email;
            this.emailService.sendMail(subject, mail, to);
            session.setAttribute("email", email);
            session.setAttribute("message", "OTP sent.");
            OtpResponse otpResponse = new OtpResponse("OTP sent. Please check your email. ");
            return ResponseEntity.status(HttpStatus.OK).body(otpResponse);
            //return "verify_otp";
        }
    }
    /**
     * API to send otp to verify otp that user inputs after receiving otp in mail
     * and send system generated password to the same mail, if verified correctly
     * @param otpString as string
     * @param session for current logged-in user details
     * @return  valid/ invalid otp notification message
     */
    @PreAuthorize("hasRole('ORG_BUSINESS_OPS')")
    @PostMapping("/verify-otp")
    public ResponseEntity<OtpResponse> verifyOtp(@RequestParam("otp") String otpString, HttpSession session) {
        //int myOtp = (int) session.getAttribute("myotp");
        final String SUCCESS = "Entered otp is valid. New password sent to email";
        final String FAIL = "Entered otp is not valid. Please Retry.";
        String email = (String) session.getAttribute("email");
        User user = this.userService.getUserByEmail(email);
        String username = user.getUsername();
        int otp = -1;
        try {
            otp = Integer.parseInt(otpString);
        }catch (NumberFormatException e){
            log.error(e.getLocalizedMessage());
        }
        if (otp >= 0) {
            int serverOtp = otpService.getOtp(username);
            if (serverOtp > 0) {
                if (otp == serverOtp) {
                    otpService.clearOTP(username);
                    user.setPasswordChanged(false);// so that change password is prompted on re-login with dummy password
                    //generate dummy password
                    String dummyPassword = dummyPasswordService.generateDummyPassword();
                    user.setPassword(bcrypt.encode(dummyPassword));
                    userService.update(user.getId(),user);
                    //send generated dummy password to mail
                    String subject = "System Generated Password From Socly.io";
                    String mail = ""
                            + "<div style='border:1px solid #e2e2e2; padding:20px'>"
                            + "<h2> Hi " + username + ",</h2>"
                            + "<br/>"
                            + "<h2> Your system generated password is " + dummyPassword + "</h2> "
                            + "<br/>"
                            + "Thanks, "
                            + "</div>";
                    String to = email;
                    this.emailService.sendMail(subject, mail, to);
                    log.info("User OTP sent successufully");
                    OtpResponse otpResponse = new OtpResponse(SUCCESS);
                    return ResponseEntity.status(HttpStatus.OK).body(otpResponse);
                    //return (SUCCESS);
                } else {
                    OtpResponse otpResponse = new OtpResponse(FAIL);
                    return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(otpResponse);
                    // return FAIL;
                }
            } else {
                OtpResponse otpResponse = new OtpResponse(FAIL);
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(otpResponse);
                //return FAIL;
            }
        } else {
            OtpResponse otpResponse = new OtpResponse(FAIL);
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(otpResponse);
            //return FAIL;
        }

    }
}
