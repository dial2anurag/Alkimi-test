package com.compliance.soc.socly.auth.service;

import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.model.PasswordDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class PasswordService {

    @Autowired
    private BCryptPasswordEncoder bcryptEncoder;

    @Autowired
    private UserService userService;

    /**
     * method to check if old password and to be set new password are same or not
     * @param passwordDto
     * @return true/ false
     */
    public boolean isPasswordDtoValid(PasswordDto passwordDto) throws AuthException {
        String username = null;
        try {
            User user = userService.getCurrentUser();
            username = user.getUsername();
            if (!(bcryptEncoder.matches(passwordDto.getOldPassword(), user.getPassword())))
                return false;
            if (!isPasswordValid(passwordDto.getNewPassword())) {
                return false;
            }
            return true;
        }catch(Exception e){
            log.error("Password could not be validated for user: {} ",username,e.getMessage());
            throw new AuthException("Password could not be validated for user: "+username+" "+e.getMessage());
        }
    }

    private boolean isPasswordValid(String newPassword) {
        return true;
    }

}
