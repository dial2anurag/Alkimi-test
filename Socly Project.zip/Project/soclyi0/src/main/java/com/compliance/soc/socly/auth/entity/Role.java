package com.compliance.soc.socly.auth.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;
import java.util.List;

@Entity
@Getter
@Setter
/**
 * Role is an entity class and properties from the ROLE table
 */
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    /**
     * Name of the role
     */
    @Column(unique = true)
    private String name;

    @Column
    private String description;

    @Column(unique = true)
    private Boolean superAdmin;
    /**
     * active organization can view in orgView.
     */
    @Column
    private Boolean orgView;

    @Column
    private String status;

    @ManyToMany(mappedBy = "roles")
    @JsonIgnoreProperties("roles")
    private List<User> users;

}