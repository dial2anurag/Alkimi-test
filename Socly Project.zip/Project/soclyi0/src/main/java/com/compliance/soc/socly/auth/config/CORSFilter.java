package com.compliance.soc.socly.auth.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CORSFilter implements Filter {
    @Value("${allowed.origin}")
    private String allowedOrigin;

    @Override
    public void doFilter(ServletRequest servletRequest,
                         ServletResponse servletResponse,
                         FilterChain filterChain) throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        HttpServletRequest request = (HttpServletRequest) servletRequest;

        String[] originArray = allowedOrigin.split(",");
        if (originArray.length > 0) {
            String requestOrigin = request.getHeader("Origin");
            String userAgent = request.getHeader("User-Agent").toLowerCase();
            if (userAgent.contains("postman") || requestOrigin == null ||
                    (!Arrays.stream(originArray).anyMatch(requestOrigin::equalsIgnoreCase))) {
                response.setHeader("Access-Control-Allow-Origin", allowedOrigin);
            } else {
                response.setHeader("Access-Control-Allow-Origin", requestOrigin);
            }
        } else {
            response.setHeader("Access-Control-Allow-Origin", allowedOrigin);
        }

        response.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE, PATCH");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Headers", "Origin, Content-Type, Accept," +
                " Authorization, Content-Type, Access-Control-Allow-Credentials," +
                " X-Amz-Date, X-Api-Key, X-Amz-Security-Token");
        response.setHeader("Access-Control-Expose-Headers", "Location");
        response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}