package com.compliance.soc.socly.amazons3.dto;

public class FileRequestInformation {
    private String fileName;
    private String base64Content;

    public FileRequestInformation() {
    }

    public FileRequestInformation(String fileName, String base64Content) {
        this.fileName = fileName;
        this.base64Content = base64Content;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getBase64Content() {
        return base64Content;
    }

    public void setBase64Content(String base64Content) {
        this.base64Content = base64Content;
    }
}
