package com.compliance.soc.socly.contactus.Exception;

import java.io.IOException;
/**
 *  ContactUsException is exception class to handle separately with others
 */
public class ContactUsException extends IOException {

    public ContactUsException(final Exception ex) {
        super(ex);
    }

    public ContactUsException(final String errorMsg) {
        super(errorMsg);
    }
}
