package com.compliance.soc.socly.cloudservice.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
/*
It is a Dto to provide- cloud services
 */
public class CloudServiceDto {
    private int id;
    private String name;
    private List<ServiceProviderDto> providers;
}
