package com.compliance.soc.socly.cloud.azure.exception;

public class AzureServiceException extends Exception{
    String message;

    public AzureServiceException(String message) {
        this.message=message;
    }
    public AzureServiceException(Exception ex) {
        super(ex);
    }

}
