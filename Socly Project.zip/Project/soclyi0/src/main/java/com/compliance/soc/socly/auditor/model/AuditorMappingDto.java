package com.compliance.soc.socly.auditor.model;

import com.compliance.soc.socly.audit.model.FrameworkDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This is a model class used as DTO to get auditorId, organizationId, frameworkId for AuditorMapping creation
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AuditorMappingDto {
    private AuditorDto auditorDto;
    private OrganizationDto organizationDto;
    private FrameworkDto frameworkDto;

}
