package com.compliance.soc.socly.auth.model;

import com.compliance.soc.socly.enums.UserStatus;
import com.compliance.soc.socly.enums.validation.ValueOfEnum;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class UserUpdateDto {
    @NotNull(message = "Username cannot be null.")
    private String username;
    private Long[] roleIds;
    @Pattern(regexp="(^$|[0-9]{10})")
    private String phone;
    @ValueOfEnum(enumClass = UserStatus.class,  message = "Status should only be Active/InActive.")
    private String status;
}
