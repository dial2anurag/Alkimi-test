package com.compliance.soc.socly.common;

import javax.persistence.*;

@Entity
@Table(name = "ClientSaasMapping")
public class ClientSaasMapping {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int clientSaasId;
    @Column
    private int clientId;
    @Column
    private String organizationName;
    @Column
    private String saasId;
    @Column
    private String isActive;

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getSaasId() {
        return saasId;
    }

    public void setSaasId(String saas_Id) {
        saasId = saas_Id;
    }

    public String isActive() {
        return isActive;
    }

    public void setActive(String active) {
        isActive = active;
    }

    public int getClientSaasId() {
        return clientSaasId;
    }

    public void setClientSaasId(int clientSaasId) {
        this.clientSaasId = clientSaasId;
    }
}