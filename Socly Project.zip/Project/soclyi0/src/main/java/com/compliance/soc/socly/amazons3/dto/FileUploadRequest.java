package com.compliance.soc.socly.amazons3.dto;

public class FileUploadRequest {
    private String source;
    private String complianceId;
    private FileRequestInformation[] files;

    public FileUploadRequest() {
    }

    public FileUploadRequest(String source, String complianceId, FileRequestInformation[] files) {
        this.source = source;
        this.complianceId = complianceId;
        this.files = files;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getComplianceId() {
        return complianceId;
    }

    public void setComplianceId(String complianceId) {
        this.complianceId = complianceId;
    }

    public FileRequestInformation[] getFiles() {
        return files;
    }

    public void setFiles(FileRequestInformation[] files) {
        this.files = files;
    }
}
