package com.compliance.soc.socly.auth.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class RoleDto {
    private long id;
    private String name;
    private String description;
    private Boolean superAdmin;
    private Boolean orgView;
    private String status;
    @JsonIgnoreProperties("userFromUserDto")
    private List<UserDto> users;

}
