package com.compliance.soc.socly.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/")
public class ClientSaasMappingApi {

    @Autowired
    ClientSaasMappingService clientSaasMappingService;

    @GetMapping("/active/saasintegrations")
    public List<String> getActiveSaasIntegrations(@RequestParam("orgName") String organizationName, @RequestParam("active") String active) {
        List<String> l = new ArrayList<>();
        String message = null;
        if (organizationName.trim().isEmpty() || active.trim().isEmpty()) {
            message = "Parameter orgName & active must be provided with values";
            l.add(message);
            return l;
        }

        ClientSaasMapping[] clientSaasMappings = clientSaasMappingService.getClientSaasRecordOnStatus(organizationName, active);

        if (clientSaasMappings != null && clientSaasMappings.length > 0) {
            for (ClientSaasMapping clientSaasMapping : clientSaasMappings) {
                l.add(clientSaasMapping.getSaasId());
            }
            return l;
        } else message = "No records exist for the given orgName & status";
        l.add(message);
        return l;
    }
}
