package com.compliance.soc.socly.audit.repository;

import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.organization.entity.Framework;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * AuditPeriodRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface AuditPeriodRepository extends JpaRepository<AuditPeriod, Integer> {

    /**
     * jpa method to find AuditPeriod table records by organisation and status
     *
     * @param organization
     * @param status
     * @return List<AuditPeriod>
     */

    List<AuditPeriod> findByOrganizationAndStatus(Organization organization, Character status);

    /**
     * jpa method to find All AuditPeriod records by organization.
     *
     * @param organization
     * @return
     */
    List<AuditPeriod> findAllByOrganization(Organization organization);

    /**
     * jpa method to find one AuditPeriod record by organization and status.
     *
     * @param organization
     * @param status
     * @return
     */
    AuditPeriod findOneByOrganizationAndStatus(Organization organization, char status);

    /**
     * jpa method to find AuditPeriod records by organization and status.
     *
     * @param organization
     * @param status
     * @return
     */
    List<AuditPeriod> findByOrganizationAndStatus(Organization organization, String status);

    /**
     * jpa method to find AuditPeriod records by organization and status and framework.
     *
     * @param organization
     * @param status
     * @param framework
     * @return
     */
    AuditPeriod findOneByOrganizationAndStatusAndFramework(Organization organization, String status, Framework framework);

    /**
     * jpa method to find AuditPeriod records by Status and frameworkId
     *
     * @param status
     * @param frameworkId
     * @return
     */
    List<AuditPeriod> findByStatusAndFrameworkId(String status, Integer frameworkId);

    /**
     * jpa method to find AuditPeriod records by AuditId.
     *
     * @param auditId
     * @return
     */
    AuditPeriod findByAuditId(Integer auditId);

    /**
     * jpa method to save AuditPeriod records.
     *
     * @param audit
     * @return
     */
    AuditPeriod save(AuditPeriod audit);
}
