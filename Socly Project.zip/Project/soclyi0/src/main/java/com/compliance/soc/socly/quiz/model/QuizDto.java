package com.compliance.soc.socly.quiz.model;

import com.compliance.soc.socly.auth.model.UserDetailsResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class QuizDto {
    @JsonIgnoreProperties("quizDetail")
    private UserDetailsResponse userDetails;
    private Integer score;
    private Boolean pass;
    private Date date;
}