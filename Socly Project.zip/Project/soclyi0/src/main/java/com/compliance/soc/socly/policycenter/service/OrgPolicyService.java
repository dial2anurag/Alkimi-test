package com.compliance.soc.socly.policycenter.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.enums.FileExtension;
import com.compliance.soc.socly.enums.PolicyCenter;
import com.compliance.soc.socly.enums.PolicyStatus;
import com.compliance.soc.socly.policycenter.entity.OrgPolicy;
import com.compliance.soc.socly.policycenter.exception.OrgPolicyException;
import com.compliance.soc.socly.policycenter.model.OrgPolicyDto;
import com.compliance.soc.socly.policycenter.model.PolicyDto;
import com.compliance.soc.socly.policycenter.model.PolicyFileResponse;
import com.compliance.soc.socly.policycenter.repository.OrgPolicyRepository;
import com.compliance.soc.socly.util.s3.S3Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Slf4j
@Service
public class OrgPolicyService {
    @Autowired
    private OrgPolicyRepository orgPolicyRepository;

    @Autowired
    private OrgMasterService orgMasterService;

    @Autowired
    private UserService userService;

    @Autowired
    private S3Util s3Util;

    @Value("${s3Bucket.policy.template}")
    private String policyTemplateLocation;

    @Value("${s3Bucket.policies}")
    private String s3BucketPolicies;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private AmazonS3 s3Client;

    /**
     * method to save the values to org_policy table
     *
     * @param orgPolicyDto
     * @param multipartFile
     * @return
     * @throws OrgPolicyException
     */
    public OrgPolicyDto unapprovedSave(OrgPolicyDto orgPolicyDto, MultipartFile multipartFile) throws OrgPolicyException {
        try {
            final OrgPolicy orgPolicy = this.handleOrgPolicyUpdate(orgPolicyDto);
            if (multipartFile != null) {
                orgPolicy.setFilename(multipartFile.getOriginalFilename());
            }
            orgPolicy.setPolicyStatus(orgPolicyDto.getPolicyStatus().name());
            final Organization organization = orgPolicy.getOrganization();
            final OrgPolicy savedOrgPolicy = orgPolicyRepository.save(orgPolicy);
            String unapprovedFolder = PolicyCenter.data + "/" + PolicyCenter.policy_center + "/" + PolicyCenter.unapproved + "/";
            if (multipartFile != null) {
                this.saveFileInS3Bucket(multipartFile, organization, unapprovedFolder);
            }
            return populateOrgPolicyDto(savedOrgPolicy);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new OrgPolicyException(exception);
        }
    }

    /**
     * method to populate data of org_policy and after saved to orgPolicyDto and similar to organization and user.
     *
     * @param savedOrgPolicy
     * @return
     * @throws UserDetailsException
     */
    private OrgPolicyDto populateOrgPolicyDto(OrgPolicy savedOrgPolicy) throws UserDetailsException {
        final OrgPolicyDto policyDto = new OrgPolicyDto();
        policyDto.setId(savedOrgPolicy.getId());
        policyDto.setPolicyStatus(Enum.valueOf(PolicyStatus.class, savedOrgPolicy.getPolicyStatus()));
        policyDto.setFilename(savedOrgPolicy.getFilename());
        policyDto.setApprovedOn(savedOrgPolicy.getApprovedOn());
        policyDto.setCreatedOn(savedOrgPolicy.getCreatedOn());

        final Organization organization = savedOrgPolicy.getOrganization();
        final OrganizationDto organizationDto = new OrganizationDto();
        organizationDto.setOrgName(organization.getOrgName());
        organizationDto.setDescription(organization.getDescription());
        organizationDto.setClientId(organization.getId());
        organizationDto.setParentId(organization.getParentId());
        organizationDto.setDetailFilled(organization.isDetailFilled());
        organizationDto.setStatus(organization.getStatus());
        organizationDto.setRegisteredDateTime(organization.getRegisteredDateTime());
        policyDto.setOrganizationDto(organizationDto);

        policyDto.setCreatedBy(userService.getUserDto(savedOrgPolicy.getCreatedBy()));
        if (savedOrgPolicy.getApprovedBy() != null) {
            policyDto.setApprovedBy(userService.getUserDto(savedOrgPolicy.getApprovedBy()));
        }
        policyDto.setComments(savedOrgPolicy.getComments());
        return policyDto;
    }

    /**
     * @param orgPolicyDto
     * @return
     */
    private OrgPolicy handleOrgPolicyUpdate(final OrgPolicyDto orgPolicyDto) throws OrgPolicyException {
        try {
            OrgPolicy orgPolicy = null;
            final Integer orgPolicyId = orgPolicyDto.getId();
            if (orgPolicyId != null && orgPolicyId > 0) {
                orgPolicy = orgPolicyRepository.findById(orgPolicyId).get();
                String previousComment = orgPolicy.getComments();
                if (orgPolicyDto.getPolicyStatus().equals(PolicyStatus.RequestChange)) {
                    String nextComment = previousComment != null ? previousComment + "," + orgPolicyDto.getComments() : orgPolicyDto.getComments();
                    orgPolicy.setComments(nextComment);
                }
            } else {
                orgPolicy = new OrgPolicy();
                orgPolicy.setCreatedOn(new Date());
                final User currentUser = userService.getCurrentUser();
                orgPolicy.setCreatedBy(currentUser);
                orgPolicy.setOrganization(currentUser.getOrganization());
            }
            return orgPolicy;
        } catch (final Exception ex) {
            log.error("Data of orgPolicy is not updated due to" + ex.getMessage());
            throw new OrgPolicyException(ex);
        }
    }

    /**
     * retrieve org_policy records based on policyStatus or on SendToApproval and RequestChange (if policyStatus is null)
     *
     * @param policyStatus
     * @return policiesDto (list of policies)
     */
    public List<OrgPolicyDto> getPolicies(PolicyStatus policyStatus) throws OrgPolicyException {
        try {
            List<OrgPolicyDto> policiesDto = new ArrayList<>();
            List<OrgPolicy> policies = new ArrayList<>();
            final Organization organization = userService.getCurrentUser().getOrganization();
            PolicyStatus[] policyStatuses = this.getStatus(policyStatus);
            log.info("policies to be fetched for status(es): {}", policyStatuses);
            for (PolicyStatus status : policyStatuses) {
                policies.addAll(orgPolicyRepository.findByOrganizationAndPolicyStatus(organization, status.name()));
            }
            policies.forEach(orgPolicy -> {
                try {
                    policiesDto.add(this.populateOrgPolicyDto(orgPolicy));
                } catch (UserDetailsException e) {
                    log.error("OrgPolicy entity to DTO conversion could not be done due to " + e.getMessage());
                }
            });
            return policiesDto;
        } catch (Exception e) {
            String message = "Unable to fetch the policies pending for approval due to : " + e.getMessage();
            log.error(message);
            throw new OrgPolicyException(message);
        }
    }

    /**
     * get statuses SendToApproval and RequestChange if argument policyStatus is null, else get status based on
     * argument.
     *
     * @param policyStatus
     * @return statusArray
     */
    private PolicyStatus[] getStatus(PolicyStatus policyStatus) {
        PolicyStatus[] statusArray;
        if (policyStatus == null) {
            statusArray = new PolicyStatus[]{
                    PolicyStatus.SendToApproval,
                    PolicyStatus.RequestChange};
        } else {
            statusArray = new PolicyStatus[]{policyStatus};
        }
        return statusArray;
    }

    /**
     * move approved file from policy-center/unapproved to policy_center and update org_policy table in db
     *
     * @param orgPolicyDto
     * @return String message
     * @throws OrgPolicyException
     */
    public OrgPolicyDto approvePolicy(OrgPolicyDto orgPolicyDto, MultipartFile multipartFile) throws OrgPolicyException {
        try {
            boolean validRequest = this.validatePolicyApprovalRequest(orgPolicyDto, multipartFile);
            if (!validRequest) {
                throw new OrgPolicyException("Policy approval request is invalid.");
            }
            final String policyCenterBucketFolder = PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name() + "/";
            final User currentUser = userService.getCurrentUser();
            this.saveFileInS3Bucket(multipartFile, currentUser.getOrganization(), policyCenterBucketFolder);
            final OrgPolicy savedOrgPolicy = this.updateOrgPolicy(orgPolicyDto, currentUser, multipartFile.getOriginalFilename());
            final OrgPolicyDto savedOrgPolicyDto = this.populateOrgPolicyDto(savedOrgPolicy);
            log.info("Policy approved and saved for file " + multipartFile.getOriginalFilename() + " and id: " + orgPolicyDto.getId() + ". ");
            return savedOrgPolicyDto;
        } catch (Exception exception) {
            String message = "Failed to approve the policy file " + multipartFile.getOriginalFilename() + " and id: " + orgPolicyDto.getId() + ". " + exception.getMessage();
            log.error(message);
            throw new OrgPolicyException(message);
        }
    }

    /**
     * Validating approve policy request
     *
     * @param orgPolicyDto
     * @param multipartFile
     * @return true/false
     */
    private boolean validatePolicyApprovalRequest(OrgPolicyDto orgPolicyDto, MultipartFile multipartFile) {
        boolean valid = true;
        String filename = multipartFile.getOriginalFilename();
        if (multipartFile.isEmpty()) {
            log.error("No file found in request.");
            valid = false;
        } else if (!orgPolicyDto.getPolicyStatus().name().equals(PolicyStatus.Approved.name())) {
            log.error("PolicyStatus must be Approved only. Given status: " + orgPolicyDto.getPolicyStatus() + ".");
            valid = false;
        } else if (!filename.contains(FileExtension.pdf.name()) && !filename.contains(FileExtension.txt.name())) {
            log.error("File must be of type pdf or txt. Given file has extension: " + this.findExtension(multipartFile.getOriginalFilename()) + ".");
            valid = false;
        }
        return valid;
    }

    /**
     * Update approvedBy, pdfFilename, organization, policyStatus in orgPolicy table
     *
     * @param orgPolicyDto
     * @param currentUser
     * @param pdfFilename
     * @return savedOrgPolicy
     * @throws OrgPolicyException
     */
    private OrgPolicy updateOrgPolicy(OrgPolicyDto orgPolicyDto, User currentUser, String pdfFilename) throws OrgPolicyException {
        try {
            OrgPolicy orgPolicy = orgPolicyRepository.findById(orgPolicyDto.getId()).get();
            orgPolicy.setApprovedOn(new Date());
            orgPolicy.setApprovedBy(currentUser);
            orgPolicy.setFilename(pdfFilename);
            orgPolicy.setPolicyStatus(orgPolicyDto.getPolicyStatus().name());
            OrgPolicy savedOrgPolicy = orgPolicyRepository.save(orgPolicy);
            log.info("org_policy table record created for file: {} and id: {}", pdfFilename, orgPolicyDto.getId());
            return savedOrgPolicy;
        } catch (Exception e) {
            String message = "Unable to update org policy details. " + e.getMessage();
            log.error(message);
            throw new OrgPolicyException(message);
        }
    }


    /**
     * In this method file is saved under the specific Organization S3bucket inside the unapproved folder.
     *
     * @param multipartFile
     * @param organization
     * @param folderName
     * @return
     * @throws OrgPolicyException
     */
    private void saveFileInS3Bucket(final MultipartFile multipartFile, final Organization organization, final String folderName) throws OrgPolicyException {
        try {
            final File file = new File(multipartFile.getOriginalFilename());
            final FileOutputStream fos = new FileOutputStream(file);
            fos.write(multipartFile.getBytes());
            fos.close();
            DataUpload2FolderRequest dataUpload2FolderRequest = new DataUpload2FolderRequest();
            dataUpload2FolderRequest.setBucketName(organization.getOrgName().toLowerCase());
            dataUpload2FolderRequest.setFolderName(folderName);
            dataUpload2FolderRequest.setData(new FileInputStream(file));
            dataUpload2FolderRequest.setKey(multipartFile.getOriginalFilename());
            final boolean uploaded = s3Util.uploadUnderFolder(dataUpload2FolderRequest);
            if (!uploaded) {
                throw new OrgPolicyException("Policy approval failed! , As system not able to upload files in S3");
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new OrgPolicyException(exception);
        }
    }

    /**
     * get file extension
     *
     * @param filename
     * @return extension
     */
    private String findExtension(String filename) {
        if (filename == null) {
            throw new IllegalArgumentException("Filename cannot be null.");
        }
        int indexOfExtension = filename.lastIndexOf(".");
        String extension = filename.substring(indexOfExtension + 1);
        return extension;
    }


    /**
     * Fetching policy file
     *
     * @param fileName gives the fileName, which is used to fetch policy/template file.
     * @param reset    : is a boolean value to decide to fetch template/file
     * @return file if it exists in unapproved else the template in DevUtility Bucket.
     * @throws OrgPolicyException
     */
    public PolicyFileResponse fetchTempPolicy(final String fileName, boolean reset) throws OrgPolicyException {
        Organization organization = null;
        try {
            S3Object policyFileS3Object;
            String policyFileFolder;
            S3ObjectInputStream s3ObjectInputStream;
            String bucket;
            final PolicyFileResponse fileResponse = new PolicyFileResponse();
            organization = userService.getCurrentUser().getOrganization();
            if (organization != null) {
                OrgPolicy orgPolicy = orgPolicyRepository.findByFilenameAndOrganization(fileName, organization);
                if (reset || orgPolicy == null) {
                    bucket = policyTemplateLocation;
                    policyFileFolder = PolicyCenter.policy_center.name() + "/";
                } else if (orgPolicy != null) {
                    //Check whether there is an entry for the file in the DB.
                    bucket = organization.getOrgName().toLowerCase(Locale.ROOT);
                    fileResponse.setDetails(this.populateOrgPolicyDto(orgPolicy));
                    policyFileFolder = PolicyCenter.data + "/" + PolicyCenter.policy_center + "/" + PolicyCenter.unapproved + "/";
                } else {
                    throw new OrgPolicyException(fileName + "file does not exist");
                }
            } else {
                throw new OrgPolicyException("Not able to get the associated organization ");
            }
            policyFileS3Object = s3Util.getObjectS3(bucket, policyFileFolder, fileName);
            if (policyFileS3Object == null) {
                throw new FileNotFoundException(fileName + "file does not exist ");
            }
            s3ObjectInputStream = policyFileS3Object.getObjectContent();
            log.info(String.valueOf(s3ObjectInputStream));
            final InputStreamResource streamResource = new InputStreamResource(s3ObjectInputStream);
            fileResponse.setFileContent(streamResource.getInputStream().readAllBytes());
            return fileResponse;
        } catch (Exception exception) {
            log.error("Unable to fetch the file {}  for the organization {} due to the following error {} ", fileName, organization.getOrgName(), exception);
            throw new OrgPolicyException(exception);
        }
    }

    /**
     * TODO :
     * 1. Interface implementation
     * 2. Method comments
     * <p>
     * Service layer method that used to fetch the policy files from S3 bucket
     *
     * @return : List<PolicyDto>
     */
    public List<PolicyDto> fetchPolicies() throws OrgPolicyException {
        try {
            final ListObjectsRequest policiesRequest = new ListObjectsRequest()
                    .withBucketName(policyTemplateLocation.toLowerCase());
            ObjectListing policiesS3Object = s3Util.listObjects(policiesRequest);
            List<PolicyDto> policyDtos = new ArrayList<>();
            while (true) {
                final List<S3ObjectSummary> policiesS3ObjectSummaries = policiesS3Object.getObjectSummaries();
                if (policiesS3ObjectSummaries.size() < 1) {
                    break;
                }
                // populating filenames to policyDtos
                this.populateFilenames(policyDtos, policiesS3ObjectSummaries);
                policiesS3Object = s3Client.listNextBatchOfObjects(policiesS3Object);
            }
            return policyDtos;
        } catch (final Exception ex) {
            log.error("Failed to get the lists of policies.. due to the error {}", ex.getMessage());
            throw new OrgPolicyException(ex);
        }
    }

    /**
     * method to populate the names in the file list
     *
     * @param policyDtos
     * @param policiesS3ObjectSummaries
     */
    private void populateFilenames(final List<PolicyDto> policyDtos, final List<S3ObjectSummary> policiesS3ObjectSummaries) {
        final String policyCentreFolder = PolicyCenter.policy_center.name() + "/";
        policiesS3ObjectSummaries.stream().filter(policiesS3ObjectSummary -> policiesS3ObjectSummary.getKey().contains(policyCentreFolder)).
                collect(Collectors.toList()).forEach(policiesS3ObjectSummary -> {
                    final String filename = policiesS3ObjectSummary.getKey().replace(policyCentreFolder, "");
                    if (!filename.isEmpty() && !filename.isBlank()) {
                        log.info("Filename : {}", filename);
                        policyDtos.add(PolicyDto.builder()
                                .name(filename.replace("." + FileExtension.txt.name(), ""))
                                .build());
                    }
                });
    }

    /**
     * Api to download the Approved policy file.
     *
     * @param orgPolicyId id of the org_policy table.
     * @return Download the Approved policy file.
     * @throws OrgPolicyException
     */
    public S3ObjectInputStream downloadPolicy(int orgPolicyId) throws OrgPolicyException {
        try {
            OrgPolicy orgPolicy = orgPolicyRepository.findById(orgPolicyId);
            S3ObjectInputStream s3ObjectInputStream;
            if (orgPolicy.getPolicyStatus().equals(PolicyStatus.Approved.name())) {
                String bucket = userService.getCurrentUser().getOrganization().getOrgName().toLowerCase(Locale.ROOT);
                String policyFileFolder = PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name() + "/";
                S3Object policyFileS3Object = null;
                String fileName = orgPolicy.getFilename();
                policyFileS3Object = s3Util.getObjectS3(bucket, policyFileFolder, fileName);
                s3ObjectInputStream = policyFileS3Object.getObjectContent();
            } else {
                throw new OrgPolicyException("There is no Approved file is present by the given id " + orgPolicyId);
            }
            return s3ObjectInputStream;
        } catch (Exception exception) {
            log.error("Unable to fetch the Approved File {} due to the following error {} " + exception);
            throw new OrgPolicyException(exception);
        }
    }
}