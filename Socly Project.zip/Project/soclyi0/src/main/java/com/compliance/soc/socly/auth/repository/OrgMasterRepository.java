package com.compliance.soc.socly.auth.repository;

import com.compliance.soc.socly.auth.entity.Organization;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface OrgMasterRepository extends CrudRepository<Organization, BigInteger> {
    List<Organization> findAll();

    Organization findByOrgName(String organizationName);

    Boolean existsByOrgNameIgnoreCase(String organizationName);

    Organization findById(Long Id);

    List<Organization> findAllByStatus(String status);
}
