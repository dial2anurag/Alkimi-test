package com.compliance.soc.socly.common.service;

import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.ComplianceFramework;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.SaasProvider;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Timestamp;

public class BaseService {

    @Autowired
    protected UserService userService;

    @Autowired
    protected StorageService storageService;

    /**
     * @param clientId           : bucket Name
     * @param complianceResponse : Response to be persists
     */
    protected void persistsJSONResponse(final String clientId, final ComplianceResponse complianceResponse) {
        final String keyName = clientId + "_gsuite_response" + new Timestamp(System.currentTimeMillis());
        final DataUpload2FolderRequest dataUpload2FolderRequest = new DataUpload2FolderRequest();
        dataUpload2FolderRequest.setBucketName(clientId.toLowerCase());
        dataUpload2FolderRequest.setFolderName(ComplianceFramework.SOC2.name() + "/" + SaasProvider.GSUITE.name() + "/");
        dataUpload2FolderRequest.setData(complianceResponse);
        dataUpload2FolderRequest.setKey(keyName);
        storageService.uploadUnderFolder(dataUpload2FolderRequest);
    }
}
