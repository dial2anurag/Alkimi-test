package com.compliance.soc.socly.alert.repository;

import com.compliance.soc.socly.alert.exceptions.SoclyAlertException;
import com.compliance.soc.socly.alert.entity.Compliance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * ComplianceRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface ComplianceRepository extends JpaRepository<Compliance,Integer> {

    Compliance findByComplianceNameAndTitle(String compliance,String Title)throws SoclyAlertException;
}
