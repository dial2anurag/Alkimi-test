package com.compliance.soc.socly.organization.repository;

import com.compliance.soc.socly.organization.entity.OrgDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgDetailsRepository extends JpaRepository<OrgDetails, Integer> {


}
