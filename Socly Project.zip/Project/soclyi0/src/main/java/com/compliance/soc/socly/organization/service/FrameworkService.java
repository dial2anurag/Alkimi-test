package com.compliance.soc.socly.organization.service;

import com.compliance.soc.socly.audit.Exceptions.AuditPeriodException;
import com.compliance.soc.socly.organization.entity.Framework;
import com.compliance.soc.socly.organization.exception.FrameworkException;
import com.compliance.soc.socly.organization.repository.FrameworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * it is a service class of framework.
 */
@Component
public class FrameworkService {

    @Autowired
    private FrameworkRepository frameworkRepository;

    /**
     * it is a framework service finding the framework through name.
     *
     * @param name
     * @return
     * @throws FrameworkException
     */
    public Framework findFramework(String name) throws FrameworkException {
        return frameworkRepository.findByName(name);
    }

    /**
     * it framework service finding the framework through id.
     *
     * @param id
     * @return
     * @throws FrameworkException
     */
    public Optional<Framework> findById(Integer id) throws FrameworkException {
        return frameworkRepository.findById(id);
    }

}
