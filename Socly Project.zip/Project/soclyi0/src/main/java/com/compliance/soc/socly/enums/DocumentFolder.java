package com.compliance.soc.socly.enums;

public enum DocumentFolder {
    data,
    template,
    documents
}
