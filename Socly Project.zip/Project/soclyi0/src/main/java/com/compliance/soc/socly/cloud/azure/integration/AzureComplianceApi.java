package com.compliance.soc.socly.cloud.azure.integration;

import com.compliance.soc.socly.cloud.azure.exception.AzureException;
import com.compliance.soc.socly.cloud.azure.model.AzureCredential;
import com.compliance.soc.socly.cloud.azure.model.AzureResponse;
import com.compliance.soc.socly.cloud.azure.model.AzureResponseMetadata;
import com.compliance.soc.socly.cloud.azure.model.AzureTokenRequest;
import com.compliance.soc.socly.cloud.aws.service.CloudConstant;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class AzureComplianceApi {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private AzureTokenRequest azureTokenRequest;


    /**
     * This method is used to get azure access token by making an API call
     *
     * @param azureCredential
     * @return accessToken
     */
    public String azureToken(AzureCredential azureCredential) throws AzureException {
        String accessToken = null;
        azureTokenRequest.setClient_id(azureCredential.getClientId());
        azureTokenRequest.setClient_secret(azureCredential.getClientSecret());
        azureTokenRequest.setGrant_type(CloudConstant.AZURE_GRANT_TYPE);
        azureTokenRequest.setResource(CloudConstant.AZURE_RESOURCE);
        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", CloudConstant.AZURE_GRANT_TYPE);
        requestBody.add("resource", CloudConstant.AZURE_RESOURCE);
        requestBody.add("client_id", azureCredential.getClientId());
        requestBody.add("client_secret", azureCredential.getClientSecret());
        final String url = CloudConstant.AZURE_BEARE_TOKEN_ENDPOINT + azureCredential.getTenantId() + "/oauth2/token";
        log.info("Azure access token endpoint: {}", url);
        ResponseEntity<String> responseToken = null;
        try {
            responseToken = restTemplate.postForEntity(url, requestBody, String.class);
            if (responseToken.getStatusCode() != HttpStatus.OK) {
                throw new AzureException("Error while getting access token" + responseToken);
            }
            if (responseToken.getStatusCode() == HttpStatus.OK) {
                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(responseToken.getBody());
                accessToken = (String) jsonObject.get("access_token");
            }
        } catch (ParseException e) {
            log.error("Exception while parsing response" + e);
            throw new AzureException(e);
        } catch (Exception e) {
            log.error("Exception while processing response" + e);
            throw new AzureException(e);
        }
        return accessToken;
    }
    /**
     * This method is used to build azure endpoint used to get compliance metadata and compliance result
     *
     * @param subscriptionId
     * @param azureUri
     * @return azure-endpoint
     */
    public String azureEndpointBuilder(String subscriptionId, String azureUri) throws Exception {
        String azureEndpoint;
        if (azureUri.equals(CloudConstant.AZURE_COMPLIANCE) || azureUri.equals(CloudConstant.AZURE_COMPLIANCE_METADATA)) {
            azureEndpoint = CloudConstant.AZURE_ENDPOINT + "/" + subscriptionId + "/" + CloudConstant.AZURE_ENDPOINT_BUILDER + azureUri + CloudConstant.AZURE_ENDPOINT_APIVERSION;
        } else {
            throw new Exception("Invalid Azure Compliance URI = " + azureUri);
        }
        return azureEndpoint;
    }
    /**
     * This method is to get build HttpEntity by passing Bearer token
     *
     * @param token
     * @return HttpEntity
     */
    public HttpEntity<String> requestBuilder(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + token);
        HttpEntity<String> request = new HttpEntity(headers);
        return request;
    }
    /**
     * This method is to get Azure compliance result
     *
     * @param subscriptionId
     * @param token
     * @return List<AzureResponse>
     */
    public List<AzureResponse> getAzureCompliance(String subscriptionId, String token) throws Exception {
        List<AzureResponse> responses = new ArrayList<>();
        String azureEndpoint = azureEndpointBuilder(subscriptionId, CloudConstant.AZURE_COMPLIANCE);
        HttpEntity<String> request = requestBuilder(token);
        log.info("Azure API to fetch compliance result: {}", azureEndpoint);
        ResponseEntity<String> azureResponse = restTemplate.exchange(azureEndpoint, HttpMethod.GET, request, String.class);
        JSONParser jsonParser = new JSONParser();
        try {
            JSONObject jsonObject = (JSONObject) jsonParser.parse(azureResponse.getBody());
            JSONArray jsonValue = (JSONArray) jsonObject.get("value");
            String valueResponse = jsonValue.toString();
            ObjectMapper objectMapper = new ObjectMapper();
            responses = objectMapper.readValue(valueResponse, new TypeReference<>() {
            });
        } catch (ParseException e) {
            log.error("Exception while parsing " + e);
        } catch (JsonMappingException e) {
            log.error("Exception while json mapping " + e);
        } catch (JsonProcessingException e) {
            log.error("Exception while json processing " + e);
        }
        return responses;
    }
    /**
     * This method is to fetch standard compliance metadata from Azure
     *
     * @param subscriptionId
     * @param token
     * @return List<AzureResponseMetadata>
     */
    public List<AzureResponseMetadata> getAzureComplianceMetadata(String subscriptionId, String token) throws Exception {
        List<AzureResponseMetadata> responses = new ArrayList<>();
        String azureEndpoint = azureEndpointBuilder(subscriptionId, CloudConstant.AZURE_COMPLIANCE_METADATA);
        log.info("Azure API to fetch compliance metadata: {}", azureEndpoint);
        HttpEntity<String> request = requestBuilder(token);
        ResponseEntity<String> azureResponse = restTemplate.exchange(azureEndpoint, HttpMethod.GET, request, String.class);
        JSONParser jsonParser = new JSONParser();
        try {
            JSONObject jsonObject = (JSONObject) jsonParser.parse(azureResponse.getBody());
            JSONArray jsonValue = (JSONArray) jsonObject.get("value");
            String valueResponse = jsonValue.toString();
            ObjectMapper objectMapper = new ObjectMapper();
            responses = objectMapper.readValue(valueResponse, new TypeReference<>() {
            });
        } catch (ParseException e) {
            log.error("Exception while parsing " + e);
        } catch (JsonMappingException e) {
            log.error("Exception while json mapping " + e);
        } catch (JsonProcessingException e) {
            log.error("Exception while json processing " + e);
        }
        return responses;
    }
}