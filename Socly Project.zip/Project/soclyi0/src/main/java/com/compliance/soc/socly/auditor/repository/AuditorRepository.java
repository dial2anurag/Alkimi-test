package com.compliance.soc.socly.auditor.repository;

import com.compliance.soc.socly.auditor.entity.Auditor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * AuditorRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface AuditorRepository extends JpaRepository<Auditor, Integer> {

    Auditor findByEmail(String email);

    Auditor findByUsername(String username);

    List<Auditor> findByStatusIgnoreCase(String status);
}
