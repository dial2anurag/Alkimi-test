package com.compliance.soc.socly.saas.configuration.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.IdClass;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@IdClass(SaasConfigId.class)
@Table(name = "saas_config")
@Setter
@Getter
/**
 * SaasConfig is an entity class, with properties from the metrics table
 */
public class SaasConfiguration {

    @Id
    @Column(name = "saas_id")
    private String saasId;

    @Id
    @Column(name = "org_id")
    private Long orgId;

    @Id
    @Column(name = "framework_id")
    private Integer frameworkId;

    @Column(name = "name")
    @NotNull
    private String name;

    @Column(name = "value",columnDefinition = "TEXT")
    @NotNull
    private String value;

}
