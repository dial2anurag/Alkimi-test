package com.compliance.soc.socly.organization;

import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.auth.service.impl.UserServiceImpl;
import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.organization.service.OrganizationConfigService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/org/description")
public class OrganizationConfigController extends BaseController {

    @Autowired
    private OrganizationConfigService organizationConfigService;

    /**
     * API to save all the images and json in S3 bucket for System Description
     *
     * @param imageFiles
     * @param orgDescription
     */
    @PostMapping
    public ResponseEntity addOrgDescription(@RequestParam("files") MultipartFile[] imageFiles, @RequestParam("orgDescription") String orgDescription) {
        try {
            String organizationName = userService.getCurrentUser().getOrganization().getOrgName().toLowerCase();
            organizationConfigService.uploadDescriptionFilesToS3(organizationName, imageFiles, orgDescription);
            return ResponseEntity.ok().body("Files Uploaded successfully");
        }
        catch (UserDetailsException userDetailsException) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found " + userDetailsException);
        }
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to upload files " + e);
        }
    }

    /**
     * API to get all the images and json saved in S3 bucket
     *
     * @return List<ResponseEntity>
     */
    @GetMapping
    public List<ResponseEntity> getOrgDescription() {
        List<ResponseEntity> responseEntities = new ArrayList<>();
        ResponseEntity response;
        String organizationName = null;
        try {
            organizationName = userService.getCurrentUser().getOrganization().getOrgName().toLowerCase();
        } catch (UserDetailsException e) {
            return (List<ResponseEntity>) ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found " + e);
        }
        List<S3ObjectInputStream> s3ObjectInputStreamList = organizationConfigService.getDescriptionFiles(organizationName);
        for (S3ObjectInputStream s3ObjectInputStream : s3ObjectInputStreamList) {
            try {
                String fileExtension = FilenameUtils.getExtension(s3ObjectInputStream.getHttpRequest().getRequestLine().getUri());
                if (fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("jpg") ||
                        fileExtension.equalsIgnoreCase("jpeg")) {
                    byte[] bytes = s3ObjectInputStream.readAllBytes();
                    response = ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(bytes);
                } else {
                    String fileContent = new JSONObject(new String(s3ObjectInputStream.readAllBytes())).toString();
                    response = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(fileContent);
                }
            } catch (IOException e) {
                log.error("Error when reading file " + e);
                response = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error when reading file " + e);
            }
            responseEntities.add(response);
        }
        return responseEntities;
    }
}
