package com.compliance.soc.socly.alert.service.Impl;

import com.compliance.soc.socly.alert.entity.OrgSaas;
import com.compliance.soc.socly.alert.exceptions.SoclyAlertException;
import com.compliance.soc.socly.alert.entity.Compliance;
import com.compliance.soc.socly.alert.entity.SaasCompliance;
import com.compliance.soc.socly.alert.model.AlertDto;
import com.compliance.soc.socly.alert.repository.ComplianceRepository;
import com.compliance.soc.socly.alert.repository.OrgSaasRepository;
import com.compliance.soc.socly.alert.repository.SaasComplianceRepository;
import com.compliance.soc.socly.alert.service.AlertService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.AbstractResponse;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.EntityCompliance;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import com.compliance.soc.socly.saas.service.SaasMasterService;
import com.compliance.soc.socly.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class AlertServiceImpl implements AlertService {
    @Autowired
    private ComplianceRepository complianceRepository;
    @Autowired
    private SaasComplianceRepository saasComplianceRepository;
    @Autowired
    private SaasMasterService saasMasterService;
    @Autowired
    private OrgSaasRepository orgSaasRepository;
    @Autowired
    private UserService userService;

    /**
     * method is to populate the data from bitbucket,Gsuite ,AWS, github and to store in
     * saasCompliance table
     *
     * @param response
     * @param saasId
     */
    @Override
    public void populateData(final ComplianceResponse response, String saasId) throws SoclyAlertException {
        try {
            List<SaasCompliance> saasCompliances = new ArrayList<>();
            Compliance compliance = null;
            Organization organization = userService.getCurrentUser().getOrganization();
            SaasMaster saasMaster = saasMasterService.getSaasMaster(saasId);
            OrgSaas orgSaas = orgSaasRepository.findByOrganizationAndSaasMaster(organization,saasMaster);
            for (AbstractResponse abstractResponse :
                    response.getAbstractResponse()) {
                for (EntityCompliance entityCompliance :
                        abstractResponse.getEntityCompliance()) {
                    String complianceName = entityCompliance.getComplianceID();
                    String title = entityCompliance.getComplianceTitle();
                    compliance = complianceRepository.findByComplianceNameAndTitle(
                            complianceName, title);
                    if (compliance == null) {
                        compliance = new Compliance();
                        compliance.setComplianceName(complianceName);
                        compliance.setTitle(title);
                        compliance = complianceRepository.save(compliance);
                    }
                    SaasCompliance saasCompliance = new SaasCompliance();

                    saasCompliance.setCreatedDate(entityCompliance.getCreatedAt() != null ? entityCompliance.getCreatedAt().substring(0, 19).replace('T', ' ')
                            : null);
                    saasCompliance.setRemediation(entityCompliance.getRecommended_Remediation());
                    saasCompliance.setDescription(entityCompliance.getDescription());
                    saasCompliance.setStatus(entityCompliance.getComplianceStatus());
                    saasCompliance.setOrgSaas(orgSaas);
                    saasCompliance.setCompliance(compliance);

                    saasCompliances.add(saasCompliance);
                }
            }
            saasComplianceRepository.saveAll(saasCompliances);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new SoclyAlertException("unable to populate data from " + saasId);
        }
    }

    /**
     * method is to fetch the list of data history of alerts from the complianceId and range of date
     *
     * @param cName
     * @param orgId
     * @param sDate
     * @param eDate
     * @return
     */
    @Override
    public List<AlertDto> fetchAlertStatus(String cName, Date sDate, Date eDate, long orgId) throws SoclyAlertException {
        try {
            List<AlertDto> alertDtos = saasComplianceRepository.fetchAlerts(
                    cName, orgId, DateUtils.getDate(sDate),
                    DateUtils.getDate(eDate));
            return alertDtos;
        } catch (SoclyAlertException exception) {
            log.error(exception.getMessage());
            throw new SoclyAlertException("Alerts could not be retrieved for compliance: " + cName + " and orgId: "+ orgId
                    + " between " + DateUtils.getDate(sDate) + " and " +
                    DateUtils.getDate(eDate));
        }
    }
}
