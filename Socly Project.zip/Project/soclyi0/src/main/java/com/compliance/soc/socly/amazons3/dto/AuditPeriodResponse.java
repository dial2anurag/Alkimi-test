package com.compliance.soc.socly.amazons3.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuditPeriodResponse {
    private Integer auditId;
    private String status;
    private String period;
    private long clientId;
    private Date startDate;
    private Date endDate;
    private Long createdBy;
    private Long modifiedBy;
    private Long endedBy;
    private Date auditDate;
}
