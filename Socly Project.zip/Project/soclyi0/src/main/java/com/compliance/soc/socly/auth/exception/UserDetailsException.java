package com.compliance.soc.socly.auth.exception;

public class UserDetailsException extends Exception{

    public UserDetailsException(final Exception ex) {

        super(ex);

    }


    public UserDetailsException(final String errorMsg) {

        super(errorMsg);

    }
}
