package com.compliance.soc.socly.audit.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;

/**
 * FileMaster is an entity class and properties from the FileMaster table
 */
@Entity
@Getter
@Setter
@Table(name = "file_master")
public class FileMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * the  id is primary key of this table
     */
    @Column(name = "id")
    private Integer fileId;
    /**
     * the  fileName shows the name of the file
     */
    @Column(name = "file_name")
    private String fileName;
    /**
     * the status which shows auditStatus
     */
    @Column(name = "status", columnDefinition = "char(1) default 'A'")
    private String status;
    /**
     * the createdDate shows on which date it is created
     */
    @Column(name = "created_date")
    private Date createdDate;
    /**
     * the modifiedDate shows on which date it is modified
     */
    @Column(name = "modified_date")
    private Date modifiedDate;
    /**
     * the createdBy shows from which user it is being created
     */
    @Column(name = "created_by")
    private Long createdBy;
    /**
     * the modifiedBy shows from which user it is being modified
     */
    @Column(name = "modified_by")
    private Long modifiedBy;

    /**
     * joining with FileApproval entity, foreign key : file_id
     */
    @OneToMany(targetEntity = FileApproval.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "file_id", referencedColumnName = "id")
    private List<FileApproval> fileApprovalList;

}
