package com.compliance.soc.socly.oauth;

import com.compliance.soc.socly.scm.bitbucket.BitBucketAPIService;
import com.compliance.soc.socly.scm.github.integration.GitHubAPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class ApiTester {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private BitBucketAPIService bitBucketAPIService;

    @Autowired
    private GitHubAPIService gitHubAPIService;

    @Autowired
    private OAuthContext oAuthContext;
}
