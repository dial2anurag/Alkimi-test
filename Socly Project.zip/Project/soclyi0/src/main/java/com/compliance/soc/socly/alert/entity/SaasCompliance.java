package com.compliance.soc.socly.alert.entity;

import com.compliance.soc.socly.saas.entity.SaasMaster;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * SaasCompliance is an entity class and properties from the SaasCompliance table
 *
 */
@Entity
@Table(name = "saas_compliance")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SaasCompliance implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	/**
	 * 
	 */
	@Column(name = "status")
	private String status;

	/**
	 * 
	 */
	@Column(name = "description", columnDefinition = "Text")
	private String description;
	/**
	 * 
	 */
	@Column(name = "remediation",columnDefinition = "Text")
	private String remediation;

	/**
	 * 
	 */
	@Column(name = "created")
	private String createdDate;

	/**
	 *
	 */
	@ManyToOne(targetEntity = Compliance.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "compliance_id", referencedColumnName = "id")
	private Compliance compliance;

	/**
	 *
	 */
	@ManyToOne(targetEntity = OrgSaas.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "org_saas_id", referencedColumnName = "saas_id")
	private OrgSaas orgSaas;
}
