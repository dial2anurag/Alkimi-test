package com.compliance.soc.socly.metrics.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PrincipleResponse {
    private int metricsId;
    private String principle;
    private String title;
    private String flag;
    private String status;

}
