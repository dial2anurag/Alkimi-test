package com.compliance.soc.socly.audit.Exceptions;

/**
 *  PrincipleApproval exception class to handle separately with others
 */
public class PrincipleApprovalException extends Exception{
    public PrincipleApprovalException(final Exception ex) {
        super(ex);
    }

    public PrincipleApprovalException(final String errorMsg) {
        super(errorMsg);
    }
}
