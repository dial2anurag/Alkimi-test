package com.compliance.soc.socly.amazons3.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.IOUtils;
import com.compliance.soc.socly.amazons3.comparators.S3FileDateComparator;
import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.amazons3.dto.FileListResponse;
import com.compliance.soc.socly.amazons3.dto.FileUploadResponse;
import com.compliance.soc.socly.amazons3.exception.ActiveAuditNotFoundException;
import com.compliance.soc.socly.amazons3.exception.FileNotFoundException;
import com.compliance.soc.socly.amazons3.exception.FileTypeNotAllowedException;
import com.compliance.soc.socly.amazons3.exception.S3BucketException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.entity.FileApproval;
import com.compliance.soc.socly.audit.entity.FileMaster;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.FileApprovalDto;
import com.compliance.soc.socly.audit.service.AuditPeriodService;
import com.compliance.soc.socly.audit.service.FileMasterService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.ComplianceFramework;
import com.compliance.soc.socly.enums.AuditPeriodStatus;
import com.compliance.soc.socly.enums.DocumentFolder;
import com.compliance.soc.socly.enums.EvidenceFileType;
import com.compliance.soc.socly.enums.PolicyCenter;
import com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse;
import com.compliance.soc.socly.metrics.dto.PrincipleDto;
import com.compliance.soc.socly.metrics.entity.Principle;
import com.compliance.soc.socly.metrics.service.PrincipleService;
import com.compliance.soc.socly.organization.service.OrganizationConfigService;
import com.compliance.soc.socly.saas.enums.SAASFolders;
import com.compliance.soc.socly.util.s3.S3Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Slf4j
public class StorageService {

    @Autowired
    private AmazonS3 s3Client;

    @Autowired
    private UserService userService;

    @Autowired
    private S3Util s3Util;

    @Autowired
    private FileMasterService fileMasterService;

    @Autowired
    private AuditPeriodService auditPeriodService;

    @Autowired
    private PrincipleService principleService;

    // check if a compliance passed is valid or not
    public static boolean validateFramework(String framework) {
        return Arrays.stream(ComplianceFramework.values()).anyMatch(a -> a.name().equalsIgnoreCase(framework));
    }

    /**
     * Service layer method to upload multiple files (pdf, jpeg, png) into "compliance_pdf" folder  of corresponding
     * logged-in user's organization in AWS s3 bucket.
     *
     * @param source
     * @param complianceId
     * @param multipartFiles
     * @return FileUploadResponse (containing filename, filesize, type of file) OR Exception in case of
     * wrong format
     */
    public List<FileUploadResponse> uploadFile(String source, String complianceId, MultipartFile[] multipartFiles) throws S3BucketException {
        try {
            int numberOfMultipartFiles = validateFileFormat(multipartFiles);
            final List<FileUploadResponse> fileUploadResponseList = new ArrayList<>();
            final String organizationName = userService.getCurrentUser().getOrganization().getOrgName();
            // get the framework
            final ComplianceFramework framework = this.fetchFramework(complianceId);
            if (numberOfMultipartFiles > 0) {
                for (MultipartFile multipartFile : multipartFiles) {
                    String originalFileName = multipartFile.getOriginalFilename();
                    String filename = generateFileName(source, complianceId, originalFileName, organizationName);
                    File file = this.convertMultiPartFileToFile(multipartFile);
                    String folder = organizationName.toLowerCase() + "/" + framework.name() + "/" + SAASFolders.compliance_docs;
                    if (source.equals(OrganizationConfigService.SYSTEM_DESCRIPTION)) {
                        folder = organizationName.toLowerCase() + "/" + SAASFolders.organization_docs;
                    }
                    s3Util.putFileS3(folder, filename, file);
                    log.info("File {} uploaded in folder : {}", filename, folder);
                    fileUploadResponseList.add(new FileUploadResponse(filename, multipartFile.getContentType(), multipartFile.getSize()));
                    file.delete();
                }
            }
            return fileUploadResponseList;
        } catch (final Exception exception) {
            log.error("File(s) could not be uploaded. " + exception.getMessage());
            throw new S3BucketException("File(s) could not be uploaded. " + exception.getMessage());
        }
    }

    /**
     * @param multipartFiles
     * @return
     */
    private int validateFileFormat(final MultipartFile[] multipartFiles) {
        int numberOfMultipartFiles = multipartFiles.length;
        if (numberOfMultipartFiles > 0) {
            for (MultipartFile multipartFile : multipartFiles) {
                String extension = getExtension(multipartFile.getOriginalFilename());
                if (!extension.equalsIgnoreCase("pdf") && !extension.equalsIgnoreCase("jpeg") && !extension.equalsIgnoreCase("jpg") && !extension.equalsIgnoreCase("png") && !extension.equalsIgnoreCase("zip")) {
                    String message = "File extension not supported for one or more files. Please upload pdfs and image files only.";
                    throw new FileTypeNotAllowedException(message);
                }
            }
        }
        log.info("All files have appropriate format");
        return numberOfMultipartFiles;
    }

    /**
     * Service layer method to download file from "compliance_pdf" folder  of corresponding
     * logged-in user's organization in AWS s3 bucket.
     *
     * @param filename
     * @return ByteArray (file content)
     * @throws S3BucketException
     */
    public byte[] downloadFile(String filename, String framework) throws S3BucketException {
        try {
            String organizationName = userService.getCurrentUser().getOrganization().getOrgName();
            String folder = null;
            if (framework.equalsIgnoreCase(ComplianceFramework.ISO.name())) {
                folder = organizationName.toLowerCase() + "/" +
                        ComplianceFramework.ISO.name() + "/" + SAASFolders.compliance_docs;
            } else if (framework.equalsIgnoreCase(ComplianceFramework.SOC2.name())) {
                folder = organizationName.toLowerCase() + "/" +
                        ComplianceFramework.SOC2.name() + "/" + SAASFolders.compliance_docs;
            }
            if (!s3Client.doesObjectExist(folder, filename)) {
                String message = "File does not exist";
                throw new FileNotFoundException(message);
            }
            log.info("File {} exists", filename);
            S3Object s3Object = s3Client.getObject(folder, filename);
            S3ObjectInputStream s3ObjectInputStream = s3Object.getObjectContent();
            try {
                byte[] content = IOUtils.toByteArray(s3ObjectInputStream);
                log.info("File converted to byte array");
                return content;
            } catch (IOException e) {
                log.error(e.getLocalizedMessage(), e);
            }
            return null;
        } catch (final Exception exception) {
            log.error("File could not be downloaded. " + exception.getMessage());
            throw new S3BucketException("File could not be downloaded. " + exception.getMessage());
        }
    }

    /**
     * Service layer method to fetch list of the latest files based on complianceId from "compliance_pdf" folder of corresponding
     * logged-in user's organization in AWS s3 bucket. The files are fetched based on modified date
     * and audit initiate date.
     *
     * @param complianceId
     * @param principleId
     * @return FileListResponse (containing filename, complianceId, principleId, clientId, auditId, auditStatus)
     * @throws S3BucketException,ActiveAuditNotFoundException
     */
    public List<FileListResponse> listFiles(String complianceId, int principleId) throws S3BucketException, ActiveAuditNotFoundException {
        try {
            final HashMap<String, Date> filesAndDateMap = new HashMap<>();
            List<String> allS3Files = this.collectFiles(complianceId, filesAndDateMap);
            // check if any active audit present for current client Id
            final Organization currentOrganization = userService.getCurrentUser().getOrganization();
            final List<AuditPeriod> activeAudits = auditPeriodService.findByOrganizationAndStatus(currentOrganization, AuditPeriodStatus.O.toString());
            final long currentUserId = userService.getCurrentUser().getId();
            final boolean isUserAnAuditor = auditPeriodService.isAuditor(currentUserId);
            //no active audit and user is an auditor
            if (activeAudits.isEmpty() && isUserAnAuditor) {
                String message = "No active audit found for auditor";
                throw new ActiveAuditNotFoundException(message);
            }
            //Latest unique source files with given complianceId
            List<String> latestFiles = new ArrayList<>();
            List<String> fileSources = findUniqueFileSources(allS3Files);
            AuditPeriodDto auditPeriodDto = populateAuditPeriod(activeAudits);
            evidencePopulation(complianceId, filesAndDateMap, allS3Files, currentOrganization, auditPeriodDto, isUserAnAuditor, latestFiles, fileSources);
            //Adding auditor data
            List<FileListResponse> fileListResponses = new ArrayList<>();
            fileListResponses = this.handleFileList(fileListResponses, complianceId, activeAudits, latestFiles, principleId);
            return fileListResponses;
        } catch (final ActiveAuditNotFoundException ae) {
            log.error("Files could not be fetched. " + ae.getMessage());
            throw new ActiveAuditNotFoundException("Files could not be fetched. " + ae.getMessage());
        } catch (final Exception exception) {
            log.error("Files could not be fetched. " + exception.getMessage());
            throw new S3BucketException("Files could not be fetched. " + exception.getMessage());
        }
    }

    /**
     * This is the method to populate the data auditPeriodDto.
     *
     * @param activeAudits (check where there is active audit)
     * @return audit periodDto.
     */
    private AuditPeriodDto populateAuditPeriod(List<AuditPeriod> activeAudits) {
        AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
        for (AuditPeriod auditPeriod : activeAudits) {
            auditPeriodDto.setPeriod(auditPeriod.getPeriod());
            auditPeriodDto.setAuditId(auditPeriod.getAuditId());
            auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
            auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
            auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
            auditPeriodDto.setStatus(auditPeriod.getStatus());
            auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
            auditPeriodDto.setStartDate(auditPeriod.getStartDate());
            auditPeriodDto.setEndDate(auditPeriod.getEndDate());
        }
        return auditPeriodDto;
    }

    /**
     * THis an API Method to collecting evidence population through filesources.
     *
     * @param complianceId        (compliance)
     * @param filesAndDateMap     (files and date mapping)
     * @param allS3Files          (Contains all the S3 filenames)
     * @param currentOrganization (current user organization)
     * @param auditPeriodDto      (Dto object of {@link AuditPeriodDto})
     * @param isUserAnAuditor     (checking weather user is an auditor)
     * @param latestFiles         (The last updated files)
     * @param fileSources         (source of the file)
     */
    private void evidencePopulation(String complianceId, HashMap<String, Date> filesAndDateMap, List<String> allS3Files, Organization currentOrganization, AuditPeriodDto auditPeriodDto, boolean isUserAnAuditor, List<String> latestFiles, List<String> fileSources) {
        // loop through the fileSources and
        fileSources.forEach(source -> {
            final String autoGenFile = this.fetchSystemGenFiles(allS3Files, source, filesAndDateMap, currentOrganization.getOrgName(), complianceId, isUserAnAuditor, auditPeriodDto);
            if (autoGenFile != null) {
                // collecting auto evidence
                latestFiles.add(autoGenFile);
            }
            // Collecting manual evidence
            latestFiles.addAll(this.fetchManualFiles(allS3Files, source, filesAndDateMap, currentOrganization.getOrgName(), complianceId, isUserAnAuditor, auditPeriodDto));
        });
    }

    /**
     * @param fileListResponses
     * @param complianceId
     * @param activeAuditForCurrentClient
     * @param latestFilesList
     * @param principleId
     * @return
     * @throws S3BucketException
     */
    private List<FileListResponse> handleFileList(List<FileListResponse> fileListResponses, String complianceId, List<AuditPeriod> activeAuditForCurrentClient, List<String> latestFilesList, int principleId) throws S3BucketException {
        try {
            //no active audit but user is not an auditor
            if (activeAuditForCurrentClient == null) {
                for (String filename : latestFilesList) {
                    FileListResponse fileListResponse = FileListResponse.builder().complianceId(complianceId).fileName(filename).build();
                    fileListResponses.add(fileListResponse);
                }
                return fileListResponses;
            }
            for (String filename : latestFilesList) {
                final FileMaster fileMaster = fileMasterService.fetchFileMaster(filename);
                if (fileMaster == null) {
                    FileListResponse fileListResponse = FileListResponse.builder().complianceId(complianceId).fileName(filename).build();
                    fileListResponses.add(fileListResponse);
                } else {
                    /**
                     * The below for loop is redundant here and the loop (same logic) is executing no of times
                     * that of the no of fileApprovals exists for a file, which is not required here.
                     */

                   // List<FileApproval> fileApprovals = fileMaster.getFileApprovalList();
                   // for (FileApproval fileApproval : fileApprovals) {
                   //     String auditNote = fileApproval.getAuditNote();
                        List<FileApproval> fileApprovalList = fileMaster.getFileApprovalList();
                        fileApprovalList = fileApprovalList.stream().filter(n -> n.getPrincipleId().equals(principleId)).collect(Collectors.toList());
                        if (fileApprovalList.isEmpty()) {
                            FileListResponse fileListResponse = new FileListResponse(filename, complianceId, null, null, null);
                            fileListResponses.add(fileListResponse);
                        } else {
                            this.handleApprovedFile(complianceId, principleId, fileListResponses, filename, fileApprovalList);
                        }
                   // }
                }
            }//filenames loop
            return fileListResponses;
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new S3BucketException(exception.getMessage());
        }
    }

    /**
     * @param complianceId
     * @param principleId
     * @param fileListResponses
     * @param filename
     * @param fileApprovalList
     */
    private void handleApprovedFile(String complianceId, int principleId, List<FileListResponse> fileListResponses, String filename, List<FileApproval> fileApprovalList) throws S3BucketException {
        try {
            Organization currentOrganization = userService.getCurrentUser().getOrganization();
            OrganizationDto organizationDto = new OrganizationDto();
            organizationDto.setClientId(currentOrganization.getId());
            organizationDto.setStatus(currentOrganization.getStatus());
            organizationDto.setDescription(currentOrganization.getDescription());
            organizationDto.setOrgName(currentOrganization.getOrgName());
            organizationDto.setDetailFilled(currentOrganization.isDetailFilled());
            organizationDto.setRegisteredDateTime(currentOrganization.getRegisteredDateTime());
            organizationDto.setParentId(currentOrganization.getParentId());
            for (FileApproval fileApproval : fileApprovalList) {
                long clientIdFromFileApprovalEntity = fileApproval.getOrganization().getId();
                String auditPeriodStatus = fileApproval.getAuditPeriod().getStatus();
                String complianceIdFromFileApprovalEntity = fileApproval.getComplianceId();
                int principleIdFromFileApprovalEntity = fileApproval.getPrincipleId();
                FileApprovalDto fileApprovalDto = new FileApprovalDto();
                fileApprovalDto.setId(fileApproval.getId());
                fileApprovalDto.setFileId(fileApproval.getFileId());
                fileApprovalDto.setStatus(fileApproval.getStatus());
                fileApprovalDto.setComplianceId(fileApproval.getComplianceId());
                fileApprovalDto.setPrincipleId(fileApproval.getPrincipleId());
                fileApprovalDto.setCreatedDate(fileApproval.getCreatedDate());
                fileApprovalDto.setModifiedDate(fileApproval.getModifiedDate());
                fileApprovalDto.setCreatedBy(fileApproval.getCreatedBy());
                fileApprovalDto.setModifiedBy(fileApproval.getModifiedBy());
                fileApprovalDto.setAuditNote(fileApproval.getAuditNote());

                AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
                auditPeriodDto.setPeriod(fileApproval.getAuditPeriod().getPeriod());
                auditPeriodDto.setAuditId(fileApproval.getAuditPeriod().getAuditId());
                auditPeriodDto.setAuditInitiateDate(fileApproval.getAuditPeriod().getAuditInitiateDate());
                auditPeriodDto.setEndedBy(fileApproval.getAuditPeriod().getEndedBy());
                auditPeriodDto.setModifiedBy(fileApproval.getAuditPeriod().getModifiedBy());
                auditPeriodDto.setStatus(fileApproval.getAuditPeriod().getStatus());
                auditPeriodDto.setCreatedBy(fileApproval.getAuditPeriod().getCreatedBy());
                auditPeriodDto.setStartDate(fileApproval.getAuditPeriod().getStartDate());
                auditPeriodDto.setEndDate(fileApproval.getAuditPeriod().getEndDate());
                fileApprovalDto.setAuditPeriod(auditPeriodDto);

                Principle principle = principleService.getPrincipleById(principleId);
                PrincipleDto principleDto = new PrincipleDto();
                principleDto.setId(principle.getMetricsId());
                principleDto.setPrinciple(principle.getPrinciple());
                principleDto.setTitle(principle.getTitle());
                principleDto.setFlag(principle.getFlag());
                principleDto.setStatus(principle.getStatus());

                FileListResponse fileListResponse;
                if (Objects.equals(clientIdFromFileApprovalEntity, currentOrganization.getId()) && complianceIdFromFileApprovalEntity.equalsIgnoreCase(complianceId) && principleIdFromFileApprovalEntity == principleId && auditPeriodStatus.equalsIgnoreCase(AuditPeriodStatus.O.toString())) {
                    fileListResponse = new FileListResponse(filename, complianceId, principleDto, fileApprovalDto, organizationDto);
                    fileListResponses.add(fileListResponse);
                } else if (Objects.equals(clientIdFromFileApprovalEntity, currentOrganization.getId()) && complianceIdFromFileApprovalEntity.equalsIgnoreCase(complianceId) && principleIdFromFileApprovalEntity != principleId && auditPeriodStatus.equalsIgnoreCase(AuditPeriodStatus.O.toString())) {
                    fileListResponse = new FileListResponse(filename, complianceId, principleDto, fileApprovalDto, organizationDto);
                    fileListResponses.add(fileListResponse);
                }
            }//fileApproval loop
        } catch (final Exception exception) {
            log.error("Files could not be fetched. File approval condition checking error. " + exception.getMessage());
            throw new S3BucketException("Files could not be fetched. File approval condition checking error.  " + exception.getMessage());
        }
    }

    /**
     * collect files containing specific complianceId and current user's organizationName
     *
     * @param complianceId
     * @return
     */
    private List<String> collectFiles(String complianceId, HashMap<String, Date> filesAndModifiedDateMapping) throws S3BucketException {
        try {
            final List<String> allFiles = new ArrayList<>();
            final List<String> itemsToBeIncludedInFilename = new ArrayList<>();
            //check for complianceId and organization name in file name
            itemsToBeIncludedInFilename.add(complianceId);
            String organizationName = userService.getCurrentUser().getOrganization().getOrgName();
            // fetching principle's framework
            final ComplianceFramework framework = this.fetchFramework(complianceId);
            ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(organizationName.toLowerCase()).withPrefix(framework.name() + "/" + SAASFolders.compliance_docs + "/");
            //since some users do not have organization
            if (organizationName != null) {
                itemsToBeIncludedInFilename.add(organizationName);
            }
            ObjectListing objects = s3Util.listObjects(listObjectsRequest);
            while (true) {
                List<S3ObjectSummary> objectSummaries = objects.getObjectSummaries();
                if (objectSummaries.size() < 1) {
                    break;
                }
                for (S3ObjectSummary item : objectSummaries) {
                    String filename = item.getKey().replace(framework.name() + "/" + SAASFolders.compliance_docs + "/", "");
                    Date lastModifiedDate = item.getLastModified();
                    if (containsWords(filename, itemsToBeIncludedInFilename)) {
                        allFiles.add(filename);
                        filesAndModifiedDateMapping.put(filename, lastModifiedDate);
                    }
                }
                log.info("Fetched document successfully with input data {}, total file count {}", complianceId, allFiles.size());
                objects = s3Client.listNextBatchOfObjects(objects);
            }
            if (allFiles.isEmpty()) {
                String message = "No files found with given complianceId";
                log.info(message + " " + complianceId);
            }
            return allFiles;
        } catch (final Exception exception) {
            log.error("Files containing current user's organization name could not be fetched. " + exception.getMessage());
            throw new S3BucketException("Files containing current user's organization name could not be fetched. " + exception.getMessage());
        }
    }

    /**
     * Find the underline framework of compliance
     *
     * @param complianceId
     * @return
     */
    private ComplianceFramework fetchFramework(String complianceId) {
        try {
            ComplianceFramework framework = ComplianceFramework.SOC2;
            final List<ActivePrinciplesResponse> principlesResponses = principleService.getPrinciplesByCompianceId(complianceId);
            if (principlesResponses.stream().findFirst().get().getFlag().equalsIgnoreCase(ComplianceFramework.ISO.name())) {
                framework = ComplianceFramework.ISO;
            }
            return framework;
        } catch (final Exception ex) {
            throw new S3BucketException(ex.getMessage());
        }
    }

    /**
     * @param orgName
     * @return :
     */
    public boolean s3StructureSetup(final String orgName, String[] frameworkSubscribed) {
        boolean structureCreated = false;
        // 1. create S3 bucket , name : orgName
        s3Util.createBucket(orgName.toLowerCase());
        for (String framework : frameworkSubscribed) {
            // 2. create folder under s3 bucket for compliance framework
            s3Util.createBucketFolder(orgName.toLowerCase(), framework.toUpperCase());
            // 3. create folder under compliance framework folder , name : orgName_Compliances
            String folderName = framework.toUpperCase() + "/" + SAASFolders.compliance_docs.name();
            s3Util.createBucketFolder(orgName.toLowerCase(), folderName);
        }
        s3Structure4PolicyCenter(orgName);
        structureCreated = true;
        return structureCreated;
    }

    /**
     * Creating S3 folders for the policy center
     *
     * @param orgName : Organization name == S3 bucket name
     */
    private void s3Structure4PolicyCenter(final String orgName) {
        try {
            // 1. Creating data folder under the organization bucket
            s3Util.createBucketFolder(orgName.toLowerCase(Locale.ROOT), PolicyCenter.data.name());
            log.info("Creation of {} folder for the {} done successfully", PolicyCenter.data.name(), orgName);
            // 2. Creating policy_center folder under the data folder
            s3Util.createBucketFolder(orgName.toLowerCase(Locale.ROOT), PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name());
            log.info("Creation of {} folder for the {} done successfully", PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name(), orgName);
            // 3. Creating documents folder also under the data folder
            s3Util.createBucketFolder(orgName.toLowerCase(Locale.ROOT), PolicyCenter.data.name() + "/" + DocumentFolder.documents);
            log.info("Creation of {} folder for the {} done successfully", PolicyCenter.data.name() + "/" + DocumentFolder.documents, orgName);
            // 4. Creating unapproved folder under the policy_center folder.
            s3Util.createBucketFolder(orgName.toLowerCase(Locale.ROOT), PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name() + "/" + PolicyCenter.unapproved.name());
            log.info("Creation of {} folder for the {} done successfully", PolicyCenter.data.name() + "/" + PolicyCenter.policy_center.name() + "/" + PolicyCenter.unapproved.name(), orgName);
        } catch (final Exception ex) {
            log.error("Creation of Policy Center's S3 folder for the organization {} failed due to reason {} ", orgName, ex.getMessage(), ex);
            throw new S3BucketException(ex.getMessage());
        }
    }

    /**
     * Method to upload the data under Specific folder under specific buckert
     *
     * @param dataUpload2FolderRequest : folder upload request data
     * @return success ( TRUE | FALSE)
     */
    public boolean uploadUnderFolder(final DataUpload2FolderRequest dataUpload2FolderRequest) {
        return s3Util.uploadUnderFolder(dataUpload2FolderRequest);
    }

    // HELPER FUNCTIONS

    /**
     * helper method to find unique sources( BITBUCKET, AWS, etc) from list of files
     *
     * @param filenames (list of files)
     * @return sourceList (list of source names)
     */
    private List<String> findUniqueFileSources(List<String> filenames) {
        List<String> sourceList = new ArrayList<>();
        for (String filename : filenames) {
            String[] filenameSplit = filename.split("_");
            String source = filenameSplit[2];
            if (!sourceList.contains(source.toUpperCase(Locale.ROOT))) {
                sourceList.add(source.toUpperCase(Locale.ROOT));
            }
        }
        return sourceList;
    }

    /**
     * helper method to find latest file from list of single source files and their modified date
     * stored in hashmap fileAndModifiedDateMapping) based on modified date and auditor initiate date
     *
     * @param fileAndModifiedDateMapping  (hashmap with single source files and corresponding modified dates)
     * @param isAuditor                   (boolean to identify if user is an auditor)
     * @param activeAuditForCurrentClient (AuditPeriod data for logged in client)
     * @return sourceList (list of source names)
     */
    private String getLatestFilesByModifiedDate(HashMap<String, Date> fileAndModifiedDateMapping, boolean isAuditor, AuditPeriodDto activeAuditForCurrentClient) {

        Map.Entry<String, Date> maxEntry = null;
        String latestFile = "";

        if (isAuditor) {
            Date auditInitiateDate = activeAuditForCurrentClient.getAuditInitiateDate();
            for (Map.Entry<String, Date> currentEntry : fileAndModifiedDateMapping.entrySet()) {
                if (maxEntry == null || ((currentEntry.getValue().compareTo(maxEntry.getValue()) > 0) && (currentEntry.getValue().compareTo(auditInitiateDate) <= 0))) {
                    maxEntry = currentEntry;
                }
            }
        } else {
            for (Map.Entry<String, Date> currentEntry : fileAndModifiedDateMapping.entrySet()) {
                if (maxEntry == null || currentEntry.getValue().compareTo(maxEntry.getValue()) > 0) {
                    maxEntry = currentEntry;
                }
            }
        }

        latestFile = maxEntry.getKey();
        return latestFile;
    }

    /**
     * helper method to find given file from list of files
     *
     * @param fileList (list of files)
     * @param file     (filename to be searched)
     * @return true/false
     */
    private boolean isFilePresentInList(List<String> fileList, String file) {
        boolean flag = false;
        for (String entry : fileList) {
            if (entry.equalsIgnoreCase(file)) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * helper method to find list of files for a particular source from list of files for several source
     *
     * @param filenames    (list of files for several source)
     * @param source       (target source for which list of files is required)
     * @param orgName      ( Gives the organization name)
     * @param complianceId ( it is the compliance)
     * @param fileType     (It takes {@link EvidenceFileType})
     * @return list of files
     */
    private List<String> findFilesWithSourceName(List<String> filenames, String source, String orgName, String complianceId, EvidenceFileType fileType) {
        List<String> sourceList = new ArrayList<>();
        String prefix = (orgName + "_" + complianceId + "_" + source + "_" + fileType.name()).toLowerCase(Locale.ROOT);
        for (String filename : filenames) {
            if (filename.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                sourceList.add(filename);
            }
        }
        return sourceList;
    }

    public String getFormatFromMetadata(String metadata) {
        String[] metadataSplit = metadata.split(";");
        String[] extractFormat = metadataSplit[0].split("/");
        String format = extractFormat[1];
        return format;
    }

    public byte[] base64ToByteArray(String base64Content) {
        byte[] decodedBytes = Base64.getDecoder().decode(base64Content);
        return decodedBytes;
    }

    /**
     * helper method to convert multipart file to file
     *
     * @param multipartFile (Multipart)
     * @return converted file
     */
    public File convertMultiPartFileToFile(MultipartFile multipartFile) {
        File convertedFile = new File(multipartFile.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
            fos.write(multipartFile.getBytes());
        } catch (IOException e) {
            log.error("Error converting multipartFile to file", e);
        }
        return convertedFile;
    }

    /**
     * helper method to generate file name from source, complianceId, original filename and organization name
     *
     * @param source
     * @param complianceId
     * @param originalFileName
     * @param organizationName
     * @return filename with source, complianceId, original filename , organization name and timestamp
     */
    private String generateFileName(String source, String complianceId, String originalFileName, String organizationName) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        Date date = new Date();
        String fileName = organizationName + "_" + complianceId + "_" + source + "_" + "M" + "_" + formatter.format(date) + "_" + originalFileName;
        return fileName;
    }

    /**
     * helper method to get extension from filename
     *
     * @param filename
     * @return extension
     */
    private String getExtension(String filename) {
        return Optional.ofNullable(filename).filter(f -> f.contains(".")).map(f -> f.substring(filename.lastIndexOf(".") + 1)).map(Object::toString).orElse("");
    }

    /**
     * helper method to check if a filename contains complianceId and organization name
     *
     * @param filename
     * @param itemsToBeIncludedInFilename (list of strings containing complianceId and organization name)
     * @return true/false
     */
    private boolean containsWords(String filename, List<String> itemsToBeIncludedInFilename) {
        boolean found = false;

        if (filename.isEmpty()) {
            return found;
        }
        List<String> regexList = new ArrayList<>();
        for (String item : itemsToBeIncludedInFilename) {
            regexList.add("\\b" + item.toLowerCase() + "\\b");
        }
        String filenameLowerCase = filename.toLowerCase();
        String[] filenameSplit = filenameLowerCase.split("_");
        int count = 0;
        //checking for organization name
        for (String regex : regexList) {
            //Creating a pattern object
            Pattern pattern = Pattern.compile(regex);
            //Matching the compiled pattern in the String
            Matcher matcher = pattern.matcher(filenameSplit[0]);
            if (matcher.find()) {
                count++;
            }
        }
        //checking for complianceId
        for (String regex : regexList) {
            //Creating a pattern object
            Pattern pattern = Pattern.compile(regex);
            //Matching the compiled pattern in the String
            Matcher matcher = pattern.matcher(filenameSplit[1]);
            if (matcher.find()) {
                count++;
            }
        }
        if (count == 2) {
            found = true;
        }
        return found;
    }

    /**
     * this method will fetch the systemgenerated files.
     *
     * @param allS3Files                  (Contains all the S3 filenames)
     * @param source                      (Gives the source name)
     * @param filesAndModifiedDateMapping (Map with filenames and DateModified)
     * @param orgName                     (Organization name)
     * @param complianceId                (Compliance)
     * @param isUserAnAuditor             (boolean to represent user is an auditor or not)
     * @param auditPeriodDto              (Dto object of {@link AuditPeriodDto})
     * @return system generated files
     */
    private String fetchSystemGenFiles(List<String> allS3Files, String source, HashMap<String, Date> filesAndModifiedDateMapping, String orgName, String complianceId, boolean isUserAnAuditor, AuditPeriodDto auditPeriodDto) {
        List<String> allSystemGenFiles = findFilesWithSourceName(allS3Files, source, orgName, complianceId, EvidenceFileType.SG);
        if (!allSystemGenFiles.isEmpty()) {
            HashMap<String, Date> singleSourceFilesAndModifiedDateMapping = new HashMap<>();
            for (String fileName : allSystemGenFiles) {
                singleSourceFilesAndModifiedDateMapping.put(fileName, filesAndModifiedDateMapping.get(fileName));
            }
            return getLatestFilesByModifiedDate(singleSourceFilesAndModifiedDateMapping, isUserAnAuditor, auditPeriodDto);
        }
        return null;
    }

    /**
     * This method fetch the list of manual files
     * <p>
     * TODO : Need to improve the coding in this method
     *
     * @param allS3Files                  (Contains all the filenames)
     * @param source                      (Gives the source name)
     * @param filesAndModifiedDateMapping (Map with filenames and DateModified)
     * @param orgName                     (Organization name)
     * @param complianceId                (Compliance)
     * @param isUserAnAuditor             (boolean to represent user is an auditor or not)
     * @param auditPeriodDto              (Dto object of {@link AuditPeriodDto})
     * @return it returns the manual files
     */
    private List<String> fetchManualFiles(List<String> allS3Files, String source, HashMap<String, Date> filesAndModifiedDateMapping, String orgName, String complianceId, boolean isUserAnAuditor, AuditPeriodDto auditPeriodDto) {
        try {
            List<String> manualFiles = findFilesWithSourceName(allS3Files, source, orgName, complianceId, EvidenceFileType.M);
            if (!manualFiles.isEmpty()) {
                HashMap<String, Date> manualFilesAndModifiedDateMapping = new LinkedHashMap<>();
                for (String filename : manualFiles) {
                    manualFilesAndModifiedDateMapping.put(filename, filesAndModifiedDateMapping.get(filename));
                }
                List<Map.Entry<String, Date>> listOfFilesWithDate =
                        new LinkedList<>(manualFilesAndModifiedDateMapping.entrySet());
                // Sort the list
                Collections.sort(listOfFilesWithDate, new S3FileDateComparator());
                // clear the map and put sorted data back to same hashmap
                manualFilesAndModifiedDateMapping.clear();
                for (Map.Entry<String, Date> file : listOfFilesWithDate) {
                    if (isUserAnAuditor) {
                        if (file.getValue().before(auditPeriodDto.getAuditInitiateDate())) {
                            manualFilesAndModifiedDateMapping.put(file.getKey(), file.getValue());
                        }
                    } else {
                        manualFilesAndModifiedDateMapping.put(file.getKey(), file.getValue());
                    }
                }
                Iterator<String> itr = manualFilesAndModifiedDateMapping.keySet().iterator();
                // clear the manualFiles list and add only 5 recent files back to same list
                manualFiles.clear();
                for (int i = 0; i < 5 && itr.hasNext(); i++) {
                    manualFiles.add(itr.next());
                }
            }
            return manualFiles;
        } catch (Exception exception) {
            log.error("Files could not be fetched. " + exception.getMessage());
            throw new S3BucketException("Files could not be fetched. " + exception.getMessage());
        }
    }
}