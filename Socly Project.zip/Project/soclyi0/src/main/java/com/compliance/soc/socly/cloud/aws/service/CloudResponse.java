package com.compliance.soc.socly.cloud.aws.service;

import com.compliance.soc.socly.common.AbstractResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
/**
 * It is a response body for CloudResponse.
 */
public class CloudResponse {
	    String module;
	    Integer totalCompliancePoint;
	    Integer acceptedComplianceScore ;
	    Integer rejectedComplianceScore;
	    Double percentComplianceScore;
	    List<AbstractResponse> abstractResponse;
}
