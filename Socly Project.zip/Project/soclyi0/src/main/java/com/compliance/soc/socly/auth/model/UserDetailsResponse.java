package com.compliance.soc.socly.auth.model;

import com.compliance.soc.socly.quiz.model.QuizDetail;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
public class UserDetailsResponse {
    private String username;
    private String email;
    private String phone;
    private String name;
    private Set<RoleDto> roles;
    private OrganizationDto organization;
    private String businessTitle;
    private String organizationName;
    private Date createdDate;
    private Long createdBy;
    private Date modifiedDate;
    private Long modifiedBy;
    private boolean isPasswordChanged;
    private boolean isDetailsFilled;
    private String status;
    private QuizDetail quizDetail;
}
