package com.compliance.soc.socly.contactus.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.validation.constraints.NotNull;

/**
 * ContactUsDto is a model class and it is a data transfer object and set or get properties from the ContactUsDto.
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContactUsDto {
    @NotNull
    private String subject;
    @NotNull
    private String category;
    @NotNull
    private String query;
}
