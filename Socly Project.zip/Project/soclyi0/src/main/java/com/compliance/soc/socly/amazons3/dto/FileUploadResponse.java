package com.compliance.soc.socly.amazons3.dto;

public class FileUploadResponse {
    private String filename;
    private String type;
    private float filesize;

    public FileUploadResponse() {
    }

    public FileUploadResponse(String filename, String type, float filesize) {
        this.filename = filename;
        this.type = type;
        this.filesize = filesize;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getFileSize() {
        return filesize;
    }

    public void setFileSize(float filesize) {
        this.filesize = filesize;
    }
}
