package com.compliance.soc.socly.audit.service;

import com.compliance.soc.socly.audit.entity.FileApproval;
import com.compliance.soc.socly.audit.model.FileApprovalDto;
import com.compliance.soc.socly.audit.model.FileApprovalRequest;
import com.compliance.soc.socly.auth.entity.User;

import javax.validation.Valid;
import java.util.List;

/**
 * FileApprovalService is an Interface create methods and implement methods in impl class
 */
public interface FileApprovalService {
    List<FileApproval> getAll();

    FileApprovalDto save(@Valid FileApprovalRequest fileApprovalRequest, User user) throws Exception;
}
