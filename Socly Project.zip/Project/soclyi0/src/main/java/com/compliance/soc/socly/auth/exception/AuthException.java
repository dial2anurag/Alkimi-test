package com.compliance.soc.socly.auth.exception;


/**
 * Custom exception class to handle exception in auth package
 */

public class AuthException extends Exception {

    public AuthException(final Exception ex) {

        super(ex);

    }


    public AuthException(final String errorMsg) {

        super(errorMsg);

    }

}
