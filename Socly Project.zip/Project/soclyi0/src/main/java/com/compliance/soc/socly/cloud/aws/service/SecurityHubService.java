package com.compliance.soc.socly.cloud.aws.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClientBuilder;
import com.amazonaws.services.identitymanagement.model.AttachedPolicy;
import com.amazonaws.services.identitymanagement.model.GetGroupRequest;
import com.amazonaws.services.identitymanagement.model.GetGroupResult;
import com.amazonaws.services.identitymanagement.model.Group;
import com.amazonaws.services.identitymanagement.model.ListAttachedGroupPoliciesRequest;
import com.amazonaws.services.identitymanagement.model.ListAttachedGroupPoliciesResult;
import com.amazonaws.services.identitymanagement.model.ListAttachedUserPoliciesRequest;
import com.amazonaws.services.identitymanagement.model.ListAttachedUserPoliciesResult;
import com.amazonaws.services.identitymanagement.model.ListGroupsResult;
import com.amazonaws.services.identitymanagement.model.ListUsersResult;
import com.amazonaws.services.identitymanagement.model.User;
import com.amazonaws.services.securityhub.AWSSecurityHub;
import com.amazonaws.services.securityhub.AWSSecurityHubClientBuilder;
import com.amazonaws.services.securityhub.model.AwsSecurityFinding;
import com.amazonaws.services.securityhub.model.GetFindingsRequest;
import com.amazonaws.services.securityhub.model.GetFindingsResult;
import com.amazonaws.services.securityhub.model.Resource;
import com.compliance.soc.socly.auth.entity.SuperUser;
import com.compliance.soc.socly.common.AbstractResponse;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.EntityCompliance;
import com.compliance.soc.socly.util.secrets.ClientSecretsUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class SecurityHubService {

    @Autowired
    private ClientSecretsUtil secretsUtil;

    private static final Logger log = LoggerFactory.getLogger(SecurityHubService.class);

    /**
     * it is compliance security response method.
     * @param accessKey
     * @param secretKey
     * @param defaultRegion
     * @param superUser
     * @return
     */

    public ComplianceResponse security(String accessKey, String secretKey, String defaultRegion, SuperUser superUser) {

        BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKey, secretKey);
        List<List<AwsSecurityFinding>> l = new ArrayList();

        List<AwsSecurityFinding> s3List = new ArrayList();
        List<AwsSecurityFinding> rdsList = new ArrayList();
        List<AwsSecurityFinding> ec2List = new ArrayList();
        List<AwsSecurityFinding> iamList = new ArrayList();
        List<AwsSecurityFinding> awsList = new ArrayList();
        List<AwsSecurityFinding> arnList = new ArrayList();
        List<AwsSecurityFinding> miscList = new ArrayList();

        List<AwsSecurityFinding> securityFindingList = new ArrayList();

        String cloudAwsAdmins = superUser.getCloudAwsAdmins();
        String admins[] = cloudAwsAdmins.split(",");
        log.info("List of admins as per client " + Arrays.asList(admins));

        AmazonIdentityManagement iam = null;
        try {
            iam = AmazonIdentityManagementClientBuilder.standard().withRegion(defaultRegion)
                    .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

        } catch (Exception e) {
            log.error("Exception " + e);
        }

        if (iam == null) {
            log.info("Invalid Credential");
            throw new RuntimeException("Invalid Credential");
        }

        ListUsersResult listUsersResult = iam.listUsers();

        List<User> users = listUsersResult.getUsers();

        List adminList = new ArrayList();
        for (User user : users) {
            String username = user.getUserName();
            log.info("user {}", user);
            ListAttachedUserPoliciesRequest req = new ListAttachedUserPoliciesRequest().withUserName(username);
            ListAttachedUserPoliciesResult policyResult = iam.listAttachedUserPolicies(req);
            List<AttachedPolicy> attachedPolicies = policyResult.getAttachedPolicies();
            log.info("for username {}", username);
            for (AttachedPolicy policies : attachedPolicies) {
                String policyName = policies.getPolicyName();
                log.info("PolicyName {}", policyName);
                if (policyName.equalsIgnoreCase("AdministratorAccess")) {

                    adminList.add(username);
                }
            }
        }
        ListGroupsResult listGroupsResult = iam.listGroups();
        List<Group> groups = listGroupsResult.getGroups();
        for (Group group : groups) {
            String groupName = group.getGroupName();
            ListAttachedGroupPoliciesRequest listAttachedGroupPoliciesRequest = new ListAttachedGroupPoliciesRequest().withGroupName(groupName);
            ListAttachedGroupPoliciesResult listAttachedGroupPoliciesResult = iam.listAttachedGroupPolicies(listAttachedGroupPoliciesRequest);
            List<AttachedPolicy> attachedPolicies = listAttachedGroupPoliciesResult.getAttachedPolicies();
            log.info("For Group {} ", groupName);
            for (AttachedPolicy policies : attachedPolicies) {
                String policyName = policies.getPolicyName();
                log.info("PolicyName {}", policyName);
                if (policyName.equalsIgnoreCase("AdministratorAccess")) {
                    GetGroupRequest grp = new GetGroupRequest();
                    grp.setGroupName(groupName);
                    GetGroupResult group1 = iam.getGroup(grp);
                    List<User> users1 = group1.getUsers();
                    for (User u : users1) {
                        log.info("Username is  {}", u.getUserName());
                        adminList.add(u.getUserName());
                    }
                }
            }
        }

        log.info("adminList from aws account {}", adminList);

        List finalAdmins = new ArrayList();

        for (int i = 0; i < admins.length; i++) {
            log.info("admins {}  {}", i, admins[i]);
            boolean b = adminList.remove(admins[i]);
            log.info("b value is {}", b);
            if (b == false) {
                finalAdmins.add(admins[i]);
            }
        }

        if (adminList.size() > 0) {
            for (Object obj : adminList) {
                String admin = (String) obj;
                log.info("admin being added {}", admin);
                finalAdmins.add(admin);
            }
        }
        int iamAdmin = 1;    //passed
        String iamAdminCheck = "PASSED";
        if (finalAdmins.size() != 0) {
            log.info("finalAdmins {}", finalAdmins);
            iamAdmin = 0;        // failed
            iamAdminCheck = "FAILED";
        }


        AWSSecurityHub awsSecurity = AWSSecurityHubClientBuilder.standard().withRegion(defaultRegion)
                .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();
        GetFindingsRequest req = new GetFindingsRequest();
        String nextToken = null;

        int count1 = 0;
        int count2 = 0;
        int count3 = 0;


        for (int i = 0; i < 15; i++) {
            GetFindingsResult result = awsSecurity.getFindings(req.withMaxResults(100));
            nextToken = result.getNextToken();

            log.info("Token " + nextToken);
            log.info("Token {}", nextToken);
            req.setNextToken(nextToken);
            List<AwsSecurityFinding> findings = result.getFindings();
            log.info("Total json object received in {} call {}", i, findings.size());

            for (AwsSecurityFinding asf : findings) {
                Resource resource = asf.getResources().get(0); // always only 1 in size

                if (asf.getRecordState().equals("ACTIVE") && asf.getGeneratorId().contains("aws-foundational-security-best-practices")) {
                    count1++;
                    if (asf.getTitle().contains("S3")) {
                        s3List.add(asf);
                    } else if (asf.getTitle().contains("RDS") || asf.getTitle().contains("DB")) {
                        rdsList.add(asf);
                    } else if (asf.getTitle().contains("EC2")) {
                        ec2List.add(asf);
                    } else if (asf.getTitle().contains("IAM")) {
                        iamList.add(asf);
                    } else {
                        awsList.add(asf);
                    }
                } else if (asf.getRecordState().equals("ACTIVE") && asf.getGeneratorId().contains("arn:aws:securityhub:::ruleset")) {
                    count2++;
                } else {
                    count3++;
                }
            }
            if (nextToken == null) {
                break;
            }
        }

        AbstractResponse s3Response = new AbstractResponse();
        AbstractResponse rdsResponse = new AbstractResponse();
        AbstractResponse ec2Response = new AbstractResponse();
        AbstractResponse iamResponse = new AbstractResponse();
        AbstractResponse awsResponse = new AbstractResponse();

        s3Response.setModule("S3 bucket for storage");
        rdsResponse.setModule("RDS for database");
        ec2Response.setModule("EC2 for server instance");
        iamResponse.setModule("IAM for user access");
        awsResponse.setModule("Miscellaneous Entities");

        s3Response.setCompliancePoint(s3List.size());
        rdsResponse.setCompliancePoint(rdsList.size());
        ec2Response.setCompliancePoint(ec2List.size());
        iamResponse.setCompliancePoint(iamList.size() + 1);
        awsResponse.setCompliancePoint(awsList.size());

        int s3passed = (int) s3List.stream().filter(a -> a.getCompliance().getStatus().equalsIgnoreCase("passed")).count();
        int rdspassed = (int) rdsList.stream().filter(a -> a.getCompliance().getStatus().equalsIgnoreCase("passed")).count();
        int ec2passed = (int) ec2List.stream().filter(a -> a.getCompliance().getStatus().equalsIgnoreCase("passed")).count();
        int iampassed = (int) iamList.stream().filter(a -> a.getCompliance().getStatus().equalsIgnoreCase("passed")).count();
        int miscpassed = (int) awsList.stream().filter(a -> a.getCompliance().getStatus().equalsIgnoreCase("passed")).count();

        iampassed = iampassed + iamAdmin;

        s3Response.setAcceptedComplianceScore(s3passed);
        rdsResponse.setAcceptedComplianceScore(rdspassed);
        ec2Response.setAcceptedComplianceScore(ec2passed);
        iamResponse.setAcceptedComplianceScore(iampassed);
        awsResponse.setAcceptedComplianceScore(miscpassed);

        s3Response.setPercentComplianceScore((s3passed * 100.0) / s3List.size());
        rdsResponse.setPercentComplianceScore((rdspassed * 100.0) / rdsList.size());
        ec2Response.setPercentComplianceScore((ec2passed * 100.0) / ec2List.size());
        iamResponse.setPercentComplianceScore((iampassed * 100.0) / (iamList.size() + 1));
        awsResponse.setPercentComplianceScore((miscpassed * 100.0) / awsList.size());

        s3Response.setRejectedComplianceScore(s3List.size() - s3passed);
        rdsResponse.setRejectedComplianceScore(rdsList.size() - rdspassed);
        ec2Response.setRejectedComplianceScore(ec2List.size() - ec2passed);
        iamResponse.setRejectedComplianceScore((iamList.size() + 1) - iampassed);
        awsResponse.setRejectedComplianceScore(awsList.size() - miscpassed);

        List<EntityCompliance> s3entityComplianceList = new ArrayList<>();
        List<EntityCompliance> rdsentityComplianceList = new ArrayList<>();
        List<EntityCompliance> ec2entityComplianceList = new ArrayList<>();
        List<EntityCompliance> iamentityComplianceList = new ArrayList<>();
        List<EntityCompliance> awsentityComplianceList = new ArrayList<>();

        for (AwsSecurityFinding securityFinding : s3List) {

            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getTitle());
            String complianceStatus = securityFinding.getCompliance().getStatus();
            entityCompliance.setComplianceStatus(complianceStatus);
            Resource resource = securityFinding.getResources().get(0);
            entityCompliance.setDescription("Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
            if (!complianceStatus.equals("PASSED")) {
                entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            }
            s3entityComplianceList.add(entityCompliance);

        }


        for (AwsSecurityFinding securityFinding : rdsList) {
            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getTitle());
            String complianceStatus = securityFinding.getCompliance().getStatus();
            entityCompliance.setComplianceStatus(complianceStatus);
            Resource resource = securityFinding.getResources().get(0);
            entityCompliance.setDescription("Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
            if (!complianceStatus.equals("PASSED")) {
                entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            }
            rdsentityComplianceList.add(entityCompliance);
        }

        for (AwsSecurityFinding securityFinding : ec2List) {
            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getTitle());
            String complianceStatus = securityFinding.getCompliance().getStatus();
            entityCompliance.setComplianceStatus(complianceStatus);
            Resource resource = securityFinding.getResources().get(0);
            entityCompliance.setDescription("Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
            if (!complianceStatus.equals("PASSED")) {
                entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            }
            ec2entityComplianceList.add(entityCompliance);
        }

        for (AwsSecurityFinding securityFinding : iamList) {
            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getTitle());
            String complianceStatus = securityFinding.getCompliance().getStatus();
            entityCompliance.setComplianceStatus(complianceStatus);
            Resource resource = securityFinding.getResources().get(0);
            entityCompliance.setDescription("Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
            if (!complianceStatus.equals("PASSED")) {
                entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            }
            iamentityComplianceList.add(entityCompliance);
        }

        EntityCompliance entityComplianceIamAdmin = new EntityCompliance();
        entityComplianceIamAdmin.setComplianceTitle("This control checks whether list of aws admin provided during registration is same as in aws IAM account");
        entityComplianceIamAdmin.setDescription("This control checks whether list of aws admin provided during registration is same as in aws IAM account");
        entityComplianceIamAdmin.setComplianceStatus(iamAdminCheck);
        if (!iamAdminCheck.equalsIgnoreCase("passed")) {
            String newline = System.getProperty("line.separator");
            String s = "List of IAM admins provided during client registration: " + Arrays.asList(admins) + newline + " while the list of IAM admins available in the aws account: " + adminList;
            log.info(s);
            entityComplianceIamAdmin.setRecommended_Remediation(s);

        }
        iamentityComplianceList.add(entityComplianceIamAdmin);

        for (AwsSecurityFinding securityFinding : awsList) {
            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getTitle());
            String complianceStatus = securityFinding.getCompliance().getStatus();
            entityCompliance.setComplianceStatus(complianceStatus);
            Resource resource = securityFinding.getResources().get(0);
            entityCompliance.setDescription("Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
            if (!complianceStatus.equals("PASSED")) {
                entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            }
            awsentityComplianceList.add(entityCompliance);
        }


        s3Response.setEntityCompliance(s3entityComplianceList);
        rdsResponse.setEntityCompliance(rdsentityComplianceList);
        ec2Response.setEntityCompliance(ec2entityComplianceList);
        iamResponse.setEntityCompliance(iamentityComplianceList);
        awsResponse.setEntityCompliance(awsentityComplianceList);


        List<AbstractResponse> finalList = new ArrayList<>();
        finalList.add(s3Response);
        finalList.add(rdsResponse);
        finalList.add(ec2Response);
        finalList.add(iamResponse);
        finalList.add(awsResponse);

        count1++;
        ComplianceResponse complianceResponse = new ComplianceResponse();
        complianceResponse.setModule("Cloud_AWS");
        complianceResponse.setTotalCompliancePoint(count1);
        int totalPassed = s3passed + rdspassed + ec2passed + iampassed + miscpassed;
        complianceResponse.setTotalAcceptedComplianceScore(totalPassed);
        complianceResponse.setPercentComplianceScore((totalPassed * 100.0) / count1);
        complianceResponse.setTotalRejectedComplianceScore(count1 - totalPassed);
        complianceResponse.setAbstractResponse(finalList);


        log.info("s3 object count {}", s3List.size());
        log.info("rds {}", rdsList.size());
        log.info("ec2 {}", ec2List.size());
        log.info("iam {}", iamList.size());
        log.info("Total number of Json object from aws : {}", count1);
        log.info("Total number of Json object from arn : {}", count2);
        log.info("Total number of Json object for which \"details\"  is null : {}", count3);


        l.add(s3List);
        l.add(rdsList);
        l.add(ec2List);
        l.add(iamList);
        l.add(awsList);


        securityFindingList.addAll(s3List);
        securityFindingList.addAll(rdsList);
        securityFindingList.addAll(ec2List);
        securityFindingList.addAll(iamList);
        securityFindingList.addAll(awsList);

        for (AwsSecurityFinding securityFinding : securityFindingList) {
            EntityCompliance entityCompliance = new EntityCompliance();
            entityCompliance.setComplianceTitle(securityFinding.getDescription());
            entityCompliance.setDescription(securityFinding.getDescription());
            entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
            entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
        }

        log.info("Total Json Object {}", l.size());

        return complianceResponse;

    }
}

