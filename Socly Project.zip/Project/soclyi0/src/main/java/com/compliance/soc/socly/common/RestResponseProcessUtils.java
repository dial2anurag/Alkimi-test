package com.compliance.soc.socly.common;

import java.util.Map;

/**
 * Util class used in multiple controllers@jirataskTrackerAPIService @BitbucketService @Github Service.
 */

public class RestResponseProcessUtils {

    public static <T> T extractValue(String keyExp, Map object, Class<T> targetType) {
        String[] keys = keyExp.split("\\.");
        Map value = object;
        for (int i = 0; i < keys.length - 1; i++) {
            value = (Map) value.get(keys[i]);
            if (value == null) {
                return null;
            }
        }
        return targetType.cast(value.get(keys[keys.length - 1]));
    }
}
