package com.compliance.soc.socly.metrics.service;

import com.compliance.soc.socly.metrics.entity.MetricTypes;
import com.compliance.soc.socly.metrics.repository.MetricTypesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MetricTypesService {

    @Autowired
    private MetricTypesRepository metricTypesRepository;

    /**
     * API method to fetch the  list of All active metrics types through the types
     * @return metrics
     */
    public List<MetricTypes> getAllActiveMetricTypes(){
        return (List<MetricTypes>) metricTypesRepository.findByStatus("Active");
    }
}
