package com.compliance.soc.socly.audit.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * PrincipleApprovalDto is a Dto class used for post or get values of selected properties
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PrincipleApprovalRequest {

    private char status;
    private int principleId;
    private int clientId;
    private int auditId;
    private String auditNote;
    private FrameworkDto framework;

}
