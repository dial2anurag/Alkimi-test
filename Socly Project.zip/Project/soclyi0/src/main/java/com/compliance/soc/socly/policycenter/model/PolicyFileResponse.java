package com.compliance.soc.socly.policycenter.model;

import lombok.Data;

/**
 * it is model class to request the file from s3bucket.
 */
@Data
public class PolicyFileResponse {
    /**
     * Fetch file details if exist or null
     */
    private OrgPolicyDto details;

    /**
     * Policy file content
     */
    private byte[] fileContent;
}
