package com.compliance.soc.socly.enums;

/**
 *Enumerations for module.
 */
public enum Module {
    CLOUD,
    TASK_TRACKER,
    SOURCE_CONTROL_MANAGEMENT,
    USER_MANAGEMENT
}
