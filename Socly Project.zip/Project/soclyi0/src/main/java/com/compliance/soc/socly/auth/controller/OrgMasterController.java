package com.compliance.soc.socly.auth.controller;

import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.model.OrgMasterUserDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.organization.model.OrgDetailsDto;
import com.compliance.soc.socly.util.IsBusinessAdmin;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/organization")
@Slf4j
public class OrgMasterController {

    @Autowired
    private OrgMasterService orgMasterService;

    /**
     * API method to register the organization .
     * and admin also get registered and saves in Users.
     *
     * @param orgMasterDto
     * @return
     */
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @PostMapping(value = "/register")
    public ResponseEntity<?> save(final @RequestBody OrgMasterUserDto orgMasterDto) {
        try {
            final OrganizationDto organization = orgMasterService.save(orgMasterDto);
            return ResponseEntity.ok().body(organization);
        } catch (final Exception ue) {
            log.error(ue.getMessage());
            return ResponseEntity.badRequest().body(ue.getMessage());
        }
    }

    /**
     * API method to get all organization details by status.
     *
     * @param status
     */
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @GetMapping(value = "/all/on/status")
    public ResponseEntity<?> getOrgs(@RequestParam String status) {
        List<OrganizationDto> organizations;
        try {
            organizations = orgMasterService.getOrganizations(status);
            if (organizations == null || organizations.isEmpty())
                throw new AuthException("No organizations found for given status: " + status);
        } catch (Exception ae) {
            log.error(ae.getMessage());
            return ResponseEntity.badRequest().body(ae.getMessage());
        }
        return ResponseEntity.ok(organizations);
    }

    /**
     * update is a APi method is used to update values in OrgDetailsDto table of given list of params
     *
     * @param orgDetailsDtos : organization details request.
     * @return orgDetailsDto: returnig organization details with id.
     */
    @PutMapping(value = "/update/details")
    public ResponseEntity<?> orgDetailsUpdate(@RequestBody List<OrgDetailsDto> orgDetailsDtos) {
        try {
            orgDetailsDtos = orgMasterService.updateOrgDetails(orgDetailsDtos);
            return ResponseEntity.status(HttpStatus.OK).body(orgDetailsDtos);
        } catch (final Exception ue) {
            log.error("Unable to update the organization details for the Organization {} with error {} ", orgDetailsDtos.get(1).getOrgId(), ue.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to update the organization Details.");
        }
    }

    /**
     * Api to save the organization file in folder documents.
     *
     * @param file Input file
     * @return
     */
    @PostMapping(value = "/file/save",
            consumes = {"multipart/form-data"})
    @IsBusinessAdmin
    public ResponseEntity<String> saveFileForOrganization(@RequestParam(value = "file") MultipartFile file) {
        try {
            orgMasterService.saveFileForOrganization(file);
            log.info(file.getOriginalFilename() + " File is saved under the document folder of organization");
            return ResponseEntity.ok().body(file.getOriginalFilename() + " File is saved under the document folder of organization");
        } catch (Exception exp) {
            log.error(exp.getMessage() + file.getOriginalFilename());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exp.getMessage());
        }
    }
}