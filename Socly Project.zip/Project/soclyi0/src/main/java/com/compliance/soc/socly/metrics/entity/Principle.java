package com.compliance.soc.socly.metrics.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;


@Entity
@Table(name = "metrics_master")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
/**
 * entity class with properties from the metrics_master table
 */
public class Principle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "metrics_id")
    private int metricsId;

    @Column(name = "principle")
    private String principle;

    @Column(name = "title")
    private String title;

    @Column(name = "flag")
    private String flag;

    @Column(name = "status")
    private String status;
    /**
     * joining metricsmaster table and metrics_compliance_mapping.
     */

    @OneToMany(targetEntity = MetricsComplianceMapping.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "master_id", referencedColumnName = "metrics_id")
    private List<MetricsComplianceMapping> metricsComplianceMapping;

}
