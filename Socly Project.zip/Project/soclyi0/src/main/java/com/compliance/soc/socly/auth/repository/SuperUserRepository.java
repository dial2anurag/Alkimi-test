package com.compliance.soc.socly.auth.repository;

import com.compliance.soc.socly.auth.entity.SuperUser;
import org.springframework.data.repository.CrudRepository;

public interface SuperUserRepository extends CrudRepository<SuperUser, Integer> {
    public SuperUser findByCompanyName(String companyName);
}

