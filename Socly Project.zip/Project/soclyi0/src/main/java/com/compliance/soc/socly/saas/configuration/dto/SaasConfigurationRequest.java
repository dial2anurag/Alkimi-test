package com.compliance.soc.socly.saas.configuration.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaasConfigurationRequest {

    private String saasId;
    private Integer frameworkId;
    private String name;
    private String configurationValue;
}
