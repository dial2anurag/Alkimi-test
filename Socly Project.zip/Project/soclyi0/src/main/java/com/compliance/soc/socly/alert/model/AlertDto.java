package com.compliance.soc.socly.alert.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * AlertDto is a model class and it is a data transfer object and set or get properties from the AlertDto.
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AlertDto {

    private String complianceName;

    private String createdDate;

    private String description;

    private String status;

    private String remediation;

    private String orgSaasId;
}
