package com.compliance.soc.socly.policycenter.controller;

import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.compliance.soc.socly.enums.PolicyStatus;
import com.compliance.soc.socly.policycenter.model.OrgPolicyDto;
import com.compliance.soc.socly.policycenter.model.PolicyDto;
import com.compliance.soc.socly.policycenter.model.PolicyFileResponse;
import com.compliance.soc.socly.policycenter.service.OrgPolicyService;
import com.compliance.soc.socly.util.IsBusinessAdmin;
import com.compliance.soc.socly.util.s3.S3Util;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
public class PolicyCenterController {

    @Autowired
    private final S3Util s3Util;
    @Autowired
    private OrgPolicyService orgPolicyService;
    @Value("${s3Bucket.policies}")
    private String s3BucketPolicies;

    /**
     * API to fetch {@link S3Util} policy based on given id
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/policies/{id}", method = RequestMethod.GET, produces = "application/pdf")
    public ResponseEntity<Object> getPolicy(@PathVariable String id) {
        try {
            Optional<PolicyDto> policyObject = orgPolicyService.fetchPolicies().stream()
                    .filter(policy -> {
                        return policy.getId().equals(id);
                    })
                    .findFirst();
            if (!policyObject.isPresent()) {
                log.error("Policy doesn't exist for given Id: {}", id);
                return ResponseEntity.badRequest()
                        .body("Policy doesn't exist for given Id: " + id);
            }
            S3Object object = s3Util.getObjectS3(s3BucketPolicies, policyObject.get().getName() + ".pdf");
            S3ObjectInputStream s3is = object.getObjectContent();
            log.info("successful");
            return ResponseEntity.ok()
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .cacheControl(CacheControl.noCache())
                    .header("Content-Disposition", "attachment; filename=" + "testing.pdf")
                    .body(new InputStreamResource(s3is));
        } catch (Exception e) {
            log.error("The policies does not exist for given id" + id);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }

    /**
     * API to fetch all policies from
     *
     * @return
     */
    @RequestMapping(value = "/policies/", method = RequestMethod.GET)
    public ResponseEntity<List<PolicyDto>> getAllPolicies() {
        try {
            final List<PolicyDto> policyDtos = orgPolicyService.fetchPolicies();
            log.info("All policies fetched successfully");
            return ResponseEntity.ok()
                    .body(policyDtos);
        } catch (Exception e) {
            log.error("Failed to fetch the policy files due to {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.EMPTY_LIST);
        }
    }

    /**
     * This api method to save the policies in unapproved folder.
     *
     * @param orgPolicyDto
     * @return
     */
    @PreAuthorize("hasRole('ORG_BUSINESS_ADMIN')")
    @PostMapping(value = "policy/unapproved/save",
            consumes = {"multipart/form-data"})
    public ResponseEntity<?> saveOrgUnapprovedPolicy(@ModelAttribute OrgPolicyDto orgPolicyDto, @RequestParam(value = "unapproved_policy_files", required = false) MultipartFile multipartFile) {
        try {
            final OrgPolicyDto policyDto = orgPolicyService.unapprovedSave(orgPolicyDto, multipartFile);
            return ResponseEntity.ok().body(policyDto);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return ResponseEntity.badRequest().body(exp.getMessage());
        }
    }

    /**
     * This API method to approve and save the policies in policy center object.
     *
     * @param orgPolicyDto
     * @param multipartFile
     * @return
     */
    @PutMapping(value = "policy/approve/save",
            consumes = {"multipart/form-data"})
    public ResponseEntity<OrgPolicyDto> saveOrgApprovedPolicy(@ModelAttribute OrgPolicyDto orgPolicyDto, @RequestParam(value = "approved_policy_files") MultipartFile multipartFile) {
        OrgPolicyDto savedOrgPolicy = new OrgPolicyDto();
        try {
            savedOrgPolicy = orgPolicyService.approvePolicy(orgPolicyDto, multipartFile);
            return ResponseEntity.ok().body(savedOrgPolicy);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            savedOrgPolicy.setError(exp.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(savedOrgPolicy);
        }
    }

    /**
     * fetch list of policies based on status from org_policy table
     *
     * @param status : SendToApproval, RequestChange, Approved, Rejected, InProgress
     * @return policies (policy list based on status)
     */
    @GetMapping(value = "/policies/by/status")
    public ResponseEntity<List<OrgPolicyDto>> fetchPolicies(@RequestParam(required = false) PolicyStatus status) {
        try {
            List<OrgPolicyDto> policies = orgPolicyService.getPolicies(status);
            return ResponseEntity.ok().body(policies);
        } catch (Exception exp) {
            String message = "Policies could not be retrieved for status :" + status + " (default statuses in case null : SendToApproval and RequestChange). ";
            log.error(message + exp.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    /**
     * API to fetch the policy either template or unapproved file .
     *
     * @param fileName : Name of the policy file name
     * @param reset    : is a boolean value to decide to fetch template/file
     * @return policy template or unapproved policy file for given policy file name.
     */
    @GetMapping(value = "/policy/file")
    @IsBusinessAdmin
    public ResponseEntity<PolicyFileResponse> fetchPolicyTemplate(@RequestParam String fileName, @RequestParam(required = false) boolean reset) {
        try {
            final PolicyFileResponse policyFileResponse = orgPolicyService.fetchTempPolicy(fileName, reset);
            log.info("Successfully fetched the policy file {}", fileName);
            return ResponseEntity.ok()
                    .body(policyFileResponse);
        } catch (Exception exp) {
            log.error("Unable to fetch the file {} ", fileName);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new PolicyFileResponse());
        }
    }

    /**
     * Api to download the Approved policy file.
     *
     * @param orgPolicyId id of the org_policy table.
     * @return Download the Approved policy file.
     */
    @GetMapping(value = "policy/file/download/{orgPolicyId}")
    public ResponseEntity<InputStreamResource> downloadPolicy(@PathVariable int orgPolicyId) {
        try {
            S3ObjectInputStream s3ObjectInputStream = orgPolicyService.downloadPolicy(orgPolicyId);
            log.info("The Approved policy file exist for the given id " + orgPolicyId);
            return ResponseEntity.ok()
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .cacheControl(CacheControl.noCache())
                    .header("Content-Disposition", "attachment; filename=" + orgPolicyId)
                    .body(new InputStreamResource(s3ObjectInputStream));
        } catch (Exception e) {
            log.error("The Approved policy does not exist for given id " + orgPolicyId);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new InputStreamResource(InputStream.nullInputStream()));

        }
    }
}