package com.compliance.soc.socly.contactus.controller;

import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.contactus.model.ContactUsDto;
import com.compliance.soc.socly.contactus.service.ContactUsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.validation.Valid;
import java.io.IOException;

@Slf4j
@RestController
@RequestMapping(value = "/contactus")
public class ContactUsController extends BaseController{

    @Autowired
    ContactUsService contactUsService;

    /**
     * Api method is used to send email to support@socly.io with given request query below by the user
     * @param contactUsDto
     * @param attachment
     * @return
     * @throws IOException
     * @throws MessagingException
     */
    @PostMapping(value = "/sendemail",
            consumes = {"multipart/form-data"})
    public ResponseEntity<?> sendEmail(@ModelAttribute @Valid ContactUsDto contactUsDto, @RequestParam(value = "attachment", required = false) MultipartFile attachment) throws IOException, MessagingException {
        try {
            String content = ""
                    + "<div style='border:1px solid #e2e2e2; padding:20px'>"
                    + "<h3> Hello " + userService.getCurrentUser().getName() + ",</h3>"
                    + "<h3> We have received your request for support, someone will contact you. The details of your support request are as follows.</h3> "
                    + "<h3> Query: " + contactUsDto.getQuery() + "<h3>"
                    + "<br/>"
                    + "<h3>Thank you for reaching out.</h3>\n"
                    + "<h3>SOCLY.io </h3>"
                    + "<div style='text-align:center;'>"
                    + "<img height ='80 width='80' src='https://socly.io/wp-content/uploads/2021/09/cropped-cropped-cropped-cropped-SOCLY.IO_-3-1-1.png' title='logo' alt='logo'>"
                    + "</a>"
                    + "</div>"
                    + "</div>";
            contactUsDto.setQuery(content);
            if (attachment != null)
                contactUsService.sendMail(contactUsDto, attachment, userService.getCurrentUser());
            else {
                contactUsService.sendMail(contactUsDto, userService.getCurrentUser());
            }
            return ResponseEntity.ok().body("Email sent successfully");
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.valueOf(exception.getMessage()));
        }
    }
}
