package com.compliance.soc.socly.audit.model;

import com.compliance.soc.socly.auth.model.OrganizationDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

/**
 * FileApprovalDto is a Dto class used for post or get values of selected properties
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FileApprovalDto {
    private Integer id;

    /*
     * the fileId  which is reference of AuditPeriod(fileId)
     */
    private Integer fileId;

    /**
     * the status which shows auditStatus
     */
    private String status;

    /**
     * the complianceId which is reference of Metrics(complianceId)
     */
    private String complianceId;

    /**
     * the principleId which is reference of MetricsMaster(metricsId)
     */
    private Integer principleId;

    /**
     * the createdDate shows on which date it is created
     */
    private Date createdDate;

    /**
     * the modifiedDate shows on which date it is modified
     */
    private Date modifiedDate;

    /**
     * the createdBy shows from which user it is being created
     */
    private Long createdBy;

    /**
     * the modifiedBy shows from which user it is being modified
     */
    private Long modifiedBy;

    /**
     * the auditNote is to write audit comment while approving File
     */
    private String auditNote;

    /**
     * It is a mapping is done through AuditPeriod and FileApproval with reference of auditId
     */
    private AuditPeriodDto auditPeriod;

    /**
     * It is a mapping is done through Organization and FileApproval with reference of client_id
     */
    private OrganizationDto organization;
}
