package com.compliance.soc.socly.auth.repository;

import com.compliance.soc.socly.auth.entity.Role;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleRepository extends CrudRepository<Role, Long> {
    Role findRoleByName(String name);

    Role findById(long id);

    Role findByName(String name);

    List<Role> findAllByOrgView(Boolean orgView);

    List<Role> findAll();
}