package com.compliance.soc.socly.amazons3.dto;

import com.compliance.soc.socly.audit.model.ComplianceApprovalDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.metrics.dto.PrincipleDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ComplianceApprovalResponse {
    private Integer id;
    private char status;
    private PrincipleDto principleDto;
    private Date createdDate = new Date();
    private Date modifiedDate;
    private Long createdBy;
    private Long modifiedBy;
    private String auditNote;
    private ComplianceApprovalDto complianceDto;
    private AuditPeriodResponse auditPeriod;
    private OrganizationDto organizationDto;
}
