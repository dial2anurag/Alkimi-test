package com.compliance.soc.socly.cloudservice.service;

import com.compliance.soc.socly.cloudservice.dto.CloudServiceDto;

import java.util.List;

/**
 * fetching all list of cloud service providers.
 */
public interface ServiceManager {
    List<CloudServiceDto> getAllServices();
}
