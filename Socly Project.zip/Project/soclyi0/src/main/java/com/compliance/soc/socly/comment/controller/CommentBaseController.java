package com.compliance.soc.socly.comment.controller;
import com.compliance.soc.socly.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

public class CommentBaseController {

    @Autowired
    protected UserService userService;
}
