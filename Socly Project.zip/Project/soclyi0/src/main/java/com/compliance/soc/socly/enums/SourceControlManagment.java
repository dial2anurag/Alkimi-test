package com.compliance.soc.socly.enums;

/**
 * Enumeration for source control management.
 */
public enum SourceControlManagment {
    BITBUCKET,GITHUB
}
