package com.compliance.soc.socly.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
/**
 * Model for ComplianceResponse for Type2.
 */
public class Type2ComplianceData {
    private ComplianceResponse complianceResponse;
    private String fileDate;
}
