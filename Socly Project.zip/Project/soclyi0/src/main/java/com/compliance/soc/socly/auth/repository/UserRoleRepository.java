package com.compliance.soc.socly.auth.repository;

import com.compliance.soc.socly.auth.entity.UserRole;
import com.compliance.soc.socly.auth.model.UserRoleId;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRoleRepository extends CrudRepository<UserRole, UserRoleId> {
    UserRole findByUserIdAndRoleId(long userId, long roleId);
}
