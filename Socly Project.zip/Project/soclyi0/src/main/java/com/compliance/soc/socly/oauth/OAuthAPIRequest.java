package com.compliance.soc.socly.oauth;

import com.compliance.soc.socly.util.SecretManager;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.client.RestTemplate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OAuthAPIRequest {
    private String accessTokenUrl;
    private String clientId;
    private String clientSecret;
    private String authCode;
    private String redirectUri;
    private RestTemplate restTemplate;
    private String saasAccessToken;
    private SecretManager secretManager;
}
