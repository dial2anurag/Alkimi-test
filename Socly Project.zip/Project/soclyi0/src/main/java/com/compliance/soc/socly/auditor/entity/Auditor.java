package com.compliance.soc.socly.auditor.entity;


import com.compliance.soc.socly.auth.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;

/**
 * Auditor is an entity class and properties from the auditor table
 */
@Entity
@Getter
@Setter
@Table(name = "auditor")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Auditor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column(unique = true, nullable = false)
    private String username;
    @Column(unique = true, nullable = false)
    private String email;
    @Column
    private String name;
    @Column
    private String description;
    @Column
    private String phone;
    @Column
    private String status;
    @Column
    private Date createdDate;
    @Column
    private Date modifiedDate;
    @Column
    private boolean passwordChanged;
    @Column
    private String password;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name = "modified_by", referencedColumnName = "id")
    private User modifiedBy;

    @OneToMany(targetEntity = AuditorMapping.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "auditor_id", referencedColumnName = "id")
    private List<AuditorMapping> auditorMappings;
}
