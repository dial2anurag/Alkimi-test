package com.compliance.soc.socly.metrics.controller;


import com.compliance.soc.socly.metrics.entity.MetricTypes;
import com.compliance.soc.socly.metrics.service.MetricTypesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/metrictypes")
public class MetricTypesController {

    @Autowired
    private MetricTypesService metricTypesService;

    /**
     * API methods to get all the Active metrics Types
     * @return
     */

    @GetMapping("/allactivemetrictypes")
    public ResponseEntity<List<MetricTypes>> getAllActiveMetricTypes() {
        List<MetricTypes> list = metricTypesService.getAllActiveMetricTypes();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }
}
