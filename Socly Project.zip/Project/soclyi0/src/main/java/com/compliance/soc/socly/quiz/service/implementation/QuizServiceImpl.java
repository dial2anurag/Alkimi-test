package com.compliance.soc.socly.quiz.service.implementation;

import com.compliance.soc.socly.auth.service.impl.UserServiceImpl;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.quiz.repository.QuizRepository;
import com.compliance.soc.socly.quiz.entity.Quiz;
import com.compliance.soc.socly.quiz.exception.QuizException;
import com.compliance.soc.socly.quiz.model.QuizDto;
import com.compliance.soc.socly.quiz.model.QuizResult;
import com.compliance.soc.socly.quiz.service.QuizService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
@Slf4j
public class QuizServiceImpl implements QuizService {

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private MappingService mappingService;

    /**
     * save security awareness quiz data in Quiz table
     * @param quizResult
     * @return savedQuizDto
     */
    @Override
    public QuizDto saveQuiz(final QuizResult quizResult) throws QuizException {
        try {
            Quiz quiz = new Quiz();
            quiz.setUser(userService.getCurrentUser());
            quiz.setScore(quizResult.getScore());
            quiz.setPass(quizResult.getPass());
            quiz.setDate(new Date());
            Quiz savedQuiz = quizRepository.save(quiz);
            QuizDto savedQuizDto = mappingService.quizToQuizDto(savedQuiz);
            return savedQuizDto;
        } catch (Exception e) {
            log.error("Quiz details not saved. "+ e.getMessage());
            throw new QuizException("Quiz details not saved. "+ e.getMessage());
        }
    }
}



