package com.compliance.soc.socly.organization.exception;

public class OrganizationConfigException extends Exception{
    String message;

    OrganizationConfigException(){}
    public OrganizationConfigException(String message){
        this.message=message;
    }
}
