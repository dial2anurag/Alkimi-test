package com.compliance.soc.socly.metrics.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "metrics")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
/**
 * entity class with properties from the metrics table
 */
public class Metrics {

    @Id
    @Column(name = "Compliance_Id")
    private String complianceId;

    @Column(name = "Control_Name")
    private String controlName;

    @Column(name = "Description",columnDefinition = "Text")
    private String description;

    @Column(name = "Test_Procedures",columnDefinition = "Text")
    private String testProcedures;

    @Column(name = "Sample_Files",columnDefinition = "Text")
    private String sampleFiles;

    @Column(name = "Status")
    private String status;

    @Column(name = "Upload_Type")
    private String uploadType;

    @Column(name = "Type")
    private String type;

}