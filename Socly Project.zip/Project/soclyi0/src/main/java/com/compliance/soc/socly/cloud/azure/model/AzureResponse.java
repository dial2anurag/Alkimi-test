package com.compliance.soc.socly.cloud.azure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@Component
@ToString
public class AzureResponse {
    private String id;
    private String name;
    private String type;
    private AzureProperties properties;
}
