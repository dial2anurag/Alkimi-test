package com.compliance.soc.socly.metrics.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "metrics_compliance_mapping")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
/**
 * entity class with properties from the metrics_compliance_mapping table
 */
public class MetricsComplianceMapping {
    @Id
    @Column(name = "mcp_id")
    private String metricsComplianceId;

    @Column(name = "master_id")
    private int masterId;

    @Column(name = "compliance", insertable = false, updatable = false)
    private String complianceId;

    @Column(name = "status")
    private String status;

    /**
     * joining to tables metrics and the metrics_compliance_mapping.
     */
    @ManyToOne(targetEntity = Metrics.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "compliance", referencedColumnName = "compliance_id")
    private Metrics metrics;


}
