package com.compliance.soc.socly.cloudservice.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * It is a dto to provide the cloud services.
 */
public class ServiceProviderDto {
    private int id;
    private String name;
}
