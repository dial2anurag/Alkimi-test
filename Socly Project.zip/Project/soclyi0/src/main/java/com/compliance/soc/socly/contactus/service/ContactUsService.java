package com.compliance.soc.socly.contactus.service;

import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.contactus.Exception.ContactUsException;
import com.compliance.soc.socly.contactus.model.ContactUsDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Slf4j
@Service
public class ContactUsService {

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendMail(ContactUsDto contactUsDto, User user) throws MessagingException, IOException {
        sendMail(contactUsDto, null, user);
    }

    /**
     * sendMail method is used send an email to support@socly.io with the given request below
     *
     * @param contactUsDto
     * @param attachment
     * @param user
     * @return
     * @throws MessagingException
     * @throws IOException
     */
    public ContactUsDto sendMail(ContactUsDto contactUsDto, MultipartFile attachment, User user) throws ContactUsException,MessagingException, IOException {
        try {

            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

            mimeMessageHelper.setTo("support@socly.io");
            mimeMessageHelper.setText(contactUsDto.getQuery(), true);
            mimeMessageHelper.setSubject(contactUsDto.getCategory() + "-" + contactUsDto.getSubject());
            mimeMessageHelper.setCc(user.getEmail());
            mimeMessageHelper.setFrom("support@socly.io");
            if (attachment != null) {
                File convFile = new File(attachment.getOriginalFilename());
                FileOutputStream fos = new FileOutputStream(convFile);
                fos.write(attachment.getBytes());
                fos.close();

                FileSystemResource fileSystemResource = new FileSystemResource(convFile);
                mimeMessageHelper.addAttachment(fileSystemResource.getFilename(), fileSystemResource);
            }
            javaMailSender.send(mimeMessage);
        } catch (ContactUsException exception) {
            log.error("Error sending email" + exception.getMessage());
            throw new ContactUsException(exception);
        }
        return null;
    }
}
