package com.compliance.soc.socly.common;

import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.auth.config.TokenProvider;
import com.compliance.soc.socly.auth.repository.UserRepository;
import com.compliance.soc.socly.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

/**
 * Its a base controller used in controllers to fetch common details
 */
public class BaseController {
    @Value("${jwt.header.string}")
    protected String HEADER_STRING;

    @Value("${jwt.token.prefix}")
    protected String TOKEN_PREFIX;

    @Autowired
    protected UserRepository userRepository;

    @Autowired
    protected TokenProvider jwtTokenUtil;

    @Autowired
    protected StorageService storageService;

    @Autowired
    protected UserService userService;
}
