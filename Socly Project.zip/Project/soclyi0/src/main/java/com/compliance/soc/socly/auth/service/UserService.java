package com.compliance.soc.socly.auth.service;

import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.model.AdminCreatedUser;
import com.compliance.soc.socly.auth.model.PasswordDto;
import com.compliance.soc.socly.auth.model.UserDetailsResponse;
import com.compliance.soc.socly.auth.model.UserDto;
import com.compliance.soc.socly.auth.model.UserUpdateDto;
import com.compliance.soc.socly.quiz.model.QuizDto;

import java.util.List;

/**
 * Its an interface for the service layer of {link USER functionalities}.
 */
public interface UserService {
    String IS_ACTIVE = "Active";

    UserDetailsResponse save(UserDto user) throws UserDetailsException;

    List<User> findAll();

    User findOne(String username);

    UserDetailsResponse changeUserPassword(PasswordDto passwordDto) throws UserDetailsException;

    User getUserByEmail(String email);

    UserDetailsResponse saveUser(AdminCreatedUser adminCreatedUser) throws UserDetailsException;

    UserDetailsResponse saveUser(User user, String userRole) throws UserDetailsException;

    UserDetailsResponse updateUser(UserUpdateDto userUpdateDto) throws UserDetailsException;

    List<UserDetailsResponse> getUsersByOrganization(String status) throws UserDetailsException;

    UserDetailsResponse getCurrentUserDetails() throws UserDetailsException;

    User getCurrentUser() throws UserDetailsException;

    User getUser(UserDto userDto);

    UserDto getUserDto(User user);
    /**
     * Generating password for User and is sent to the registered {@link User#getEmail()}.
     *
     * @param username
     * @param email
     * @return password (one time 6 digit random password )
     */
    Integer generateAndSendOtp(String username, String email) throws AuthException;
}