package com.compliance.soc.socly.enums;

/**
  Enumerations for cloud modules.
 */
public enum CloudModule {
    AWS,
    AZURE
}
