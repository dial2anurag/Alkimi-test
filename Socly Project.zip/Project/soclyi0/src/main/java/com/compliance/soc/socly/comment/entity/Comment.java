package com.compliance.soc.socly.comment.entity;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.enums.AssociationCategory;
import com.compliance.soc.socly.enums.validation.ValueOfEnum;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.Date;
import java.util.List;

/**
 * Comment is an entity class and properties from the Comment table
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "comment")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    /**
     * comment is a like message commented by a user
     */
    @Column(name = "comments",columnDefinition = "Text")
    private String comments;

    /**
     * This is relationship between parent to child message
     */
    @ManyToOne(fetch = FetchType.LAZY)
    private Comment parent;
    /**
     * one comments may have more than one child comment
     * hence, a list of Comment objects : reply
     */
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "parent")
    @JsonIgnoreProperties("parent")
    private List<Comment> reply;

    @Column(name = "created_on")
    private Date createdOn;

    @Column(name = "modified_on")
    private Date modifiedOn;

    /**
     * AssociationCategory is enum that represents a group of constants (like POLICY, EVIDENCE,ORGANIZATION).
     */
    @Column(name = "association_category")
    @ValueOfEnum(enumClass = AssociationCategory.class)
    private String associationCategory;

    /**
     * Each AssociationCategory have a unique ID
     */
    @Column(name = "association_id")
    private long associationId;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name = "created_by", referencedColumnName = "id")
    private User createdBy;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name = "modified_by", referencedColumnName = "id")
    private User modifiedBy;

}
