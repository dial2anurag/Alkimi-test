package com.compliance.soc.socly.cloud.azure.controller;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.cloud.aws.exception.SecretNotFoundException;
import com.compliance.soc.socly.cloud.aws.exception.UserNotFoundException;
import com.compliance.soc.socly.cloud.aws.service.CredentialUtil;
import com.compliance.soc.socly.cloud.azure.model.AzureCredential;
import com.compliance.soc.socly.cloud.azure.service.AzureComplianceService;
import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.EntityCompliance;
import com.compliance.soc.socly.common.SaasProvider;
import com.compliance.soc.socly.util.ResponseProcessor;
import com.compliance.soc.socly.util.SecretManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/azure")
public class AzureController extends BaseController {

    @Autowired
    private CredentialUtil credentialUtil;
    @Autowired
    private SecretManager secretManager;
    @Autowired
    private AzureComplianceService azureComplianceService;
    @Autowired
    private ResponseProcessor responseProcessor;

    /**
     * API to save credentials for Azure
     *
     * @param azureCredential
     * @param request         subscription_id = a99f45a3-4415-4179-babb-b5bd37c8bb59
     *                        tenant id = 90ee9c0d-797a-4205-bfad-8ea9f4772f22
     *                        client secret - gWd7Q~y5HH9MdMkmVo8FtKL5tyt9EkbS6cmMP
     *                        client id = 3a8fdd1c-45b7-4b21-b261-00d331c3963a
     */
    @PostMapping("/credentials")
    public ResponseEntity<?> storeAzureCredential(@Valid @RequestBody AzureCredential azureCredential, HttpServletRequest request) {
        String header = request.getHeader(HEADER_STRING);
        String authToken = header.replace(TOKEN_PREFIX, "");
        String message;
        try {
            String organizationName = credentialUtil.retrieveOrganization(authToken);
            log.info("organization extracted from token {}", organizationName);
            message = secretManager.addOrUpdateSecretsToAWS(organizationName, azureCredential);
        } catch (UserNotFoundException userException) {
            return new ResponseEntity(userException.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(message, HttpStatus.OK);
    }

    /**
     * Azure API to fetch the 1. real time compliances 2. Store response on S3 bucket folder based on compliance type
     * and 3. store PDFs in S3 Compliance folder under organizational bucket based on complianceType
     * Compliance Type is decided based on the url
     *
     * @param request
     */
    @GetMapping({"/{framework}/compliance"})
    public ResponseEntity getCompliance(@PathVariable("framework") String framework, HttpServletRequest request) {
        String complianceType = framework.toUpperCase();
        if (!(complianceType.equals("ISO") || complianceType.equals("SOC2"))) {
            return new ResponseEntity<>("URI path not valid", HttpStatus.NOT_FOUND);
        }
        String header = request.getHeader(HEADER_STRING);
        String authToken = header.replace(TOKEN_PREFIX, "");
        try {
            String organizationName = credentialUtil.retrieveOrganization(authToken);
            log.info("Get compliance for organization: {}", organizationName);
            AzureCredential clientSecret = azureComplianceService.getClientSecret(organizationName);
            List<EntityCompliance> entityComplianceList = azureComplianceService.fetchCompliance(clientSecret, complianceType);
            responseProcessor.processResponse(entityComplianceList, organizationName, SaasProvider.AZURE.name(), complianceType);
            ComplianceResponse complianceResponse = azureComplianceService.entityToComplianceResponse(entityComplianceList);
            azureComplianceService.persistResponse(organizationName, complianceResponse, complianceType);
            return new ResponseEntity<>(complianceResponse, HttpStatus.OK);

        } catch (UserNotFoundException userException) {
            return new ResponseEntity(userException.getMessage(), HttpStatus.NOT_FOUND);
        } catch (SecretNotFoundException secretNotFoundException) {
            return new ResponseEntity(secretNotFoundException.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception exception) {
            return new ResponseEntity(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
