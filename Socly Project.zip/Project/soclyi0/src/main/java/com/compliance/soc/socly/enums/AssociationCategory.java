package com.compliance.soc.socly.enums;
/**
 * Enumeration for AssociationCategory.
 */
public enum AssociationCategory {
    POLICY,
    EVIDENCE,
    ORGANIZATION;
}
