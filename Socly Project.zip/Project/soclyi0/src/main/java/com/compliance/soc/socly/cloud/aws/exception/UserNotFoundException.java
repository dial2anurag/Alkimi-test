package com.compliance.soc.socly.cloud.aws.exception;

public class UserNotFoundException extends RuntimeException {

    String message;
    public UserNotFoundException(String message){
        super(message);
        this.message=message;
    }
    @Override
    public String toString() {
        return message;
    }
}
