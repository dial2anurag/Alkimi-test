package com.compliance.soc.socly.organization.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Setter
@Getter
@EqualsAndHashCode
public class OrgFrameworkID implements Serializable {
    private long org_id;
    private int framework_id;
}
