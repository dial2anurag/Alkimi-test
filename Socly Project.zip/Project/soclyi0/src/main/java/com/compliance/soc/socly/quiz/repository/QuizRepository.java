package com.compliance.soc.socly.quiz.repository;

import com.compliance.soc.socly.quiz.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizRepository extends JpaRepository<Quiz, Integer> {

}