package com.compliance.soc.socly.audit.service.Impl;

import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.entity.FileMaster;
import com.compliance.soc.socly.audit.repository.FileMasterRepository;
import com.compliance.soc.socly.audit.service.FileMasterService;
import com.compliance.soc.socly.auth.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.tool.schema.ast.SqlScriptParserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
@Slf4j
public class FileMasterServiceImpl implements FileMasterService {
    @Autowired
    FileMasterRepository fileMasterRepository;

    /**
     * method to save FileMaster data in file_master table
     *
     * @param fileMaster object
     * @return FileMaster data
     */
    @Override
    public FileMaster save(FileMaster fileMaster) {
        return fileMasterRepository.save(fileMaster);
    }

    /**
     * method to retrieve FileMaster data from file_master table based on filename
     *
     * @param filename
     * @return FileMaster data
     */
    @Override
    public FileMaster fetchFileMaster(String filename) {
        FileMaster fileMaster = new FileMaster();
        fileMaster = fileMasterRepository.findByFileName(filename);
        return fileMaster;
    }

    /**
     * method to save FileMaster data in file_master table based on filename and User data
     *
     * @param filename (string) , User data (object)
     * @return FileMaster data
     * @throws ComplianceApprovalException (custom Exception)
     */
    @Override
    public FileMaster save(String filename, User user) throws ComplianceApprovalException {
        FileMaster fileMaster = new FileMaster();
        fileMaster.setFileName(filename);
        fileMaster.setCreatedBy(user.getId());
        fileMaster.setStatus("A");
        fileMaster.setCreatedDate(new Date());
        try {
            return fileMasterRepository.save(fileMaster);
        } catch (SqlScriptParserException sq) {
            log.error("Unable to save filemaster", sq);
            throw new ComplianceApprovalException("Unable to save filemaster");
        }
    }
}
