package com.compliance.soc.socly.amazons3.dto;

import com.compliance.soc.socly.audit.model.FileApprovalDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.metrics.dto.PrincipleDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileListResponse {

    private String fileName;
    private String complianceId;
    private PrincipleDto principle;
    private FileApprovalDto fileApproval;
    private OrganizationDto organization;

}
