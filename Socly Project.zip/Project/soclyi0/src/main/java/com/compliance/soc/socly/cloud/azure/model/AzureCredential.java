package com.compliance.soc.socly.cloud.azure.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Getter
@Setter
@Component
public class AzureCredential implements Serializable {

    @NotNull(message = "subscriptionId must be provided")
    @NotBlank(message = "A valid subscriptionId value must be provided")
    private String subscriptionId;
    @NotNull(message = "clientId must be provided")
    @NotBlank(message = "A valid clientId value must be provided")
    private String clientId;
    @NotNull(message = "clientSecret must be provided")
    @NotBlank(message = "A valid clientSecret value must be provided")
    private String clientSecret;
    @NotNull(message = "tenantId must be provided")
    @NotBlank(message = "A valid tenantId value must be provided")
    private String tenantId;

    @Override
    public String toString() {
        return "{" +
                "subscriptionId='" + subscriptionId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", clientSecret='" + clientSecret + '\'' +
                ", tenantId='" + tenantId + '\'' +
                '}';
    }
}
