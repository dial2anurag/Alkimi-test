package com.compliance.soc.socly.auth.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Getter
@Setter
public class SuperUser {
    @Id
    @GeneratedValue
    private int id;

    @Column
    private String companyName;

    @Column
    private String cloudAwsAdmins;

    @Column
    private String approvers;
}
