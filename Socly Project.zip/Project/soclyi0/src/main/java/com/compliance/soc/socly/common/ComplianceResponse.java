package com.compliance.soc.socly.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
/**
 * Response model for ComplianceResponse.
 */
public class ComplianceResponse {
    @NonNull
    String module;
    Integer totalCompliancePoint;
    Integer totalAcceptedComplianceScore;
    Integer totalRejectedComplianceScore;
    Double percentComplianceScore;
    // Add compliance Type as well
    List<AbstractResponse> abstractResponse;
}
