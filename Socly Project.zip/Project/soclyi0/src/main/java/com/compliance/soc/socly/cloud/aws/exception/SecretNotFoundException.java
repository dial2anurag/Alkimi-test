package com.compliance.soc.socly.cloud.aws.exception;

public class SecretNotFoundException extends RuntimeException {

    String message;
    public SecretNotFoundException(String message){
        super(message);
        this.message=message;
    }
    @Override
    public String toString() {
        return message;
    }
}
