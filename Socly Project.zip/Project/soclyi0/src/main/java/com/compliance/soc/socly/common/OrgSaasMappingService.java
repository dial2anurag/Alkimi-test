package com.compliance.soc.socly.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrgSaasMappingService {

    @Autowired
    OrgSaasMappingRepository orgSaasMappingRepository;


    public void addClientSaasRecord(SaasProvider saasId, String organizationName, String status) {
        try {
            ClientSaasMapping clientSaasMappingFromDB = getClientSaasRecord(organizationName, saasId.toString());
            if (clientSaasMappingFromDB == null) {
                ClientSaasMapping clientSaasMapping = new ClientSaasMapping();
                clientSaasMapping.setSaasId(saasId.toString());
                clientSaasMapping.setOrganizationName(organizationName);
                clientSaasMapping.setActive(status);
                orgSaasMappingRepository.save(clientSaasMapping);
                log.info("ClientSaasRecord saved ");
            }
        } catch (final Exception ex) {
            log.error("failed to map client {} and saas {}", organizationName, saasId);
        }
    }

    public ClientSaasMapping getClientSaasRecord(String organizationName, String saasId) {
        return orgSaasMappingRepository.findByOrganizationNameAndSaasId(organizationName, saasId);
    }

    public ClientSaasMapping[] getClientSaasRecordOnStatus(String organizationName, String isActive) {
        return orgSaasMappingRepository.findByOrganizationNameAndIsActive(organizationName, isActive);
    }
}
