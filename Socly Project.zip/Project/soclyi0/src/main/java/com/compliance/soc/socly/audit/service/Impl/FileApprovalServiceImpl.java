package com.compliance.soc.socly.audit.service.Impl;

import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.entity.FileApproval;
import com.compliance.soc.socly.audit.entity.FileMaster;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.FileApprovalDto;
import com.compliance.soc.socly.audit.model.FileApprovalRequest;
import com.compliance.soc.socly.audit.repository.AuditPeriodRepository;
import com.compliance.soc.socly.audit.repository.ComplianceApprovalRepository;
import com.compliance.soc.socly.audit.repository.FileApprovalRepository;
import com.compliance.soc.socly.audit.repository.FileMasterRepository;
import com.compliance.soc.socly.audit.repository.PrincipleApprovalRepository;
import com.compliance.soc.socly.audit.service.FileApprovalService;
import com.compliance.soc.socly.audit.service.FileMasterService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class FileApprovalServiceImpl implements FileApprovalService {

    @Autowired
    FileApprovalRepository fileApprovalRepository;

    @Autowired
    FileMasterService fileMasterService;

    @Autowired
    FileMasterRepository fileMasterRepository;

    @Autowired
    private AuditPeriodRepository auditPeriodRepository;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private PrincipleApprovalRepository principleApprovalRepository;

    @Autowired
    private ComplianceApprovalRepository complianceApprovalRepository;

    @Override
    public List<FileApproval> getAll() {
        return fileApprovalRepository.findAll();
    }

    /**
     * method to save ComplianceApproval data in compliance_approval table
     *
     * @param fileApprovalRequest and User objects
     * @return ComplianceApproval data
     * @throws Exception
     */
    @Override
    public FileApprovalDto save(FileApprovalRequest fileApprovalRequest, User user) throws Exception {
        FileApproval fileApproval;
        final Framework framework = new Framework();
        framework.setId(fileApprovalRequest.getFramework().getId());
        AuditPeriod period = auditPeriodRepository.findOneByOrganizationAndStatusAndFramework(user.getOrganization(), "O",framework);
        if (period == null) {
            throw new ComplianceApprovalException("Audit period not found for ." + user.getOrganization().getOrgName());
        } else {
            FileMaster fileMaster = fileMasterRepository.findByFileName(fileApprovalRequest.getFileName());
            if (fileMaster == null) {
                fileMaster = fileMasterService.save(fileApprovalRequest.getFileName(), user);
                fileApproval = fromDto(fileApprovalRequest, user);
                fileApproval = setAttrs(fileApproval, period, fileMaster.getFileId(), user.getOrganization());
                return convert2Dto(fileApprovalRepository.save(fileApproval));
            } else {
                fileApproval = fileApprovalRepository.
                        findOneByFileIdAndComplianceIdAndPrincipleId(fileMaster.getFileId(),
                                fileApprovalRequest.getComplianceId(), fileApprovalRequest.getPrincipleId());
                if (fileApproval == null) {
                    fileApproval = fromDto(fileApprovalRequest, user);
                    fileApproval = setAttrs(fileApproval, period, fileMaster.getFileId(), user.getOrganization());
                    return convert2Dto(fileApprovalRepository.save(fileApproval));
                } else {
                    fileApproval.setStatus(fileApprovalRequest.getAuditStatus());
                    fileApproval.setModifiedBy(user.getId());
                    fileApproval.setModifiedDate(new Date());
                    fileApproval.setAuditNote(fileApprovalRequest.getAuditNote());
                    return convert2Dto(fileApprovalRepository.save(fileApproval));
                }
            }
        }
    }

    /**
     * This method is to convert Entity objects to Dto objects by set and get the each properties.
     *
     * @param save
     * @return
     */
    private FileApprovalDto convert2Dto(FileApproval save) {
        FileApprovalDto fileApprovalDto = new FileApprovalDto();
        fileApprovalDto.setId(save.getId());
        fileApprovalDto.setFileId(save.getFileId());
        fileApprovalDto.setStatus(save.getStatus());
        fileApprovalDto.setCreatedDate(save.getCreatedDate());
        fileApprovalDto.setModifiedDate(save.getModifiedDate());
        fileApprovalDto.setCreatedBy(save.getCreatedBy());
        fileApprovalDto.setModifiedBy(save.getModifiedBy());
        fileApprovalDto.setAuditNote(save.getAuditNote());
        fileApprovalDto.setOrganization(mappingService.getOrgDtoFromEntity(save.getOrganization()));
        fileApprovalDto.setPrincipleId(save.getPrincipleId());
        fileApprovalDto.setComplianceId(save.getComplianceId());

        AuditPeriod auditPeriod = save.getAuditPeriod();
        AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
        auditPeriodDto.setAuditId(auditPeriod.getAuditId());
        auditPeriodDto.setPeriod(auditPeriod.getPeriod());
        auditPeriodDto.setStatus(auditPeriod.getStatus());
        auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
        auditPeriodDto.setStartDate(auditPeriod.getStartDate());
        auditPeriodDto.setEndDate(auditPeriod.getEndDate());
        auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
        auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
        auditPeriodDto.setOrgId(auditPeriod.getOrganization().getId());
        auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
        fileApprovalDto.setAuditPeriod(auditPeriodDto);

        return fileApprovalDto;
    }

    /**
     * This method is set FileApproval fields from dto FileApprovalRequest.
     *
     * @param dto
     * @param user
     * @return
     */
    protected FileApproval fromDto(FileApprovalRequest dto, User user) {
        FileApproval fileApproval = new FileApproval();
        fileApproval.setPrincipleId(dto.getPrincipleId());
        fileApproval.setCreatedBy(user.getId());
        fileApproval.setStatus(dto.getAuditStatus());
        fileApproval.setComplianceId(dto.getComplianceId());
        fileApproval.setCreatedDate(new Date());
        fileApproval.setAuditNote(dto.getAuditNote());
        return fileApproval;
    }

    /**
     * This method is set FileApproval field attributes from dto's auditPeriod,organization and fileId.
     *
     * @param fileApproval
     * @param auditPeriod
     * @param fileId
     * @param organization
     * @return
     */
    private FileApproval setAttrs(FileApproval fileApproval, AuditPeriod auditPeriod, Integer fileId, Organization organization) {
        fileApproval.setAuditPeriod(auditPeriod);
        fileApproval.setFileId(fileId);
        fileApproval.setAuditPeriod(auditPeriod);
        fileApproval.setOrganization(organization);
        return fileApproval;
    }
}
