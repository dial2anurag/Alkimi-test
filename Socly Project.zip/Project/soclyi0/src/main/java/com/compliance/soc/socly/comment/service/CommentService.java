package com.compliance.soc.socly.comment.service;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.comment.exceptions.CommentException;
import com.compliance.soc.socly.comment.model.CommentDto;
import org.springframework.stereotype.Service;
import javax.validation.Valid;
import java.util.List;

/**
 * CommentService is an Interface create methods and implement methods in impl class
 */
@Service
public interface CommentService {
    /**
     * this method for fetching the all comments.
     * @return
     * @throws CommentException
     */
    List<CommentDto> getAllComment() throws CommentException ;
    /**
     * this method for fetching the comments by commentId.
     *
     * @param id
     * @return
     * @throws CommentException
     */
    CommentDto getComment(long id) throws CommentException;
    /**
     * this method for saving the comments.
     *
     * @param commentDto
     * @return
     * @throws CommentException
     */
    CommentDto save(@Valid CommentDto commentDto, User user ) throws CommentException;
    /**
     * this method for update the comments.
     *
     * @param commentDto
     * @return
     * @throws CommentException
     */
    CommentDto update(@Valid CommentDto commentDto, User user) throws CommentException;
    /**
     * this method for Delete the comments based on id.
     *
     * @param id
     * @return
     * @throws CommentException
     */
    boolean delete(Long id) throws CommentException;
}
