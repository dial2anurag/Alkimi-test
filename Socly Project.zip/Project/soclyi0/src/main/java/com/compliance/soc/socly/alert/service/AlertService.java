package com.compliance.soc.socly.alert.service;


import com.compliance.soc.socly.alert.exceptions.SoclyAlertException;
import com.compliance.soc.socly.alert.model.AlertDto;
import com.compliance.soc.socly.common.ComplianceResponse;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * AlertService is an Interface create methods and implement methods in impl class
 */
@Service
public interface AlertService {

    void populateData(final ComplianceResponse response, String saasId) throws SoclyAlertException;

    public List<AlertDto> fetchAlertStatus(String cName, Date sDate, Date eDate, long orgId) throws SoclyAlertException;
}
