package com.compliance.soc.socly.alert.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.util.Date;


/**
 * OrgSaas is an entity class and properties from the OrgSaas table
 */
@Entity
@Table(name = "org_saas")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrgSaas {

    /**
     *
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    /**
     *
     */
    @Column(name = "from_date")
    private Date fromDate;

    /**
     *
     */
    @OneToOne(targetEntity = Organization.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private Organization organization;

    /**
     *
     */
    @OneToOne(targetEntity = SaasMaster.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "saas_id", referencedColumnName = "id")
    private SaasMaster saasMaster;
}
