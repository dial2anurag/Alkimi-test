package com.compliance.soc.socly.metrics.controller;

import com.compliance.soc.socly.amazons3.exception.ActiveAuditNotFoundException;
import com.compliance.soc.socly.common.BaseController;
import com.compliance.soc.socly.metrics.dto.ActivePrincipleDto;
import com.compliance.soc.socly.metrics.dto.ActivePrinciplesResponse;
import com.compliance.soc.socly.metrics.dto.ComplianceDto;
import com.compliance.soc.socly.metrics.dto.PrincipleResponse;
import com.compliance.soc.socly.metrics.service.PrincipleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/principles")
@Slf4j
public class PrincipleController extends BaseController {

    @Autowired
    private PrincipleService principleService;

    /**
     * API Method to return the list of Active principles.
     *
     * @return
     */

    @GetMapping("/active")
    public ResponseEntity<List<ActivePrinciplesResponse>> getPrinciples() {
        try {
            List<ActivePrinciplesResponse> list = principleService.getAllActivePrinciples(userService.getCurrentUser().getOrganization().getId());
            return ResponseEntity.status(HttpStatus.OK).body(list);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }

    /**
     * API method to fetch all Active principles by the type
     *
     * @param type (eg:A, CM etc; check metrics_types table for details)
     * @return list of principles.
     */
    @GetMapping("/allactiveprinciples/{type}")
    public ResponseEntity<List<PrincipleResponse>> getPrinciplesByType(@PathVariable String type) {
        try {
            List<PrincipleResponse> list = principleService.getAllActivePrinciplesByType(type);
            return ResponseEntity.status(HttpStatus.OK).body(list);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }

    /**
     * API to get the compliances for the principal Id from metric master.
     * Cache is Implemented to store the data in mem cache.
     *
     * @param principleId
     * @return list of compliance Info.
     */
    @GetMapping("/complianceinfo/{principleId}")
    public ResponseEntity<List<ComplianceDto>> getCompliancesByPrincipleId(@PathVariable Integer principleId) {
        try {
            final List<ComplianceDto> list = principleService.getCompliancesAndFilesByPrincipleId(principleId);
            return ResponseEntity.status(HttpStatus.OK).body(list);

        } catch (final ActiveAuditNotFoundException ae) {
            log.error(ae.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Collections.emptyList());
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }

    /**
     * API method to get list of principles on compliance where the principles should be Active.
     *
     * @param complianceId
     * @return list of principles for given complianceId.
     */

    @GetMapping("/active/{complianceId}")
    public ResponseEntity<List<ActivePrinciplesResponse>> getPrinciplesByComplianceId(@PathVariable String complianceId) {
        try {
            final List<ActivePrinciplesResponse> list = principleService.getPrinciplesByCompianceId(complianceId);
            return ResponseEntity.status(HttpStatus.OK).body(list);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }

    /**
     * API method to get all list of principles by the Framework name like ex: iso/soc2.
     * Cache is Implemented to store the data in mem cache.
     *
     * @param framework
     * @return
     */
    @GetMapping("/active/on/framework/{framework}")
    public ResponseEntity<List<ActivePrincipleDto>> getPrinciplesByFramework(@PathVariable String framework) {
        try {
            List<ActivePrincipleDto> list = principleService.getAllActivePrinciplesByFramework(framework);
            return ResponseEntity.status(HttpStatus.OK).body(list);
        } catch (Exception exception) {
            log.error(exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
}
