package com.compliance.soc.socly.saas.configuration.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.EqualsAndHashCode;

import java.io.Serializable;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class SaasConfigId implements Serializable {
    private String saasId;
    private Long orgId;
    private Integer frameworkId;
}
