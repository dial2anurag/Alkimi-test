package com.compliance.soc.socly.common;

import com.compliance.soc.socly.enums.Module;

public enum SaasProvider {
    AWS, TEST, GSUITE, GITHUB, BITBUCKET, JIRA, AZURE ;
}
