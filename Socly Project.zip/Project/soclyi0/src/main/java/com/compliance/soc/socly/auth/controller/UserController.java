package com.compliance.soc.socly.auth.controller;

import com.compliance.soc.socly.auth.config.TokenProvider;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.model.AdminCreatedUser;
import com.compliance.soc.socly.auth.model.AuthToken;
import com.compliance.soc.socly.auth.model.LoginUser;
import com.compliance.soc.socly.auth.model.PasswordDto;
import com.compliance.soc.socly.auth.model.UserDetailsResponse;
import com.compliance.soc.socly.auth.model.UserDto;
import com.compliance.soc.socly.auth.model.UserUpdateDto;
import com.compliance.soc.socly.auth.service.PasswordService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.util.IsBusinessAdmin;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import javax.validation.Valid;
import java.time.Duration;
import java.util.List;

@RestController
@RequestMapping("/users")
@Component
@Slf4j
public class UserController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenProvider jwtTokenUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordService passwordService;

    @Value("${socly.api.rate.limit.bucket4j.capacity}")
    private int bucket4jCapacity;

    @Value("${socly.api.rate.limit.refill.rate.in.min}")
    private int refillRate;

    private Bucket bucket;

    @PostConstruct
    public void initApiRateLimit() {
        final Bandwidth limit = Bandwidth.classic(bucket4jCapacity, Refill.greedy(refillRate, Duration.ofMinutes(1)));
        this.bucket = Bucket.builder()
                .addLimit(limit)
                .build();
    }

    /**
     * API it gives  token For the registered User
     *
     * @param loginUser
     * @return
     * @throws AuthenticationException
     */
    @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
    public ResponseEntity<?> generateToken(@RequestBody LoginUser loginUser) throws AuthenticationException {
        final Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginUser.getUsername(),
                        loginUser.getPassword()
                )
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        final String token = jwtTokenUtil.generateToken(authentication);
        return ResponseEntity.ok(new AuthToken(token));
    }

    /**
     * API to update role, phone and status in User table
     *
     * @param userUpdateDto
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public ResponseEntity updateUser(@RequestBody @Valid UserUpdateDto userUpdateDto) {
        UserDetailsResponse userDetailsResponse;
        try {
            userDetailsResponse = userService.updateUser(userUpdateDto);
            return ResponseEntity.status(HttpStatus.OK).body(userDetailsResponse);
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
    }

    /**
     * API to change the password of the User
     * @param passwordDto
     * @return
     */
    @RequestMapping(value = "/change/password", method = RequestMethod.POST)
    public ResponseEntity<?> changePassword(@RequestBody PasswordDto passwordDto) {
        try {
            if (!passwordService.isPasswordDtoValid(passwordDto)) {
                return ResponseEntity.badRequest().body("Password is invalid");
            }
            userService.changeUserPassword(passwordDto);
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
        return ResponseEntity.ok("Password updated");
    }

    /**
     * API method to register the @org_business_ops,@org-business_Admin.
     * This registration can be done by SUPER-ADMIN.
     *
     * @param userDto
     * @return
     */
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity<?> saveUser(@RequestBody UserDto userDto) {
        try {
            UserDetailsResponse newUser = userService.save(userDto);
            return ResponseEntity.ok(newUser);
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    /**
     * API method to get the data of the User
     *
     * @return
     */
    @RequestMapping(value = "/data", method = RequestMethod.GET)
    public ResponseEntity<?> getDetails() {
        UserDetailsResponse userDetailsResponse;
        try {
            userDetailsResponse = userService.getCurrentUserDetails();
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(userDetailsResponse);
    }

    /**
     * @return
     */
//TODO
    @PreAuthorize("hasRole('ORG_BUSINESS_ADMIN')")
    @RequestMapping(value = "/adminping", method = RequestMethod.GET)
    public String adminPing() {
        return "Only Admins Can Read This";
    }

    @PreAuthorize("hasRole('ORG_BUSINESS_OPS')")
    @RequestMapping(value = "/userping", method = RequestMethod.GET)
    public String userPing() {
        return "Any User Can Read This";
    }

    /**
     * API method for To register @org_business_Admin and @org_business_ops  for organization by ORG_BUSINESS_ADMIN.
     *
     * @param adminCreatedUser
     * @return
     */
    @PreAuthorize("hasRole('ORG_BUSINESS_ADMIN')")
    @PostMapping(value = "/adminRegisteredUser")
    public ResponseEntity<?> enrollUser(@RequestBody AdminCreatedUser adminCreatedUser) {
        try {
            UserDetailsResponse savedUserDetails = userService.saveUser(adminCreatedUser);
            return ResponseEntity.ok(savedUserDetails);
        } catch (Exception e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    /**
     * API method is for to fetch the details of the Users for the organization
     *
     * @return list of users for respected user
     */
    @GetMapping(value = "/organization")
    @IsBusinessAdmin
    public ResponseEntity<?> getData(@RequestParam (required = false) String status) {
        List<UserDetailsResponse> userList;
        try {
            userList = userService.getUsersByOrganization(status);
        } catch (Exception ex) {
            log.error(ex.getMessage());
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(ex.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(userList);
    }
}