package com.compliance.soc.socly.amazons3.comparators;

import java.util.Comparator;
import java.util.Date;
import java.util.Map;


public class S3FileDateComparator implements Comparator<Map.Entry<String, Date>> {
    /**
     * it is comparator method for S3 files date comparator
     * @param date1
     * @param date2
     * @return sorted files
     */
    @Override
    public int compare(Map.Entry<String, Date> date1, Map.Entry<String, Date> date2) {
        return date2.getValue().compareTo(date1.getValue());
    }
}
