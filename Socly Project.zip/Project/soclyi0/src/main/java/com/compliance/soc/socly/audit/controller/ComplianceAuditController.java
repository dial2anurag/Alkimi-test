package com.compliance.soc.socly.audit.controller;

import com.compliance.soc.socly.amazons3.dto.ComplianceApprovalExceptionResponse;
import com.compliance.soc.socly.amazons3.dto.ComplianceApprovalResponse;
import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.model.ComplianceApprovalDto;
import com.compliance.soc.socly.audit.model.ComplianceApprovalRequest;
import com.compliance.soc.socly.audit.service.ComplianceApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/audit")
public class ComplianceAuditController extends AuditBaseController{

    @Autowired
    private ComplianceApprovalService complianceApprovalService;

    @Autowired
    private MappingService mappingService;

    /**
     * method to save ComplianceApproval data in compliance_approval table
     * @param complianceApprovalRequest class data
     * @return compliance approval data/ exception message and Http status
     */
    @PostMapping(value = "compliance")
    public ResponseEntity<?> save(@RequestBody ComplianceApprovalRequest complianceApprovalRequest) {
        try {
            User user = userService.getCurrentUser();
            ComplianceApprovalDto compliance = complianceApprovalService.save(complianceApprovalRequest, user);
            ComplianceApprovalResponse response = mappingService.populateComplianceApprovalResponse(compliance);
            return ResponseEntity.ok().body(response);
        } catch (ComplianceApprovalException exp) {
            ComplianceApprovalExceptionResponse res = new ComplianceApprovalExceptionResponse(exp.getMessage(), HttpStatus.EXPECTATION_FAILED.toString());
            log.error(exp.getMessage());
            return ResponseEntity.ok().body(res);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR, HttpStatus.EXPECTATION_FAILED);
        }
    }
}
