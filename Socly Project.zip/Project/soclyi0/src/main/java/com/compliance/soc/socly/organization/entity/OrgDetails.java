package com.compliance.soc.socly.organization.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Getter
@Setter
@Table(name = "org_details")
public class OrgDetails implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "name")
    @NotNull
    private String name;

    @Column(name = "value",columnDefinition = "Text")
    @NotNull
    private String value;

}