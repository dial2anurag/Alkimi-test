package com.compliance.soc.socly.enums;

public enum UserRoles {
    ORG_BUSINESS_OPS;
}
