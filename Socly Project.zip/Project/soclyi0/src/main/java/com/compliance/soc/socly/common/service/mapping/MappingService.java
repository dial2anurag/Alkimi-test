package com.compliance.soc.socly.common.service.mapping;

import com.compliance.soc.socly.amazons3.dto.AuditPeriodResponse;
import com.compliance.soc.socly.amazons3.dto.ComplianceApprovalResponse;
import com.compliance.soc.socly.audit.Exceptions.AuditPeriodException;
import com.compliance.soc.socly.audit.entity.AuditPeriod;
import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.model.ComplianceApprovalDto;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.Role;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.model.RoleDto;
import com.compliance.soc.socly.auth.model.UserDetailsResponse;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.metrics.dto.PrincipleDto;
import com.compliance.soc.socly.metrics.entity.Principle;
import com.compliance.soc.socly.metrics.repository.PrincipleRepository;
import com.compliance.soc.socly.organization.entity.Framework;
import com.compliance.soc.socly.organization.entity.OrgDetails;
import com.compliance.soc.socly.organization.model.FrameworkDto;
import com.compliance.soc.socly.organization.model.OrgDetailsDto;
import com.compliance.soc.socly.quiz.entity.Quiz;
import com.compliance.soc.socly.quiz.model.QuizDetail;
import com.compliance.soc.socly.quiz.model.QuizDto;
import com.compliance.soc.socly.saas.entity.SaasMaster;
import com.compliance.soc.socly.saas.entity.ServiceType;
import com.compliance.soc.socly.saas.model.SaasMasterDto;
import com.compliance.soc.socly.saas.model.ServiceTypeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
@Slf4j
public class MappingService {

    @Autowired
    private PrincipleRepository principleRepository;

    @Autowired
    private UserService userService;

    /**
     * method for populating the data Auditperiod DTO
     *
     * @param auditPeriod
     * @return
     * @throws AuditPeriodException
     */
    public AuditPeriodDto populateAuditPeriodDto(AuditPeriod auditPeriod) throws AuditPeriodException {
        try {
            AuditPeriodDto auditPeriodDto = new AuditPeriodDto();
            auditPeriodDto.setAuditId(auditPeriod.getAuditId());
            if (auditPeriod.getOrganization() != null)
                auditPeriodDto.setOrgId(auditPeriod.getOrganization().getId());
            auditPeriodDto.setStatus(auditPeriod.getStatus());
            auditPeriodDto.setPeriod(auditPeriod.getPeriod());
            auditPeriodDto.setStartDate(auditPeriod.getStartDate());
            auditPeriodDto.setEndDate(auditPeriod.getEndDate());
            auditPeriodDto.setCreatedBy(auditPeriod.getCreatedBy());
            auditPeriodDto.setModifiedBy(auditPeriod.getModifiedBy());
            auditPeriodDto.setEndedBy(auditPeriod.getEndedBy());
            auditPeriodDto.setAuditInitiateDate(auditPeriod.getAuditInitiateDate());
            com.compliance.soc.socly.audit.model.FrameworkDto frameworkDto = new com.compliance.soc.socly.audit.model.FrameworkDto();
            if (auditPeriod.getFramework() != null) {
                frameworkDto.setId(auditPeriod.getFramework().getId());
                frameworkDto.setName(auditPeriod.getFramework().getName());
            }
            auditPeriodDto.setFramework(frameworkDto);
            return auditPeriodDto;
        } catch (Exception exception) {
            log.error(exception.getMessage());
            throw new AuditPeriodException(exception.getMessage());
        }
    }

    /**
     * map ComplianceApproval to ComplianceApprovalResponse
     *
     * @param compliance
     * @return
     */
    public ComplianceApprovalResponse populateComplianceApprovalResponse(ComplianceApprovalDto compliance) {

        AuditPeriodResponse auditPeriodResponse = new AuditPeriodResponse();
        AuditPeriodDto auditPeriod = compliance.getAuditPeriod();
        auditPeriodResponse.setAuditId(auditPeriod.getAuditId());
        auditPeriodResponse.setStatus(auditPeriod.getStatus());
        auditPeriodResponse.setPeriod(auditPeriod.getPeriod());
        auditPeriodResponse.setClientId(auditPeriod.getOrgId());
        auditPeriodResponse.setStartDate(auditPeriod.getStartDate());
        auditPeriodResponse.setEndDate(auditPeriod.getEndDate());
        auditPeriodResponse.setCreatedBy(auditPeriod.getCreatedBy());
        auditPeriodResponse.setModifiedBy(auditPeriod.getModifiedBy());
        auditPeriodResponse.setEndedBy(auditPeriod.getEndedBy());
        auditPeriodResponse.setAuditDate(auditPeriod.getAuditInitiateDate());

        ComplianceApprovalResponse complianceApprovalResponse = new ComplianceApprovalResponse();
        complianceApprovalResponse.setId(compliance.getId());
        complianceApprovalResponse.setStatus(compliance.getStatus());
        complianceApprovalResponse.setComplianceDto(compliance);
        complianceApprovalResponse.setOrganizationDto(compliance.getOrganizationDto());
        Principle principle = principleRepository.findById(compliance.getPrincipleId()).get();
        if (principle != null) {
            PrincipleDto principleDto = new PrincipleDto();
            principleDto.setPrinciple(principle.getPrinciple());
            principleDto.setFlag(principle.getFlag());
            principleDto.setTitle(principle.getTitle());
            principleDto.setId(principle.getMetricsId());
            principleDto.setStatus(principle.getStatus());
            complianceApprovalResponse.setPrincipleDto(principleDto);
        }
        complianceApprovalResponse.setCreatedDate(compliance.getCreatedDate());
        complianceApprovalResponse.setModifiedDate(compliance.getModifiedDate());
        complianceApprovalResponse.setCreatedBy(compliance.getCreatedBy());
        complianceApprovalResponse.setId(compliance.getId());
        complianceApprovalResponse.setModifiedBy(compliance.getModifiedBy());
        complianceApprovalResponse.setAuditPeriod(auditPeriodResponse);
        complianceApprovalResponse.setAuditNote(compliance.getAuditNote());
        return complianceApprovalResponse;
    }

    /**
     * map Quiz entity to QuizDto
     *
     * @param quiz
     */
    public QuizDto quizToQuizDto(Quiz quiz) {
        QuizDto quizDto = new QuizDto();
        User user = quiz.getUser();
        UserDetailsResponse userDetails = this.userToUserDetailsResponse(user);
        quizDto.setUserDetails(userDetails);
        quizDto.setScore(quiz.getScore());
        quizDto.setPass(quiz.getPass());
        quizDto.setDate(quiz.getDate());
        return quizDto;
    }

    /**
     * method to map User entity to userDetailsResponse
     *
     * @param user
     * @return
     */
    public UserDetailsResponse userToUserDetailsResponse(User user) {
        UserDetailsResponse userDetails = new UserDetailsResponse();
        userDetails.setUsername(user.getUsername());
        userDetails.setEmail(user.getEmail());
        userDetails.setPhone(user.getPhone());
        userDetails.setName(user.getName());
        userDetails.setOrganizationName(user.getOrganization().getOrgName());
        Set<RoleDto> roles = this.getRoleDtosFromUser(user);
        userDetails.setRoles(roles);
        Organization organization = user.getOrganization();
        OrganizationDto organizationDto = getOrgDtoFromEntity(organization);
        userDetails.setOrganization(organizationDto);
        userDetails.setBusinessTitle(user.getBusinessTitle());
        userDetails.setCreatedDate(user.getCreatedDate());
        userDetails.setCreatedBy(user.getCreatedBy());
        userDetails.setModifiedDate(user.getModifiedDate());
        userDetails.setModifiedBy(user.getModifiedBy());
        userDetails.setDetailsFilled(user.getOrganization().isDetailFilled());
        userDetails.setPasswordChanged(user.isPasswordChanged());
        userDetails.setStatus(user.getStatus());
        Quiz quiz = user.getQuiz();
        if (quiz != null) {
            QuizDetail quizDetail = new QuizDetail();
            quizDetail.setScore(quiz.getScore());
            quizDetail.setPass(quiz.getPass());
            quizDetail.setDate(quiz.getDate());
            userDetails.setQuizDetail(quizDetail);
        }
        return userDetails;
    }

    /**
     * method to map Organization entity to dto
     *
     * @param organization
     * @return
     */
    public OrganizationDto getOrgDtoFromEntity(Organization organization) {
        final OrganizationDto organizationDto = new OrganizationDto();
        organizationDto.setClientId(organization.getId());
        organizationDto.setOrgName(organization.getOrgName());
        organizationDto.setDescription(organization.getDescription());
        organizationDto.setRegisteredDateTime(organization.getRegisteredDateTime());
        organizationDto.setDetailFilled(organizationDto.isDetailFilled());
        organizationDto.setStatus(organization.getStatus());
        organizationDto.setParentId(organization.getParentId());
        List<FrameworkDto> frameworkDtoList = this.getFrameworkDtoListFromEntityList(organization);
        organizationDto.setFrameworks(frameworkDtoList);
        List<SaasMasterDto> saasMasterDtoList = this.getSaasMasterDtoListFromEntityList(organization);
        organizationDto.setSaasMasters(saasMasterDtoList);
        // set the org detail in the org dto
        final List<OrgDetailsDto> orgDetailsDtos = this.populateOrgDetailsDtos(organization.getOrgDetails());
        organizationDto.setOrgDetails(orgDetailsDtos);
        return organizationDto;
    }

    /**
     * Framework Entity to DTO mapping
     *
     * @param organization
     * @return
     */
    private List<FrameworkDto> getFrameworkDtoListFromEntityList(Organization organization) {
        List<FrameworkDto> frameworkDtoList = new ArrayList<>();
        for (Framework framework : organization.getFrameworks()) {
            FrameworkDto frameworkDto = new FrameworkDto();
            frameworkDto.setId(framework.getId());
            frameworkDto.setName(framework.getName());
            frameworkDtoList.add(frameworkDto);
        }
        return frameworkDtoList;
    }

    /**
     * Saas<aster entity to DTO mapping
     *
     * @param organization
     * @return
     */
    private List<SaasMasterDto> getSaasMasterDtoListFromEntityList(Organization organization) {
        List<SaasMasterDto> saasMasterDtoList = new ArrayList<>();
        List<SaasMaster> saasMasterList = organization.getSaasMasters();
        if (saasMasterList != null && !saasMasterList.isEmpty()) {
            for (SaasMaster saasMaster : saasMasterList) {
                SaasMasterDto saasMasterDto = new SaasMasterDto();
                saasMasterDto.setSaasId(saasMaster.getSaasId());
                saasMasterDto.setSaasType(saasMaster.getSaasType());
                saasMasterDto.setSaasDescription(saasMaster.getSaasDescription());
                saasMasterDto.setStatus(saasMaster.getStatus());
                saasMasterDto.setClassInstance(saasMaster.getClassInstance());
                saasMasterDto.setImage(saasMaster.getImage());
                ServiceTypeDto serviceTypeDto = this.getServiceTypeDtoFromEntity(saasMaster);
                saasMasterDto.setServiceType(serviceTypeDto);
                saasMasterDtoList.add(saasMasterDto);
            }
        }
        return saasMasterDtoList;
    }

    /**
     * SaasMaster entity to DTO mapping
     *
     * @param saasMaster
     * @return
     */
    private ServiceTypeDto getServiceTypeDtoFromEntity(SaasMaster saasMaster) {
        ServiceTypeDto serviceTypeDto = new ServiceTypeDto();
        ServiceType serviceType = saasMaster.getServiceType();
        serviceTypeDto.setServiceTypeId(serviceType.getServiceTypeId());
        serviceTypeDto.setDescription(serviceType.getDescription());
        serviceTypeDto.setName(serviceType.getName());
        serviceTypeDto.setStatus(serviceType.getStatus());
        return serviceTypeDto;
    }

    /**
     * map Role From User Entity to DTO
     *
     * @param user
     * @return
     */
    private Set<RoleDto> getRoleDtosFromUser(User user) {
        Set<RoleDto> roles = new HashSet<>();
        for (Role role : user.getRoles()) {
            RoleDto roleDto = new RoleDto();
            roleDto.setId(role.getId());
            roleDto.setName(role.getName());
            roleDto.setDescription(role.getDescription());
            roleDto.setSuperAdmin(role.getSuperAdmin());
            roleDto.setOrgView(role.getOrgView());
            roleDto.setStatus(role.getStatus());
            roles.add(roleDto);
        }
        return roles;
    }

    /**
     * This method is to transfer  data from OrgDetails  to OrgDetailsDto
     *
     * @param orgDetails
     * @return : List<OrgDetailsDto>
     */
    private List<OrgDetailsDto> populateOrgDetailsDtos(List<OrgDetails> orgDetails) {
        final List<OrgDetailsDto> detailsDtos = new ArrayList<>();
        if (orgDetails != null && !orgDetails.isEmpty()) {
            orgDetails.forEach(orgDEntity -> {
                final OrgDetailsDto detailsDto = new OrgDetailsDto();
                detailsDto.setId(orgDEntity.getId());
                detailsDto.setOrgId(orgDEntity.getOrgId());
                detailsDto.setName(orgDEntity.getName());
                detailsDto.setValue(orgDEntity.getValue());
                detailsDtos.add(detailsDto);
            });
        }
        return detailsDtos;
    }
}
