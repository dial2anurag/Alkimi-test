package com.compliance.soc.socly.auth.entity;

import com.compliance.soc.socly.auth.model.UserRoleId;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "user_roles")
@Getter
@Setter
@IdClass(UserRoleId.class)
/**
 * userRole is an entity class and properties from the user_Role table.
 */
public class UserRole {

    @Id
    @Column(name = "user_id")
    private long userId;
    @Id
    @Column(name = "role_id")
    private long roleId;

}
