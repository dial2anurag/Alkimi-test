package com.compliance.soc.socly.auditor.service;

import com.compliance.soc.socly.auditor.exception.AuditorException;
import com.compliance.soc.socly.auditor.model.AuditorDto;

public interface AuditorService {
    /**
     * saves/updates Auditor details in database.
     * @param auditorDto
     * @return AuditorDto
     * @throws AuditorException
     */
    AuditorDto saveAuditor(AuditorDto auditorDto) throws AuditorException;
}
