package com.compliance.soc.socly.cloud.aws.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.networkfirewall.AWSNetworkFirewall;
import com.amazonaws.services.networkfirewall.AWSNetworkFirewallClientBuilder;
import org.springframework.stereotype.Service;

@Service
public class Firewall {

	/**
	 * API method for AWS network firewall Builder.
	 * @param aswCreds
	 */
	public void firewall(BasicAWSCredentials aswCreds){
		
		AWSNetworkFirewall network = AWSNetworkFirewallClientBuilder.standard().withRegion("eu-north-1").withCredentials(new AWSStaticCredentialsProvider(aswCreds)).build();
	//	network.listFirewalls(arg0)
		
	}
	
}
