package com.compliance.soc.socly.auth.exception;

/**
 * RoleException exception class to handle separately with others.
 */
public class RoleException extends Exception {
    public RoleException(final Exception ex) {
        super(ex);
    }

    public RoleException(final String errorMsg) {
        super(errorMsg);
    }
}

