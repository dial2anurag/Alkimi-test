package com.compliance.soc.socly.enums;

/**
 *Enumerations for policy status.
 */
public enum PolicyStatus {
    InProgress,
    SendToApproval ,
    Approved ,
    Rejected ,
    RequestChange
}
