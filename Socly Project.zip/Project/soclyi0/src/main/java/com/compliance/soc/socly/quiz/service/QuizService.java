package com.compliance.soc.socly.quiz.service;

import com.compliance.soc.socly.quiz.exception.QuizException;
import com.compliance.soc.socly.quiz.model.QuizDto;
import com.compliance.soc.socly.quiz.model.QuizResult;


public interface QuizService {
    /**
     * method to save client quiz details (scores, pass/ fail etc)
     */
    QuizDto saveQuiz(final QuizResult quizResult) throws QuizException;
}
