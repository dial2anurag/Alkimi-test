package com.compliance.soc.socly.alert.repository;

import com.compliance.soc.socly.alert.exceptions.SoclyAlertException;
import com.compliance.soc.socly.alert.entity.SaasCompliance;
import com.compliance.soc.socly.alert.model.AlertDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * SaasComplianceRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface SaasComplianceRepository extends JpaRepository<SaasCompliance, Long> {
    String alerts = "select new com.compliance.soc.socly.alert.model.AlertDto (" +
            "c.complianceName,\n" +
            "sc.createdDate,\n" +
            "sc.description,\n" +
            "sc.status,\n" +
            "sc.remediation,\n" +
            "os.saasMaster.saasId" +
            ")from Compliance c, OrgSaas os,SaasCompliance sc\n" +
            "where c.complianceName=:cName and c.id=sc.compliance.id\n" +
            "and os.organization.id=:orgId\n" +
            "and os.saasMaster.saasId=os.saasMaster.saasId\n" +
            "and sc.createdDate between :sDate and :eDate";

    @Query(alerts)
    public List<AlertDto> fetchAlerts(@Param("cName") String cName, @Param("orgId") long orgId,
                                      @Param("sDate") String sDate, @Param("eDate") String eDate) throws SoclyAlertException;

}
