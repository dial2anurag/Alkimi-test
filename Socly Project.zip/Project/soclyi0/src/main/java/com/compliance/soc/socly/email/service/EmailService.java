package com.compliance.soc.socly.email.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
@Slf4j
@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    String from;

    @Value("${spring.mail.password}")
    String fromEmailPassword;


    /**
     * method to send email to specified email
     * @param subject (string)
     * @param message to be delivered (string)
     * @param to email where message is to be sent (string)
     */
    public void sendMail(String subject, String message, String to) {
        boolean f = false;

        //Variable for gmail
        String host = "smtp.gmail.com";

        //get the system properties
        Properties properties = System.getProperties();
        log.info("PROPERTIES " + properties);

        //setting host information
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");//465
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");

        //1)getting into session object
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, fromEmailPassword);
            }

        });

        session.setDebug(true);

        //2)composing message
        MimeMessage m = new MimeMessage(session);

        try {

            //from email
            m.setFrom(from);

            //adding recipient to message
            m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            //adding subject to message
            m.setSubject(subject);

            //adding text to message
            //m.setText(message);
            m.setContent(message, "text/html");

            //3)send message
            Transport.send(m);

            log.info("Sent success...................");
            f = true;

        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
        }
    }
}

