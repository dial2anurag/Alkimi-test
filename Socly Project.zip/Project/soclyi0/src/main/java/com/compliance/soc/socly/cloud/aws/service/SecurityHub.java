package com.compliance.soc.socly.cloud.aws.service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClientBuilder;
import com.amazonaws.services.identitymanagement.model.AttachedPolicy;
import com.amazonaws.services.identitymanagement.model.GetGroupRequest;
import com.amazonaws.services.identitymanagement.model.GetGroupResult;
import com.amazonaws.services.identitymanagement.model.Group;
import com.amazonaws.services.identitymanagement.model.ListAttachedGroupPoliciesRequest;
import com.amazonaws.services.identitymanagement.model.ListAttachedGroupPoliciesResult;
import com.amazonaws.services.identitymanagement.model.ListAttachedUserPoliciesRequest;
import com.amazonaws.services.identitymanagement.model.ListAttachedUserPoliciesResult;
import com.amazonaws.services.identitymanagement.model.ListGroupsResult;
import com.amazonaws.services.identitymanagement.model.ListUsersResult;
import com.amazonaws.services.identitymanagement.model.User;
import com.amazonaws.services.securityhub.AWSSecurityHub;
import com.amazonaws.services.securityhub.AWSSecurityHubClientBuilder;
import com.amazonaws.services.securityhub.model.AwsSecurityFinding;
import com.amazonaws.services.securityhub.model.GetFindingsRequest;
import com.amazonaws.services.securityhub.model.GetFindingsResult;
import com.amazonaws.services.securityhub.model.Resource;
import com.compliance.soc.socly.auth.entity.SuperUser;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.cloud.aws.exception.CloudIntegrationException;
import com.compliance.soc.socly.common.AbstractResponse;
import com.compliance.soc.socly.common.ComplianceFramework;
import com.compliance.soc.socly.common.ComplianceResponse;
import com.compliance.soc.socly.common.EntityCompliance;
import com.compliance.soc.socly.common.SaasProvider;
import com.compliance.soc.socly.common.enums.Environment;
import com.compliance.soc.socly.saas.configuration.entity.SaasConfiguration;
import com.compliance.soc.socly.saas.configuration.service.SaasConfigurationService;
import com.compliance.soc.socly.util.ResponseProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SecurityHub {

    @Autowired
    private ControlMapping controlMapping;

    @Autowired
    private ResponseProcessor responseProcessor;

    @Autowired
    private SaasConfigurationService saasConfigurationService;

    @Autowired
    private UserService userService;

    private Boolean ARNConfigured = Boolean.FALSE;


    /**
     * Aws compliance response method.
     *
     * @param accessKey
     * @param secretKey
     * @param defaultRegion
     * @param superUser
     * @param organizationName
     * @param framework
     * @return
     */
    public ComplianceResponse security(String accessKey, String secretKey, String defaultRegion, SuperUser superUser, String organizationName, String framework) throws CloudIntegrationException {
        try {
            AbstractResponse abstractResponse = new AbstractResponse();
            List<AbstractResponse> abstractResponseList = new ArrayList<>();
            BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
            String cloudAwsAdmins = superUser.getCloudAwsAdmins();
            String admins[] = cloudAwsAdmins.split(",");
            log.info("List of admins as per client {}", Arrays.asList(admins));
            // initializing the IAM
            final AmazonIdentityManagement iam = getIdentityManagement(defaultRegion, awsCredentials);
            // Collect administrator users
            final List<String> adminList = getCloudAdminUsers(iam);
            log.info("List of admins as per IAM {}", adminList);
            // TODO : the logic for admin check
            String iamAdminCheck = getIamAdminCheck(admins, adminList);
            int count = 0;
            AWSSecurityHub awsSecurity = AWSSecurityHubClientBuilder
                    .standard()
                    .withRegion(defaultRegion)
                    .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                    .build();
            GetFindingsRequest req = new GetFindingsRequest();
            String nextToken = null;
            List<AwsSecurityFinding> securityHubList = new ArrayList<>();
            // fetching the data from aws 100 records at a time , until the all record fetched
            for (int i = 0; ; i++) {
                GetFindingsResult result = awsSecurity.getFindings(req.withMaxResults(100));
                nextToken = result.getNextToken();
                req.setNextToken(nextToken);
                List<AwsSecurityFinding> findings = result.getFindings();
                log.info("Total json  received in {} restriction  {}", i + 1, findings.size());
                for (AwsSecurityFinding asf : findings) {
                    if (asf.getRecordState().equals("ACTIVE") && asf.getGeneratorId().contains("aws-foundational-security-best-practices")) {
                        count++;
                        securityHubList.add(asf);
                    }
                }
                if (nextToken == null) {
                    log.info("Got the complete data with {} iteration", i + 1);
                    break;
                }
            }

            final List<EntityCompliance> awsEntityComplianceList = this.populateEntityCompliances(securityHubList, framework);
            // get EntityCompliance for admin check
            final EntityCompliance entityComplianceIamAdmin = new EntityCompliance();
            entityComplianceIamAdmin.setComplianceTitle("This control checks whether list of aws admin provided during registration is same as in aws IAM account");
            entityComplianceIamAdmin.setComplianceID(controlMapping.titleToIdMapping("list of aws admin provided during registration", framework));
            entityComplianceIamAdmin.setDescription("This control checks whether list of aws admin provided during registration is same as in aws IAM account");
            entityComplianceIamAdmin.setComplianceStatus(iamAdminCheck);
            if (!iamAdminCheck.equalsIgnoreCase("passed")) {
                String newline = System.getProperty("line.separator");
                String s = "List of IAM admins provided during client registration: " + Arrays.asList(admins) + newline + " while the list of IAM admins available in the aws account: " + adminList;
                log.info(s);
                entityComplianceIamAdmin.setRecommended_Remediation(s);
            }
            final List<EntityCompliance> entityCompliances = this.handleMultiISOCompliance(entityComplianceIamAdmin, framework);
            awsEntityComplianceList.addAll(entityCompliances);
            responseProcessor.processResponse(this.filterEntityComplianceForEvidence(awsEntityComplianceList), organizationName, SaasProvider.AWS.name(), framework);
            count++;    // for iamAdminCheck
            awsEntityComplianceList.sort(Collections.reverseOrder());
            abstractResponse.setModule("SecurityHub");
            abstractResponse.setCompliancePoint(count);
            int controlPassed = (int) securityHubList.stream().filter(securityFinding -> securityFinding.getCompliance().getStatus().equalsIgnoreCase("passed")).count();
            if (iamAdminCheck.equalsIgnoreCase("passed")) {
                controlPassed++;
            }
            abstractResponse.setAcceptedComplianceScore(controlPassed);
            abstractResponse.setPercentComplianceScore((controlPassed * 100.0) / count);
            abstractResponse.setRejectedComplianceScore(count - controlPassed);
            abstractResponse.setEntityCompliance(awsEntityComplianceList);
            abstractResponseList.add(abstractResponse);

            ComplianceResponse complianceResponse = new ComplianceResponse();
            complianceResponse.setModule(SaasProvider.AWS.name());
            complianceResponse.setTotalCompliancePoint(count);
            complianceResponse.setTotalAcceptedComplianceScore(controlPassed);
            complianceResponse.setPercentComplianceScore((controlPassed * 100.0) / count);
            complianceResponse.setTotalRejectedComplianceScore(count - controlPassed);
            complianceResponse.setAbstractResponse(abstractResponseList);

            log.info("total object {}", awsEntityComplianceList.size());
            log.info("count {}", count);

            return complianceResponse;
        } catch (final Exception ex) {
            log.error("Failed to fetch the AWS data for the org: {} and framework {}", organizationName, framework);
            throw new CloudIntegrationException(ex);
        }
    }

    /**
     * @param entityComplianceIamAdmin
     * @param framework
     * @return
     */
    private List<EntityCompliance> handleMultiISOCompliance(final EntityCompliance entityComplianceIamAdmin, final String framework) {
        final List<EntityCompliance> entityCompliances = new ArrayList<>();
        if (ComplianceFramework.ISO.name().equalsIgnoreCase(framework)) {
            final String[] compliances = entityComplianceIamAdmin.getComplianceID().split("_");
            Arrays.stream(compliances).forEach(complianceId -> {
                try {
                    final EntityCompliance entityCompliance = entityComplianceIamAdmin.clone();
                    entityCompliance.setComplianceID(complianceId);
                    entityCompliances.add(entityCompliance);
                } catch (final CloneNotSupportedException e) {
                    log.error("Cloning failed for the ISO compliance {}", complianceId);
                }
            });
        } else {
            entityCompliances.add(entityComplianceIamAdmin);
        }
        return entityCompliances;
    }

    /**
     * Filter data for production evidence generation.
     * @param awsEntityComplianceList
     * @return
     */
    private List<EntityCompliance> filterEntityComplianceForEvidence(final List<EntityCompliance> awsEntityComplianceList) {
        // pass the production list for evidence generation
        return awsEntityComplianceList.stream().filter(entityCompliance -> {
            final Environment complianceEnvironment = entityCompliance.getEnvironment();
            return !this.ARNConfigured || (complianceEnvironment != null && complianceEnvironment.name().equalsIgnoreCase(Environment.PRODUCTION.name()));
        }).collect(Collectors.toList());
    }

    /**
     * @param securityHubList
     * @param framework       (SOC2/ISO)
     * @return
     */
    private List<EntityCompliance> populateEntityCompliances(final List<AwsSecurityFinding> securityHubList, final String framework) throws CloudIntegrationException {
        AwsSecurityFinding awsSecurityFinding = null;
        try {
            List<EntityCompliance> awsEntityComplianceList = new ArrayList<>();
            for (final AwsSecurityFinding securityFinding : securityHubList) {
                awsSecurityFinding = securityFinding;
                final EntityCompliance entityCompliance = this.populateEntityCompliance(securityFinding, framework);
                final List<EntityCompliance> entityCompliances = this.handleMultiISOCompliance(entityCompliance, framework);
                awsEntityComplianceList.addAll(entityCompliances);
            }
            log.info("awsEntityComplianceList {}", awsEntityComplianceList.size());
            return awsEntityComplianceList;
        } catch (Exception e) {
            log.error("Entity compliance could not be populated for AwsSecurityFinding :" + awsSecurityFinding);
            throw new CloudIntegrationException(e.getMessage());
        }
    }

    /**
     * @param securityFinding
     * @param framework       (SOC2/ISO)
     * @return
     */
    private EntityCompliance populateEntityCompliance(final AwsSecurityFinding securityFinding, final String framework) throws CloudIntegrationException {
        final EntityCompliance entityCompliance = new EntityCompliance();
        entityCompliance.setComplianceID(controlMapping.titleToIdMapping(securityFinding.getTitle(), framework));
        entityCompliance.setComplianceTitle(securityFinding.getTitle());
        String complianceStatus = securityFinding.getCompliance().getStatus();
        entityCompliance.setComplianceStatus(complianceStatus);
        Resource resource = securityFinding.getResources().get(0);
        String description = "Type " + resource.getType() + " | Resource " + resource.getId() + " | Region " + resource.getRegion() + " | Created At " + securityFinding.getCreatedAt();
        entityCompliance.setDescription(description);
        entityCompliance.setCreatedAt(securityFinding.getCreatedAt());
        if (!complianceStatus.equals("PASSED")) {
            entityCompliance.setRecommended_Remediation(securityFinding.getRemediation().getRecommendation().getUrl());
        }
        // process data for environment check
        try {
            SaasConfiguration saasConfiguration = saasConfigurationService.getConfiguration("AWS", framework, "ARN");
            entityCompliance.setEnvironment(this.findEnvironment(securityFinding, saasConfiguration));
        } catch (Exception e) {
            log.error("Environment could not be set.");
            throw new CloudIntegrationException(e.getMessage());
        }
        return entityCompliance;
    }

    /**
     * @param awsSecurityFinding
     * @param saasConfiguration
     * @return
     */
    private Environment findEnvironment(final AwsSecurityFinding awsSecurityFinding, final SaasConfiguration saasConfiguration) throws CloudIntegrationException {
        Environment environment = Environment.NON_PRODUCTION;
        final Resource resource = awsSecurityFinding.getResources().get(0);
        final String arn = resource.getId();
        try {
            if (saasConfiguration != null && !saasConfiguration.getValue().isEmpty()) {
                this.ARNConfigured = Boolean.TRUE;
                final String cloudARN = saasConfiguration.getValue();
                String[] cloudArns = cloudARN.split(",");
                cloudArns = Arrays.stream(cloudArns).map(String::trim).toArray(String[]::new);
                if (Arrays.stream(cloudArns).anyMatch(arn::contains)) {
                    environment = Environment.PRODUCTION;
                }
            } else {
                environment = null;
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new CloudIntegrationException(e.getMessage());
        }
        return environment;
    }

    /**
     * TODO : logic ??
     *
     * @param admins    -> as per client
     * @param adminList -> as per IAM
     * @return
     */
    private String getIamAdminCheck(String[] admins, List<String> adminList) {
        List<String> finalAdmins = new ArrayList<>();
        for (int i = 0; i < admins.length; i++) {
            log.info("admins {}  {}", i, admins[i]);
            boolean b = adminList.remove(admins[i]);
            log.info("b value is {}", b);
            if (!b) {
                finalAdmins.add(admins[i]);
            }
        }

        if (adminList.size() > 0) {
            for (final String admin : adminList) {
                log.info("admin being added {}", admin);
                finalAdmins.add(admin);
            }
        }
        int iamAdmin = 1;    //passed
        String iamAdminCheck = "PASSED";
        if (finalAdmins.size() != 0) {
            log.info("finalAdmins {}", finalAdmins);
            iamAdmin = 0;        // failed
            iamAdminCheck = "FAILED";
        }
        return iamAdminCheck;
    }

    /**
     * @param iam
     * @return
     */
    private List<String> getCloudAdminUsers(AmazonIdentityManagement iam) {
        ListUsersResult listUsersResult = iam.listUsers();
        List<User> users = listUsersResult.getUsers();
        List<String> adminList = new ArrayList<>();
        for (User user : users) {
            String username = user.getUserName();
            log.info("Cloud user {}", user);
            ListAttachedUserPoliciesRequest req = new ListAttachedUserPoliciesRequest().withUserName(username);
            ListAttachedUserPoliciesResult policyResult = iam.listAttachedUserPolicies(req);
            List<AttachedPolicy> attachedPolicies = policyResult.getAttachedPolicies();
            log.info("for username {}", username);
            for (AttachedPolicy policies : attachedPolicies) {
                String policyName = policies.getPolicyName();
                log.info("PolicyName {}", policyName);
                if (policyName.equalsIgnoreCase("AdministratorAccess")) {
                    adminList.add(username);
                }
            }
        }
        // Adding Admin user from Administrator group users
        ListGroupsResult listGroupsResult = iam.listGroups();
        List<Group> groups = listGroupsResult.getGroups();
        for (Group group : groups) {
            String groupName = group.getGroupName();
            ListAttachedGroupPoliciesRequest listAttachedGroupPoliciesRequest = new ListAttachedGroupPoliciesRequest().withGroupName(groupName);
            ListAttachedGroupPoliciesResult listAttachedGroupPoliciesResult = iam.listAttachedGroupPolicies(listAttachedGroupPoliciesRequest);
            List<AttachedPolicy> attachedPolicies = listAttachedGroupPoliciesResult.getAttachedPolicies();
            log.info("For Group {} ", groupName);
            for (AttachedPolicy policies : attachedPolicies) {
                String policyName = policies.getPolicyName();
                log.info("PolicyName {}", policyName);
                if (policyName.equalsIgnoreCase("AdministratorAccess")) {
                    GetGroupRequest grp = new GetGroupRequest();
                    grp.setGroupName(groupName);
                    GetGroupResult group1 = iam.getGroup(grp);
                    List<User> users1 = group1.getUsers();
                    for (User u : users1) {
                        log.info("Username is  {}", u.getUserName());
                        adminList.add(u.getUserName());
                    }
                }
            }
        }
        log.info("adminList from aws account {}", adminList);

        return adminList;
    }

    /**
     * @param defaultRegion
     * @param awsCredentials
     * @return
     * @throws CloudIntegrationException
     */
    private AmazonIdentityManagement getIdentityManagement(final String defaultRegion, final BasicAWSCredentials awsCredentials) throws CloudIntegrationException {
        AmazonIdentityManagement iam = null;
        try {
            iam = AmazonIdentityManagementClientBuilder
                    .standard()
                    .withRegion(defaultRegion)
                    .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                    .build();
            if (iam == null) {
                throw new CloudIntegrationException("Invalid Credential");
            }

        } catch (final Exception e) {
            log.error("Exception occurred while AWS IAM configuration {}", e);
            throw new CloudIntegrationException(e);
        }
        return iam;
    }
}


