package com.compliance.soc.socly.enums;

/**
 Enumerations for File Extensions.
 */
public enum FileExtension {
    pdf,
    txt
}
