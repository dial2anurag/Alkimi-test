package com.compliance.soc.socly.common;

/**
 * Enumerations for compliance Framework.
 */
public enum ComplianceFramework {
    SOC2, ISO, GDPR;

    public static ComplianceFramework valueOfOrElse(String name) {
        for (ComplianceFramework value : values()) {
            if (value.name().equalsIgnoreCase(name)) {
                return value;
            }
        }
        return SOC2;
    }
}