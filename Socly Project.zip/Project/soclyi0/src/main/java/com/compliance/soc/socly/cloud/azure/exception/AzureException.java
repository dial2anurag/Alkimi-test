package com.compliance.soc.socly.cloud.azure.exception;

public class AzureException extends Exception{
    String message;
    public AzureException(String message) {
        this.message=message;
    }
    public AzureException(Exception e) {
        super(e);
    }
    @Override
    public String toString() {
        return message;
    }
}
