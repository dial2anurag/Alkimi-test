package com.compliance.soc.socly.cloud.aws.service;

import org.springframework.stereotype.Service;

import java.util.stream.Stream;

@Service
public class ControlMapping {
    /**
     * Method for converting SOC2 controlId to ISO controlId
     *
     * @param controlId
     * @return
     */
    public static String soc2IsoMapping(String controlId) {
        if (controlId.equals("SEC1")) {
            controlId = "A.10.1.1";
        } else if (controlId.equals("SEC9")) {
            controlId = "A.10.1.1";
        } else if (controlId.equals("SEC15")) {
            controlId = "A.9.1.2";
        } else if (controlId.equals("SEC12")) {
            controlId = "A.9.2.3";
        } else if (controlId.equals("SYSOPS2")) {
            controlId = "A.12.1.3";
        } else if (controlId.equals("SYSOPS4")) {
            controlId = "A.12.4.1_A.12.4.2_A.12.4.3";
        } else if (controlId.equals("SYSOPS12")) {
            controlId = "A.10.1.1";
        } else if (controlId.equals("CM4")) {
            controlId = "A.12.1.4";
        } else if (controlId.equals("C1")) {
            controlId = "A.10.1.1";
        } else if (controlId.equals("NA")) {
            controlId = "A.9.2.4_A.10.1.2_A.13.2.3_A.14.1.3_A.12.3.1";
        } else if (controlId.equals("SEC5")) {
            controlId = "A.6.1.1_A.6.1.2_A.9.4.1";
        } else if (controlId.equals("ELC23_SYSOPS7_SYSOPS6")) {
            controlId = "A.14.2.3_A.16.1.4_A.16.1.5_A.16.1.6_A.18.2.1";
        } else if (controlId.equals("AMAZON")) {
            controlId = "AMAZON";
        } else {
            controlId = "Others";
        }
        return controlId;
    }

    /**
     * the method is used to map each Azure response into different compliance based on response's displayName and also does soc2 -> iso if required
     *
     * @param displayName
     * @param complianceType
     * @return
     */
    public static String displayNameToIdMapping(String displayName, String complianceType) {
        String complianceId;
        if (Stream.of("encrypt", "https", "ftps", "rsasha1", "certificates").anyMatch(displayName::contains)) {
            complianceId = "SEC1";
        } else if ((Stream.of("firewall", "network watcher", "ip filter", "default network does not exist", "legacy networks do not exist", "enable connecting to serial ports", "ip forwarding",
                "shielded vm", "do not have public ip", "not open to the world", "listen on allowed ports only", "allow ingress from 0.0.0.0/0").anyMatch(displayName::contains))
                || (displayName.contains("network security group") && !displayName.contains("port"))) {
            complianceId = "SEC9";
        } else if ((Stream.of("permissions", "service account", "service account", "root account", "ssh access", "ssh keys", "rdp access", "cors",
                "restrict public access", "prohibit public access", "unrestricted", "access keys", "privilege", "authentication").anyMatch(displayName::contains))
                || (displayName.contains("restricted") && !displayName.contains("firewall"))
                || (displayName.contains("subscriptions") || displayName.contains("mfa") || displayName.contains("iam") || displayName.contains("network access") && !displayName.contains("log"))
                || (displayName.contains("storage account") && !displayName.contains("firewall or encryp or azure resource manager"))) {
            complianceId = "SEC15";
        } else if ((Stream.of("auto scaling groups", "limits", "at least three", "azure resource manager").anyMatch(displayName::contains))
                || (displayName.contains("vulnerability") && !displayName.contains("sql"))) {
            complianceId = "SYSOPS2";
        } else if ((Stream.of("guest attestation", "email notification").anyMatch(displayName::contains))
                || (displayName.contains("log") && !(displayName.contains("firewall") || displayName.contains("encrypt")))) {
            complianceId = "SYSOPS4";
        } else if (Stream.of("backup").anyMatch(displayName::contains)) {
            complianceId = "SYSOPS12";
        } else if (Stream.of("repositories", "CodeBuild").anyMatch(displayName::contains)) {
            complianceId = "CM4";
        } else if ((Stream.of("cloud sql mysql instance", "data security", "migration", "cloud storage bucket", "bigquery datasets").anyMatch(displayName::contains))
                || (displayName.contains("sql") && (displayName.contains("audit") || displayName.contains("vulnerability")))
                || (displayName.contains("flag for Cloud SQL SQL") && !(displayName.contains("access")))) {
            complianceId = "C1";
        } else if (Stream.of("defender", "update", "latest").anyMatch(displayName::contains)) {
            complianceId = "ELC23_SYSOPS7_SYSOPS6";
        } else if (Stream.of("aws", "amazon", "s3", "ec2", "rds", "vpc", "kms", "cloudfront", "dynamodb", "beanstalk", "cloudtrail", "acm", "cmks", "guardduty").anyMatch(displayName::contains)) {
            complianceId = "AMAZON";
        } else {
            complianceId = "Others";
        }

        if (null != complianceType && complianceType.equals("ISO")) {
            complianceId = soc2IsoMapping(complianceId);
        }

        return complianceId;
    }

    /**
     * it is mapping with controlid for titleTO ID.
     *
     * @param controlTitle
     * @return
     */

    public String titleToIdMapping(String controlTitle, String framework) {
        String control_Id;

        if (Stream.of("S3.4", "RDS.3", "RDS.4", "EC2.3", "EC2.7", "ES.1", "ES.3", "ES.8", "EFS.1", "ELB.2", "ELB.8", "S3.5", "ELB.3", "SQS.1", "SNS.1", "APIGateway.5", "APIGateway.2", "Redshift.2", "CloudTrail.2", "DynamoDB.3").anyMatch(controlTitle::contains)) {
            control_Id = "SEC1";
        } else if (Stream.of("RDS.18", "EC2.2", "EC2.6", "EC2.10", "ECS.2", "EC2.18", "EC2.19", "ES.2", "Redshift.7", "SageMaker.1", "APIGateway.4").anyMatch(controlTitle::contains)) {
            control_Id = "SEC9";
        } else if (Stream.of("S3.1", "S3.2", "S3.3", "S3.8", "RDS.2", "RDS.10", "RDS.12", "EC2.16", "KMS.1", "KMS.2", "KMS.3", "Lambda.1", "Redshift.1").anyMatch(controlTitle::contains)) {
            control_Id = "SEC15";
        } else if (Stream.of("IAM.1", "IAM.2", "IAM.3", "IAM.4", "IAM.5", "IAM.6", "IAM.7", "IAM.8", "IAM.21", "aws admin").anyMatch(controlTitle::contains)) {
            control_Id = "SEC12";
        } else if (Stream.of("RDS.5", "RDS.6", "RDS.15", "RDS.19", "RDS.20", "RDS.21", "RDS.22", "AutoScaling.1", "GuardDuty.1", "DynamoDB.1", "ElasticBeanstalk.1").anyMatch(controlTitle::contains)) {
            control_Id = "SYSOPS2";
        } else if (Stream.of("RDS.9", "ELB.5", "ES.4", "ES.5", "CloudTrail.1", "CloudTrail.4", "CloudTrail.5", "Config.1", "APIGateway.1", "Redshift.4").anyMatch(controlTitle::contains)) {
            control_Id = "SYSOPS4";
        } else if (Stream.of("EFS.2", "EC2.1", "RDS.16", "RDS.17", "DynamoDB.2").anyMatch(controlTitle::contains)) {
            control_Id = "SYSOPS12";
        } else if (Stream.of("SSM.1", "SSM.2", "SSM.3", "SSM.4").anyMatch(controlTitle::contains)) {
            control_Id = "CM4";
        } else if (controlTitle.contains("EMR.1")) {
            control_Id = "C1";
        } else if (controlTitle.contains("ELBv2.1")) {
            control_Id = "NA";
        } else if (Stream.of("S3.6", "SecretsManager.1", "SecretsManager.2", "SecretsManager.3", "SecretsManager.4", "list of aws admin provided during registration").anyMatch(controlTitle::contains)) {
            control_Id = "SEC5";
        } else {
            control_Id = "Others";
        }

        if (null != framework && framework.equals("ISO")) {
            control_Id = soc2IsoMapping(control_Id);
        }
        return control_Id;
    }
}
