package com.compliance.soc.socly.comment.controller;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.comment.exceptions.CommentException;
import com.compliance.soc.socly.comment.model.CommentDto;
import com.compliance.soc.socly.comment.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/comment")
public class CommentController extends CommentBaseController {
    @Autowired
    private CommentService commentReplyService;
    /**
     * method to save comments in Comment table.
     * @param commentDto model class data
     * @return
     */
    @PostMapping(value = "/save")
    public ResponseEntity<CommentDto> save(@RequestBody CommentDto commentDto) {
        try {
            User user = userService.getCurrentUser();
            CommentDto commentReply = commentReplyService.save(commentDto, user);
            return ResponseEntity.ok().body(commentReply);
        } catch (Exception exp) {
            log.error(exp.getMessage());
        }
        return (ResponseEntity<CommentDto>) ResponseEntity.ok();
    }
    /**
     * update is a APi method is used to update values in Comment table of given params.
     *
     * @return
     */
    @PutMapping(value = "/update")
    public ResponseEntity<CommentDto> update(@RequestBody CommentDto commentDto) {
        try {
            User user = userService.getCurrentUser();
            CommentDto commentReply = commentReplyService.update(commentDto,user);
            if (commentReply != null) {
                return ResponseEntity.ok().body(commentReply);
            }
        } catch (Exception exp) {
            log.error(exp.getMessage());
        }
        return (ResponseEntity<CommentDto>) ResponseEntity.ok();
    }
    /**
     * getComment is a Api method is to fetch values from the comment table and filtering with given @param CommentId
     *
     * @param  id
     * @return
     */
    @GetMapping(value = "/get/{id}")
    public ResponseEntity<CommentDto> getComment(@RequestParam long id) {
        try {
            CommentDto commentReply = commentReplyService.getComment(id);
            if (commentReply == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok().body(commentReply);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return (ResponseEntity<CommentDto>) ResponseEntity.ok();
        }
    }
    /**
     * getAllComment is a Api method is to fetch all comments from the Comment table
     *
     * @return
     */
    @GetMapping(value = "/all")
    public ResponseEntity<List<CommentDto>> getAllComment() {
        try {
            List<CommentDto> commentReply = commentReplyService.getAllComment();
            if (commentReply == null || commentReply.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok().body(commentReply);
        } catch (Exception exp) {
            log.error(exp.getMessage());
        }
        return (ResponseEntity<List<CommentDto>>) ResponseEntity.ok();
    }
    /**
     * API Method to delete the comments through CommentId.
     *
     * @return id
     */
    @DeleteMapping("/{id}")
    public void deleteComment(@PathVariable long id) throws CommentException {
        commentReplyService.delete(id);
    }
}
