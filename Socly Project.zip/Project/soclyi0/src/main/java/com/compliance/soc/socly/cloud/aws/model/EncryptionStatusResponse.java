package com.compliance.soc.socly.cloud.aws.model;

import com.compliance.soc.socly.common.AbstractResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
/**
 * It is a requestbody for the EncryptionStatusResponse.
 */
public class EncryptionStatusResponse extends AbstractResponse {

    public EncryptionStatusResponse() {
        super();
        this.setModule("Cloud_AWS");
    }

}
