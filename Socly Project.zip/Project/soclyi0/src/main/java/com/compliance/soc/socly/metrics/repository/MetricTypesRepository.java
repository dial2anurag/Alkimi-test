package com.compliance.soc.socly.metrics.repository;

import com.compliance.soc.socly.metrics.entity.MetricTypes;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface MetricTypesRepository extends CrudRepository<MetricTypes,String> {
    List<MetricTypes> findByStatus(String status);
}
