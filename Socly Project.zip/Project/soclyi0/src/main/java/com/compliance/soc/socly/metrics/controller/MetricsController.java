package com.compliance.soc.socly.metrics.controller;


import com.compliance.soc.socly.metrics.entity.Metrics;
import com.compliance.soc.socly.metrics.service.MetricsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

// TODO : Change this API to Compliance
// TODO : Also change the class as Compliance controller
// TODO : Change the return data to dto
@RestController
@RequestMapping("/metrics")
public class MetricsController {

    @Autowired
    private MetricsService metricsService;


    /**
     * API method for to get all  list of metrics.
     *
     * @return list of metrics
     */

    @GetMapping("/allmetrics")
    public ResponseEntity<List<Metrics>> getAllMetrics() {
        List<Metrics> list = metricsService.getAll();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    /**
     * API method to get All Active metrics.
     *
     * @return all active metrics.
     */

    @GetMapping("/allactivemetrics")
    public ResponseEntity<List<Metrics>> getAllActiveMetrics() {
        List<Metrics> list = metricsService.getAllActiveMetrics();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    /**
     * API method to get all active metrics by filtering with Type{like ELC}
     *
     * @param type
     * @return list of metrics of the type
     */
    @GetMapping("/allactivemetrics/{type}")
    public ResponseEntity<List<Metrics>> getAllActiveMetricsByType(@PathVariable String type) {
        List<Metrics> list = metricsService.getAllActiveMetricsByType(type);
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }
}
