package com.compliance.soc.socly.email.service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Random;
import java.util.concurrent.TimeUnit;
@Slf4j
@Component
public class OTPService {
    private static final Integer EXPIRE_MINUTES = 4;
    private LoadingCache<String, Integer> otpCache;

    public OTPService() {
        super();
        otpCache = CacheBuilder.newBuilder().
                expireAfterWrite(EXPIRE_MINUTES, TimeUnit.MINUTES)
                .build(new CacheLoader<String, Integer>() {
                    public Integer load(String key) {
                        return 0;
                    }
                });
    }

    public int generateOTP(String Username) {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        otpCache.put(Username, otp);
        return otp;
    }

    public int getOtp(String Username) {
        try {
            return otpCache.get(Username);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            return 0;
        }
    }

    public void clearOTP(String Username) {
        otpCache.invalidate(Username);
    }
}
