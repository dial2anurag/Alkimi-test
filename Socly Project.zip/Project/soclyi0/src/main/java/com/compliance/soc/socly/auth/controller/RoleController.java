package com.compliance.soc.socly.auth.controller;

import com.compliance.soc.socly.auth.exception.RoleException;
import com.compliance.soc.socly.auth.model.RoleDto;
import com.compliance.soc.socly.auth.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/role")
@Slf4j
public class RoleController {
    @Autowired
    RoleService roleService;

    /**
     * In this API we will get roles by OrgView.
     * if we give true we will get all true orgview roles.if none all roles should be shown.
     * @param orgView
     */
    @GetMapping(value = "/get")
    public ResponseEntity<?> getRoles(@RequestParam(required = false) Boolean orgView)throws RoleException {
        try {
            List<RoleDto> roles=roleService.findAllByOrgView(orgView);
            return ResponseEntity.ok(roles);
        }
        catch (Exception ex){
            log.error(ex.getMessage());
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}
