package com.compliance.soc.socly.organization.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "org_framework")
@IdClass(OrgFrameworkID.class)
@Setter
@Getter
public class OrgFramework {

    @Id
    @OneToOne(targetEntity = Organization.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "org_id", referencedColumnName = "id")
    private Organization org_id;

    @Id
    @OneToOne(targetEntity = Framework.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "framework_id", referencedColumnName = "id")
    private Framework framework_id;
}