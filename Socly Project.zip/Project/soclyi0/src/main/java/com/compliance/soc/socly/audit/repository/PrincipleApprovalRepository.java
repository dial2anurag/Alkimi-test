package com.compliance.soc.socly.audit.repository;


import com.compliance.soc.socly.audit.entity.PrincipleApproval;
import com.compliance.soc.socly.audit.model.PrincipleApprovalID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * PrincipleApprovalRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface PrincipleApprovalRepository extends JpaRepository<PrincipleApproval, PrincipleApprovalID> {
    /**
     * It is a jpa method to find principleApproval records by Id.
     *
     * @param id
     * @return
     */
    Optional<PrincipleApproval> findById(final PrincipleApprovalID id);

    /**
     * It is a jpa method to find principleApproval records by PrincipleId.
     *
     * @param principleId
     * @return
     */
    List<PrincipleApproval> findByPrincipleId(Integer principleId);

    /**
     * It is a jpa method to save principleApproval records.
     *
     * @param principleApproval
     * @return
     */
    PrincipleApproval save(final PrincipleApproval principleApproval);
}
