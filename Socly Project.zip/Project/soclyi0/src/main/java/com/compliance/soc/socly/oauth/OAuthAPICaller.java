package com.compliance.soc.socly.oauth;

import com.compliance.soc.socly.common.SaasProvider;
import com.compliance.soc.socly.scm.github.exception.GitHubException;
import com.compliance.soc.socly.util.SecretManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Slf4j
public class OAuthAPICaller {

    protected AccessTokenResponse accessToken;
    protected RestTemplate restTemplate;
    protected String accessTokenUrl;
    private String clientId;
    private String clientSecret;
    private String code;
    private String saas;
    private String userOrg;
    private SecretManager secretManager;

    public OAuthAPICaller(String accessTokenUrl, String clientId, String clientSecret, RestTemplate restTemplate) {
        this.accessTokenUrl = accessTokenUrl;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.restTemplate = restTemplate;
    }

    /**
     * Getting the response for authorizing the client.
     *
     * @param url
     * @param responseType
     * @param <T>
     * @return
     */
    public <T> T getResponse(String url, Class<T> responseType) throws Exception {
        try {
            final String accessToken = getAccessToken();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + accessToken);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<T> response = restTemplate.exchange(url,
                    HttpMethod.GET, entity, responseType);
            return response.getBody();
        } catch (final Exception ex) {
            log.error("Failed to get saas {} response : ", url, ex);
            throw ex;
        }
    }

    /**
     * get access token for saas providers for further interaction.
     *
     * @return
     */
    protected String getAccessToken() throws Exception {
        try {
            if (this.accessToken != null) {
                if (((System.currentTimeMillis() - this.accessToken.getGeneratedOn()) / 1000) > this.accessToken.getExpires_in()) {
                    if (this.accessToken.getRefresh_token() != null) {
                        this.accessToken = this.getAccessTokenUsingRefreshToken();
                    } else {
                        this.accessToken = null;
                    }
                }
            }
            if (this.accessToken == null) {
                this.accessToken = this.generateNewAccessToken();
                final String saasTokenError = this.accessToken.getError();
                if (saasTokenError != null && !saasTokenError.isEmpty()) {
                    // TODO replace with SaasAccessTokenException
                    throw new Exception(saasTokenError);
                }
                // update token in the secrete manager with new thread
                if (this.saas != null && this.saas.equalsIgnoreCase(SaasProvider.GITHUB.name())) {
                    updateWithSeparateProcess();
                }
            }
            return this.accessToken.getAccess_token();
        } catch (final Exception ex) {
            log.error("Exception occurred while saas access token generation : ", ex);
            throw ex;
        }
    }

    /**
     * Method that fork separate thread for update the secrete manager
     */
    private void updateWithSeparateProcess() {
        final Thread secreteManagerUpdateThread = new Thread(this.userOrg + " Secrete_Manager_" + this.saas + " Update_Thread") {
            /**
             * If this thread was constructed using a separate
             * {@code Runnable} run object, then that
             * {@code Runnable} object's {@code run} method is called;
             * otherwise, this method does nothing and returns.
             * <p>
             * Subclasses of {@code Thread} should override this method.
             *
             * @see #start()
             * @see #stop()
             */
            @Override
            public void run() {
                try {
                    log.info("Thread : {} started to update ...", this.getName());
                    secretManager.updateSaasToken(getSaas(), getUserOrg(), accessToken.getAccess_token());
                    log.info("Thread : {} complete the update ...", this.getName());
                } catch (final Exception ex) {
                    log.error("Thread : {} failed to update and got error {}...", this.getName(), ex.getMessage());
                    throw ex;
                }
            }
        };
        secreteManagerUpdateThread.start();
    }

    /**
     * Getting new access token for further interaction.
     */
    protected AccessTokenResponse generateNewAccessToken() throws GitHubException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", "client_credentials");
        map.add("client_id", this.clientId);
        map.add("client_secret", this.clientSecret);
        return getAccessTokenResponse(this.accessTokenUrl, map);
    }

    /**
     * Getting the saas  access token using Refresh token for further interaction.
     *
     * @return
     */
    protected AccessTokenResponse getAccessTokenUsingRefreshToken() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", "refresh_token");
        map.add("refresh_token", this.accessToken.getRefresh_token());
        map.add("client_id", this.clientId);
        map.add("client_secret", this.clientSecret);
        return getAccessTokenResponse(this.accessTokenUrl, map);
    }

    /**
     * Getting the Saas access token for further interaction
     *
     * @param url : get access token url
     * @param map
     * @return
     */
    private AccessTokenResponse getAccessTokenResponse(final String url, final MultiValueMap<String, String> map) {
        try {
            final HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity(map, new HttpHeaders());
            final ResponseEntity<AccessTokenResponse> response = this.restTemplate.exchange(url, HttpMethod.POST, entity, AccessTokenResponse.class);
            this.accessToken = response.getBody();
            log.info("Fetching saas : {} access token is success with ", url);
            this.accessToken.setGeneratedOn(System.currentTimeMillis());
            return this.accessToken;
        } catch (final Exception ex) {
            log.error("Fetching saas : {} access token failed with the following error {}", url, ex);
            throw ex;
        }
    }

    public String getSaas() {
        return saas;
    }

    public void setSaas(String saas) {
        this.saas = saas;
    }

    public String getUserOrg() {
        return userOrg;
    }

    public void setUserOrg(String userOrg) {
        this.userOrg = userOrg;
    }

    public SecretManager getSecretManager() {
        return secretManager;
    }

    public void setSecretManager(SecretManager secretManager) {
        this.secretManager = secretManager;
    }
}
