package com.compliance.soc.socly.auditor.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This is a model class used as DTO just to get id and name for a type
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class IdAndName {
    private int id;
    private String name;
}
