package com.compliance.soc.socly.common;

public class Constant {
    public static final String ARN = "ARN";
}
