package com.compliance.soc.socly.audit.service;

import com.compliance.soc.socly.audit.Exceptions.ComplianceApprovalException;
import com.compliance.soc.socly.audit.entity.FileMaster;
import com.compliance.soc.socly.auth.entity.User;
import org.springframework.stereotype.Service;

import javax.validation.Valid;

/**
 * FileMasterService is an Interface create methods and implement methods in impl class
 */
@Service
public interface FileMasterService {

    FileMaster save(@Valid FileMaster master);

    FileMaster fetchFileMaster(String fileName);

    FileMaster save(String name, User user) throws ComplianceApprovalException;
}
