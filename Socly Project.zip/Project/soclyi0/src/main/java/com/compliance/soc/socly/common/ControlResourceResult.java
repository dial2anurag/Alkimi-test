package com.compliance.soc.socly.common;

/**
 * controlResource Result is a response class
 */
public class ControlResourceResult {

    private String control_Id;
    private String status;
    private String resource;

    public void setControl_Id(String control_Id) {
        this.control_Id = control_Id;
    }
    public String getControl_Id() {
        return control_Id;
    }


    public void setStatus(String status) {
        this.status = status;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }




    public String getStatus() {
        return status;
    }

    public String getResource() {
        return resource;
    }

    public ControlResourceResult() {
    }

    public ControlResourceResult(String control_id, String status, String resource) {
        this.control_Id = control_id;
        this.status = status;
        this.resource = resource;
    }

    @Override
    public String toString() {
        String newline = System.getProperty("line.separator");
        return "Status = " +status + newline +
                "Resource = "+resource;
    }

}
