package com.compliance.soc.socly.metrics.dto;

import com.compliance.soc.socly.amazons3.dto.FileListResponse;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class ComplianceDto {

    private String complianceId;

    private String controlName;

    private String description;

    private String testProcedures;

    private String sampleFiles;

    private String status;

    private String uploadType;

    private Integer auditId;

    private String auditStatus;

    private Long orgId;

    private Integer principleId;

    private String auditNote;

    private List<FileListResponse> fileListResponses;

}
