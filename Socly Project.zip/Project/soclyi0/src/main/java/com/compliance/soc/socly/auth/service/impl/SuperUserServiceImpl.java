package com.compliance.soc.socly.auth.service.impl;


import com.compliance.soc.socly.auth.entity.SuperUser;
import com.compliance.soc.socly.auth.repository.SuperUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SuperUserServiceImpl {

    @Autowired
    private SuperUserRepository superUserRepository;

    public void addSuperUser(SuperUser superUser) {
        superUserRepository.save(superUser);
    }

    public SuperUser getSuperUser(String companyName) {
        return superUserRepository.findByCompanyName(companyName);
    }

    public void updateSuperUser(String awsAdmin, SuperUser superUser) {
        superUser.setCloudAwsAdmins(awsAdmin);
        superUserRepository.save(superUser);
    }

}
