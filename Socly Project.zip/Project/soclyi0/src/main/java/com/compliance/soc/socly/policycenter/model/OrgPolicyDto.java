package com.compliance.soc.socly.policycenter.model;

import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.model.UserDto;
import com.compliance.soc.socly.enums.PolicyStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * OrgPolicyDto is  a data transfer object and set or get properties from the OrgPolicyDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrgPolicyDto {

    private Integer id;

    private String filename;

    private PolicyStatus policyStatus;

    private Date createdOn;

    private Date approvedOn;

    private OrganizationDto organizationDto;

    private UserDto createdBy;

    private UserDto approvedBy;

    private String comments;

    private String error;
}
