package com.compliance.soc.socly.amazons3.exception;

public class ActiveAuditNotFoundException extends RuntimeException{

    private String message;

    public ActiveAuditNotFoundException() {
    }

    public ActiveAuditNotFoundException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
