package com.compliance.soc.socly.amazons3.exception;

public class S3BucketException extends  RuntimeException{
    private String message;

    public S3BucketException() {
    }

    public S3BucketException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
