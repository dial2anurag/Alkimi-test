package com.compliance.soc.socly.quiz.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
public class QuizDetail {
    private Integer score;
    private Boolean pass;
    private Date date;
}
