package com.compliance.soc.socly.metrics.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;

@Setter
@Getter
@AllArgsConstructor
public class JoinResponse {

    private Integer metricsId;
    private String complianceId;
    private String controlName;
    private String description;
    private String testProcedures;
    private String sampleFiles;
    private String status;
    private String uploadType;
    private String complianceType;
    private Character auditStatus;
    private Integer auditId;
    private Integer principleId;
    private BigInteger clientId;

}
