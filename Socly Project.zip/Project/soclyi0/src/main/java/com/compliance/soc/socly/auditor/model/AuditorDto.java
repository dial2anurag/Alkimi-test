package com.compliance.soc.socly.auditor.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * AuditorDto is a model class and it is a data transfer object and set or get properties from the AuditorDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditorDto {
    private int id;
    private String username;
    private String email;
    private String name;
    private String description;
    private String status;
    private Boolean passwordChanged;
    private String password;
    private String phone;
    private List<AuditorMappingDto> auditorMappingDtos;

}
