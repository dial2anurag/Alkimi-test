package com.compliance.soc.socly.cloudservice.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "service_provider")
@Getter
@Setter
/**
 * service_provider is an entity class and properties from Service_provider table
 */
public class ServiceProvider {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column
    private String name;

    @Column
    private String active;
    /**
     * joining column ServiceProvider and CloudService.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "service_id")
    private CloudService service;
}
