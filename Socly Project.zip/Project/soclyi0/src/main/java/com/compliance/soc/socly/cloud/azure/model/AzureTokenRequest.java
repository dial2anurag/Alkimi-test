package com.compliance.soc.socly.cloud.azure.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@NoArgsConstructor
public class AzureTokenRequest {
    private String grant_type;
    private String client_id;
    private String client_secret;
    private String resource;
}
