package com.compliance.soc.socly.metrics.dto;

/**
 * ComplianceResponse is a model class and it is a data transfer object and set or get properties from the ComplianceResponse.
 */
public interface ComplianceResponse {
    Integer getMetricsId();

    String getComplianceId();

    String getControlName();

    String getDescription();

    String getTestProcedures();

    String getSampleFiles();

    String getStatus();

    String getUploadType();

    Integer getAuditId();

    String getAuditStatus();

    Long getOrgId();

    Integer getPrincipleId();

    String getAuditNote();
}
