package com.compliance.soc.socly.comment.model;
import com.compliance.soc.socly.auth.model.UserDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;
import java.util.List;

/**
 * CommentDto is a data transfer object and set or get properties from the CommentDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CommentDto {
    private long id;
    private String comments;
    private CommentDto parent;
    private List<CommentDto> replies;
    private String associationCategory;
    private Date createdOn;
    private Date modifiedOn;
    private long associationId;
    private UserDto createdBy;
    private UserDto modifiedBy;
}
