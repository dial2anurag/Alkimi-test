package com.compliance.soc.socly.audit.entity;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.enums.AuditPeriodStatus;
import com.compliance.soc.socly.enums.validation.ValueOfEnum;
import com.compliance.soc.socly.organization.entity.Framework;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

/**
 * AuditPeriod is an entity class and properties from the AuditPeriod table
 */
@Entity
@Getter
@Setter
@Table(name = "audit_period")
public class AuditPeriod {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * the auditId is primary key of this table
     */
    @Column(name = "id")
    private Integer auditId;
    /**
     * the status which shows auditStatus
     */
    @Column(name = "status")
    @ValueOfEnum(enumClass = AuditPeriodStatus.class,  message = "Status should only be O/I/C")
    private String status;
    /**
     * the period which shows duration period
     */
    @Column(name = "period")
    private String period;

    /**
     * the startDate shows on which date it is started
     */
    @Column(name = "start_date")
    private Date startDate;
    /**
     * the endDate shows on which date it is ended
     */
    @Column(name = "end_date")
    private Date endDate;
    /**
     * the createdBy shows from which user it is being created
     */
    @Column(name = "created_by")
    private Long createdBy;
    /**
     * the modifiedBy shows from which user it is being modified
     */
    @Column(name = "modified_by")
    private Long modifiedBy;
    /**
     * the endedBy shows from which user it is being ended
     */
    @Column(name = "ended_by")
    private Long endedBy;
    /**
     * the auditDate shows the current date
     */
    @Column(name = "audit_initiate_date")
    private Date auditInitiateDate;
    /**
     * framework_id give the framework name
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Framework.class)
    @JoinColumn(name = "framework_id",referencedColumnName = "id")
    private Framework framework;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Organization.class)
    @JoinColumn(name = "client_id")
    private Organization organization;
}
