package com.compliance.soc.socly.organization.exception;

/**
 * It is a exception class to handle the FrameworkException.
 */
public class FrameworkException extends Exception {
    public FrameworkException(final Exception ex) {
        super(ex);
    }
    public FrameworkException(final String errorMsg) {
        super(errorMsg);
    }
}

