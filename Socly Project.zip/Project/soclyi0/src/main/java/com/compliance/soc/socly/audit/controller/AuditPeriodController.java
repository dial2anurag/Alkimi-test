package com.compliance.soc.socly.audit.controller;

import com.compliance.soc.socly.audit.model.AuditPeriodDto;
import com.compliance.soc.socly.audit.service.AuditPeriodService;
import com.compliance.soc.socly.auth.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/audit")
public class AuditPeriodController extends AuditBaseController {

    @Autowired
    private AuditPeriodService service;

    /**
     * method to save audit data in audit_period table
     *
     * @param audit model class data
     * @return audit period data/ exception message and Http status
     */
    @PostMapping(value = "/audit_period/save")
    public ResponseEntity<?> save(@RequestBody AuditPeriodDto audit) {
        try {
            User user = userService.getCurrentUser();
            AuditPeriodDto auditPeriod = service.save(audit, user);
            if (auditPeriod != null) {
                return ResponseEntity.ok().body(auditPeriod);
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to save audit period");
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(exp.getMessage());
        }
    }

    /**
     * update is a APi method is used to update values in Audit period table of given params
     *
     * @param audit
     * @return
     */
    @PutMapping(value = "/audit_period/update")
    public ResponseEntity<?> update(@RequestBody AuditPeriodDto audit) {
        try {
            User user = userService.getCurrentUser();
            AuditPeriodDto auditPeriod = service.update(audit, user);
            if (auditPeriod != null) {
                return ResponseEntity.ok().body(auditPeriod);
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Unable to update audit period.");
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(exp.getMessage());
        }
    }

    /**
     * getAudit is a Api method is to fetch values from the Audit period table and filtering with given @param orgId
     *
     * @param orgId
     * @return
     */
    @GetMapping(value = "/audit_period/fetch")
    public ResponseEntity<?> getAudit(@RequestParam long orgId, @RequestParam(required = false) String status) {
        try {
            List<AuditPeriodDto> periods = service.getAudit(orgId, status);
            if (periods == null || periods.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok().body(periods);
        } catch (Exception exp) {
            log.error(exp.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(exp.getMessage());
        }
    }
}