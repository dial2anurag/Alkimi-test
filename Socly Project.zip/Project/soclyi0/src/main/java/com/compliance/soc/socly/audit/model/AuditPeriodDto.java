package com.compliance.soc.socly.audit.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * AuditPeriodDto is a model class and it is a data transfer object and set or get properties from the AuditPeriodDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuditPeriodDto {
    private Integer auditId;

    private String status;

    private String period;

    private long orgId;

    private Date startDate;

    private Date endDate;

    private Long createdBy;

    private Long modifiedBy;

    private Long endedBy;

    private Date auditInitiateDate;

    private FrameworkDto framework;
}
