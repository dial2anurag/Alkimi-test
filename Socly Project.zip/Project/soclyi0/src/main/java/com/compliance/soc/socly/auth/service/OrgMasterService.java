package com.compliance.soc.socly.auth.service;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.model.OrgMasterUserDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.organization.model.OrgDetailsDto;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * Its an interface for the service layer of {link Orgmaster functionalities}.
 */
@Service
public interface OrgMasterService {
    /**
     * It is the interface method for saveing Organization
     *
     * @param orgMasterDto
     * @return
     * @throws Exception
     */
    OrganizationDto save(final OrgMasterUserDto orgMasterDto) throws AuthException;

    void update(final String username) throws AuthException;

    /**
     * It is the interface method for fetching the organization.
     *
     * @param status
     * @return
     * @throws AuthException
     */
    List<OrganizationDto> getOrganizations(String status) throws AuthException;

    /**
     * It is the interface method for geting the organization.
     *
     * @param organizationName
     * @return
     * @throws AuthException
     */
    Organization getOrganization(String organizationName) throws AuthException;

    /**
     * it is interface method to find the organization by orgId.
     *
     * @param orgId
     * @return
     * @throws AuthException
     */
    Organization findById(Long orgId) throws AuthException;

    /**
     * It is the interface method for Updating the orgDetails.
     *
     * @param orgDetailsDtos
     * @return
     * @throws AuthException
     */
    List<OrgDetailsDto> updateOrgDetails(List<OrgDetailsDto> orgDetailsDtos) throws AuthException;

    /**
     * It is the interface method for save file for organization
     *
     * @param file
     * @throws AuthException
     */
    public void saveFileForOrganization(final MultipartFile file) throws AuthException;

}
