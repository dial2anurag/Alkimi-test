package com.compliance.soc.socly.audit.controller;

import com.compliance.soc.socly.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

public class AuditBaseController {

    @Autowired
    protected UserService userService;
}
