package com.compliance.soc.socly.enums;

/**
 *Enumerations for policy center.
 */
public enum PolicyCenter {
    data,
    policy_center,
    unapproved
}
