package com.compliance.soc.socly.audit.Exceptions;

/**
 *  AuditPeriod exception class to handle separately with others
 */
public class AuditPeriodException extends Exception{
    public AuditPeriodException(final Exception ex) {
        super(ex);
    }

    public AuditPeriodException(final String errorMsg) {
        super(errorMsg);
    }
}