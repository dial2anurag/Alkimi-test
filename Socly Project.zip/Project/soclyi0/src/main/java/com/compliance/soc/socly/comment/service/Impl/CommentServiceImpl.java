package com.compliance.soc.socly.comment.service.Impl;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.comment.exceptions.CommentException;
import com.compliance.soc.socly.comment.model.CommentDto;
import com.compliance.soc.socly.comment.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Slf4j
public class CommentServiceImpl implements CommentService {
    @Override
    public List<CommentDto> getAllComment() throws CommentException {
        return null;
    }
    @Override
    public CommentDto getComment(long id) throws CommentException {
        return null;
    }
    @Override
    public CommentDto save(CommentDto commentDto, User user) throws CommentException {
        return null;
    }

    @Override
    public CommentDto update(CommentDto commentDto, User user) throws CommentException {
        return null;
    }

    @Override
    public boolean delete(Long id) throws CommentException {
        return false;
    }
}
