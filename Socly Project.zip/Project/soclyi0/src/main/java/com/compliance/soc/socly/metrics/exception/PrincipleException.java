package com.compliance.soc.socly.metrics.exception;

public class PrincipleException extends Exception{
    public PrincipleException(final Exception e){
        super(e);
    }
    public PrincipleException(final String errorMsg){
        super(errorMsg);
    }
}
