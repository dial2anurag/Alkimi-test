package com.compliance.soc.socly.auth.repository;

import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
    User findByUsername(String username);

    User findByEmail(String email);

    Boolean existsByUsername(String username);

    List<User> findByOrganizationAndStatus(Organization organization, String status);

    /**
     * Fetching the users by organization name
     * @param organization
     * @return
     */
    List<User> findByOrganization(Organization organization);

    User findByUsernameIgnoreCase(String username);
}