package com.compliance.soc.socly.auth.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
/**
 * it is an dto class for the user_role table.
 */
public class UserRoleId implements Serializable {

    private long userId;
    private long roleId;

}
