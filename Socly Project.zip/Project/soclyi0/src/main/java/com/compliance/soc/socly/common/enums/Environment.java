package com.compliance.soc.socly.common.enums;

/**
 * enumerations for saas providers.
 */
public enum Environment {
    PRODUCTION, NON_PRODUCTION;
}