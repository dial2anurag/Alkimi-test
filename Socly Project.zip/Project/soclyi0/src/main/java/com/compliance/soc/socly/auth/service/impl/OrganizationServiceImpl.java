package com.compliance.soc.socly.auth.service.impl;

import com.compliance.soc.socly.amazons3.dto.DataUpload2FolderRequest;
import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.auth.entity.Organization;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.AuthException;
import com.compliance.soc.socly.auth.model.OrgMasterUserDto;
import com.compliance.soc.socly.auth.model.OrganizationDto;
import com.compliance.soc.socly.auth.repository.OrgMasterRepository;
import com.compliance.soc.socly.auth.repository.UserRepository;
import com.compliance.soc.socly.auth.service.OrgMasterService;
import com.compliance.soc.socly.auth.service.UserService;
import com.compliance.soc.socly.common.service.mapping.MappingService;
import com.compliance.soc.socly.enums.DocumentFolder;
import com.compliance.soc.socly.enums.PolicyCenter;
import com.compliance.soc.socly.organization.entity.Framework;
import com.compliance.soc.socly.organization.entity.OrgDetails;
import com.compliance.soc.socly.organization.exception.OrganizationException;
import com.compliance.soc.socly.organization.model.OrgDetailsDto;
import com.compliance.soc.socly.organization.repository.FrameworkRepository;
import com.compliance.soc.socly.organization.repository.OrgDetailsRepository;
import com.compliance.soc.socly.util.s3.S3Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Slf4j
@Service
public class OrganizationServiceImpl implements OrgMasterService {

    @Autowired
    private OrgMasterRepository orgMasterRepository;

    @Autowired
    private FrameworkRepository frameworkRepository;

    @Autowired
    private StorageService storageService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private OrgDetailsRepository orgDetailsRepository;

    @Autowired
    private S3Util s3Util;

    /**
     * @param orgMasterUserDto which holds the details of {@link Organization} and {@link User}.
     * @return {@link Organization}
     * @throws AuthException
     */
    @Override
    public OrganizationDto save(OrgMasterUserDto orgMasterUserDto) throws AuthException {
        final String orgName = orgMasterUserDto.getOrgName();
        if (orgMasterRepository.existsByOrgNameIgnoreCase(orgName)) {
            throw new UsernameNotFoundException("Organization with " + orgMasterUserDto.getOrgName() +
                    " already exists.");
        }
        if (userRepository.existsByUsername(orgMasterUserDto.getEmail())) {
            throw new UsernameNotFoundException("UserName with " + orgMasterUserDto.getEmail() +
                    " already exists.");
        }
        String[] frameworks = orgMasterUserDto.getFrameworkSubscribed();
        if (null == frameworks || frameworks.length == 0) {
            throw new AuthException("Subscribe atleast one framework");
        }
        for (String framework : frameworks) {
            if (!StorageService.validateFramework(framework)) {
                throw new AuthException(framework + " is not a valid framework");
            }
        }
        Organization savedOrganization = null;
        OrganizationDto savedOrganizationDto = null;
        try {
            savedOrganization = orgMasterRepository.save(this.getOrgFromOrgUserDto(orgMasterUserDto));
            savedOrganizationDto = mappingService.getOrgDtoFromEntity(savedOrganization);
            final User newUser = this.userFromOrgUserDto(orgMasterUserDto);
            newUser.setOrganization(savedOrganization);
            newUser.setOrganizationName(savedOrganization.getOrgName());
            userService.saveUser(newUser, "ORG_BUSINESS_ADMIN");
            // creating the S3 bucket structure
            storageService.s3StructureSetup(orgName, orgMasterUserDto.getFrameworkSubscribed());
            log.info("S3 setup done for the org {}", orgName);
            return savedOrganizationDto;
        } catch (Exception e) {
            log.error("Given Organization " + orgMasterUserDto.getOrgName() + " could not be registered");
            throw new AuthException("Given Organization " + orgMasterUserDto.getOrgName() + " could not be registered");
        }
    }

    /**
     * if the user is already registered with any saas providers then we set the isdetailedFilled Active.
     *
     * @param username
     * @throws AuthException
     */
    @Override
    public void update(String username) throws AuthException {
        try {
            User user = userRepository.findByUsername(username);
            Organization organization = user.getOrganization();
            if (organization != null && !organization.isDetailFilled()) {
                organization.setDetailFilled(true);
                orgMasterRepository.save(organization);
                return;
            }
            log.error("The user" + username + " is already registered for saas provider");
        } catch (Exception ae) {
            log.error("The user" + username + "already registered for one of saas provider");
            throw new AuthException(ae);
        }
    }

    /**
     * method to fetch all active organizations by status.
     *
     * @param status
     * @return
     * @throws AuthException
     */
    @Override
    public List<OrganizationDto> getOrganizations(String status) throws AuthException {
        try {
            final List<Organization> organizations = orgMasterRepository.findAllByStatus(status);
            if (organizations != null || !organizations.isEmpty()) {
                List<OrganizationDto> organizationDtoList = new ArrayList<>();
                for (Organization organization : organizations) {
                    OrganizationDto organizationDto = mappingService.getOrgDtoFromEntity(organization);
                    organizationDtoList.add(organizationDto);
                }
                return organizationDtoList;
            }
            log.error("No list of Organization entity records found with {} status", status);
            throw new AuthException("No list of Organization entity records found with " + status + " status");
        } catch (Exception ae) {
            log.error("No list of Organization entity records found with {} status", status);
            throw new AuthException(ae);
        }
    }

    /**
     * method to fetch Organization record with given organizationName
     *
     * @param organizationName
     * @return
     * @throws AuthException
     */
    @Override
    public Organization getOrganization(String organizationName) throws AuthException {
        try {
            Organization organization = orgMasterRepository.findByOrgName(organizationName);
            if (organization != null) {
                return organization;
            }
            log.error("No Organization entity record found with orgName {}", organizationName);
            throw new AuthException("No Organization entity record found with orgName " + organizationName);
        } catch (Exception ae) {
            log.error("No Organization entity record found with orgName {}", organizationName);
            throw new AuthException(ae);
        }
    }

    /**
     * This method  is for finding the organization with the given orgId.
     * clientId is the organizationId for the Organization.
     *
     * @param orgId
     * @return {@link Organization}
     * @throws AuthException
     */
    @Override
    public Organization findById(Long orgId) throws AuthException {
        try {
            Organization organization = orgMasterRepository.findById(orgId);
            if (organization != null) {
                return organization;
            }
            log.error("No organization found for given orgId " + orgId);
            throw new OrganizationException("NO organization found with the given OrgId " + orgId);
        } catch (Exception e) {
            log.error("No organization found for this clientId" + orgId);
            throw new AuthException(e);
        }
    }

    /**
     * method to Update orgDetails.
     *
     * @param orgDetailsDtos: saving the list of organization details request.
     * @return orgDetailsDtos: returning the organization details with id.
     * @throws AuthException
     */
    @Override
    public List<OrgDetailsDto> updateOrgDetails(List<OrgDetailsDto> orgDetailsDtos) throws AuthException {
        try {
            for (OrgDetailsDto orgDetailsDto : orgDetailsDtos) {
                OrgDetails orgDetails = this.getOrgDetails(orgDetailsDto);
                OrgDetails savedOrgDetails = orgDetailsRepository.save(orgDetails);
                orgDetailsDto.setId(savedOrgDetails.getId());
            }
            return orgDetailsDtos;
        } catch (Exception ex) {
            log.error("Unable to update the OrgDetails for the organization.");
            throw new AuthException(ex);
        }
    }

    /**
     * To handle the details of Organization when registering a new one.
     *
     * @return {@link Organization}
     * @throws AuthException
     */
    private Organization getOrgFromOrgUserDto(OrgMasterUserDto orgMasterUserDto) throws AuthException {
        try {
            Organization organization = new Organization();
            organization.setOrgName(orgMasterUserDto.getOrgName());
            organization.setDescription(orgMasterUserDto.getDescription());
            Set<Framework> frameworkSet = new HashSet<>();
            for (String compliance : orgMasterUserDto.getFrameworkSubscribed()) {
                Framework framework = frameworkRepository.findByName(compliance);
                frameworkSet.add(framework);
            }
            organization.setFrameworks(frameworkSet);
            return organization;
        } catch (Exception ae) {
            log.error("The given details" + orgMasterUserDto.getOrgName() + "could not be registered");
            throw new AuthException(ae);
        }
    }

    /**
     * To handle the details of User when registering a new one.
     *
     * @return {@link User}
     * @throws AuthException
     */
    private User userFromOrgUserDto(OrgMasterUserDto orgMasterUserDto) throws AuthException {
        try {
            User user = new User();
            user.setEmail(orgMasterUserDto.getEmail());
            user.setPhone(orgMasterUserDto.getPhone());
            user.setName(orgMasterUserDto.getName());
            user.setUsername(orgMasterUserDto.getEmail());
            return user;
        } catch (Exception ae) {
            log.error("Unable to register the user ");
            throw new AuthException(ae);
        }
    }

    /**
     * To handle the details of OrgDetails when updating a new one.
     *
     * @return {@link OrgDetails}
     * @throws AuthException
     */
    private OrgDetails getOrgDetails(OrgDetailsDto orgDetailsDto) throws AuthException {
        try {
            OrgDetails orgDetails = new OrgDetails();
            Long orgId = userService.getCurrentUser().getOrganization().getId();
            orgDetails.setId(orgDetailsDto.getId());
            orgDetails.setOrgId(orgId);
            orgDetails.setName(orgDetailsDto.getName());
            orgDetails.setValue(orgDetailsDto.getValue());
            return orgDetails;
        } catch (Exception ex) {
            log.error("Unable to register the organization Details. ");
            throw new AuthException(ex);
        }
    }

    /**
     * In this method to handle the file for organization and save it in folder documents.
     *
     * @param file input file
     * @throws AuthException
     */
    public void saveFileForOrganization(final MultipartFile file) throws AuthException {
        try {
            final File fileName = new File(file.getOriginalFilename());
            final FileOutputStream fos = new FileOutputStream(fileName);
            fos.write(file.getBytes());
            fos.close();

            String bucketName = userService.getCurrentUser().getOrganization().getOrgName().toLowerCase(Locale.ROOT);
            String folderName = PolicyCenter.data.name() + "/" + DocumentFolder.documents.name() + "/";
            DataUpload2FolderRequest dataUpload2FolderRequest = new DataUpload2FolderRequest();
            dataUpload2FolderRequest.setBucketName(bucketName);
            dataUpload2FolderRequest.setFolderName(folderName);
            dataUpload2FolderRequest.setData(new FileInputStream(fileName));
            dataUpload2FolderRequest.setKey(file.getOriginalFilename());
            s3Util.uploadUnderFolder(dataUpload2FolderRequest);
        } catch (Exception exception) {
            log.error(exception.getMessage() + file.getOriginalFilename());
            throw new AuthException(exception);
        }
    }
}
