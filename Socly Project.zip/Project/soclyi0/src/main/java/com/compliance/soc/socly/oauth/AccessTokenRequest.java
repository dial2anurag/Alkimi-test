package com.compliance.soc.socly.oauth;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * Json response class for Access token Request.
 */
public class AccessTokenRequest {

    private String grant_type;
    private String client_id;
    private String client_secret;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String refresh_token;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String redirect_uri;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String code;
}
