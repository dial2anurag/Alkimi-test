package com.compliance.soc.socly.auth.model;

import com.compliance.soc.socly.auth.entity.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminCreatedUser {
    private String email;
    private String phone;
    private String name;
    private String businessTitle;

    /**
     * API method get the details from the User
     * @return user
     */
    public User getUserFromAdmin() {
        User user = new User();
        user.setUsername(email);
        user.setEmail(email);
        user.setPhone(phone);
        user.setName(name);
        user.setBusinessTitle(businessTitle);
        return  user;
    }

}