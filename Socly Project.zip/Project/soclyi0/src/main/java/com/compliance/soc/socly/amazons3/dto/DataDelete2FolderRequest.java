package com.compliance.soc.socly.amazons3.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class DataDelete2FolderRequest implements Serializable {
    private String bucketName;
    private String folderName;
    private Object data;
    private String key;
}