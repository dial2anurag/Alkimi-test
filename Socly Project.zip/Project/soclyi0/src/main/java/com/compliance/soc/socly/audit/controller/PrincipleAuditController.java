package com.compliance.soc.socly.audit.controller;

import com.compliance.soc.socly.audit.Exceptions.PrincipleApprovalException;
import com.compliance.soc.socly.audit.model.PrincipleApprovalDto;
import com.compliance.soc.socly.audit.model.PrincipleApprovalRequest;
import com.compliance.soc.socly.audit.service.PrincipleApprovalService;
import com.compliance.soc.socly.auth.entity.User;
import com.compliance.soc.socly.auth.exception.UserDetailsException;
import com.compliance.soc.socly.auth.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Component
@RequestMapping(value = "/audit")
public class PrincipleAuditController extends AuditBaseController{

    @Autowired
    private PrincipleApprovalService service;

    /**
     * method to save PrincipleApproval data in principle_approval table
     *
     * @param principleApproval class data
     * @return principle approval data/ exception message and Http status
     */
    @PostMapping(value = "principle")
    public ResponseEntity<?> save(@RequestBody PrincipleApprovalRequest principleApproval) {
        try {
            User user = userService.getCurrentUser();
            PrincipleApprovalDto details = service.save(principleApproval, user);
            return ResponseEntity.ok().body(details);
        } catch (PrincipleApprovalException | UserDetailsException exp) {
            log.error(exp.getMessage());
            return ResponseEntity.badRequest().body(exp.getMessage());
        }
    }
}