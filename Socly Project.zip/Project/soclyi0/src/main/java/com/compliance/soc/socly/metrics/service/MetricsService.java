package com.compliance.soc.socly.metrics.service;

import com.compliance.soc.socly.metrics.entity.Metrics;
import com.compliance.soc.socly.metrics.repository.MetricsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MetricsService {
    @Autowired
    private MetricsRepository metricsRepository;

    /**
     * API method for fetching list of metrics.
     * @return metrics
     */
    public List<Metrics> getAll(){
        return (List<Metrics>) metricsRepository.findAll();
    }

    /**
     * API Method for fetching All active metrics
     * @return metrics
     */

    public List<Metrics> getAllActiveMetrics(){
        return (List<Metrics>) metricsRepository.findByStatus("Active");
    }

    /**
     * API method for fetching  list of all active metrics by the type.
     * @param type
     * @return metrics
     */

    public List<Metrics> getAllActiveMetricsByType(String type){
        return (List<Metrics>) metricsRepository.findByStatusAndType("Active", type);
    }
}
