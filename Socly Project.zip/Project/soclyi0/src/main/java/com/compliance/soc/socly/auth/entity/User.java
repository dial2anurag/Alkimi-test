package com.compliance.soc.socly.auth.entity;

import com.compliance.soc.socly.quiz.entity.Quiz;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OneToOne;

import java.util.Date;
import java.util.Set;

@Entity
@Getter
@Setter
@EntityListeners(AuditingEntityListener.class)
/**
 * User is an entity class and properties from the User table
 */
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column
    private String password;

    @Column
    private String email;

    @Column
    private String phone;

    @Column
    private String name;

    @Column
    private String businessTitle;

    @Column
    private String organizationName;

    @Column
    private boolean isPasswordChanged;

    @Column
    private boolean isDetailsFilled;

    @Column
    private Date createdDate;

    @Column
    private Long createdBy;

    @Column
    private Date modifiedDate;

    @Column
    private Long modifiedBy;

    /**
     * joining the user and user_role table
     */

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "USER_ROLES",
            joinColumns = {
                    @JoinColumn(name = "USER_ID")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "ROLE_ID")})
    private Set<Role> roles;
    /**
     * Joining the org_master and user table .
     */

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "client_id")
    private Organization organization;

    /**
     * Joining User and Quiz tables
     */
    @OneToOne(mappedBy = "user")
    private Quiz quiz;

    @Column(columnDefinition = "varchar(50) default 'Active'", nullable = false)
    private String status = "Active";
}
