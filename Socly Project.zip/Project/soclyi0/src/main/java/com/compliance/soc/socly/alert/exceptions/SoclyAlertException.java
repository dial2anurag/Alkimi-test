package com.compliance.soc.socly.alert.exceptions;
/**
 *  SoclyAlertException is exception class to handle separately with others
 */
public class SoclyAlertException extends Exception {
    public SoclyAlertException(final Exception ex) {
        super(ex);
    }

    public SoclyAlertException(final String errorMsg) {
        super(errorMsg);
    }
}

