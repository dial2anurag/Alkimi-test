package com.compliance.soc.socly.comment.repository;
import com.compliance.soc.socly.comment.entity.Comment;
import com.compliance.soc.socly.comment.exceptions.CommentException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * CommentRepository is a Repository class or DAO class it access data from the Data base tables.
 */
@Repository
public interface CommentRepository extends  CrudRepository<Comment, Long> {

    /**
     * this method for fetching the comments based on CommentId.
     *
     * @param id
     */
    Comment findByid(Long id);
    /**
     * this method for fetching the comments based on CommentId & associationId.
     *
     * @param id, associationId
     */
    Optional<Comment> findByidAndAssociationId(Long id, Long associationId);

}
