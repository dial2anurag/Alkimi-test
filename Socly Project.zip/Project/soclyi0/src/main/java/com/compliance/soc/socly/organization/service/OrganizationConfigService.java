package com.compliance.soc.socly.organization.service;

import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.compliance.soc.socly.amazons3.service.StorageService;
import com.compliance.soc.socly.organization.exception.OrganizationConfigException;
import com.compliance.soc.socly.saas.enums.SAASFolders;
import com.compliance.soc.socly.util.PathUtil;
import com.compliance.soc.socly.util.s3.S3Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
public class OrganizationConfigService {

    @Autowired
    private StorageService service;
    @Autowired
    private S3Util s3Util;

    public static final String SYSTEM_DESCRIPTION = "SystemDescription";
    /**
     * save all the images and json in S3 bucket under folder organization_docs and if unsuccessful wrap exception and throw OrganizationConfigException
     *
     * @param orgId
     * @param images
     * @param orgDescription - detail about company as json
     */
    public void uploadDescriptionFilesToS3(String orgId, MultipartFile[] images, String orgDescription) throws OrganizationConfigException {
        String systemFolder = orgId + "/" + SAASFolders.organization_docs;
        Path file = Paths.get("system.temp");
        try {
            service.uploadFile(SYSTEM_DESCRIPTION, "NA", images);
            Files.write(file, Collections.singleton(orgDescription), StandardCharsets.UTF_8);
            s3Util.putFileS3(systemFolder, SYSTEM_DESCRIPTION, file.toFile());
            Files.delete(file);
        } catch (Exception e) {
            log.error("Unable to upload files to S3 bucket for client %s " ,orgId + e);
            throw new OrganizationConfigException("Error while uploading files to S3 for "+orgId + e);
        }
    }
    /**
     * this method calls S3 utility to get S3ObjectInputStream by passing orgId and folder name
     *
     * @param orgId
     */
    public List<S3ObjectInputStream> getDescriptionFiles(String orgId) {
        return s3Util.getObjFromS3(orgId, SAASFolders.organization_docs+"/");
    }
}
