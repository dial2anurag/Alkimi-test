package com.compliance.soc.socly.metrics.repository;

import com.compliance.soc.socly.metrics.entity.Metrics;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MetricsRepository extends CrudRepository<Metrics,String> {
    List<Metrics> findByStatus(String status);
    List<Metrics> findByStatusAndType(String status, String type);
}
