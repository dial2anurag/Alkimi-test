import React from 'react'
import profile from '../Assets/profile.png'
import logo from '../Assets/logo.png'
import notification from '../Assets/notification.svg'
import info from '../Assets/info.svg'
import account from '../Assets/account.svg'
import '../Styles/nav.css'
import { Link } from 'react-router-dom'
import { LinkStyleNormal, LinkStyleClicked } from '../StyledComponents/ComponentWrapper'

interface IState {
    pathname: string
}

class Nav extends React.Component<any, IState> {
    constructor(props: any) {
        super(props)
    
        this.state = {
            pathname: ''
        }
    }

    componentDidMount() {
        this.setState({
            pathname: window.location.pathname
        })
    }
    
    render() {
        return (
            <header>
                <img src={logo} alt="Socly logo" className="soclylogo" />
                { 
                    this.state.pathname !== '/tools' ? (
                        <nav>
                            <ul className="nav-items">
                                <li><Link to="/dashboard" style={this.state.pathname === '/dashboard' ? LinkStyleClicked : LinkStyleNormal}>Dashboard</Link></li>
                                <li><Link to="/alerts" style={this.state.pathname === '/alerts' ? LinkStyleClicked : LinkStyleNormal}>Alerts</Link></li>
                                <li><Link to="/monitoring" style={this.state.pathname === '/monitoring' ? LinkStyleClicked : LinkStyleNormal}>Monitoring</Link></li>
                            </ul>
                        </nav>
                    ) : null
                }
                <nav>
                    <ul className = "nav-items">
                        <li><Link to="/dashboard" style={this.state.pathname === '/dashboard' ? LinkStyleClicked : LinkStyleNormal}>Dashboard</Link></li>
                        <li><Link to="/tools" style={this.state.pathname === '/tools' ? LinkStyleClicked : LinkStyleNormal}>Tools</Link></li>
                    </ul>
                </nav>

                <ul className="nav-links">
                    <li className="nav-item"><img src={account} alt="nav element" className="nav-element" /></li>
                    <li className="nav-item"><img src={info} alt="nav element" className="nav-element" /></li>
                    <li className="nav-item"><img src={notification} alt="nav element" className="nav-element" /></li>
                    <li className="nav-item"><img src={profile} alt="nav element" className="profile" /></li>
                </ul>
            </header>
        )
    }
}

export default Nav
