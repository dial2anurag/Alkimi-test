import React, { Component } from 'react';
import RichTextEditorService from '../../services/Common/RichTextEditorService';
import RichTextWrapper from './RichTestEditor.style';
import SunEditor, {buttonList} from 'suneditor-react';
import SunEditorCore  from "suneditor/src/lib/core";
import 'suneditor/dist/css/suneditor.min.css';
import { SunEditorReactProps } from 'suneditor-react/dist/types/SunEditorReactProps';
import SetOptions from 'suneditor-react/dist/types/SetOptions';

export interface RichTextEditorOptionEntity {
  showSave?: boolean,
  readonly?: boolean,
  disable?: boolean,
  disableToolbar?: boolean,
  autoFocus ? : boolean,
  showmedia ? : boolean
}

export type RichTextEditorState = {
  content: string,
  option ?: RichTextEditorOptionEntity
}

export interface RichTextEditorProps {
  onChange ? : (htmlstring : any) => void,
  onSave ? : (content : string) => void,
  defaultcontent ? : string,  
  content ? : string,
  onImageUpload ? : (imageFile : Blob , imageFiles : Blob[]) => void,
  height ? : string,
  width ?: string,
  placeholder ? : string,
  option ?: RichTextEditorOptionEntity
}

export class RichTextEditor extends 
  Component<RichTextEditorProps,RichTextEditorState,any> {
  private _editorref :any ;
  constructor(props : RichTextEditorProps){
    super(props);
    this.state ={
      content : this.props.content ? this.props.content : "",
      option: this.props.option
    }
    this._editorref = React.createRef();
    if(this.props.content){
      this.handleOnChangeProps(this.props.content);
    }
  }

  shouldComponentUpdate(nextProps : RichTextEditorProps){
      let returnValue: boolean = false;
      if (nextProps.content !== this.state.content) {
        this.setState({content: nextProps.content ? nextProps.content : ""});
        returnValue = true;
      }
      if(nextProps.option !== this.state.option) {
        this.setState({option: nextProps.option});
        returnValue = true;
      }
      return returnValue;
  }

  getSunEditorInstance (sunEditor : SunEditorCore):void{
    this._editorref.current = sunEditor;
  }
  
  handleOnChangeProps(content : string){
    if(this.props.onChange){
      this.props.onChange(content);
    }
  }

 handleOnSave(content : string) : void {
    if(this.props.onSave){
       this.props.onSave(content);
    }
  }

  handleImageUpload(targetImgElement: HTMLImageElement, index: number, state: string, imageInfo: object, remainingFilesCount: number) : void{
    
  }

  setEditorProps():SunEditorReactProps {
    let option = {
      readonly: this.state.option && this.state.option.readonly ? this.state.option.readonly : false,
      showmedia: this.state.option && this.state.option.showmedia ? this.state.option.showmedia : false,
      showSave: this.state.option && this.state.option.showSave ? this.state.option.showSave : false,
      autoFocus: this.state.option && this.state.option.autoFocus ? this.state.option.autoFocus : false,
      disable: this.state.option && this.state.option.disable ? this.state.option.disable : false,
      disableToolbar: this.state.option && this.state.option.disableToolbar ? this.state.option.disableToolbar : false
    }
    let medialist : string[] =["link","image"];
    if(option.showmedia){
      medialist.push("video");
      medialist.push("audio");
    }

    let btnlist : any[] =[
      ["undo", "redo"],
      ["bold", "underline", "italic", "strike"],
      ["font", "fontSize","fontColor", "hiliteColor"],
      ["align", "list", "lineHeight"],
      ['paragraphStyle', 'blockquote'],
      ["outdent", "indent"],
      ["table", "horizontalRule"],
      medialist,
      ["fullScreen", "showBlocks"],
      ["removeFormat"],
      ["preview", "print"],
    ]
    
    if(!option.readonly && option.showSave) {
      btnlist.push(["save"]);
    }

    let setOptions :SetOptions ={
      defaultTag: "div",
      alignItems : ['center','justify','left','right'],
      buttonList :btnlist
    }

    let propsPrams : SunEditorReactProps ={
      height : this.props.height ? this.props.height : "auto",
      width : this.props.width ? this.props.width :"auto",
      setOptions : setOptions,
      defaultValue : this.props.defaultcontent,
      setContents : this.state.content,
      autoFocus : option.autoFocus,
      placeholder : this.props.placeholder,
      getSunEditorInstance :this.getSunEditorInstance.bind(this), 
      onImageUpload  : this.handleImageUpload.bind(this),
      readOnly : option.readonly,
      disable: option.disable,
      disableToolbar: option.disableToolbar
    }
    if(!option.readonly){
      propsPrams.onChange = this.handleOnChangeProps.bind(this);
      if(option.showSave) {
        propsPrams.onSave =this.handleOnSave.bind(this);
      }
    }

    return propsPrams;
  }

  render() {
    return (
      <RichTextWrapper key="richtexteditordivmain">
          <SunEditor  {...this.setEditorProps()} />
      </RichTextWrapper>
    )
  }
}

export default RichTextEditor