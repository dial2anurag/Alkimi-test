import { padding } from '@atlaskit/modal-dialog/dist/types/internal/constants';
import React from 'react';
import styled, { css } from 'styled-components'

export const Form = styled.form`
    width: 50%;
    margin: 0 auto;
    margin-top: 2rem;
`;

export const Fields = styled.div`
    margin-top: 1rem;
`;


export const Grid = styled.div`
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    grid-gap: 2rem;
    margin-top: 2rem;
`;

export const GridItem = styled.div`
    display: grid;
    grid-column: span 12;
    width: 30%;
    margin: 0 auto;
    grid-template-columns: repeat(12, 1fr);
    border-radius: 12px;
    border: solid 1px #e3e4e8;
    background-color: #ffffff;
    padding: 1rem;
`;

export const AlertTableHead = styled.div`
    background-color: #ffffff;
    display: grid;
    grid-template-columns: repeat(24, 1fr);
    margin-top: 1rem;
    padding: 5px;
`;

export const CommonRowsHead = styled.div`
display: grid;
grid-column: span 4;
text-align: left;
font-size: 18px;
font-weight: 600;
font-stretch: normal;
font-style: normal;
line-height: 3.33;
letter-spacing: normal;
color: #293134;
`;

export const Description = styled.div<ClickedRemediateProps>`
display: grid;
grid-column: span 8;
padding: 10px;
padding-top: 5px;
padding-left: 6px;
font-size: 16px;
font-weight: normal;
font-stretch: normal;
font-style: normal;
line-height: 1;
letter-spacing: normal;
text-align: left;
color: #8d8d8f;
${
    props => props.clickedRemediate && css`
        color: #ffffff;
    `
};
`;

export const DescriptionHead = styled.div`
display: grid;
grid-column: span 8;
text-align: left;
font-size: 18px;
font-weight: 600;
font-stretch: normal;
font-style: normal;
line-height: 3.33;
letter-spacing: normal;
color: #293134;
`;

export interface ClickedRemediateProps {
    clickedRemediate?: boolean
}

export const AlertTable = styled.div<ClickedRemediateProps>`
background-color: #ffffff;
display: grid;
grid-template-columns: repeat(24, 1fr);
margin-top: 1rem;
padding: 5px;
border-radius: 12px;
${
    props => props.clickedRemediate && css`
        background-color: #20a7e8;
        border-bottom-left-radius: 0px;
        border-bottom-right-radius: 0px;
    `
};
`;

export const CommonRows = styled.div<ClickedRemediateProps>`
grid-column: span 4;
padding: 10px;
padding-left: 6px;
padding-top: 5px;
font-size: 16px;
font-weight: normal;
font-stretch: normal;
font-style: normal;
line-height: 3.33;
letter-spacing: normal;
text-align: left;
color: #8d8d8f;
${
    props => props.clickedRemediate && css`
        color: #ffffff;
    `
};
`;
export const ViewButton = styled.div<ClickedRemediateProps>`
    padding: 0px;
    border-radius: 4px;
    background-color: #002260;
    text-align: center;
    font-size: 16px;
    color: #ffffff;
    width: 60%;
    margin: 0 auto;
    padding: -5px 0px;
    cursor: pointer;
    ${
        props => props.clickedRemediate && css`
            display: none;
        `
    };
`;

export const IconBox = styled.div`
    display: grid;
    grid-column: span 6;
`;

export const AlertNumber = styled.div`
    display: grid;
    grid-column: span 6;
    font-size: 85px;
    font-weight: 500;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.21;
    letter-spacing: normal;
    text-align: center;
    margin: auto;
`;

export const PageText = styled.div`
    margin-top: 10px;
    font-size: 16px;
    font-weight: 500;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.23;
    letter-spacing: normal;
    text-align: center;
    color: #8d8d8f;
`;

export const ChartContainer = styled.div`
    border-radius: 20px;
    border: solid 1px #e3e4e8;
    background-color: #ffffff;
    width: 100%;
    padding: 1rem;
    margin-top: 2rem;
`;

export const ChartHeading = styled.div`
    font-size: 18px;
    font-weight: 550;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.23;
    letter-spacing: normal;
    text-align: center;
    color: #5c5c5f;
    margin-bottom: 15px;
`;
export const Icon = styled.div`
display: grid;
grid-column: span 2;
padding: 10px;
padding-left: 0px;
border-bottom: solid 1px #e3e4e8;
`;

export const IconHead = styled.div`
display: grid;
grid-column: span 2;
padding: 10px;
padding-left: 0px;
`;

