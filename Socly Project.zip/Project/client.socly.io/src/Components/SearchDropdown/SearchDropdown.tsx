import React, { Component } from 'react';
import './searchdropdown.css';
import SpinnersComponent from '../SpinnersComponent'

export type SearchDropdownProps={
    id : string
    source : any[],
    displayColumn : string,
    idColumn : string
    searchColumns :string [],
    searchafterlength ? : number
    onOptionSelection : (event : any , selectedData : any, seltext : string) => boolean
    placeholder ? : string
    displayaslist ? : boolean
}

type SearchDropdownState ={
  selectedText : string,
  listData :any[],
  showSpinner : boolean
}

export class SearchDropdown extends Component<SearchDropdownProps,SearchDropdownState> {
  private inputref : React.RefObject<HTMLInputElement> ;
  private inputdivref : React.RefObject<HTMLDivElement> ;
  constructor(props : SearchDropdownProps){
    super(props);
    this.state = {selectedText : "" , listData :this.props.source , showSpinner : false}
    this.inputref =React.createRef() ;
    this.inputdivref = React.createRef();
    this.onOptionClick = this.onOptionClick.bind(this); 
  }
  
  static getDerivedStateFromProps(nextProps : SearchDropdownProps, prevState : SearchDropdownState) {
    return nextProps.source;
  }

  handleChange(event : any){
    if(event.target.id === `inputtext-${this.props.id}`){
      this.setState({selectedText : event.target.value})
    }
  }

  onOptionClick(event :any, selectedData : any , seltext : string) {
    if(this.inputref && this.inputref.current){
      this.inputref.current.value=seltext;
    }
    this.setState({selectedText : seltext });

    if(! this.props.displayaslist && this.inputdivref && this.inputdivref.current){
      this.inputdivref.current.className="list-ul-div list-ul-div-nodisplay";
    }

    this.props.onOptionSelection(event,selectedData,seltext);
  }

  filterData(event : any){
    let searchafterlenght :number =this.props.searchafterlength ? this.props.searchafterlength : 3;
    if(this.state.selectedText.trim().length < searchafterlenght){
      if(this.state.listData.length !== this.props.source.length){
        this.setState({listData : this.props.source})  
      }
      if(! this.props.displayaslist 
        && this.inputdivref && this.inputdivref.current 
        && this.inputdivref.current.className.indexOf("list-ul-div-display")>=0){
        this.inputdivref.current.className ="list-ul-div list-ul-div-nodisplay"
      } 
      return;
    }
    if(this.inputdivref && this.inputdivref.current){
      this.inputdivref.current.className="list-ul-div list-ul-div-display";
    }
    this.setState({showSpinner : true});
    let list : any[]=[];
    let tmplist : any[];

    this.props.searchColumns.forEach((col,index)=>{
      tmplist = this.props.source.filter(e=> e[col].toString().toLowerCase().indexOf(this.state.selectedText.toLowerCase())>=0)
      tmplist.forEach((e, index)=>{
          if(! list.find(e1=> e1 === e)){
            list.push(e);
          }
      })
    })
    this.setState({listData : list , showSpinner : false});
    if(list.length <=0 && this.inputdivref && this.inputdivref.current){
      this.inputdivref.current.className="list-ul-div list-ul-div-nodisplay";
    }
  }

  render() {
    return (
        <div key={`divparent-${this.props.id}`} 
        className="dropdown-content list-div">
          <input 
             ref={this.inputref} 
              type="text" 
              placeholder={ this.props.placeholder ? this.props.placeholder : "Search.."} 
              key={`inputtext-${this.props.id}`} 
              id={`inputtext-${this.props.id}`}
              onChange={this.handleChange.bind(this)} 
              onKeyUp={this.filterData.bind(this)}
              className="list-input-text"
             />
             <div
             key={`div-ul-${this.props.id}`} 
             className={"list-ul-div" + (this.props.displayaslist? " list-ul-div-display" :" list-ul-div-nodisplay" )}
             ref={this.inputdivref} 
             >
               <SpinnersComponent key="searchspinnercomponent" showspinner={this.state.showSpinner}  />
                <ul 
                key={`ul-${this.props.id}`}
                className="list-ul"
                >
                  {
                    this.state.listData.map((itm,index)=>{
                      return(
                        <li className='list-li'  key={`li-${this.props.id}-(${index})`}
                        onClick={(e)=>{ this.onOptionClick(e,itm,itm[this.props.displayColumn])}}
                        >{itm[this.props.displayColumn]}</li>
                      )
                    })
                  }
                </ul>
              </div>
        </div>
    )
  }
}
export default SearchDropdown