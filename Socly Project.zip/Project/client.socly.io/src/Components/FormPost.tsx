import React, { Component, HTMLAttributes, HtmlHTMLAttributes } from 'react';
import Frame from 'react-frame-component';
export interface formPostParams {
    name : string,
    value : string
}
export interface formPostFormProps{
    action:string,
    method : "POST" | "GET",
    handleonSubmit? : (event:any) => void
}
export interface FormPostProps {
    params : formPostParams[],
    formProps : formPostFormProps
}
export class FormPost extends Component<FormPostProps> {
    private formRef : React.RefObject<HTMLFormElement>;
    constructor(props:FormPostProps){
        super(props);
        this.formRef = React.createRef<HTMLFormElement>();
    }

    componentDidMount() {
        if (null !==this.formRef.current) {
            this.formRef.current.submit();
        }
    }

    render() {
        return (
            <>
                <form 
                    action={this.props.formProps.action} 
                    method={this.props.formProps.method}
                    ref={this.formRef}>
                    {
                        this.props.params.map((item , index)=>{
                             return(
                                 <input type='hidden' name={item.name} id={item.name} value={item.value} />
                             )       
                        })
                    }
                </form>
            </>
        )
    }
}

export default FormPost
