import React, { Component } from 'react';
import {
    Button , 
    Modal
} from 'react-bootstrap';
import SpinnersComponent from './SpinnersComponent' ;
import {
    Form,
    Fields
} from './CommonComponent';
import { TextField } from '@material-ui/core';

export interface ValidateOTPProps{
    showModal: boolean,
    referenceId : string,
    handleValidate : (otp:string) => boolean,
    handleCancel ? : () => boolean,
    headerText ? :string
}

type ValidateOTPState = {
    showModal :boolean,
    otp : string,
    showSpinner :boolean
}
export default class ValidateOTP extends Component<ValidateOTPProps,ValidateOTPState> {
    constructor(props : ValidateOTPProps){
        super(props);  
        this.state ={
            showModal :this.props.showModal,
            otp :"",
            showSpinner : false
        }
        this.handleChange = this.handleChange.bind(this);
    }

    async handleClose(event:any){
        this.setState({showModal: false});
        if(this.props.handleCancel) this.props.handleCancel();
    }

    async handleSave(event : any){
        event.preventDefault();
        if(! this.state.otp) return
        this.setState({showSpinner : true});
        let value = await this.props.handleValidate(this.state.otp);
        if(value)
        {   
            this.setState({showModal: false});
        }
        this.setState({showSpinner : false});
    }

    handleChange(event :any){
        switch(event.target.id){
            case "otp":
                this.setState({otp : event.target.value});
                break;
        }
    }

    render() {
    return (
    <div>
        <Modal show={this.state.showModal} onHide={this.handleClose.bind(this)}
            size="sm"
            aria-labelledby="contained-modal-title-vcenter"
            centered>
                <Modal.Header closeButton>
                  <Modal.Title>{(this.props.headerText ? this.props.headerText : "Validate OTP")}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <SpinnersComponent key="validateotpspinnercomponent" showspinner = {this.state.showSpinner } />
                    <div>
                        <Form>
                            <Fields>
                                <TextField id="otp" label="Enter OTP" value={this.state.otp } fullWidth variant="outlined" onChange={this.handleChange} required = {true} />
                            </Fields>
                        </Form>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={this.handleClose.bind(this)}>Cancel</Button>
                  <Button variant="primary" onClick={this.handleSave.bind(this)}>Validate</Button>
                </Modal.Footer>
        </Modal>
     </div>);
  }
}
