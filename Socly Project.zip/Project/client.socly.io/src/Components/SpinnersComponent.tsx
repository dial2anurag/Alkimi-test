import React, { Component, CSSProperties } from 'react'
import PacmanLoader from "react-spinners/PacmanLoader";
import SpinnerComponentWrapper from './spinnersComponent.style'

const override: CSSProperties = {
    display: "initial",
    marginRight: "auto",
};

export interface ISpinnerComponentProps {
    showspinner?: boolean,
    disablesection?: boolean,
    parentclassname?: string
    childclassname?: string,
    textonloader?: string,
}

export class SpinnersComponent extends Component<ISpinnerComponentProps, any> {
    constructor(props: ISpinnerComponentProps) {
        super(props);
    }

    showLoaderText() {
        if (this.props.textonloader && this.props.textonloader.trim().length > 0) {
            return (<div key="text2displayprops" className="loadingTex/t">{this.props.textonloader}</div>)
        }
        else {
            return (<div key="text2display" className="loadingText" style={{ color: "#00008b" }} >We are crunching your data. Please do not refresh.</div>)
        }
    }
    render() {
        if (this.props.showspinner) {
            return (
                <SpinnerComponentWrapper>
                    <div key={`divparent`}>
                        <div key={`divchild1`} className={this.props.parentclassname ||
                            this.props.disablesection ? "loading" : "loadingFull"}>
                            <div key={`divsubchild1`} className={this.props.childclassname || "loader"} >
                                <PacmanLoader size={20} color={'#00008b'}
                                    cssOverride={override}
                                />
                                {this.showLoaderText()}
                            </div>
                        </div>
                    </div>
                </SpinnerComponentWrapper>
            );
        }
        else {
            return (null);
        }
    }
}
export default SpinnersComponent
