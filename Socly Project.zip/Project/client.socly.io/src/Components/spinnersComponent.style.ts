import styled from 'styled-components';

const SpinnerComponentWrapper = styled.div`
.loader {
    left: 35%;
}
.loader, .loader:after {
    position: absolute;
    top: 25%;
    transform: translate(-50%, -50%);
}
.loading {
    position: fixed;
    width: 100%;
    height: 100%;
    z-index: 9999999999;
    overflow: hidden;
    background: #fff;
    opacity: 0.5;
}
.loadingFull {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999999999;
    overflow: hidden;
    background: #fff;
    opacity: 0.5;
}
.loadingText{
    width: 100%;
    margin-top: 5rem;
    color: rgb(12, 12, 100);
    text-decoration: solid;
    font-size: medium;
    font-weight:bolder;
}
`;

export default SpinnerComponentWrapper;