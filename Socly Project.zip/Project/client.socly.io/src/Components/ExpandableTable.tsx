import React, { Component } from 'react';
import styled, { css } from 'styled-components';
import {
    Table,
    TableProps
} from 'react-bootstrap';


export type HeaderMappingType={
    property : string,
    headerText : string
}

interface ExpandableTableProps{
    parentList : any[] ,
    childList ?:any[],
    parentTableProps ?: TableProps
    childTableProps ? : TableProps
    parentheaderFieldMapping :HeaderMappingType[],
    childheaderFiledMapping : HeaderMappingType[],
    parentChildReferenceKey ?: string,
    parentTableHeadProps ? : React.TableHTMLAttributes<HTMLTableSectionElement>
    parentTableBodyProps ? : React.TableHTMLAttributes<HTMLTableSectionElement>
    parentTableHeadRowProps ?: React.TableHTMLAttributes<HTMLTableRowElement> ,
    parentTableBodyRowProps ?: React.TableHTMLAttributes<HTMLTableRowElement>,
    parentTableHeadColumnProps ? : React.TableHTMLAttributes<HTMLTableCellElement>,
    parentTableColumnProps ? : React.TableHTMLAttributes<HTMLTableCellElement>,
    parentColumnForChildProps ? : React.TableHTMLAttributes<HTMLTableRowElement>
    childTableHeadProps ? : React.TableHTMLAttributes<HTMLTableSectionElement>
    childTableBodyProps ? : React.TableHTMLAttributes<HTMLTableSectionElement>
    childTableHeadRowProps ?: React.TableHTMLAttributes<HTMLTableRowElement> ,
    childTableBodyRowProps ?: React.TableHTMLAttributes<HTMLTableRowElement>,
    childTableHeadColumnProps ? : React.TableHTMLAttributes<HTMLTableCellElement>,
    childTableColumnProps ? : React.TableHTMLAttributes<HTMLTableCellElement>
}

type ExpandableTableState = {
    expandedRows : any[]
}

export class ExpandableTable extends Component<ExpandableTableProps,ExpandableTableState> {
    constructor(props : ExpandableTableProps){
        super(props);
        this.state = {
            expandedRows : []
        }
    }

    getMappedObject(obj : any,headermappingType :HeaderMappingType[] ):any{
        let resultobject : any={};
        headermappingType.forEach((header) => {
            resultobject[header.property] = obj[header.property];
        });
        return resultobject;
    }

    handleRowClick(referenceValue: string | number) {
        let currentExpandedRows = this.state.expandedRows ;
        let isRowCurrentlyExpanded = currentExpandedRows.includes(referenceValue);
        
        let newExpandedRows = isRowCurrentlyExpanded ? 
			currentExpandedRows.filter(id => id !== referenceValue) : 
			currentExpandedRows.concat(referenceValue);
        
        this.setState({expandedRows : newExpandedRows});
    }

    getParentChildReference() : string{
        if(! this.props.parentChildReferenceKey){
            return "index";
        }
        else{
            return this.props.parentChildReferenceKey;
        }
    }

    renderItem(item : any ,referenceValue : string | number) {
        let referencekey =this.getParentChildReference();
        let clickCallback = () => this.handleRowClick(referenceValue);
        let parentItem=this.getMappedObject(item,this.props.parentheaderFieldMapping);
        let childItem : any;

        let itemRows = [
			<tr onClick={clickCallback} 
            key={`row-data- ${referenceValue}`}
            {...this.props.parentTableBodyRowProps}
            >
                {
                    Object.keys(parentItem).map((key,index)=>{
                        return(
                            <td key={`parent-td-${index}`}
                            {...this.props.parentTableColumnProps}
                            >{parentItem[key]}</td>
                        )
                    })
                }
			</tr>
        ];

        if(this.state.expandedRows.includes(referenceValue)) {
            if(this.props.childList && this.props.childList.length > 0 ){
                let childitemRows  :any[] =[]
                this.props.childList.forEach((childItem , childindex) => {
                    childItem = this.getMappedObject(childItem,this.props.childheaderFiledMapping);        
                    childitemRows.push(
                        <tr
                        key={`childrow-data-${referenceValue}-${childindex}`}
                        {...this.props.childTableBodyRowProps}>
                            {
                                Object.keys(childItem).map((key:string,index)=>{
                                    return(
                                        <td key={`child-td-${referenceValue}-${childindex}-${index}`}
                                        {...this.props.childTableColumnProps}>{childItem[key]}</td>
                                    )
                                })
                            }
                        </tr> 
                    );
                });
                itemRows.push(
                    <tr
                        key={`parentchildrow-data- ${referenceValue}`}
                         {...this.props.parentColumnForChildProps}>
                            <td key={`parentchildtd${referenceValue}`} 
                            colSpan={Object.keys(parentItem).length}
                            {...this.props.childTableColumnProps}>
                                {
                                    this.renderTable(this.props.childList,childitemRows,"Child")             
                                }
                            </td>
                        </tr>
                )
            }
            else{
                childItem = this.getMappedObject(item,this.props.childheaderFiledMapping)

                itemRows.push(
                    <tr key={"row-expanded-" + referenceValue}
                    {...this.props.parentColumnForChildProps}
                    >
                        {
                            Object.keys(childItem).map((key,index)=>{
                                return(
                                    <td key={`child-td-${index}`}
                                    colSpan={Object.keys(childItem).length === 1 ? Object.keys(parentItem).length -(Object.keys(childItem).length -1) : 1 }
                                    {...this.props.childTableColumnProps}
                                    >{childItem[key]}</td>
                                )
                            })
                        }
                    </tr>
                );
            }
        }
        return itemRows;    
    }

    renderTable(mappings : HeaderMappingType[],
        allItemRows :any,
        parentChild : "Parent" | "Child"){
        
        let tableProps : TableProps | undefined ;
        let tableHeadProps : any | undefined;    
        let tableHeadRowProps : any | undefined;
        let tableHeadColumnProps : any|undefined
        let tableBodyProps : any | undefined;    

        if(parentChild === "Parent"){
            tableProps = this.props.parentTableProps;
            tableHeadProps = this.props.parentTableHeadProps;
            tableHeadRowProps =  this.props.parentTableHeadRowProps;
            tableHeadColumnProps =  this.props.parentTableHeadColumnProps;
            tableBodyProps = this.props.parentTableBodyProps;
        }
        else{
            tableProps = this.props.childTableProps;
            tableHeadProps = this.props.childTableHeadProps;
            tableHeadRowProps =  this.props.childTableHeadRowProps;
            tableHeadColumnProps =  this.props.childTableHeadColumnProps;
            tableBodyProps = this.props.childTableBodyProps;
        }
       
        return(
                <Table {...tableProps}>
                    <thead {...tableHeadProps}>
                        <tr {...tableHeadRowProps}>
                            {
                                mappings.map((header,index)=>{
                                    return(
                                        <th key={`thead${index}`}
                                        {...tableHeadColumnProps}
                                        >{header.headerText}</th>
                                    )
                                })
                            }
                        </tr>
                    </thead>
                    <tbody {...tableBodyProps}>
                       {allItemRows}     
                    </tbody>
                </Table>
            );
        }

    render() {
        let allItemRows : any[]= [];
        
        let refereceKey = this.getParentChildReference();
        let referenceValue :string | number ;
        this.props.parentList.forEach((item,index) => {
            if(refereceKey === "index"){
                item[refereceKey] = index;
                referenceValue =index;
            }
            else{
                referenceValue = item[refereceKey];
            }

            const perItemRows = this.renderItem(item,referenceValue);
            allItemRows = allItemRows.concat(perItemRows);
        });
        return(
                <>
                    {this.renderTable(this.props.parentheaderFieldMapping,allItemRows,"Parent")}
                </>
        );
    }
}

export default ExpandableTable
