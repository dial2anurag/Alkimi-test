import React, { Component } from 'react'
import ReactChipsWrapper from './reactChips.style';

type ReactChipState = {
    value: string;
    chips: Array<string>;
    error?: string | null;
    items?: Array<string>;
}

type ReactChipProps = {
  onChange: (value: string[]) => void;
  value: string[] | string;
}

export class ReactChips extends Component<ReactChipProps, ReactChipState> {
    constructor(props : ReactChipProps){
        super(props);
        let chipsData: string[] = [];
        if(typeof this.props.value === "string" && this.props.value !== "") {
          let data = this.props.value.split(",");
          chipsData = data;
        } 
        this.state = {
            value: "",
            chips: chipsData,
            error: null
        }
      }

handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    this.setState({
        value: e.target.value,
        error: null
    });
};

handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (["Tab", "Enter", ","].includes(e.key)) {
      e.preventDefault();
      let chip: string = this.state.value.trim();
      if (chip && this.isValid(chip)) {
        this.state.chips.push(chip);
        this.setState({
          value: ""
        });
        this.props.onChange(this.state.chips);
      }
    }
}

handleDelete(toBeRemoved: string) {
    // TODO Issue: if two similar chips are posted, only one can be deleted
    this.setState({
      chips: this.state.chips.filter((chip) => chip !== toBeRemoved)
    });
}

handlePaste(evt: React.ClipboardEvent<HTMLInputElement>) {
    evt.preventDefault();

    let paste: string = evt.clipboardData.getData("text");
    let chips: string[] | null = paste.match(
      /[\w\d\-]/g
    );

    if (chips) {
      var toBeAdded = chips.filter((chip) => !this.isInList(chip));
      this.state.chips.push(...toBeAdded);
      this.props.onChange(this.state.chips);
    }
}

isValid(chip: string): boolean {
    let error = null;
    if (this.isInList(chip)) {
      error = `${chip} has already been added.`;
    }
    if (error) {
      this.setState({ error });
      return false;
    }
    return true;
}

isInList(chip: string) {
    return this.state.chips.includes(chip);
}


render() {
  const {chips, error, value} = this.state;
    return (
        <ReactChipsWrapper>
           {chips.map((chip: string) => (
            <div className="tag-item" key={chip}>
                {chip}
                <button
                type="button"
                className="button"
                onClick={() => this.handleDelete(chip)}
                >
                &times;
                </button>
            </div>
            ))}
            <input
                key="inputReactChip"
                className={"form-control " + (error && " has-error")}
                value={value}
                placeholder="Enter here"
                onChange={(e) => this.handleChange(e)}
                onKeyDown={(e) => this.handleKeyDown(e)}
                onPaste={(e) => this.handlePaste(e)}
                />
            {error && <p className="help-error">{error}</p>}
        </ReactChipsWrapper>
    )
  }
}

export default ReactChips