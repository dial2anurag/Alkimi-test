import React, { Component } from 'react'
import styled from 'styled-components'

export const Hidediv = styled.div`
    display: none;
`

export class HideLogic extends Component {
  render() {
    return (
      <Hidediv></Hidediv>
    )
  }
} 

export default HideLogic