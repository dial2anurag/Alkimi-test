import React, { Component } from 'react'
import FrameworkComponent , {FrameworkComponentProps} from '../Base/FrameworkComponent';
import { Button, Modal } from 'react-bootstrap';
import { ContentHeading, PageContainer } from '../../StyledComponents/ComponentWrapper';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, GridReadyEvent } from 'ag-grid-community';

interface ComplianceEvidenceViewProps extends FrameworkComponentProps {
    principals : any[],
}

type ComplianceEvidenceViewState ={
    compliances : any[]
}

export class ComplianceEvidenceView extends FrameworkComponent<ComplianceEvidenceViewProps,ComplianceEvidenceViewState> {
    protected gridInstance :GridReadyEvent | undefined;
    constructor(props:ComplianceEvidenceViewProps){
        super(props);
        this.state ={compliances :[]}
    }
  componentDidMount(){
    let compliances : any[]=[];
    let compliancedata : any;
    this.props.principals.forEach((principal,index)=>{
         let compList = Array.prototype.filter.call(principal.compliances,(compliance :any)=>{
            return !compliances.find(e=> e.complianceId.toUpperCase() === compliance.complianceId.toUpperCase())
         })

         compList.forEach((compliance)=>{
            compliancedata =this.deepCopy(compliance);
            compliancedata["evidenceExists"] = compliancedata.fileListResponses && compliancedata.fileListResponses.length > 0 ? "YES" : "NO"
            compliancedata["evidenceCount"] = compliancedata.fileListResponses ? compliancedata.fileListResponses.length : 0 ;
            compliances.push(compliancedata);
         })
    })
    this.setState({compliances : compliances})
    this.setAndRefreshGrid();
  }

  setAndRefreshGrid(){
    if(this.gridInstance){
        this.gridInstance.api.refreshCells();
    }
  }

  onaggridExport2CSV(event :any){
    if(! this.gridInstance){
        return;
    }
    this.gridInstance.api.exportDataAsCsv();
 }
 
 onGridReady(params:GridReadyEvent){
    this.gridInstance = params ;
    this.setAndRefreshGrid();
 }

 gridColumnDef() : ColDef[] {
        return [{
            field: "complianceId",
            headerName : "ComplianceID",
            width : 6
        },{
            field: "controlName",
            headerName : "Control Name" ,
            width : 6
        },{
            field: "evidenceExists",
            headerName : "Evidence Exists",
            wrapText :true,
            autoHeight : true,
            width : 20
        },{
            field: "evidenceCount",
            headerName : "Evidence Count",
            wrapText :true,
            autoHeight : true,
            width : 20
        }]
    }

    defaultGridColumnsDef() : ColDef{
        return {
            sortable :true,
            flex :1,
            resizable : true,
            filter: true,
            minWidth :100
        }
    }
  render() {
    return(
        <div>
            <PageContainer>
                <div>
                    <div className='container'>
                        <div className='row'>
                            <div className='col div-export-button'>
                                <Button key="aggridExport" 
                                        variant='primary' 
                                        onClick={this.onaggridExport2CSV.bind(this)}>
                                    Export To CSV
                                </Button>
                            </div>
                       </div>
                        <div className='row'>
                            <div className='col'>
                                <div className="ag-theme-alpine" style={{height: 800, width:"100%",textAlign :"left"}}>
                                    <AgGridReact
                                        defaultColDef = {this.defaultGridColumnsDef()}
                                        columnDefs = {this.gridColumnDef()}
                                        enableCellChangeFlash ={true}
                                        onGridReady ={this.onGridReady.bind(this)}
                                        pagination ={true}
                                        rowData ={this.state.compliances}
                                    >
                                    </AgGridReact>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </PageContainer>
        </div>
    )
  }
}

export default ComplianceEvidenceView