import React, { Component } from 'react';
import UploadEvidenceService from '../../../services/Upload/UploadEvidenceService';
import {
    Button , 
    Card
} from 'react-bootstrap';
import {
    Form,
    Fields
} from '../../../Components/CommonComponent';
import SpinnersComponent from '../../../Components/SpinnersComponent' ;
import SearchDropdown from '../../../Components/SearchDropdown/SearchDropdown'
import FrameworkComponent,{FrameworkComponentProps} from '../../Base/FrameworkComponent';
import './upload.css';
import { Saas } from '../../../Model/SaasProvider/saasConfigurationEntity';

type UploadEvidenceState = { 
    compliance : string,
    complianceDescription :string 
    complianceList : any[],
    selectedFile : any | null,
    sourceList : Saas []
    showSpinner : boolean
}

interface UploadEvidenceProps extends FrameworkComponentProps {
    complianceData ? : {principal :any , compliance : any}
    handleModalClose ? : () => void
    handleOnSave ? : (compliance : any , principal : any) => void
}

export class UploadEvidence extends FrameworkComponent<UploadEvidenceProps, UploadEvidenceState> {
    private uploadRef : React.RefObject<HTMLInputElement>;
    private readonly _uploadEvidenceService : UploadEvidenceService ;
    private _source : string;
    constructor(props: UploadEvidenceProps){
        super(props);
        this._uploadEvidenceService=new UploadEvidenceService(this.props.framework);
        this.state = {
            compliance : this.props.complianceData ? this.props.complianceData.compliance.complianceId : "",
            complianceDescription : this.props.complianceData ? this.props.complianceData.compliance.description : "",
            complianceList : [],
            selectedFile : null,
            showSpinner:false,
            sourceList : []
        }
        this.uploadRef = React.createRef<HTMLInputElement>();
        this._source = "DOCUMENT"
    }
    
    componentDidMount(){
        if(!this.props.complianceData){
            this._uploadEvidenceService.getComplianceList().then((response)=>{
                if(response.status === 200){
                    let list : any[] =[];
                    Array.prototype.forEach.call(response.data,(itm,index)=>{
                        itm["displayText"] = itm["complianceId"] + "-" + itm["controlName"];
                        list.push(itm);
                    })
                    this.setState({complianceList : list.sort((a : any, b :any) => a.displayText > b.displayText ? 1 : -1)});
                }
            });
        }
        
    }
    
    handleChange(event : any){
         if(event.target.files && event.target.files.length > 0 ){
            this.setState({ selectedFile: event.target.files[0]});
        }
    }

    async handleSave(event : any){
        event.preventDefault();
        let formData = new FormData();
        if(this.state.selectedFile && this.state.compliance ){
            this.setState({showSpinner : true});
            formData.append("source", this._source);
            formData.append("complianceId", this.state.compliance);
            formData.append("files",this.state.selectedFile);

            if(await this._uploadEvidenceService.uploadFile(formData) ===200 ){
                this.setState({selectedFile  : null});
                if (null !==this.uploadRef.current) {
                    this.uploadRef.current.value ="";
                  }
                  if(this.props.handleOnSave && this.props.complianceData){
                    this.props.handleOnSave(this.props.complianceData.compliance, this.props.complianceData.principal)
                  }
                  if(this.props.handleModalClose) {
                    this.props.handleModalClose();
                  }

            }
            this.setState({showSpinner : false});
        }
    }

    handleSearchDropdownOptionSelect(event :any , selectedData :any,seltext : string){
       this.setState({compliance : selectedData.complianceId, 
       complianceDescription : selectedData.description});
        return true;
    }

    async handleClose(event:any){
    }

    render() {
       return (
            <>
                <SpinnersComponent showspinner = {this.state.showSpinner} key={"uploadevidencespinnercomponent"} />
                <Card 
                    key={"Card-0"}
                    bg='light'
                    className={!this.props.complianceData ? "card-style" : "" }
                >
                    <Card.Header key={"card-head-1"}>Upload Evidences</Card.Header>
                        <Card.Body key={"card-body-1"}>
                        <input type="text" key={"source"} className='form-control' value={this._source} readOnly />
                            {!this.props.complianceData &&
                                <Fields>
                                    <SearchDropdown 
                                        key={"searchComplianceKey"}
                                        id={"searchCompliance"} 
                                        source = {this.state.complianceList}
                                        displayColumn ={"displayText"}
                                        idColumn ={"complianceId"}
                                        searchColumns ={["complianceId","controlName"]}
                                        placeholder={"Select Compliance"}
                                        searchafterlength ={2}
                                        onOptionSelection={this.handleSearchDropdownOptionSelect.bind(this)}
                                    /> 
                                </Fields>
                            }
                            <Fields key={"Field-2"}>
                                <Card.Title key={"Card-2-Title"}>{this.state.compliance}</Card.Title>
                                <Card.Text key={"Card-2-Text"}>{this.state.complianceDescription}</Card.Text>
                            </Fields>
                            <Fields key={"Field-3"}>
                            <Form key={"Form-1"} className = "md-form">
                                <div key={"divFld-1"} className="file-field">
                                    <a key={"a-divFld-1"} className="btn-floating peach-gradient mt-0 float-left">
                                        <i key={"i-a-divFld-1"} className="fas fa-paperclip" aria-hidden="true"></i>
                                        <input id="fileUpload" key={"fileUpload"} type="file" ref={this.uploadRef}
                                        accept="application/PDF , application/zip , image/gif, image/png , 	image/jpeg" onChange={this.handleChange.bind(this)} />
                                    </a>
                                </div>
                            </Form>
                            </Fields>
                        </Card.Body>
                        <Card.Footer key={"card-footer-1"}>
                            {this.props.complianceData && 
                                <button type="button" className="btn btn-outline-primary px-4 me-3" onClick={this.props.handleModalClose}>Close</button>
                            }
                            <Button key={"SaveButton"} variant="primary" className='px-4' type ="button" onClick={this.handleSave.bind(this)}>
                                Save Changes
                            </Button>
                        </Card.Footer>
                </Card>
            </>
        )
    }
}
export default UploadEvidence;
