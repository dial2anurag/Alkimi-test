import React, { Component } from 'react';
import {
    ButtonGroup , 
    Button,
    Form
} from 'react-bootstrap';
import './auditstatus.css';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CancelIcon from '@mui/icons-material/Cancel';
import PendingIcon from '@mui/icons-material/Pending';
import AuditStatusService , {AuditFlag} from '../../../services/Audit/AuditStatusService';
import BaseComponent from '../../Base/BaseComponent';


export type KeyData ={
    principal : any,
    compliance ?: any,
    file ?: any
}

export type AuditStatusData={
    auditFlag :string,
    comment?:string
}

export type AuditStatusOption={
    showcomment :boolean,
    readonly ?: boolean
}


export type AuditStatusProps = {
    onOptionClick : (event : any , auditData : AuditStatusData , keyData : KeyData) => Promise<boolean>,
    auditData : AuditStatusData | null
    keyData : KeyData,
    option ?: AuditStatusOption
}

 export type AuditStatusState = {
     auditFlag : AuditFlag,
     comment : string
 }

export class AuditStatus extends BaseComponent<AuditStatusProps , AuditStatusState> {
    constructor(props : AuditStatusProps){
        super(props);
        this.state ={
            auditFlag : AuditStatusService.getAuditFlag(props.auditData ? 
                        props.auditData.auditFlag : 
                        AuditStatusService.getAuditStatusValue(AuditFlag.NotYetEvaluate)),
            comment : (props.auditData && props.auditData.comment ? props.auditData.comment : "")
        }
    }

    async optionClick(event : any , flag : AuditFlag){
        event.preventDefault();
        this.setState({auditFlag : flag });
        if( ! this.props.option || ! this.props.option.showcomment){
            await this.props.onOptionClick(event,
                {
                    auditFlag: AuditStatusService.getAuditStatusValue(flag),
                    comment : this.state.comment
                },
                this.props.keyData);
        }
    }

    getClassname(auditFlag : AuditFlag,button : boolean) : string{
        let classname : string ="default-status";
        if(button){
            return classname + " btn-primary icon-button ";
            //return classname + " icon-button ";
        }
        if(auditFlag === this.state.auditFlag){
            switch(auditFlag){
                case AuditFlag.Approved :{
                    classname = classname + " audit-status-approve-active"
                    break;
                }
                case AuditFlag.Rejected :{
                    classname = classname + " audit-status-reject-active"
                    break;
                }
                case AuditFlag.NotYetEvaluate :{
                    classname = classname + " audit-status-notevaluted-active"
                    break;
                }
            }
        }
        else{
            classname = classname + " audit-status-inactive"
        }
        return classname;
    }

   
    getAuditStatusIcon(auditflag:AuditFlag){
        let iconElement :any ;
        switch(auditflag){
            case AuditFlag.Approved :{
                iconElement= CheckCircleOutlineIcon;
                break;
            }
            case AuditFlag.Rejected :{
                iconElement= CancelIcon;
                break;
            }
            default :{
                iconElement= PendingIcon;
                break;
            }
        }
        return iconElement;
    }

    getIconJSXElement(auditflag :AuditFlag) :JSX.Element{
        let IconElement = this.getAuditStatusIcon(auditflag);
        return <IconElement className={this.getClassname(auditflag,false)} onClick={(e:any)=>{ this.optionClick(e,auditflag)}}  />
    }

    getButtonAuditStatusJSXElement() : JSX.Element{
        let IconElement = this.getAuditStatusIcon(this.state.auditFlag);
        return <IconElement 
        className={this.getClassname(this.state.auditFlag,true)}
        onClick= {(e:any)=>{this.handleButtonClick(e)}}
         />
    }

    async handleButtonClick(event:any){
        event.preventDefault();
        await this.props.onOptionClick(event,{
            auditFlag: AuditStatusService.getAuditStatusValue(this.state.auditFlag),
            comment : this.state.comment
        },this.props.keyData);
    }

    renderComment(){
        let commentclass :string;
        let readonly : boolean =false;
        let buttondiv :any;
        if(! this.props.option || ! this.props.option.showcomment){
            return(<></>);
        }

        commentclass="col-md-9 p-0 small";
        buttondiv=( 
                <div key={`keydivauditstatusrow2col2`} 
                className="col-md-3 p-1 buttondiv">
                    {this.getButtonAuditStatusJSXElement()}
                </div>)

        return(
            <div key={`keydivauditstatusrow2`} className='row no-gutters'>
                <div key={`keydivauditstatusrow2col1`} className={commentclass}>
                        <Form.Control type='text'
                            key="auditstatustext"
                            placeholder='Comment'
                            value={this.state.comment}
                            onChange={(e:any)=>{this.setState({comment:e.target.value})}}
                            >
                        </Form.Control>
                </div>
                {buttondiv}
            </div>
        )
    }

    renderOptions(){
        return(
            <div key={`keydivauditstatusrow1`} className='row no-gutters p-0'>
                <ButtonGroup aria-label="Status">
                    <div key={`keydivauditstatusrow1col1`} className='col-md-4 text-left'>
                            {this.getIconJSXElement(AuditFlag.Approved)}
                    </div>
                    <div key={`keydivauditstatusrow1col2`} className='col-md-4 text-left'>
                            {this.getIconJSXElement(AuditFlag.Rejected)}
                    </div>
                    <div key={`keydivauditstatusrow1col3`} className='col-md-4 text-right'>
                            {this.getIconJSXElement(AuditFlag.NotYetEvaluate)}
                    </div>
                </ButtonGroup>  
            </div>
        )
    }
    
    render() {
    let isdisabled :boolean =this.props.option && this.props.option.readonly ? this.props.option.readonly : false ;
    return (
            <div 
            key={`keydivauditstatusparent`} 
            className={`containerdiv container ${isdisabled ? 'containerdiv-is-disabled' : ''}`}
            aria-disabled = {isdisabled}
            >
                {this.renderOptions()}
                {this.renderComment()}
            </div>
        )
  }
}

export default AuditStatus