import { FrameworkComponentProps } from "../../../Base/FrameworkComponent";

export type ComplianceDetail = {
    principalid :number 
    complianceid : string,
    files : any[]
}

export interface ComplianceDataUserView {
    view : 'Auditor' | 'User';
}

export interface ComplianceDataProps extends ComplianceDataUserView, FrameworkComponentProps {}