import React, { Component } from 'react'
import FrameworkComponent , {FrameworkComponentProps} from '../../Base/FrameworkComponent';

export interface ComplianceDetail {
    principalid :number 
    complianceid : string,
    files : any[]
}

export interface ComplianceState {
    principals : any [],
    backupprincipals : any [],
    complianceDetail : ComplianceDetail,
    searchText : string ,
    lastsearchText :string,
    searched :boolean,
    showSpinner : boolean,
    selectedPrincipal: any,
    selectedCompliances: any,
    showModal :boolean
}

export interface  ComplianceProps extends FrameworkComponentProps {

}


export abstract class BaseComplianceComponent<P extends ComplianceProps , 
                                    S extends ComplianceState ,
                                    SS={}> extends FrameworkComponent<P,S,SS> {
  constructor(props:P){
      super(props);
      this.setState({
        complianceDetail :{
            principalid :0,
            complianceid : "",
            files : [],
        },
        principals :[],
        showSpinner : false,
        searchText : "",
        lastsearchText : "",
        backupprincipals : [],
        searched : false,
        selectedPrincipal: null,
        selectedCompliances: null,
        showModal: false
      });
  }

  render() {
    return (
      <div>BaseComplianceComponent</div>
    )
  }
}

export default BaseComplianceComponent