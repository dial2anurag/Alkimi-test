import React, { Component } from 'react';
import { AccessType } from '../../../Model/SysModal/sysEntiry';
import FrameworkComponent,{FrameworkComponentProps}  from '../../Base/FrameworkComponent'
import AuditStatus , {AuditStatusData , AuditStatusOption, KeyData} from '../AuditStatus/AuditStatus';
import {ComplianceDataProps} from './Entity/ComplianceDataEntity';


export interface BaseComplianceSubComponentProps extends ComplianceDataProps{
    onOptionClick :(auditData : AuditStatusData) => boolean
}


export abstract class BaseComplianceSubComponent<P extends BaseComplianceSubComponentProps , 
                                                S={} , SS={}> 
    extends FrameworkComponent<P,S,SS> {
    abstract handleAuditStatusOptionClick(event :any, auditData : AuditStatusData , keyData : KeyData) : Promise<boolean>;     
    abstract renderAuditStatusElement() : JSX.Element;
    abstract override render(): React.ReactNode;
}

export default BaseComplianceSubComponent