import React, { Component } from 'react';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import OrgFrameworkComponent , 
        {OrgFrameworkComponentProps,
        OrgFrameworkComponentState} from '../Base/OrgFrameworkComponent';
import ComplianceData, {ComplianceDataUserView} from './ComplianceData';

export interface OrgAuditCompliancesProps 
    extends ComplianceDataUserView, OrgFrameworkComponentProps {}
        
export class OrgAuditCompliances extends OrgFrameworkComponent<OrgAuditCompliancesProps,OrgFrameworkComponentState> {
    constructor(props:any){
        super(props);
    }

    override renderComponent(framework : FrameworkEntity): JSX.Element {
        if(!framework){
            return <></>;
        }
        return(<ComplianceData framework={framework} pageid={this.props.pageid} view={this.props.view} />)
    }
}

export default OrgAuditCompliances