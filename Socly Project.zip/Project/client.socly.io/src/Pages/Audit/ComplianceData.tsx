import React, { Component } from 'react' ;
import RestartAltOutlinedIcon from '@mui/icons-material/RestartAltOutlined';
import SearchSharpIcon from '@mui/icons-material/SearchSharp';
import TreeView from '@mui/lab/TreeView';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import TreeItem from "@mui/lab/TreeItem";
import GppGoodIcon from '@mui/icons-material/GppGood';
import PlaylistAddCheckIcon from '@mui/icons-material/PlaylistAddCheck';
import {AccessType} from '../../Model/SysModal/sysEntiry' ;
import AuditStatus, { AuditStatusData, KeyData } from './AuditStatus/AuditStatus';
import PrincipalService from '../../services/Audit/PrincipalService';
import ComplianceService from '../../services/Audit/ComplianceService';
import FileService from '../../services/Audit/FileService';
import AuditStatusService , {AuditFlag} from '../../services/Audit/AuditStatusService';
import { Button, Modal } from 'react-bootstrap';
import SpinnersComponent from '../../Components/SpinnersComponent'
import UploadEvidence from './UploadEvidence/UploadEvidence';

import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import ImageIcon from '@mui/icons-material/Image';
import FolderZipIcon from '@mui/icons-material/FolderZip';
import FrameworkComponent , {FrameworkComponentProps} from '../Base/FrameworkComponent';
import ComplianceEvidenceView from './ComplianceEvidenceView';
import ListAltIcon from '@mui/icons-material/ListAlt';
import AccountTreeIcon from '@mui/icons-material/AccountTree';


interface ComplianceComponentState {
    principals : any [],
    backupprincipals : any [],
    searchText : string ,
    lastsearchText :string,
    searched :boolean,
    showSpinner : boolean,
    selectedPrincipal : any | null,
    selectedCompliances : any | null,
    showModal :boolean,
    complianceEvidence : boolean
}

export interface ComplianceDataUserView {
    view : 'Auditor' | 'User';
}

export interface ComplianceDataProps extends FrameworkComponentProps , ComplianceDataUserView {}

export class ComplianceData extends FrameworkComponent<ComplianceDataProps, ComplianceComponentState> {
    constructor(props : ComplianceDataProps) {
        super(props);
        this.state = {
            complianceEvidence : false,
            principals :[],
            showSpinner : false,
            searchText : "",
            lastsearchText : "",
            backupprincipals : [],
            searched : false,
            showModal: false,
            selectedPrincipal : null,
            selectedCompliances : null
        }
        this.handleChange =this.handleChange.bind(this);
        this.downloadFile = this.downloadFile.bind(this);
        this.getComplianceFiles = this.getComplianceFiles.bind(this);
    }

    async componentDidMount(){
        this.setState({showSpinner : true});
        let response = await PrincipalService.GetPrincipals(this.props.framework);
        if(response.status === 200) {
            let principals = response.data; //Array.prototype.filter.call(response.data,principal =>  principal.flag.toUpperCase() !== "ISO");
            let responsePromiseArray :Promise<void> []=[];
            Array.prototype.forEach.call(principals, async (principal, index) => {
                responsePromiseArray.push(this.getPrincipalCompliances(principal))
            })
            await Promise.allSettled(responsePromiseArray);
            this.setState({
                    principals :  principals , 
                    backupprincipals : principals,
                    showSpinner : false
                });
        }
    }

    async getPrincipalCompliances(principal :any) : Promise<void> {
        let response =await ComplianceService.GetCompliancesForPrincipal(principal.id);
        if(response.status ===200){
            principal["compliances"]=response.data;
        }
    }

    setStateCleanonSearch() :void {
        //this.setState({complianceDetail : {principalid :0 , complianceid : "" , files : []}});    
    }

    async handlePrincipalOptionClick(event :any, auditData : AuditStatusData , keyData : KeyData) : Promise<boolean>{
        let showspinner :boolean =!this.state.showSpinner;
        let principal = this.state.backupprincipals.find(p=> p === keyData.principal);
        if(! principal){
            return false;
        }
        let backupprincipal = this.state.backupprincipals.find(p=> p.id === keyData.principal.id);
        if(! backupprincipal){
            return false;
        }
        else if(principal.principleApproval &&  principal.principleApproval["status"] && 
        principal.principleApproval["status"].toString().toUpperCase() === auditData.auditFlag.toUpperCase()){
                return true;
        }
        if(showspinner) this.setState({showSpinner :true})

        let data : any ={
            principleId : keyData.principal.id,
            status: auditData.auditFlag,
            framework :this.props.framework,
            auditNote : auditData.comment ? auditData.comment : ""
        }

        let response = await PrincipalService.SaveAuditPrincipal(data);
        if(response.status === 200 ){
            principal["principleApproval"] = response.data;
            backupprincipal["principleApproval"] = response.data;
            if(showspinner) this.setState({showSpinner :false})
            return true;
        }
        else{
            if(showspinner) this.setState({showSpinner :false})
            return false;
        }
    }

    async handlecomplianceOptionClick(event :any, auditData : AuditStatusData , keyData : KeyData) : Promise<boolean>{
        let showspinner :boolean = !this.state.showSpinner;
        if(! keyData.compliance){
            return false;
        }
        let backupprincipal = this.state.backupprincipals.find(p=> p.id === keyData.principal.id);
        if(! backupprincipal){
            return false;
        }
        let principal = this.state.principals.find(p=> p === keyData.principal);
        if(! principal){
            return false;
        }
        let compliance = Array.prototype.find.call(principal.compliances , c=> c === keyData.compliance);
        if(! compliance){
            return false;
        }
        else if(compliance["auditStatus"] && 
            compliance["auditStatus"].toString().toUpperCase() === auditData.auditFlag.toUpperCase() &&
            compliance["auditNote"] &&  compliance["auditNote"].toString() === auditData.comment){
                return true;
        }
        if(showspinner)  this.setState({showSpinner :true})
        let data : any ={
            principleId : keyData.principal.id,
            complianceId : keyData.compliance.complianceId ,
            auditStatus: auditData.auditFlag,
            framework :this.props.framework,
            auditNote : auditData.comment ? auditData.comment : ""
        }
        if(await ComplianceService.SaveAuditCompliance(data) === 200){
            compliance["auditStatus"] = auditData.auditFlag;
            compliance["auditNote"] =  auditData.comment;
            let backupcompliance = Array.prototype.find.call(backupprincipal.compliances,e=> e.complianceId ===compliance.complianceId);
            if(backupcompliance){
                backupcompliance["auditStatus"] = auditData.auditFlag
                backupcompliance["auditNote"] =  auditData.comment;
            }
            let lst = Array.prototype.filter.call(backupprincipal.compliances,c=> (c.auditStatus && c.auditStatus === auditData.auditFlag))

            if(principal.compliances.length === lst.length && 
                principal["principleApproval"] && principal["principleApproval"]["status"] &&
                principal["principleApproval"]["status"] !== auditData.auditFlag){
                    this.handlePrincipalOptionClick(event,auditData,keyData);
            }
            else if(lst.length < principal.compliances.length && 
                principal["principleApproval"] && principal["principleApproval"]["status"] &&
                principal["principleApproval"]["status"] !== AuditStatusService.getAuditStatusValue(AuditFlag.NotYetEvaluate)){
                    this.handlePrincipalOptionClick(event,
                        {auditFlag: AuditStatusService.getAuditStatusValue(AuditFlag.NotYetEvaluate)},
                        keyData);
            }
            if(showspinner) this.setState({showSpinner :false})
            return true;
        }
        else{
            if(showspinner) this.setState({showSpinner :false})
            return false;
        }
    }

    async handleFileOptionClick(event :any, auditData : AuditStatusData , keyData : KeyData) : Promise<boolean>{
        if(! keyData.file){
            return false;
        }
        let principal = this.state.principals.find(p=> p === keyData.principal);
        if(! principal){
            return false;
        }
        let compliance = Array.prototype.find.call(principal.compliances , c=> c === keyData.compliance);
        if(!compliance){
            return false;
        }
        // if(this.state.complianceDetail.principalid !== keyData.principal.id || this.state.complianceDetail.complianceid.toUpperCase() !== keyData.compliance.complianceId.toUpperCase()){
        //     return false;
        // }

        //let file = this.state.complianceDetail.files.find(f=> f === keyData.file);
        let file = Array.prototype.find.call(compliance.fileListResponses,(f=> f===keyData.file));
        if(!file){
            return false ;
        }
        else if(file["fileApproval"] && file["fileApproval"]["status"] && file["fileApproval"]["status"].toUpperCase() === auditData.auditFlag.toUpperCase()){
            return true;
        }
        this.setState({showSpinner :true})

        let data : any ={
            principleId : keyData.principal.id,
            complianceId : keyData.compliance.complianceId ,
            fileName : keyData.file!.fileName ,
            auditStatus: auditData.auditFlag,
            framework :this.props.framework,
            auditNote : auditData.comment ? auditData.comment : ""
        }
        if(await  FileService.SaveAuditFile(data) === 200){
            if(!file["fileApproval"]) file["fileApproval"] ={};
            file["fileApproval"]["status"] = auditData.auditFlag;
            file["fileApproval"]["auditNote"] = auditData.comment;
            let lst= Array.prototype.filter.call(compliance.fileListResponses,(f=> f.auditStatus && f.auditStatus === auditData.auditFlag));
            if(compliance.fileListResponses.length === lst.length && 
                compliance["auditStatus"] !== auditData.auditFlag){
                    this.handlecomplianceOptionClick(event,auditData,keyData);
            }
            else if(lst.length < compliance.fileListResponses.length && 
                compliance["auditStatus"] !== AuditStatusService.getAuditStatusValue(AuditFlag.NotYetEvaluate)){
                    this.handlecomplianceOptionClick(event,
                        {auditFlag: AuditStatusService.getAuditStatusValue(AuditFlag.NotYetEvaluate)},
                        keyData);
            }
            this.setState({showSpinner :false})
            return true;
        }
        else{
            this.setState({showSpinner :false})
            return false;
        }
    }

    loadPrincipalAuditStatusElement(principal:any,index: number){
        if(this.PageComponent?.accessdata.accessType===AccessType.Read
            || this.PageComponent?.accessdata.accessType===AccessType.CustomAccess 
            && this.PageComponent?.accessdata.customAccess?.access["principal"] ===AccessType.Read
            || this.props.view === "User"){
            return (<></>)
        }
        return(<div 
                key={`principal(${principal.id})AuditDiv-${index}`} >
                <AuditStatus 
                    key={`principal(${principal.id})AuditStatus-${index}`}
                    auditData  ={{
                        auditFlag :(principal.principleApproval && principal.principleApproval.status ?  principal.principleApproval.status : "N")
                        ,comment : (principal.auditNote ? principal.auditNote : undefined)
                    }}
                    keyData = {{ principal : principal }}
                    onOptionClick={this.handlePrincipalOptionClick.bind(this)}
                />
            </div>)
    }

    loadComplianceAuditStatusElement(principal : any ,compliance : any){
        if(this.PageComponent?.accessdata.accessType===AccessType.Read
            || this.PageComponent?.accessdata.accessType===AccessType.CustomAccess 
            && this.PageComponent?.accessdata.customAccess?.access["compliance"] ===AccessType.Read
            || this.props.view === "User"){
            return (<></>)
        }
        if(! principal ||  ! compliance){
            return(<></>)
        }
        return(<div 
                key={`${principal.id}-complience(${compliance.complianceId})AuditDiv`} >
                <AuditStatus 
                    key={`${principal.id}-complience(${compliance.complianceId})AuditStatus`}
                    keyData = {{ principal : principal , compliance: compliance }}
                    auditData  ={{
                        auditFlag :(compliance.auditStatus ? compliance.auditStatus : "N")
                        ,comment : (compliance.auditNote ? compliance.auditNote : undefined)
                    }}
                    option={{showcomment : true }}
                    onOptionClick={this.handlecomplianceOptionClick.bind(this)}
                />
            </div>)
    }

    loadFileAuditStatusElement(principal : any ,compliance : any , file :any , index : number){
        if(this.PageComponent?.accessdata.accessType===AccessType.Read
            || this.PageComponent?.accessdata.accessType===AccessType.CustomAccess 
            && this.PageComponent?.accessdata.customAccess?.access["file"] ===AccessType.Read
            || this.props.view === "User" ){
                return (<></>);
        }
        
        return(<div 
                    key={`${principal.id}-complience(${compliance.complianceId})-file-AuditDiv-${index}`} 
                    className="col">
                <AuditStatus 
                    key={`${principal.id}-complience(${compliance.complianceId})-file-AuditStatus-${index}`}
                    keyData = {{principal : principal , compliance: compliance , file : file }}
                    auditData  ={{
                        auditFlag :(file.fileApproval && file.fileApproval.status ? file.fileApproval.status : "N")
                        ,comment : (file.fileApproval && file.fileApproval.auditNote ? file.fileApproval.auditNote : undefined)
                    }}
                    onOptionClick={this.handleFileOptionClick.bind(this)}
                />
            </div>)
    }

    showFileIcon(principal : any, compliance : any, file: any , index: number){
        let filedata = file.fileName.toUpperCase().split(".");
        switch(filedata[filedata.length -1]){
            case "PDF":{
                return(<PictureAsPdfIcon  style={{color : "red" , fontSize : "2.5rem" , borderColor:"grey"}} 
                    key={`${principal.id}-${compliance.complianceId}-img${file.fileName}[${index}]`} />)    
                break;
            }
            case "ZIP":{
                return(<FolderZipIcon style={{color : "red" , fontSize : "2.5rem" , borderColor:"grey"}} 
                key={`${principal.id}-${compliance.complianceId}-img${file.fileName}[${index}]`} />)    
                break;
            }
            default :{
                return(<ImageIcon style={{color : "red" , fontSize : "2.5rem" , borderColor:"grey"}} 
                key={`${principal.id}-${compliance.complianceId}-img${file.fileName}[${index}]`} />)    
                break;
            }
        }
    }

    handleChange(event : any){
        this.setState({searchText :event.target.value})
    }

   async onSearchButtonClick(event:any) {
    event.preventDefault();
        if(this.state.searched && (this.state.searchText.trim().length <=0 || this.state.searchText.trim().toUpperCase() === this.state.lastsearchText.trim().toUpperCase())){
            this.setState({ 
                principals : this.state.backupprincipals,
                searchText : "",
                lastsearchText : "",
                searched : false
            });
            this.setStateCleanonSearch();
        }
        else {
            let searchText =this.state.searchText.toUpperCase();
            let principaldata : any[] =[] ;
            let compliancesdata : any[] =[] ;

            let principalsList = JSON.parse(JSON.stringify(this.state.backupprincipals));
            Array.prototype.forEach.call(principalsList, (principal, index) => {
                compliancesdata =  Array.prototype.filter.call(principal.compliances, (y => y.complianceId.toUpperCase() === searchText || y.controlName.toUpperCase().indexOf(searchText) > -1))
                if(compliancesdata && compliancesdata.length > 0) {
                    principal.compliances = compliancesdata;
                    principaldata.push(principal);
                }
            });            
            this.setState({
                principals : principaldata,
                searchText : "",
                lastsearchText : searchText,
                searched : true
            });
            this.setStateCleanonSearch();
        }
    }

    showSearchButtonImage() {
        if(this.state.searched)
        {
            return(<RestartAltOutlinedIcon key={"SearchDivButtonIcon1"} fontSize='small' />)
        }
        else{
            return(<SearchSharpIcon key={"SearchDivButtonIcon2"} fontSize='small' />);
        }
    }

    principleDataShow = (principleData: any) => {
        this.setState({selectedPrincipal : principleData});
        this.setState({selectedCompliances : null});
    }

    complDataShow = (complianceData: any, principleData: any) => {
        this.setState({selectedCompliances : complianceData , selectedPrincipal : principleData});
        this.getComplianceFiles(complianceData, principleData);
    }

    async handleClose(){
        this.setState({showModal: false});
    }

    uploadEvidence = () => {
        this.setState({showModal: true});
    }

    async getComplianceFiles(compliance : any, principal :any){
        
       let fileResponse = await FileService.GetComplianceFiles(compliance.complianceId.toUpperCase(),principal.id);
       if(fileResponse.status===200){
        compliance["fileListResponses"] =fileResponse.data;
       }
       else{
        compliance["fileListResponses"] =[];
       }
       this.setState({showSpinner : false});
    }

    async downloadFile(event : any, file : any){
        event.preventDefault();
        FileService.DownloadEvidanceFile(this.props.framework,file.fileName)
        .then((response) => {
            if(response.status ===200){
                let url = window.URL.createObjectURL(new Blob([response.data]));
                let link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', file.fileName); //or any other extension
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }else{
                alert("Failed to download . Please try again !!");
            }
        });
    }

    getFileName(file : any){
        let valArray=file.fileName.split("_");
        if(valArray.length >= 4 && valArray[3] !=="M"){
            return valArray[2];
        }
        else {
            return file.fileName;
        }
    }

    setPrincipalTreeViewNodeStyle(principle :any) : React.CSSProperties {
        let auditStatus = principle.principleApproval && principle.principleApproval.status ? principle.principleApproval.status : "N" ;
        return this.setTreeViewNodeStyle(auditStatus);
    }

    setTreeViewNodeStyle(auditStatus: string): React.CSSProperties{
        let style : React.CSSProperties={};
        if(this.props.view === "Auditor"){
            switch (AuditStatusService.getAuditFlag(auditStatus)){
                case AuditFlag.Approved :{
                    style.color = "green";
                    break;
                }
                case AuditFlag.Rejected :{
                    style.color = "red";
                    break;
                }
                default :{
                    break;
                }
            }
        }
        return style;
    }
    renderTree(){
        return(
            <TreeView
                id={'TreeViewPrincipal'}
                key={'TreeViewPrincipal'}
                defaultCollapseIcon={<ExpandMoreIcon />}
                defaultExpandIcon={<ChevronRightIcon />}
                sx={{ textAlign: "left", height: "calc(100vh - 202px)", overflowY: "auto"}}>
                    {this.renderPrincipalNode()}
                </TreeView>
        )
    }

    renderPrincipalNode() {
        return (<>{
            this.state.principals.map((principal,index)=>{
                return(
                        <TreeItem
                            id={`Principal(${principal.id})`}
                            nodeId={`Principal(${principal.id})`} 
                            key={`Principal(${principal.id})`} 
                            label={<div><GppGoodIcon /> {principal.title}</div>}
                            style={this.setPrincipalTreeViewNodeStyle(principal)}
                            onClick={()=>this.principleDataShow(principal)}>
                            {this.renderComplianceNode(principal,index)}
                        </TreeItem>)
            })
        }</>)
    }

    renderComplianceNode(principal : any,principalindex :number){
        return(<>
        {
            Array.prototype.map.call(principal.compliances, (compliance, indx) => 
            {
                return(
                    <TreeItem 
                        id={`Principal(${principal.id})-Compliance(${compliance.complianceId})`}
                        nodeId={`Principal(${principal.id})-Compliance(${compliance.complianceId})`}
                        key={`Principal(${principal.id})-Compliance(${compliance.complianceId})`}
                        label={<div><PlaylistAddCheckIcon /> {`${compliance.complianceId.toUpperCase()}(${compliance.fileListResponses ? compliance.fileListResponses.length : 0 })`}</div>}
                        style={this.setTreeViewNodeStyle(compliance.auditStatus)}
                        onClick={()=>this.complDataShow(compliance, principal)}>
                    </TreeItem>
                )
            })
        }
        </>)
    }

    renderFileDiv() {
        let component : any=<></>
        if(this.state.selectedPrincipal && this.state.selectedCompliances && 
            this.state.selectedCompliances.fileListResponses && this.state.selectedCompliances.fileListResponses.length >0){
            component =(<div key="renderFileDiv" className="row mt-4 ms-md-3">
            {
                Array.prototype.map.call(this.state.selectedCompliances.fileListResponses,((file , indx)=>{
                    return(
                        <div key={`renderFileDiv-div1-${indx}`} className="col-4 col-md-2 mb-4">
                            <div key={`renderFileDiv-div2-${indx}`} className="show-file-icon">
                                <a 
                                href='#'
                                key={`a1getfile[${file.principleId}-${file.complianceId}][${indx}]`}
                                onClick={(e)=>{this.downloadFile(e,file)}} >
                                    {this.showFileIcon(this.state.selectedPrincipal,this.state.selectedCompliances,file,indx)}
                                    <div key={`renderFileDiv-div3-${indx}`} className="compliance-file-filename">
                                        {this.getFileName(file)}
                                    </div>
                                </a>
                            </div>
                            <div key={`renderFileDiv-div4-${indx}`} className="file-elements">
                                { this.loadFileAuditStatusElement(this.state.selectedPrincipal,this.state.selectedCompliances,file,indx)}
                            </div>
                        </div>
                    )
                }))}             
        </div>)
        }
        return component;
    }

    renderLeftSection(){
        return(
            <div className="col-md-4 border border-1 border-start-0 border-top-0 border-bottom-0 pe-4 py-4">
                <form onSubmit ={this.onSearchButtonClick.bind(this)}>
                    <div className="input-group mb-4">
                        <input type="text"
                            className="form-control" 
                            placeholder="Search" 
                            value={this.state.searchText}
                            onChange={this.handleChange.bind(this)} />
                        <button className="btn btn-primary" type="submit">{this.showSearchButtonImage()}</button>
                    </div>
                </form>
                {this.renderTree()}
            </div>
        )
    }

    renderSelectedPrincipal(){
        if(! this.state.selectedPrincipal){
            return(<></>);
        }
        else{
            return(<>
                <div key="selectedPrincipaldiv1"
                    className="principle-data px-3 mt-3">
                    <p key="selectedPrincipalP" 
                        className='mb-2 text-start'>
                            <b> {this.state.selectedPrincipal.flag} : </b> 
                            {this.state.selectedPrincipal.principle}
                            {/* {this.loadPrincipalAuditStatusElement ? this.loadPrincipalAuditStatusElement(principal,indx) : <></>}  */}
                    </p>
                </div>
            </>)
        }
    }

    renderSelectedCompliance(){
        if(! this.state.selectedCompliances){
            return (<></>)
        }
        else{
            return(
                    <p key="selectedcomplianceP" className='px-3 text-start'>
                        <b> {this.state.selectedCompliances.complianceId.toUpperCase()} : {this.state.selectedCompliances.controlName}</b> 
                            <br />
                        {this.state.selectedCompliances.description}
                    </p>
                    )
        }
    }

    renderUploadecidence(){
        if(!this.state.selectedCompliances){
            return(<></>);
        }
        return(
            <div className="text-end">
                <button className="btn btn-primary px-5" type="submit" 
                    onClick={this.uploadEvidence}>Upload</button>
            </div>
        )
    }

    renderRightSection(){
        return(
            <div key="complianceViewRightSection" 
                className="col-md-8">
                    <div key="rightTopSection" className='right-top-section'>
                        {this.renderRightTopSection()}
                    </div>
                    <div key="rightBottomSection" className='right-bottom-section'>
                        {this.renderRightBottomSection()}
                    </div>
            </div>
        )
    }

    renderTopRightBottomSection(rightside :boolean){
        let divsection : JSX.Element;
        let sectiontorender :JSX.Element;
        if(rightside){
            if(this.props.view === "User"){
                sectiontorender= this.renderUploadecidence();
            }
            else{
                sectiontorender= this.loadComplianceAuditStatusElement(this.state.selectedPrincipal,this.state.selectedCompliances)
            }
            divsection=<div key="renderRightTopSectioncontainerrow3col1" className='col-md-3 text-end'>{sectiontorender}</div>
        }
        else{
            let commentexists = this.state.selectedCompliances && this.state.selectedCompliances.comment ? true :false;
            if(commentexists){
                sectiontorender = <><b>Comment :</b> {this.state.selectedCompliances.comment} </>
            }
            else{
                sectiontorender =<></>
            }
            divsection =<div key="renderRightTopSectioncontainerrow3col2" className='col-md-9 text-start'>
                {sectiontorender}
            </div>
        }
        return divsection;
    }

    renderRightTopSection(){
        return(
        <div key="renderRightTopSectioncontainer" className='container'>
            <div key="renderRightTopSectioncontainerrow1" className='row flex-row'>
                <div key="renderRightTopSectioncontainerrow1col1" className='col'>
                    {this.renderSelectedPrincipal()}
                </div>
            </div>
            <div key="renderRightTopSectioncontainerrow2" className='row flex-row'>
                <div key="renderRightTopSectioncontainerrow2col1" className='col'>
                    {this.renderSelectedCompliance()}
                </div>
            </div>
            <div key="renderRightTopSectioncontainerrow3" className='row flex-row-reverse'>
                {this.renderTopRightBottomSection(true)}
                {this.renderTopRightBottomSection(false)}
            </div>
        </div>
        )
    }

    renderRightBottomSection(){
        return this.renderFileDiv()
    }

    renderModal(){
        if(this.state.showModal && this.state.selectedPrincipal &&  this.state.selectedCompliances){
            return(
                    <Modal show={this.state.showModal} onHide={this.handleClose.bind(this)}
                        size="lg"
                        aria-labelledby="contained-modal-title-vcenter"  centered>
                            <Modal.Body className='p-0 m-0 text-center'>
                                <SpinnersComponent key="compliancedatamodalspinnercomponent" showspinner = {this.state.showSpinner} />
                                <div>
                                    <UploadEvidence 
                                    framework={this.props.framework }
                                    pageid = {this.props.pageid}
                                    complianceData={{compliance : this.state.selectedCompliances ,principal : this.state.selectedPrincipal}}
                                    handleOnSave={this.getComplianceFiles.bind(this)} 
                                    handleModalClose={this.handleClose.bind(this)} />
                                </div>
                            </Modal.Body>
                    </Modal>
                )
            }
            else{
                return (<></>);
            }
    }

    getToggleIconsStyle(type : "Tree" | "List") : React.CSSProperties{
        let style : React.CSSProperties ={fontSize : "large" , color : "grey"};
        switch(type){
            case "Tree":{
                if(!this.state.complianceEvidence){
                    style ={fontSize : "xx-large" , color : "blue"}
                }
                break;
            }
            case "List":{
                if(this.state.complianceEvidence){
                    style ={fontSize : "xx-large" , color : "blue"}
                }
                break;
            }
        }
        return style;
    }

    renderToggleIcons(){
        return(
            <div key="subcomponentdiv1" className="position-relative">
                <div key="subcomponentdiv1div1" className='position-absolute' style={this.state.complianceEvidence ? {top: "-90px", right: "0px"} : {top: "-60px", right: "0px"}}>
                    <h5 className='text-primary'>Toggle View</h5>
                    <div key="subcomponentdiv1div1row1" className='d-flex justify-content-center'>
                        <div key="subcomponentdiv1div1row1col1" className='me-2'>
                            <a key="subcomponentdiv1div1row1col1anchor1" 
                            href='#'
                            onClick={(e)=> this.setState({complianceEvidence : false})}
                            >
                            <AccountTreeIcon style={this.getToggleIconsStyle("Tree")} /></a>
                        </div>
                        <div key="subcomponentdiv1div1row1col2">
                            <a key="subcomponentdiv1div1row1col1anchor2" 
                            href='#'
                            onClick={(e)=> this.setState({complianceEvidence : true})}
                            >
                            <ListAltIcon style={this.getToggleIconsStyle("List")} /></a>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    renderComplianceEvidenceView(){
        return(<ComplianceEvidenceView
            key="ComplianceEvidenceView"
            framework={this.props.framework} 
            pageid ={this.props.pageid} 
            principals ={this.state.principals} />);
    }

    renderTreeView(){
        return (
            <div key="subcomponentdiv2" className="container-fluid">
                    <div key="subcomponentdiv2row1" className='row flex-row g-0'>
                        {this.renderLeftSection()}
                        {this.renderRightSection()}
                        {this.renderModal()}
                    </div>
            </div>
        )
    }

    render() {
        let component : any;
        if(this.state.complianceEvidence){
            component=this.renderComplianceEvidenceView();
        }
        else{
            component= this.renderTreeView();
        }
        let togglecomponent : any = <></>;
        if(this.props.view === "User"){
            togglecomponent =this.renderToggleIcons();
        }
        return (
            <div key="maincomponentdiv" className="tree-view mx-2">
                <SpinnersComponent key="compliancedataspinnercomponent" showspinner ={this.state.showSpinner}  />
                {togglecomponent}
                {component}
            </div>
        )
    }
}
export default ComplianceData