import React from 'react' ;
import '../../Styles/nav.css' ;
import { Link } from 'react-router-dom' ;
import {
    Navbar , 
    Nav
} from 'react-bootstrap';
import AuthService from '../../services/Users/auth.service'
import { IRolePageComponent, SectionComponent } from '../../Model/SysModal/sysEntiry';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';

export class NavItems extends AuthenticatedBaseComponent{
    private roleAccess : IRolePageComponent[];
    private refList : React.RefObject<HTMLAnchorElement>[];
    constructor(props: any) {
        super(props)
        this.roleAccess =[];
        this.refList = [];
        this.loadNavItems();
    }

    loadNavItems(){
        let roledata = AuthService.getUserAuthMenu();
        if(roledata){
            this.roleAccess =roledata.filter(e=> e.section === SectionComponent.NavBar);
            this.roleAccess.forEach((e ,index)=>{
                this.refList.push(React.createRef());
            })
        }
        else{
            this.roleAccess =[];
        }
    }

    setNavStatus(){
        let path :string= window.location.pathname.toLowerCase();
        this.roleAccess.forEach((item,index)=>{
            if(item.path?.toLowerCase() === path && this.refList[index] && this.refList[index].current){
                this.refList[index].current!.className="nav-links nav-link-active";
            }
            else if(this.refList[index] && this.refList[index].current){
                this.refList[index].current!.className="nav-links nav-link-normal";
            }
        })
    }

    getLinkClass(path : string) : string{
        let result : string ="";
        if(path.toLowerCase() === window.location.pathname.toLowerCase()){
            result="nav-links nav-link-active"
        }
        else{
            result="nav-links nav-link-normal"
        }
        return result;
    }

    getLinkStyle(ref : React.RefObject<HTMLAnchorElement>){
        this.refList.forEach((e,index)=>{
            if(e === ref){
                if(ref && ref.current){
                    ref.current.className ="nav-links nav-link-active";
                }
            }
            else{
                if(e && e.current){
                    e.current.className ="nav-links nav-link-normal"
                }
            }
        })
    }

    componentDidMount(){
        this.setNavStatus();
    }
        
    render() {
        if(! this.roleAccess){
            return (<></>)
        }
        return (
            <>
                <Navbar.Toggle key="navtoggle1" aria-controls="responsive-navbar-nav" />
                <Navbar.Collapse key="navtoggle1colapse1" id="responsive-navbar-nav">
                    <Nav key="navtoggle1colapse1nav1" className="mr-auto">
                        {
                            this.roleAccess.map((navItem : IRolePageComponent , index : number)=>{
                                return(
                                     <Nav.Item key={`navitem-${index}`}>
                                         <Link className={this.getLinkClass(navItem.path ? navItem.path : "")}
                                            key={`navitemLink-${index}`}
                                            ref={this.refList[index]} 
                                            to={navItem.path ? navItem.path : ""}
                                            onClick = {()=> this.getLinkStyle(this.refList[index])}
                                        >
                                            {navItem.title}
                                        </Link>
                                    </Nav.Item>
                                )
                            })
                        }
                    </Nav>
                </Navbar.Collapse>
            </>
       )
    }
}

export default NavItems
