import styled from 'styled-components';

const SidebarWrapper = styled.div`
.logo-style {
    height: 70px;
    margin-top: 32px;
    margin-bottom: 10px;
}
.MuiDrawer-paperAnchorLeft {
    background: #F5F8FF !important;
    box-shadow: 0px 4px 36px rgba(203, 203, 203, 0.78) !important;
    border: 0px;
    z-index: 1050;
}
.Mui-selected {
    background-color: #F5F8FF !important;
}
.nav-list-item .MuiListItemText-primary {
    font-family: 'ProductSansRegular' !important;
    font-size: 16px !important;
    line-height: 29px;
    letter-spacing: 0px;
    color: #707070 !important; 
    filter: brightness(1);
}
.nav-list-item.active .MuiListItemText-primary {
    color: #00153D !important;
    font-family: 'ProductSansMedium' !important; 
}
.nav-list-item.active .nav-list-item-img {
    filter: brightness(0.1);
}
.nav-list-item .MuiListItemIcon-root {
    min-width: 40px !important;
}
@media only screen and (min-width: 1500px) {
    .nav-list-item .MuiListItemText-primary {
        font-size: 18px !important;
    }
}
@media only screen and (max-width: 575.98px) {
    .logo-style {
        height: 60px;
        margin-top: 10px;
        margin-bottom: 20px;
    }
    .MuiIconButton-sizeMedium {
        position: absolute;
        top: 32px;
    }
}
`;

export default SidebarWrapper;