import React, { Fragment } from 'react' ;
import AuthenticatedBaseComponent from '../../Base/AuthenticatedBaseComponent';
import { NavLink } from "react-router-dom";
import SidebarWrapper from './sidebar.style';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Logo from '../../../Assets/Images/logo.svg'
import {IRolePageComponent, ComponentType, SectionComponent, IconType} from '../../../Model/SysModal/sysEntiry';
import AuthService from '../../../services/Users/auth.service'
import Collapse from '@mui/material/Collapse';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import { IConComponents } from '../../../Data/SysData/IconComponent';
import { imageListClasses } from '@mui/material';

interface SidebarProps {
    handleDrawerToggle : (value : boolean) => void
    selectedItemClick : (value : string) => void
    sidebarWidth: number
    mobileOpen: boolean
    defaultPage: any
}

interface SidebarState {
    collapsibleList: {[key: number]: boolean},
}

export class Sidebar extends AuthenticatedBaseComponent<SidebarProps, SidebarState> {
    private roleAccess : IRolePageComponent[];
    private refList : React.RefObject<HTMLAnchorElement>[];
    constructor(props : SidebarProps){
        super(props);
        this.roleAccess =[];
        this.refList = [];
        this.loadNavItems();
        this.state = {
            collapsibleList: {}
        }
        this.handleInSection = this.handleInSection.bind(this);
        this.handleCollapsibleMenu = this.handleCollapsibleMenu.bind(this);
    }

    componentDidMount(): void {
        this.isActive = this.isActive.bind(this);
    }

    loadNavItems(){
        let roledata = AuthService.getUserAuthMenu();
        if(roledata){
            this.roleAccess =roledata.filter(e=> e.section === SectionComponent.NavBar);
            this.roleAccess.forEach((e ,index)=>{
                this.refList.push(React.createRef());
            })
        }
        else{
            this.roleAccess =[];
        }
    }

    isActive= (routeName: any) => {
        return window.location.pathname === '/' && this.props.defaultPage?.path === routeName ? " active" : "";
    }
    handleCollapsibleMenu(event: any, item: IRolePageComponent): void {
        event.preventDefault();
        if(item) {
            let collapsibleList = this.state.collapsibleList;
            collapsibleList[item.id] = !collapsibleList[item.id];
            this.setState({collapsibleList: collapsibleList});
        }
    }
    handleInSection(item: IRolePageComponent): boolean {
        let collapsibleList = this.state.collapsibleList;
        if(collapsibleList[item.id]) {
            return true;
        }
        return false;
    }
    renderIconImage(item: IRolePageComponent, indx: number) : JSX.Element {
        let returnValue : JSX.Element = <></>;
        
        if(item.icon){
            let IconComponent  : any;
            let iconProps : any={};
            let iconType = item.icon.iconType;
            if(item.icon.iconProps){
                iconProps = item.icon.iconProps;
            }
            iconProps["key"] = `navitemLinkImage-icon${item.id}-${indx}`;
            switch((iconType as IconType)){
                case IconType.ICONS : {
                    IconComponent= IConComponents[item.icon.iconIndex];
                    if(!iconProps["fontSize"]) iconProps["fontSize"] ='small';
                    returnValue = <IconComponent {...iconProps}/>
                    break;
                }
                case IconType.PIC : {
                    if(!iconProps["className"]) iconProps["className"] ="nav-list-item-img";
                    if(!iconProps["alt"]) iconProps["alt"]=item.title;
                    iconProps["src"]=IConComponents[item.icon.iconIndex];
                    returnValue =<img {...iconProps} />
                    break;
                }
            }
        }
        return returnValue;
    }
    renderNavItems(parentid?: number,indx ?:number) {
        if(!indx) indx =-1;
        let listItems = this.roleAccess.filter(item => item.parentid === parentid);
        if(!listItems || listItems.length < 1) {
            return "";
        } 
        listItems.sort((a, b) => (a.sequence > b.sequence) ? 1 : -1);
        let returnItem = listItems.map((navItem, index)=> {
            let childValue = this.renderNavItems(navItem.id,index);
            let childReturnValue = <></>;
            let parentReturnValue = <></>;
            let collapsibleList = this.state.collapsibleList;
            if(childValue) {
                if(collapsibleList[navItem.id] === undefined) {
                    collapsibleList[navItem.id]=false;
                }
                childReturnValue = (
                    <>
                        <Collapse 
                            key={`collapsiblenavitemLink-${navItem.id}-${indx}`} 
                            in={this.state.collapsibleList[navItem.id]} 
                            timeout="auto" 
                            unmountOnExit sx={{ pl: 4 }}>
                            <div 
                            key={`collapsiblenavitemLinkdiv-${navItem.id}-${indx}`}>
                                {childValue}
                            </div>
                        </Collapse>
                    </>
                )
                parentReturnValue = (
                    <ListItem 
                        key={`navitemLink-${navItem.id}-${indx}`} 
                        className={"nav-list-item"+(this.isActive(navItem.path))} 
                        onClick={(e: any) => this.handleCollapsibleMenu(e, navItem)}
                        >
                        <ListItemButton key={`navitemLinkButton-${navItem.id}-${indx}`}>
                            <ListItemIcon key={`navitemLinkIcon-${navItem.id}-${indx}`}>
                                {
                                    this.renderIconImage(navItem,indx!)
                                }
                            </ListItemIcon>
                            <ListItemText 
                            key={`navitemLinkText-${navItem.id}-${indx}`} 
                            primary={navItem.title} />
                                {this.state.collapsibleList[navItem.id] ? <ExpandLess /> : <ExpandMore />}
                        </ListItemButton>
                    </ListItem>
                );
            } else {
                parentReturnValue = (
                    <ListItem 
                        key={`navitemLink-${navItem.id}-${indx}`} 
                        component={NavLink} 
                        to={navItem.path ? navItem.path : ""} 
                        className={"nav-list-item"+(this.isActive(navItem.path))} 
                        onClick={()=>this.props.selectedItemClick(navItem.title)}
                        >
                        <ListItemButton key={`navitemLinkButton-${navItem.id}-${indx}`}>
                        <ListItemIcon key={`navitemLinkIcon-${navItem.id}-${indx}`}>
                            {
                                this.renderIconImage(navItem,indx!)
                            }
                        </ListItemIcon>
                        <ListItemText key={`navitemLinkText-${navItem.id}-${indx}`} primary={navItem.title} />
                        </ListItemButton>
                    </ListItem>
                );
            }
            return (
                <>
                    {parentReturnValue}
                    {childReturnValue}
                </>
            )
        });
        return returnItem;
    }

    render() {
        const {handleDrawerToggle, sidebarWidth, mobileOpen} = this.props;
        const drawer = (
            <div key="sidebarMenu">
            <img className='logo-style' src={Logo} alt="Logo" />
              <List key="sidebarList">
                    {
                        this.renderNavItems()
                    }
              </List>
            </div>
          );
        
        return (
            <SidebarWrapper key="sidebarWrapper">
                <Box
                    key="sidebarWrapper-box"
                    component="nav"
                    sx={{ width: { sm: sidebarWidth }, flexShrink: { sm: 0 } }}
                    aria-label="mailbox folders"
                >
                    {/* LEFT SIDEBAR SECTION MOBILE */}
                    <Drawer
                        key="sidebarData"
                        variant="temporary"
                        open={mobileOpen}
                        onClose={handleDrawerToggle.bind(this)}
                        ModalProps={{
                            keepMounted: true,
                        }}
                        sx={{
                            display: { xs: 'block', sm: 'none' },
                            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: sidebarWidth },
                        }}
                    >
                        {drawer}
                    </Drawer>
                    {/* LEFT SIDEBAR SECTION WEB */}
                    <Drawer
                        variant="permanent"
                        sx={{
                            display: { xs: 'none', sm: 'block' },
                            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: sidebarWidth },
                        }}
                        open={true}
                        >
                        {drawer}
                    </Drawer>
                </Box>
            </SidebarWrapper>
        )
    }
}

export default Sidebar
