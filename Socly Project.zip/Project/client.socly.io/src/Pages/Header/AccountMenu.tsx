import * as React from 'react';
import Box from '@mui/material/Box';
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom";
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import Divider from '@mui/material/Divider';
import PersonAdd from '@mui/icons-material/PersonAdd';
import VpnKeyIcon  from '@mui/icons-material/VpnKey';
import Settings from '@mui/icons-material/Settings';
import Logout from '@mui/icons-material/Logout';
import AuthService from '../../services/Users/auth.service';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { LinkStyleNormal, LinkStyleClicked } from '../../StyledComponents/ComponentWrapper';
import {ChangePassword} from '../Security/ChangePassword'
import {
  Nav,
  NavDropdown,
  Tooltip,
  OverlayTrigger
} from 'react-bootstrap';


export default function AccountMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [changePassword, setchangePassword] = React.useState(false);
  const PATH_NAME :string = window.location.pathname;

  const open = Boolean(anchorEl);
  const handleClick = (event:any) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
   const onLogout=() => {
    AuthService.logout();
    window.location.href = '/';
};

const getUserDetails= () =>{
  let user =AuthService.getCurrentUser();
  return(<div style={{top : 0 , marginTop : ".2rem" , color: "Highlight"}}>{user.name}</div>)
}

const onAfterChangePassword = (value : boolean)=>{
  setchangePassword(false);
};

const onChangePasswordClick= ()=>{
  setchangePassword(true);
};

const onChangePassword =()=>{
  if (changePassword){
    //setchangePassword(false);
    return(<><ChangePassword onAfterChangePassword={onAfterChangePassword} /></>)
  }
  else{
    return(<></>)
  }
};


const render= ()=>{
  return(
    <div>
      <React.Fragment>
          <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }}>
            <NavDropdown title={<div className="pull-left">
            <OverlayTrigger delay={{hide: 450 , show: 300}} 
                overlay={(props)=>{
                    return(<Tooltip {...props}>
                            {getUserDetails()}
                    </Tooltip>)
                }} placement='bottom'>
                    <AccountCircleIcon style ={{color: 'blue',height: '1.40em', width:'1.5em'}}   />
                </OverlayTrigger>
            </div>}>
              <NavDropdown.Item><PersonOutlineOutlinedIcon fontSize="small"  />Profile</NavDropdown.Item>
              <NavDropdown.Item><AccountCircleOutlinedIcon fontSize="small" />My Account</NavDropdown.Item>
              <Divider />
              <NavDropdown.Item><PersonAdd fontSize="small"  /><Link style={{ color: 'inherit', textDecoration: 'inherit'}} to = "/newuser" >Add another account </Link></NavDropdown.Item>
              <NavDropdown.Item onClick={()=> onChangePasswordClick()}><VpnKeyIcon fontSize="small" />Change Password</NavDropdown.Item>

              <NavDropdown.Item><Settings fontSize="small" />Settings</NavDropdown.Item>
              {/* <NavDropdown title="Registration">
                <NavDropdown.Item><PersonOutlineOutlinedIcon fontSize="small"  /><Link to="/orgreg" style={PATH_NAME === '/orgreg' ? LinkStyleClicked : LinkStyleNormal}>Org Registration</Link></NavDropdown.Item>
                <NavDropdown.Item><PersonOutlineOutlinedIcon fontSize="small"  /><Link to="/extuser" style={PATH_NAME === '/extuser' ? LinkStyleClicked : LinkStyleNormal}>User Registration</Link></NavDropdown.Item>
              </NavDropdown> */}
              <NavDropdown.Item onClick={onLogout}><Logout fontSize="small" />Logout</NavDropdown.Item>
          </NavDropdown>
          </Box>
          
      </React.Fragment>
    </div>
   
  );
    // return (
    //   <React.Fragment>
    //     <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }}>
    //     {getUserDetails()}
    //       <Tooltip title="Account settings">
    //         <IconButton onClick={handleClick} size="small" sx={{ ml: 2 }}>
    //         <AccountCircleIcon style ={{color: 'blue',height: '2em', width:'2em'}} />
    //         </IconButton>
    //       </Tooltip>
    //     </Box>
    //     <Menu
    //       anchorEl={anchorEl}
    //       open={open}
    //       onClose={handleClose}
    //       onClick={handleClose}
    //       PaperProps={{
    //         elevation: 0,
    //         sx: {
    //           overflow: 'visible',
    //           filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
    //           mt: 1.5,
    //           '& .MuiAvatar-root': {
    //             width: 32,
    //             height: 32,
    //             ml: -0.5,
    //             mr: 1,
    //           },
    //           '&:before': {
    //             content: '""',
    //             display: 'block',
    //             position: 'absolute',
    //             top: 0,
    //             right: 14,
    //             width: 10,
    //             height: 10,
    //             bgcolor: 'background.paper',
    //             transform: 'translateY(-50%) rotate(45deg)',
    //             zIndex: 0,
    //           },
    //         },
    //       }}
    //       transformOrigin={{ horizontal: 'right', vertical: 'top' }}
    //       anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
    //     >
    //       <MenuItem>
    //         <Avatar /> Profile
    //       </MenuItem>
    //       <MenuItem>

    //         <Avatar /> My account
    //       </MenuItem>
    //       <Divider />
    //       <MenuItem>
    //         <ListItemIcon>
    //           <PersonAdd fontSize="small" />
    //         </ListItemIcon>
    //         Add another account
    //       </MenuItem>
    //       <MenuItem onClick={()=> onChangePasswordClick()}>
    //             <ListItemIcon>
    //               <VpnKeyIcon fontSize="small" />
    //             </ListItemIcon>
    //             Change Password
    //         </MenuItem>
    //       <MenuItem>
    //         <ListItemIcon>
    //           <Settings fontSize="small" />
    //         </ListItemIcon>
    //         Settings
    //       </MenuItem>

    //       <MenuItem  onClick={onLogout}>
    //         <ListItemIcon >
    //           <Logout fontSize="small" />
    //         </ListItemIcon>
    //         Logout
    //       </MenuItem>
    //     </Menu>
    //   </React.Fragment>
    // );
  };

  return( 
    <>
      {onChangePassword()}
      {render()}
    </>
  );
}
