import React, { Component } from 'react'
import {
    Nav,Navbar
} from 'react-bootstrap';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import NavItems from  './NavItems' ;
import LeftSection from './LeftSection' ;
import  RightSection from './RightSection' ;
import AuthService from '../../services/Users/auth.service'

export class Header extends AuthenticatedBaseComponent {
    constructor(props : any){
        super(props);
    }

    render() {
      window.history.forward();
        if(!sessionStorage.getItem("accessToken")){
            alert("Session Expired! Please login again ")
            AuthService.logout();
         }
        return (
            <div key="div1">
            <header key="header1">
               <Navbar key="navbar1"  collapseOnSelect expand="md" bg="white" variant="light">
                   <LeftSection key="leftsection1" />
                   <NavItems key="navitems1" />
               </Navbar>
               {/* <RightSection key="rightsection1" /> */}
            </header>
       </div>
        )
    }
}

export default Header
