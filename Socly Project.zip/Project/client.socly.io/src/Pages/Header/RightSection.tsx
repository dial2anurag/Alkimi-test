import React, { Component } from 'react';
import '../../Styles/nav.css';
import notification from '../../Assets/notification.svg';
import info from '../../Assets/info.svg';
import account from '../../Assets/account.svg';
import AuthService from '../../services/Users/auth.service';
import { Link } from 'react-router-dom';
import {
    Nav,
    NavDropdown,
    OverlayTrigger,
    Tooltip
} from 'react-bootstrap';
import { IconType, IRolePageComponent, SectionComponent } from '../../Model/SysModal/sysEntiry';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Divider from '@mui/material/Divider';
import Logout from '@mui/icons-material/Logout';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import ContactUs from '@mui/icons-material/PermPhoneMsg';
import { IConComponents } from '../../Data/SysData/IconComponent';
import { Icon } from '@iconify/react';

type RightSectionState = {
    changePassword: boolean
    navbarTitle?: string
}

interface RightSectionProps {
    onNavClick: (value: string) => void
}
export class RightSection extends AuthenticatedBaseComponent<RightSectionProps, RightSectionState> {
    private _userData: any;
    private roleAccessRolesection: IRolePageComponent[];
    private roleAccessHelpsection: IRolePageComponent[];
    private roleAccessProfilesection: IRolePageComponent[];
    constructor(props: RightSectionProps) {
        super(props);
        this._userData = this.UserProfile.organization.orgName;
        this.roleAccessRolesection = [];
        this.roleAccessHelpsection = [];
        this.roleAccessProfilesection = [];
        this.state = { changePassword: false, navbarTitle: "" }
        this.loadNavItems();
    }


    loadNavItems() {
        let roledata = AuthService.getUserAuthMenu();
        if (roledata) {
            this.roleAccessRolesection = roledata.filter(e => e.section === SectionComponent.RoleView);
            this.roleAccessHelpsection = roledata.filter(e => e.section === SectionComponent.HelpSection);
            this.roleAccessProfilesection = roledata.filter(e => e.section === SectionComponent.ProfileSection);
        }
        else {
            this.roleAccessRolesection = [];
            this.roleAccessHelpsection = [];
            this.roleAccessProfilesection = [];
        }

    }

    getUserDetails() {
        let user = AuthService.getCurrentUser();
        return (<>{user.name}</>)
    }

    onLogout = () => AuthService.logout();

    renderDropDownItems(e: IRolePageComponent, index: number, dropdownname: string) {
        let IconComponent: any;
        let iconItem: any = <></>;
        let iconProps: any = {};
        if (e.icon) {
            if (e.icon.iconProps) {
                iconProps = e.icon.iconProps;
            }
            let iconType = e.icon.iconType;
            IconComponent = IConComponents[e.icon.iconIndex];
            iconProps["key"] = `rightsection-${dropdownname}-icon${e.id}-${index}`;
            switch ((iconType as IconType)) {
                case IconType.ICONS: {
                    if (!iconProps["fontSize"]) iconProps["fontSize"] = 'small';
                    iconItem = <IconComponent {...iconProps} />
                    break;
                }
                case IconType.PIC: {
                    if (!iconProps["className"]) iconProps["className"] = "nav-list-item-img";
                    if (!iconProps["alt"]) iconProps["alt"] = e.title;
                    iconProps["src"] = IconComponent;
                    iconItem = <img {...iconProps} />
                    break;
                }
            }
        }
        return (<NavDropdown.Item key={`rightsection-${dropdownname}-dropdown-${index}`}>
            <Link
                className='nav-links nav-link-normal'
                key={`${dropdownname}Link-${index}`}
                onClick={() => this.props.onNavClick(e.title)}
                to={e.path ? e.path : ""}
            >{iconItem}{e.title}</Link>
        </NavDropdown.Item>)
    }
    renderOrgNameSection() {
        return (
            <div style={{ marginTop: "14px" }}>we <Icon icon="mdi:heart" color="darkorange" /> {this._userData}</div>
        )
    }

    renderRoleSection() {
        if (this.roleAccessRolesection.length <= 0) {
            return null;
        }

        return (
            <NavDropdown key={"nav-roleSection"}
                title={<div key={"nav-roleSectionsubDiv"} className="pull-left">
                    <img key={"nav-roleSection-img"} className="thumbnail-image"
                        src={account}
                        alt="nav element"
                    />
                </div>}>
                {
                    this.roleAccessRolesection.map((e, index) => {
                        return this.renderDropDownItems(e, index, "roleSection");
                    })
                }
            </NavDropdown>
        )
    }

    renderHelpSection() {
        return (
            <NavDropdown key={"nav-helpSection"}
                title={<div key={"nav-helpSectionsubdiv"} className="pull-left">
                    <img key={"nav-helpSection-img"} className="thumbnail-image"
                        src={info}
                        alt="nav element"
                    />
                </div>}>
                <NavDropdown.Item key={"nav-help-contactus"}>
                    <ContactUs key={"nav-help-contactus-icon"} fontSize="small" />
                    <Link key={"nav-help-contactus-link"} style={{ color: 'inherit', textDecoration: 'inherit' }} to="/contactus" onClick={() => this.props.onNavClick('Contact Us')}> Contact Us</Link>
                </NavDropdown.Item>
                {
                    this.roleAccessHelpsection.map((e, index) => {
                        return this.renderDropDownItems(e, index, "helpSection");
                    })
                }
            </NavDropdown>
        )
    }

    renderProfileSection() {
        return (
            <NavDropdown key={"nav-profileSection"}
                title={<div key={"nav-profileSectionsubdiv"} className="pull-left">
                    <OverlayTrigger key={"nav-profileSection-overlay"} delay={{ hide: 450, show: 300 }}
                        overlay={(props) => {
                            return (<Tooltip key={"nav-profileSection-tooltips"} {...props}>
                                {this.getUserDetails()}
                            </Tooltip>)
                        }} placement='bottom'>
                        <AccountCircleIcon key={"nav-profileSection-icon"} style={{ color: '#00153d', height: '1.40em', width: '1.5em' }} />
                    </OverlayTrigger>
                </div>}>
                <NavDropdown.Item key={"nav-profileSection-item-profile"}>
                    <PersonOutlineOutlinedIcon key={"nav-profileSection-Profileicon"} fontSize="small" />
                    <Link key={"nav-profileSection-profile-link"} style={{ color: 'inherit', textDecoration: 'inherit' }} to="/myprofile" onClick={() => this.props.onNavClick('Your Profile')}>Your Profile</Link>
                </NavDropdown.Item>
                {
                    this.roleAccessProfilesection.map((e, index) => {
                        return this.renderDropDownItems(e, index, "profileSection");
                    })
                }
                <NavDropdown.Item key={"nav-profileSection-item-logout"} onClick={this.onLogout}><Logout fontSize="small" />Logout</NavDropdown.Item>
            </NavDropdown>
        )
    }

    render() {
        return (
            <ul key={"ul-1"} className="nav-links justify-content-end">
                <Nav key={"nav-1"}>
                    {this.renderOrgNameSection()}
                    {this.renderRoleSection()}
                    {this.renderHelpSection()}
                    {this.renderProfileSection()}
                </Nav>
            </ul>
        )
    }
}
export default RightSection