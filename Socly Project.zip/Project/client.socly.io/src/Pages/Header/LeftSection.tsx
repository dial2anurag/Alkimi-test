import React, { Component } from 'react' ;
import logo from '../../Assets/logo.png' ;
import { Link } from 'react-router-dom' ;
import {
    Navbar
} from 'react-bootstrap';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';

export class LeftSection extends AuthenticatedBaseComponent {
    constructor(props : any){
        super(props);
    }
    render() {
        return (
                <Navbar.Brand key="navbrand1">
                    <Link key="link1" to="/home"><img key="img1" src={logo} alt="Socly logo" className="soclylogo" /></Link>   
                </Navbar.Brand>
            )
    }
}
export default LeftSection
