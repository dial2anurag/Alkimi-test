import React, { Component } from 'react';
import { Button } from 'react-bootstrap';
import RichTextEditor from '../../Components/RichTextEditor/RichTextEditor';
import RichTextEditorService from '../../services/Common/RichTextEditorService';
import SunEditor from 'suneditor-react';
import SunEditorCore  from "suneditor/src/lib/core";
import 'suneditor/dist/css/suneditor.min.css';
import { OrgDetailsEntity } from '../../Model/Organization/Org';

const valData ="<div id='sidebar'><div id='outline'></div></div><div id='page-container'>"+
                "<div id='pf1' class='pf w0 h0' data-page-no='1'><div class='pc pc1 w0 h0'></div>"+
                "<div class='t m0 x1 h2 y1 ff1 fs0 fc0 sc0 ls0 ws0'>Confidentiality<span class='_'> </span>Polic<span class='_ _0'></span>y</div>"+
                "<div class='t m0 x2 h3 y2 ff2 fs1 fc0 sc0 ls0 ws1'>Purpose<span class='_'> </span>and<span class='_'> </span>S<span class='_ _1'></span>cope:</div>"+
                "<div class='t m1 x3 h4 y3 ff1 fs2 fc0 sc0 ls0 ws2'>1.<span class='_ _2'> </span>This<span class='_'> </span>policy<span class='_'> </span>"+
                "outli<span class='_ _0'></span>nes<span class='_'> </span>expe<span class='_ _0'></span>cted<span class='_'> </span>behavior<span class='_'> </span>"+
                "of<span class='_'> </span>e<span class='_ _0'></span>mploy<span class='_ _0'></span>ees<span class='_'> </span>to<span class='_'> </span>keep<span class='_'> "+
                "</span>confiden<span class='_ _0'></span>tial</div><div class='t m1 x4 h4 y4 ff1 fs2 fc0 sc0 ls0 ws3'>information<span class='_'> </span>"+
                "about<span class='_'> </span>clie<span class='_ _0'></span>nts,<span class='_'> </span>partners,<span class='_'> </span>and<span class='_'> </span>"+
                "our<span class='_'> </span>co<span class='_ _0'></span>mpany<span class='_'> </span>secure.</div><div class='t m1 x3 h4 y5 ff1 fs2 fc0 sc0 ls0 ws4'>2."+
                "<span class='_ _2'> </span>This<span class='_'> </span>policy<span class='_'> </span>applies<span class='_'> </span>to<span class='_'> </span>all"+
                "<span class='_'> </span>employees,<span class='_'> </span>board<span class='_'> </span>me<span class='_ _0'></span>mbers,<span class='_'> </span>investo"+
                "<span class='_ _0'></span>rs,<span class='_'> </span>and</div><div class='t m1 x4 h4 y6 ff1 fs2 fc0 sc0 ls0 ws2'>contractors,<span class='_'> </span>w"+
                "<span class='_ _0'></span>ho<span class='_'> </span>may<span class='_'> </span>have<span class='_'> </span>a<span class='_ _0'></span>ccess"+
                "<span class='_'> </span>to<span class='_'> </span>confid<span class='_ _0'></span>ential<span class='_'> </span>information<span class='_ _0'></span>."+
                "<span class='_'> </span>This<span class='_'> </span>policy</div><div class='t m1 x4 h4 y7 ff1 fs2 fc0 sc0 ls0 ws3'>must<span class='_'> </span>be"+
                "<span class='_'> </span>made<span class='_'> </span>readily<span class='_'> </span>av<span class='_ _0'></span>ailable<span class='_'> </span>to"+
                "<span class='_'> </span>all<span class='_'> </span>whom<span class='_'> </span>it<span class='_'> </span>appli<span class='_ _0'></span>es"+
                "<span class='_'> </span>to.</div><div class='t m0 x1 h3 y8 ff2 fs1 fc0 sc0 ls0 ws5'>Background:</div>"+
                "<div class='t m1 x3 h4 y9 ff1 fs2 fc0 sc0 ls0 ws6'>1.</div><div class='t m1 x5 h4 ya ff1 fs2 fc0 sc0 ls0 ws7'>1.<span class='_ _2'> </span>It"+
                "<span class='_'> </span>m<span class='_ _1'></span>ay<span class='_'> </span>be<span class='_'> </span>legally<span class='_'> </span>binding"+
                "<span class='_'> </span>(i.e.<span class='_ _3'> </span>sensitive<span class='_'> </span>customer<span class='_'> </span>data)</div>"+
                "<div class='t m1 x5 h4 yb ff1 fs2 fc0 sc0 ls0 ws8'>2.<span class='_ _2'> </span>It<span class='_'> </span>may<span class='_'> </span>be"+
                "<span class='_ _4'> </span>fundamental<span class='_'> </span>to<span class='_'> </span>o<span class='_ _0'></span>ur<span class='_'> </span>busin"+
                "<span class='_ _0'></span>ess<span class='_'> </span>(i.e.<span class='_'> </span>busine<span class='_ _0'></span>ss<span class='_'> </span>pro"+
                "<span class='_ _0'></span>cesses)</div><div class='t m1 x3 h4 yc ff1 fs2 fc0 sc0 ls0 ws4'>2.<span class='_ _2'> </span>Common<span class='_'> </span>"+
                "examples<span class='_'> </span>of<span class='_'> </span>co<span class='_ _0'></span>nfidential<span class='_'> </span>information<span class='_'> </span>"+
                "in<span class='_'> </span>o<span class='_ _0'></span>ur<span class='_'> </span>company<span class='_'> </span>include<span class='_ _0'></span>s,"+
                "<span class='_'> </span>but<span class='_'> </span>is</div><div class='t m1 x4 h4 yd ff1 fs2 fc0 sc0 ls0 ws7'>not<span class='_'> </span>limited"+
                "<span class='_'> </span>to:</div><div class='t m1 x5 h4 ye ff1 fs2 fc0 sc0 ls0 ws9'>1.<span class='_ _2'> </span>Unpublished<span class='_'> </span> "+
                "financial<span class='_'> </span>information</div><div class='t m1 x5 h4 yf ff1 fs2 fc0 sc0 ls0 wsa'>2.<span class='_ _2'> </span>Customer/partne"+
                "<span class='_ _0'></span>r/vendor/external<span class='_'> </span>party<span class='_'> </span>da<span class='_ _0'></span>ta</div>"+
                "<div class='t m1 x5 h4 y10 ff1 fs2 fc0 sc0 ls0 ws8'>3.<span class='_ _2'> </span>Patents,<span class='_'> </span>formulas,<span class='_ _4'> </span>new"+
                "<span class='_'> </span>tech<span class='_ _0'></span>nologies,<span class='_'> </span>and<span class='_'> </span>o<span class='_ _0'></span>ther"+
                "<span class='_'> </span>i<span class='_ _0'></span>ntellectual<span class='_'> </span>property</div><div class='t m1 x5 h4 y11 ff1 fs2 fc0 sc0 ls0 ws3'>4."+
                "<span class='_ _2'> </span>Existing<span class='_'> </span>and<span class='_'> </span>prospec<span class='_ _0'></span>tive<span class='_'> </span>customer"+
                "<span class='_'> </span>lists</div><div class='t m1 x5 h4 y12 ff1 fs2 fc0 sc0 ls0 wsb'>5.<span class='_ _2'> </span>Undisclosed<span class='_ _4'> </span>"+
                "business<span class='_'> </span>strategies<span class='_'> </span>i<span class='_ _0'></span>ncluding<span class='_'> </span>p<span class='_ _0'></span>"+
                "ricing<span class='_ _4'> </span>&amp;<span class='_'> </span>marketing</div><div class='t m1 x5 h4 y13 ff1 fs2 fc0 sc0 ls0 ws6'>6.</div>"+
                "ricing<span class='_ _4'> </span>&amp;<span class='_'> </span>marketing</div><div class='t m1 x5 h4 y13 ff1 fs2 fc0 sc0 ls0 ws6'>6.</div>"+
                "</div>"
  
type TestComponentState={
  value : string,
  initalvalue : string
  txtvalue :string
}
export class TestComponent extends Component<any,TestComponentState> {
    private _editorref :any ;
    constructor(props: any){
        super(props);
        this.state ={value : "" , txtvalue : "",initalvalue:valData}
        this._editorref = React.createRef();
    }

    getSunEditorInstance (sunEditor : SunEditorCore):void{
      this._editorref.current = sunEditor;
    }

  handleImageUploadBefore(files : any, info : any, uploadHandler :any){
  }

  handleImageUpload(targetImgElement:any, index:any, state:any, imageInfo:any, remainingFilesCount:any){
  }

  imageUploadHandler(xmlHttpRequest :any, info : any, core: any){
  }
 
   handleOnChange(data: any) :void {
      this.setState({value : data});
   }

   handletxtOnChange(e: any) :void {
    this.setState({txtvalue :  e.target.value});
   }

   handleEditorOnSave(data: string) :void {
    
   }

   async handleOnPDFClick(event : any){
    event.preventDefault();
    //let pdfvalue = await RichTextEditorService.generatePDFfromHTML(this.state.txtvalue, this.state.value,"pdffile1.pdf");
    //let pdfvalue = await RichTextEditorService.generatePDFFilefromHTML(this.state.txtvalue, this.state.value,"pdffile1.pdf");

   }

   handleOnLoadClick(event :any){
      event.preventDefault();
      let ordata : OrgDetailsEntity ={
        logo : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAQCAYAAAD9L+QYAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIGSURBVHgBtVO/S1tRGD03L2mkP/LSFtoueQQsQsHQLl1MhnYqmKmbpIudSv+BtmMnXRXE6BQV1E1xiE6CQ3RSEBLUQSEkCBpFjSj+iPH5nRufRiO4JAcu3Pu9e893zvl4yp/wBw1VTkCpIOoF286WPaVOt0tdTgrxJ9QTItQoeYZcSqG+xLcNvridvfnEhM9jwnpuIXeUQ/44h/DbCOa3Uwg8s3S99VUI81spFM+LOCwV9f3q90RmP31TczkbEvSF+zXJ1LfkTaP2QBThdxFRAuSl6Z+P/xCSJqxHragIhLyL6zvtcnaaaPGvh302N78+/IYphKZXPtoKg2v9WmGbqPfTlazMXlorphCe6Q7yOiAiSHoo98c3xmqVT+eSyBykkRaC4vkB2t5ENLETE9fI11Fy6XhIRDGMgcRcFMNGNeRURGI+okWeFyRvRsHzX4ljJp+EJarpgCQks+1KXHxbHQlxZ6AdzT+0ag4xJYPr+tytbfLb+PqYdkZi3zUJ67H3Md1oYCWuHbGRA+Ppd+9/bmi/yfDKasLs5iysF1bFuhD0ZnrQYrboaBzsnBbglbtLu4uYzE5UYpDhFk4KtQNtBNz3C3TQ0Ry7U6u2Wg1neMx+cDX+ODmt86Lv3nAeatb6MqRjY9YPoaGxuKDsOTQAMttld7ls/DQMOyF/RxD1gkL2wjjrvAI3GNeotoQp/gAAAABJRU5ErkJggg==",
        orgName : "Socly.IO",
        Address1 : "Address 1 & Address 2",
        Address2 : "",
        city: "Hyderabad",
        state : "Maharastra",
        pincode : "412307",
        phone : "1111111111",
        website: "https://socly.io",
        email : "hello@socly.io",
        CEO : "",
        CINNo :"",
        country:"India",
        CISO: "",
        CTO :"",
        founders:"",
        GstNo :"",
        id : 2
      }
   }

      
  render() {
    return (
      <div className='fluid-container'>
        <div className='row'>
          <div className='col-md-6 text-end'>
              <Button 
                type='button' 
                variant='primary' 
                onClick={this.handleOnPDFClick.bind(this)}>
                  Generate PDF
              </Button>
          </div>
          <div className='col-md-6'>
              <Button 
                type='button' 
                variant='primary' 
                onClick={this.handleOnLoadClick.bind(this)}>
                  Load
              </Button>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-6'>
          <RichTextEditor 
            onChange={this.handleOnChange.bind(this)}
            content = {this.state.initalvalue}
            height="500px"
            width="100%"
            />
          </div>
          <div className='col-md-6'>
          <textarea
              value={this.state.txtvalue}
              onChange={this.handletxtOnChange.bind(this)}
              style={{height:"250px", width :"100%"}}
            />
            <textarea
              value={this.state.value}
              style={{height:"250px", width :"100%"}}
              />
          </div>
        </div>
        <div className='row'>
            <div className='col'>
            </div>
        </div>
      </div>
    )
  }
}   

export default TestComponent