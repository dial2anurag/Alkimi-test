import React, { Component } from 'react';
import {
    Route,
    Routes,
    Link,
    LinkProps 
  } from "react-router-dom";
import { BrowserRouter as Router } from 'react-router-dom';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import {IRolePageComponent, ComponentType, SectionComponent} from '../../Model/SysModal/sysEntiry';
import {PageComponents} from '../../Data/SysData/Components';
import RoleAccess from '../../services/Authorization/RoleAccess';
import Home from "../Home/Home";
import NotFound from '../Errors/NotFound';
import UserProfile from '../Users/UserProfile';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Sidebar from '../Header/Sidebar/Sidebar';
import RightSection from '../Header/RightSection';
import SidebarWrapper from '../Header/Sidebar/sidebar.style';
import Contactus from '../Application/Contactus';

const drawerWidth = 300;

type MainRouteState ={
  roleAccess  :  IRolePageComponent[] 
  mobileOpen : boolean,
  navbarTitle: any,
  defaultPage: IRolePageComponent | null
}

export class MainRoute extends  AuthenticatedBaseComponent<any, MainRouteState> {
  constructor(props : any){
      super(props);
      this.state = {
          mobileOpen: false,
          navbarTitle: "",
          roleAccess : [],
          defaultPage: null
      };
  }

  componentDidMount(): void {
      let defaultPage: IRolePageComponent | null = null;
      let roledata =RoleAccess.getComponentsForUser();
      if(roledata){ 
        let roleAccess = roledata.filter(e=> ((e.path && e.path.trim().length > 0) &&  (e.componentType === ComponentType.ClassComponent || e.componentType === ComponentType.FunctionalComponent )))
        let tempRoleData = roleAccess.filter(role=>role.section === SectionComponent.NavBar);

        let navTitle: string | null = "";
        if(!tempRoleData || tempRoleData.length <= 0) {
            defaultPage = null;
        } else {
            tempRoleData.sort((a, b) => (a.sequence > b.sequence) ? 1 : -1);
            defaultPage = tempRoleData[0];
            navTitle = (window.location.pathname === '/' ? defaultPage.title : document.getElementsByClassName("active")[0]?.textContent);
        } 
        if(navTitle === undefined) {
            this.rightSideRefreshNavItems();
            this.setState({roleAccess : roleAccess, defaultPage: defaultPage}); 
        } else {
            this.setState({roleAccess : roleAccess, defaultPage: defaultPage, navbarTitle: navTitle}); 
        }
      } 
  }

  rightSideRefreshNavItems() {
    let urlPath = window.location.pathname.toLowerCase();
    let navTitle: string | null = "";
      switch (urlPath) {
        case "/contactus":
          navTitle = "Contact Us";
          break;
        case "/myprofile":
          navTitle = "Your Profile";
          break;
        case "/orgdetail":
          navTitle = "Organization Details";
          break;
        case "/orgsetting":
          navTitle = "Settings";
          break;
        default:
          break;
      }
      this.setState({navbarTitle: navTitle});
  }

  handleDrawerToggle = () => {
      this.setState({mobileOpen: !this.state.mobileOpen});
  };

  selectedItem = (title: string) => {
      this.setState({navbarTitle: title});
      this.handleDrawerToggle();
  }

  handleNavClick(title: string) : void {
      this.setState({navbarTitle: title});
  }

  renderRouters(){
    let returnValue: any;
    if(this.state.roleAccess && this.state.roleAccess.length > 0){
        returnValue = (<>
        {
          this.state.roleAccess.map((page : IRolePageComponent , index : number)=>{
          return(
              <Route 
                key={`Route(${page.id})-${index}`}
                path={page.path} 
                element={this.renderRouteElement(page,index)} /> 
            )
          })
        }
        </>)
    }
    else {
      returnValue = (<></>)
    }
    if(this.state.defaultPage) {
      return (
        <>
          {
            <Route 
              key={`Route(${this.state.defaultPage.id})-1}`}
              path="/" 
              element={this.renderRouteElement(this.state.defaultPage, -1)} /> 
          }
          {returnValue}
        </>
      )
    } else {
      return returnValue;
    }
  }

  renderRouteElement(page : IRolePageComponent , index : number){
    let Component : any = PageComponents[page.componentIndex!];
    let componentProps : any={};

    if(page.componentProps) {
      componentProps =page.componentProps;
    }
    componentProps["pageid"] = page.id;
    componentProps["onNavigate"] = this.onNavigate.bind(this)

    return (<Component {...componentProps}/>); 
  }

  // showErrorPage()
  //   let path : string = window.location.pathname.trim().toLowerCase();
  //   let findPage = this.state.roleAccess.find(e=> e.path?.trim().toLowerCase()===path);
  //   if(! findPage || path !== "/"){
  //     let navigate = useNavigate();
  //     navigate("/errorpage");
  //   }
 // }

 setNavigateTitle(path : string) {
  let nodeItem = this.state.roleAccess.find(e => e.path === path);
    if(!nodeItem) {
      return <></>;
    }
    this.setState({navbarTitle : nodeItem.title});
 }

 onNavigate(propsParam: LinkProps & React.RefAttributes<HTMLAnchorElement>, childElement ?: JSX.Element): JSX.Element {
  let path : string = propsParam.to.toString();
   return (
      <Link {...propsParam} onClick={()=>this.setNavigateTitle(path)}>
          {childElement}
      </Link>
    )
 }

  renderRouteSubComponent(){
    return (<Routes>
              {
                window.history.forward()
              }
              <Route  path="/home" element={<Home/>} />
              <Route  path="/myprofile" element={<UserProfile />} />
              <Route  path="/contactus" element={<Contactus />} />
              <Route  path="/errorpage" element={<NotFound />} />
              {
                this.renderRouters()
              }
              {/* <Route  path="*" element={<NotFound/>}/> */}
          </Routes>)
  }
  
  render() {
    window.history.forward();
    return (
        <SidebarWrapper>
        <Router>
          <Box sx={{ display: 'flex' }}>
                <IconButton
                    color="inherit"
                    aria-label="open drawer"
                    edge="start"
                    onClick={this.handleDrawerToggle}
                    sx={{ mr: 2, display: { sm: 'none' } }}
                >
                    <MenuIcon />
                </IconButton>
              {/* SIDEBAR LEFT SIDE SECTION */}
                <Sidebar handleDrawerToggle={this.handleDrawerToggle.bind(this)} selectedItemClick={this.selectedItem.bind(this)} sidebarWidth={drawerWidth} mobileOpen={this.state.mobileOpen} defaultPage={this.state.defaultPage} />
              {/* RIGHT SIDE SECTION */}
              <Box
                  component="main"
                  sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
              >
                  <RightSection onNavClick={this.handleNavClick.bind(this)} />
                  <div className="heading-section">
                      <div className="heading-style">{this.state.navbarTitle}</div>
                      <hr className='heading-bar' />
                  </div>
                  {this.renderRouteSubComponent()}
              </Box>
            </Box>
        </Router>
        </SidebarWrapper>
    )
  }
}
export default MainRoute