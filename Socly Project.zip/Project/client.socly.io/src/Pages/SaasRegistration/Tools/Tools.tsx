import React, { Component } from 'react'
import ToolsWrapper from './tools.style'
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../../Base/AuthenticatedRouteComponent';
import  CloudProviders from '../Cloud/CloudProviders' //'./Cloud/CloudProviders'
import  VersionControl from '../Version/VersionControl';
import  IdentityProvider from '../Identity/IdentityProvider';
import ProjectTracking from '../ProjectTracking/ProjectTracking';
import { HrTools } from '../HrTools/HrTools';
import { Others } from '../Others/Others';

export class Tools extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps,any> {
    constructor(props : AuthenticatedRouteComponentProps){
        super(props);
    }

    render() {
        return (
            <ToolsWrapper>
                <div className='white-box'>
                    <CloudProviders pageid={this.props.pageid}  />
                </div>
                <div className='white-box'>
                    <VersionControl pageid={this.props.pageid} />
                </div>
                <div className='white-box'>
                    <IdentityProvider pageid={this.props.pageid} />
                </div>
                <div className='white-box'>
                    <ProjectTracking pageid={this.props.pageid} />
                </div>
                <div className='white-box'>
                    <HrTools pageid={this.props.pageid} />
                </div>
                <div className='white-box'>
                    <Others pageid={this.props.pageid} />
                </div>
            </ToolsWrapper>
        )
    }
}
export default Tools
