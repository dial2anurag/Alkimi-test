import styled from 'styled-components';

const ToolsWrapper = styled.div`
.sc-jSFjdj {
    font-family: 'ProductSansBold';
    font-size: 24px;
    line-height: 29px;
    color: #000000;
    letter-spacing: 0px;
    text-align: left;
    padding-left: 24px;
    padding-top: 20px;
    margin-top: 3rem;
}
.white-box {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 8px;
}
.left-arrow, .right-arrow {
    top: 50%;
}
@media only screen and (max-width: 575.98px){
    .eWezFO {
        width: 80% !important;
        min-height: 100px;
    }
}
`;

export default ToolsWrapper;