import React, { Component } from 'react'
import { ProjectTrackingList } from '../../../Data/SaasProviders/ProjectTrackings'
import ToolsComponent , {ToolsComponentState} from '../Base/ToolsComponent';
import {AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';

export class ProjectTracking extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState> {
    constructor(props: AuthenitcatedComponentProps){
        super(props);
        this.state = {
            children : null,
            headerText : "Project Management",
            providers : ProjectTrackingList
        }
        this.handleProvider =  this.handleProvider.bind(this);
    }
   
    override handleProvider(provider: any){
        // switch(trackProviderKey.key){
        //     case "gsuite":
        //         this.setState({children :  <GSUITE onModalStateChange = {this.onModalStateChange.bind(this)} />}) ;
        //         break;
        //     // case "bitbucket":
        //     //     this.setState({children :  <BitBucket onModalStateChange = {this.onModalStateChange.bind(this)} />}) ;
        //     //     break;
        //     default:
        //         break;    
        // }
    }
}

export default ProjectTracking
