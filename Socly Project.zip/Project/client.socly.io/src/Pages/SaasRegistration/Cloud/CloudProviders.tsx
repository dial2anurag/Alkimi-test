import React, { Component } from 'react'
import { CloudProviderList } from '../../../Data/SaasProviders/CloudProviders'
import ToolsComponent , {ToolsComponentState } from '../Base/ToolsComponent';
import {AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';
import AWS from './AWS';


export class CloudProviders extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState> {
    constructor(props: AuthenitcatedComponentProps){
        super(props);
        this.state = {
            children : null,
            headerText : "Cloud Provider",
            providers : CloudProviderList
        }
        this.handleProvider =  this.handleProvider.bind(this);
    }
   
    override handleProvider(provider: any){
        switch(provider.key){
            case "aws":
                this.setState({children :  <AWS pageid={this.props.pageid}  onModalStateChange = {this.onModalStateChange.bind(this)}  />}) ;
                break;
            default:
                break;    
        }
    }
}

export default CloudProviders
