import React, { Component } from 'react'
import ToolsChildComponent , {
    ToolsChildComponentProps,
    ToolsChildComponentState
}
from '../Base/ToolsChildComponent';
import  { Div } from '../Base/ToolsStypeComponent' ;
import { TextField } from '@material-ui/core';
import {
    Form,
    Fields
} from '../../../Components/CommonComponent';
import AWSSecretService from '../../../services/AWS/AWSSecretService';
import ReactChips from '../../../Components/ReactChips/ReactChips';
import AWSWrapper from './aws.style'

interface AWSState extends ToolsChildComponentState  {
    access_key :string,
    secretkey :string,
    account_admins:string[] | string,
    region:string
}

export class AWS extends ToolsChildComponent<ToolsChildComponentProps,AWSState> {
    constructor(props :ToolsChildComponentProps)
    {
        super(props);
        this.state = {
            access_key : "",
            secretkey : "",
            account_admins :[],
            showSpinner : false,
            headerText :"AWS Credentials",
            region:""
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleReactChipOnchange = this.handleReactChipOnchange.bind(this);
    }

    override async handleSave() : Promise<boolean>{
        let returnvalue = false;
        if(this.state.access_key && this.state.secretkey 
            && this.state.account_admins && this.state.account_admins.length>0
            && this.state.region)
            {
                this.setState({showSpinner : true});  
                let data = {
                    accessKey :this.state.access_key,
                    secretKey :this.state.secretkey,
                    account_admins : this.state.account_admins,
                    region : this.state.region
                }
                if( await AWSSecretService.saveSecretKey(data) === 200){ 
                    returnvalue = true;
                }
                else{
                        returnvalue = false ;
                }
                this.setState({showSpinner : false});
       }
       else{
        returnvalue= false;
       }
       this.props.onModalStateChange(returnvalue);
       return returnvalue;
    }

    override handleChange(event :any){
        switch(event.target.id){
            case "access_key":
                this.setState({access_key : event.target.value});
                break;
            case "secretkey":
                this.setState({secretkey : event.target.value});
                break;
            case "region":
                this.setState({region : event.target.value});
                break;
            default:
                break;
        }
    }

    handleReactChipOnchange(value: string[]):void {
        this.setState({ account_admins: value});
    }

   override renderComponent() {
        return (
            <AWSWrapper>
                <Div>
                    <Form>
                        <Fields>
                            <label htmlFor="access_key" className="form-label">Access Key</label>
                            <TextField id="access_key" placeholder='Access Key' className='input-height' value={this.state.access_key} 
                            fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                        <Fields>
                            <label htmlFor="secretkey" className="form-label">Client Secret</label>
                            <TextField id="secretkey" placeholder='Client Secret' value={this.state.secretkey} 
                            fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                        <Fields>
                            <label htmlFor="region" className="form-label">Region</label>
                            <TextField id="region" placeholder='Region' value={this.state.region} 
                            fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                        <Fields>
                            <label htmlFor="account" className="form-label">Admin Account</label>
                            <ReactChips onChange={this.handleReactChipOnchange.bind(this)} value="" />
                        </Fields>
                    </Form>
                </Div>
            </AWSWrapper>
        );
   }
}

export default AWS
