import React, { Component } from 'react'
import ToolsComponent , {ToolsComponentState} from '../Base/ToolsComponent';
import {AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';
import { IdentityProviderList } from '../../../Data/SaasProviders/IdentityProviders';
import GSUITE from './GSUITE/GSUITE';

export class IdentityProvider extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState> {
    constructor(props: AuthenitcatedComponentProps){
        super(props);
        this.state = {
            children : null,
            headerText : "Identity Provider",
            providers : IdentityProviderList
        }
        this.handleProvider =  this.handleProvider.bind(this);
    }
     
    handleProvider(provider: any){
        switch(provider.key){
            case "gsuite":
                this.setState({children :  <GSUITE pageid={this.props.pageid} onModalStateChange = {this.onModalStateChange.bind(this)} />}) ;
                break;
            // case "bitbucket":
            //     this.setState({children :  <BitBucket onModalStateChange = {this.onModalStateChange.bind(this)} />}) ;
            //     break;
            default:
                break;    
        }
    }
}

export default IdentityProvider
