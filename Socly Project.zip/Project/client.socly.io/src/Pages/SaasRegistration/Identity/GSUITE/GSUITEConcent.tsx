import React, { useEffect , useState } from 'react'
import {useLocation , useNavigate  } from "react-router-dom" //"react-router-dom";
import SpinnersComponent from '../../../../Components/SpinnersComponent';

export default function GSUITEConcent() {
    const param = useLocation().search;
    if(param){
        sessionStorage.setItem("gsuiteParams",param);
    }
    window.location.href ="/gsuiteprocess";
    return (
        <div>
            <SpinnersComponent key="gsuiteconcentspinnercomponent" showspinner={true} />
        </div>
    )
}