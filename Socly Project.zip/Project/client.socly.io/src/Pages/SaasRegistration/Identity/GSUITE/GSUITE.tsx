import React, { Component } from 'react'
import ToolsChildComponent , {
  ToolsChildComponentProps,
  ToolsChildComponentState
}
from '../../Base/ToolsChildComponent';
import  { Div } from '../../Base/ToolsStypeComponent' ;
import GsuiteSecretService from '../../../../services/GSUITE/GsuiteSecretService';
import  AuthService from '../../../../services/Users/auth.service'
import {
  Form,Fields
} from '../../../../Components/CommonComponent';
import FormPost , { formPostParams } from '../../../../Components/FormPost'
import ReactChips from '../../../../Components/ReactChips/ReactChips';

interface GSUITEState extends ToolsChildComponentState  {
  selectedFile : Blob | null,
  account_admins:string[],
  formPostParams :formPostParams[]
}

export class GSUITE extends ToolsChildComponent<ToolsChildComponentProps,GSUITEState> {
  private uploadRef : React.RefObject<HTMLInputElement>;

  constructor(props :ToolsChildComponentProps)
    {
        super(props);
        this.state ={
          selectedFile : null,
          showSpinner :false,
          headerText :"GSuite Credentials",
          account_admins : [],
          formPostParams :[]
      }
        this.uploadRef = React.createRef<HTMLInputElement>();
        this.handleChange =this.handleChange.bind(this);
        this.handleReactChipOnchange = this.handleReactChipOnchange.bind(this);
    }

    override handleChange(event :any) {
      switch(event.target.id){
        case "gsuiteFile":
          this.setState({ selectedFile: event.target.files[0] });
          break;
      }
    }

    handleReactChipOnchange(value: string[]):void {
      this.setState({ account_admins: value});
    }

    override async handleSave() : Promise<boolean> {
      let formData = new FormData();
      let returnvalue = false;
      if(this.state.selectedFile && this.state.account_admins && this.state.account_admins.length >0){
         this.setState({showSpinner : true}); 
          formData.append("file", this.state.selectedFile || "" );
          formData.append("admins" , this.state.account_admins.toString());
          if(await GsuiteSecretService.saveSecretKey(formData) === 200){ 
              await this.renderFormPost(this.state.selectedFile);
          }
          if (null !==this.uploadRef.current) {
            this.uploadRef.current.value ="";
          }
          this.setState({showSpinner : false});  
      }
      else{
        returnvalue= false;
      }
      this.props.onModalStateChange(returnvalue);
      return returnvalue;
    }

  async renderFormPost(file : any){
    let currentHost =`${window.location.protocol}//${window.location.host}`;
    let redirectUrl=`${currentHost}/gsuiteconcent`
    let user = AuthService.getCurrentUser();
    let orgName =  btoa(user.organizationName);

    let filedataString =await file.text();
    let filedata = JSON.parse(filedataString);
    sessionStorage.setItem("GSuitSecrets",filedataString);

    let prams : formPostParams[] =[];
    prams.push({ name : "response_type",value : "code" });
    prams.push({ name : "scope",value : "https://www.googleapis.com/auth/admin.directory.user.readonly" });
    prams.push({ name : "access_type",value : "offline" });
    prams.push({ name : "state",value : orgName });
    prams.push({ name : "include_granted_scopes",value : "true" });
    prams.push({ name : "prompt",value : "consent" });
    prams.push({ name : "client_id",value : filedata.web.client_id });
    prams.push({ name : "redirect_uri",value : redirectUrl });

    this.setState({formPostParams : prams});
  }

  renderGSuiteComponent(){
    return(
      <Form className = "md-form">
        <Fields>
          <Div> Please upload the JSON file downloaded from your GSUIT account</Div>
          <div className="file-field">
              <a className="btn-floating peach-gradient mt-0 float-left">
                <i className="fas fa-paperclip" aria-hidden="true"></i>
                <input id="gsuiteFile" type="file" accept="application/JSON" 
                ref={this.uploadRef}
                onChange={this.handleChange} />
              </a>
          </div>
        </Fields>
        <Fields>
            <label htmlFor="account" className="form-label">Admin Account</label>
            <ReactChips onChange={this.handleReactChipOnchange.bind(this)} value="" />
        </Fields>
      </Form>
    );
  }

  renderFormComponent(){
    return(<FormPost params={this.state.formPostParams} formProps={{
      action :`${process.env.REACT_APP_GSUITE_URL}/o/oauth2/v2/auth`,
      method : 'POST'
    }}  />)
  }

  override renderComponent(){
    if(this.state.formPostParams && this.state.formPostParams.length > 0){
      return this.renderFormComponent();
    }
    else{
      return this.renderGSuiteComponent();
    }
  }
}

export default GSUITE
