import React, { Component } from 'react';
import GsuiteSecretService from '../../../../services/GSUITE/GsuiteSecretService';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../../Base/AuthenitcatedComponent';

type ProcessConcentState = {
    showSpinner : boolean
}
export class ProcessConcent extends AuthenitcatedComponent<AuthenitcatedComponentProps, ProcessConcentState> {
    constructor(props:any){
        super(props);
        this.state = {
            showSpinner : true
        }
   }

  async componentDidMount(){
        if(sessionStorage.getItem("gsuiteParams") && sessionStorage.getItem("gsuiteParams")!.length > 0){
            let prmValue = sessionStorage.getItem("gsuiteParams");
            sessionStorage.removeItem("gsuiteParams");
            let qrystringObj =new URLSearchParams(prmValue!);
            if(qrystringObj.has("state") && qrystringObj.has("code")){
                let response = await GsuiteSecretService.getToken(qrystringObj);
                if(response.status !==200){
                    alert(response.message)
                }
            }
        }
        else{
            alert("Invalid Request Params");
        }
        
        this.setState({showSpinner : false});
        let link = document.createElement('a');
        link.href ="/tools";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        //window.location.href ="/tools" ;
  }

  render() {
    return (
        <div>
            <SpinnersComponent key="gsuiteprocessconcentspinnercomponent" showspinner={this.state.showSpinner}/>
        </div>);
  }
}

export default ProcessConcent;
