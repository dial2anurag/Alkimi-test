import React, { Component } from 'react'
import {
    Button , 
    Modal
} from 'react-bootstrap';
import SpinnersComponent from '../../../Components/SpinnersComponent' ;
import BaseComponent from '../../Base/BaseComponent';

type  ToolsModalProps ={
    showModal :boolean,
    children : React.ReactNode,
    headerText :string ,
    showSpinner : boolean,
    handleModalSave : () => Promise<boolean>,
    handleModalCancel:() => void
}

type ToolsModalState = {
    showModal :boolean
}

export class ToolsModal extends BaseComponent<ToolsModalProps , ToolsModalState> {
    
    constructor(props : ToolsModalProps){
        super(props)
        this.state = {
               showModal : this.props.showModal 
        }
    }

    async handleClose(event:any){
        this.setState({showModal: false});
        this.props.handleModalCancel();
    }

    async handleSave(event : any){
        event.preventDefault();
        let value = await this.props.handleModalSave();
        if(value)
        {   
            this.setState({showModal: false});
        }
    }

    render() {
        return (
            <>
            <Modal show={this.state.showModal} onHide={this.handleClose.bind(this)}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            backdrop ={"static"}
            keyboard={false}
            centered>
                <Modal.Header closeButton>
                  <Modal.Title>{this.props.headerText}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <SpinnersComponent key="toolmodalspinnercomponent" showspinner = {this.props.showSpinner} />
                    {this.props.children}
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={this.handleClose.bind(this)}>
                    Close
                  </Button>
                  <Button variant="primary" onClick={this.handleSave.bind(this)}>
                    Save Changes
                  </Button>
                </Modal.Footer>
              </Modal>
            </>
        )
    }
}

export default ToolsModal
