import styled  from 'styled-components';

// export interface ContainerProps {
//     selected: boolean
// }
export const ImageContainer = styled.div`
display: block;
margin: auto auto;
// height: 10px;

`;

export const Image = styled.img`
max-width: 100%;
height: auto;
`;

export const Div = styled.div`
padding-bottom: 2rem
`;

export const Heading = styled.div`
    font-size: 25px;
    font-weight: 650;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.21;
    letter-spacing: 0.54px;
    text-align: center;
    color: #5c5c5f;
    margin-top: 5rem;
    color: #00153d;
`;

export const Container = styled.div`
    display: grid;
   // border-radius: 4px;
   // border: solid 1px #dadce0;
    width: 40%;
    padding: 10px;
    margin: 0 auto;
    min-height: 120px;
    cursor: pointer;
`;