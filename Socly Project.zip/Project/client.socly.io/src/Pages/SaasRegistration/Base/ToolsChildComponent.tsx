import React, { Component } from 'react'
import ToolModal from './ToolsModal' ;
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent'

export interface ToolsChildComponentProps extends AuthenitcatedComponentProps {
    onModalStateChange : (value : boolean) => void
}

export interface ToolsChildComponentState {
    showSpinner :boolean,
    headerText : string
}

export abstract class ToolsChildComponent<P extends ToolsChildComponentProps ,
                                          S extends ToolsChildComponentState,SS={}> 
    extends AuthenitcatedComponent<P,S,SS> {
    
    constructor(props: P){
        super(props);
    }
    
    protected abstract handleSave() : Promise<boolean> ;
    protected abstract renderComponent() :any ;
    protected abstract handleChange(event :any) :void;

    handleModalCancel() :void{
        this.props.onModalStateChange(true);
    }

    render() {
        return(
            <>
                <ToolModal 
                  headerText={this.state.headerText}
                  showSpinner = {this.state.showSpinner}
                  showModal ={true}
                  handleModalSave ={this.handleSave.bind(this)}
                  handleModalCancel ={this.handleModalCancel.bind(this)}>
                     {this.renderComponent()}
                   </ToolModal>
            </>
        );
    }
}

export default ToolsChildComponent
