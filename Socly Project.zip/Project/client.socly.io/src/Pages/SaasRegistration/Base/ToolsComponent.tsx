import React, { Component } from 'react'
import {
    Heading ,
    Container,
    ImageContainer,
    Image 
} from './ToolsStypeComponent' ;
import Carousel from '../../../Components/Carousel'
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent'

export interface ToolsComponentState {
    children : any,
    headerText :string,
    providers : any[]
}

export abstract class ToolsComponent<P extends AuthenitcatedComponentProps 
                                    ,S extends ToolsComponentState, SS ={}> 
                extends AuthenitcatedComponent<P,S,SS>{
    public constructor(props:P){
        super(props);
    }

    protected onModalStateChange(value : boolean) : void {
        if(value){
            this.setState({children : null});
        }
    }

    protected abstract handleProvider(provider: any) :void;
    
    renderComponent(){
        return(
            <div>
                <Heading> {this.state.headerText} </Heading>
                <div>
                    <Carousel show={4}>
                        {
                            this.state.providers.map((provider: any) => {
                                return (
                                    <div key={provider.key} style={{ padding: '8px' }}>
                                        <Container  key={provider.key}
                                            onClick={() => this.handleProvider(provider)}
                                            style={{ width: '50%' }}
                                        >
                                            
                                            <ImageContainer>
                                                <Image key={provider.key} src={provider.img} width={provider.width} alt="im provider" />
                                            </ImageContainer>
                                        </Container>
                                    </div>
                                )
                            })
                        }
                    </Carousel>
                </div>
            </div>
        );
    }

    render () {
        if(this.state.children){
            return(
                <>
                {this.state.children}
                {this.renderComponent()}
                </>
            )
        }
        else{
            return(
                <>
                {this.renderComponent()}
                </>
            )
        }
    }
}
export default ToolsComponent
