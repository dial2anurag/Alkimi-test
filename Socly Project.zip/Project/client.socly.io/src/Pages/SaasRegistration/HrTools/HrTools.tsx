import React, { Component } from 'react'
import { HRToolList } from '../../../Data/SaasProviders/HRTools';
import ToolsComponent , {ToolsComponentState} from '../Base/ToolsComponent';
import {AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';

 export class HrTools extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState> {
    constructor(props: AuthenitcatedComponentProps){
        super(props);
        this.state = {
            children : null,
            headerText : "HR Tools",
            providers : HRToolList
        }
        this.handleProvider =  this.handleProvider.bind(this);
    }

    override handleProvider(provider: any){
 }
 }