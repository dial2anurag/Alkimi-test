import React, { Component } from 'react'
import { OtherProviderList } from  '../../../Data/SaasProviders/OtherProviders';
import ToolsComponent , {ToolsComponentState} from '../Base/ToolsComponent';
import {AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';

export class Others extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState> {
    constructor(props: AuthenitcatedComponentProps){
        super(props);
        this.state = {
            children : null,
            headerText : "Others",
            providers : OtherProviderList
        }
        this.handleProvider =  this.handleProvider.bind(this);
    }

    override handleProvider(provider: any){
 }
}
