import React, {  useEffect , useState } from 'react'
import {useLocation} from "react-router-dom";
import SpinnersComponent from '../../../../Components/SpinnersComponent';

export default function GitConcent() {
    var search = useLocation().search;
    if(search && sessionStorage.getItem("githubsecret")){
        let githubsecret = JSON.parse(sessionStorage.getItem("githubsecret")!);
        githubsecret["params"] = search ;
        sessionStorage.setItem("githubsecret",JSON.stringify(githubsecret));
    }
    window.location.href ="/gitprocess";
    return (
        <div key="gitconcentdiv">
            <h1 key="gitconcenth1">Git Hub Response</h1>
            <SpinnersComponent key="gitconcentpinnercomponent" showspinner={true} />
        </div>
    )
}
