import React, { Component } from 'react';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import GithubSecretService from '../../../../services/GitHub/GithubSecretService';
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../../Base/AuthenitcatedComponent';

type GitProcessState = {
    showSpinner : boolean
}

export class GitProcess extends AuthenitcatedComponent<AuthenitcatedComponentProps,GitProcessState> {
  constructor(props:AuthenitcatedComponentProps){
    super(props);
    this.state = {
        showSpinner : true
    }
  }

  async componentDidMount() {
    if(sessionStorage.getItem("githubsecret")){
      let githubsecret = JSON.parse(sessionStorage.getItem("githubsecret")!);
      sessionStorage.removeItem("githubsecret")
      if(await GithubSecretService.saveSecretKey(githubsecret)===200){
        alert("Record Saved Sucessfully !!");
      }
  }
  else{
    alert("Invalid Request Params");
  }
  this.setState({showSpinner : false});
  window.location.href ="/tools" ;       
 }

 render() {
    return <div key="gitprocessdiv">
        <SpinnersComponent key="gitprocessspinnercomponent" showspinner={this.state.showSpinner} />
    </div>;
 }
}
export default GitProcess;
