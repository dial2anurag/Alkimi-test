import React, { Component } from 'react'
import ToolsChildComponent , {
    ToolsChildComponentProps,
    ToolsChildComponentState
}
from '../../Base/ToolsChildComponent';
import GithubSecretService from '../../../../services/GitHub/GithubSecretService';
import AuthService from '../../../../services/Users/auth.service';
import {
    Form,
    Fields
} from '../../../../Components/CommonComponent';
import  { Div } from '../../Base/ToolsStypeComponent' ;
import { TextField } from '@material-ui/core';
import FormPost , {formPostParams} from '../../../../Components/FormPost'

interface GitHubState extends ToolsChildComponentState {
    clientid :string,
    secretkey :string,
    orgName:string,
    formPostParams :formPostParams[]
}

export class GitHub extends ToolsChildComponent<ToolsChildComponentProps,GitHubState> {
    constructor(props :ToolsChildComponentProps)
    {
        super(props);
        this.state = { 
            clientid : "",
            secretkey : "",
            orgName : "" ,
            showSpinner :false,
            headerText : "GitHub Credentials" ,
            formPostParams :[]
        };
        this.handleChange = this.handleChange.bind(this);
    }

    async renderFormPost(data :any){
        let currentHost =`${window.location.protocol}//${window.location.host}`;
        let redirectUrl=`${currentHost}/gitconcent`
        let user = AuthService.getCurrentUser();
        let githubsecret = {secret:data};
        sessionStorage.setItem("githubsecret", JSON.stringify(githubsecret));
        let prams : formPostParams[] =[];
        prams.push({ name : "scope",value : "repo" });
        prams.push({ name : "allow_signup",value : "false" });
        prams.push({ name : "login",value : user.email });
        prams.push({ name : "state",value : user.username });
        prams.push({ name : "client_id",value : data.clientId });
        prams.push({ name : "prompt",value : "consent" });
        prams.push({ name : "redirect_uri",value : redirectUrl });
        this.setState({formPostParams : prams});
      }

    override handleChange(event :any){
        switch(event.target.id){
            case "clientid":
                this.setState({clientid : event.target.value});
                break;
            case "secretkey":
                this.setState({secretkey : event.target.value});
                break;
            case "orgName":
                this.setState({orgName : event.target.value});
                break;
            default:
                break;
        }
    }

    override async handleSave() :Promise<boolean> {
        let returnvalue = false;
        
        if(this.state.clientid && this.state.secretkey && this.state.orgName){
            this.setState({showSpinner : true}); 
            let data = {
                clientId :this.state.clientid,
                secretKey :this.state.secretkey,
                orgName : this.state.orgName,
                refreshToken: ""
            }
            
            returnvalue=true;
            await this.renderFormPost(data);
            this.setState({showSpinner : false});  
          }
          else{
            returnvalue= false;
          }
          this.props.onModalStateChange(returnvalue);
          return returnvalue;
    }

    renderFormComponent(){
        return(<FormPost params={this.state.formPostParams} formProps={{
            action :`https://github.com/login/oauth/authorize`,
            method : 'GET'
          }}  />)
    }

    renderGitComponent(){
        return (
            <>
                <Div>
                    <Form>
                        <Fields>
                            <TextField id="clientid" label="Client ID" value={this.state.clientid} fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                        <Fields>
                            <TextField id="secretkey" label="Client Secret" value={this.state.secretkey} fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                        <Fields>
                            <TextField id="orgName" label="Organisation" value={this.state.orgName} fullWidth variant="outlined" onChange={this.handleChange} />
                        </Fields>
                    </Form>
                </Div>
            </>
        )
    }

    override renderComponent(){
        if(this.state.formPostParams && this.state.formPostParams.length >0){
           return this.renderFormComponent();
        }
        else{
            return this.renderGitComponent();
        }
    }
}

export default GitHub
