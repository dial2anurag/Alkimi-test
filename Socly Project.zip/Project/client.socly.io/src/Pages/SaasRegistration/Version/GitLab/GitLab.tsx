import ToolsChildComponent, { ToolsChildComponentProps, ToolsChildComponentState } from '../../Base/ToolsChildComponent';
import { Div } from '../../Base/ToolsStypeComponent';
import TextField from '@mui/material/TextField';
import { Form, Fields } from '../../../../Components/CommonComponent';
import GitLabSecretService from '../../../../services/GitLab/GitLabSecretService';
interface GitLabState extends ToolsChildComponentState {
    clientid: string,
    secretkey: string,
    workspace: string
}
export class GitLab extends ToolsChildComponent<ToolsChildComponentProps, GitLabState> {
    constructor(props: ToolsChildComponentProps) {
        super(props);
        this.state = {
            clientid: "",
            secretkey: "",
            workspace: "",
            showSpinner: false,
            headerText: "GitLab Credentials"
        };
        this.handleChange = this.handleChange.bind(this);
    }

    override handleChange(event: any) {
        switch (event.target.id) {
            case "clientid":
                this.setState({ clientid: event.target.value });
                break;
            case "secretkey":
                this.setState({ secretkey: event.target.value });
                break;
            case "workspace":
                this.setState({ workspace: event.target.value });
                break;
            default:
                break;
        }
    }

    override async handleSave(): Promise<boolean> {
        let returnvalue = false;
        if (this.state.clientid && this.state.secretkey
            && this.state.workspace) {
            this.setState({ showSpinner: true });
            let data = {
                clientId: this.state.clientid,
                secretKey: this.state.secretkey,
                workspace: this.state.workspace
            }
            if (await GitLabSecretService.saveSecretKey(data) === 200) {
                returnvalue = true;
            }
            else {
                returnvalue = false;
            }
            this.setState({ showSpinner: false });
        }
        else {
            returnvalue = false;
        }
        this.props.onModalStateChange(returnvalue);
        return returnvalue;
    }

    override renderComponent() {
        return (
            <Div>
                <Form>
                    <Fields>
                        <TextField id="clientid" label="Client ID" value={this.state.clientid} fullWidth variant="outlined" onChange={this.handleChange} />
                    </Fields>
                    <Fields>
                        <TextField id="secretkey" label="Client Secret" value={this.state.secretkey} fullWidth variant="outlined" onChange={this.handleChange} />
                    </Fields>
                    <Fields>
                        <TextField id="workspace" label="Workspace" value={this.state.workspace} fullWidth variant="outlined" onChange={this.handleChange} />
                    </Fields>
                </Form>
            </Div>
        );
    }
}
export default GitLab

