import React, { Component } from 'react'
import ToolsComponent, { ToolsComponentState } from '../Base/ToolsComponent';
import { AuthenitcatedComponentProps } from '../../Base/AuthenitcatedComponent';
import { VersionControlList } from '../../../Data/SaasProviders/VersionControls'
import GitHub from './GitHub/GitHub';
import BitBucket from './BitBucket';
import GitLab from './GitLab/GitLab'

export class VersionControl extends ToolsComponent<AuthenitcatedComponentProps, ToolsComponentState>  {
    constructor(props: AuthenitcatedComponentProps) {
        super(props);
        this.state = {
            children: null,
            headerText: "Version Control Provider",
            providers: VersionControlList
        }
        this.handleProvider = this.handleProvider.bind(this);
    }

    override handleProvider(provider: any) {
        switch (provider.key) {
            case "github":
                this.setState({ children: <GitHub pageid={this.props.pageid} onModalStateChange={this.onModalStateChange.bind(this)} /> });
                break;
            case "bitbucket":
                this.setState({ children: <BitBucket pageid={this.props.pageid} onModalStateChange={this.onModalStateChange.bind(this)} /> });
                break;
            case "gitlab":
                this.setState({ children: <GitLab pageid={this.props.pageid} onModalStateChange={this.onModalStateChange.bind(this)} /> });
                break;
            default:
                break;
        }
    }
}

export default VersionControl
