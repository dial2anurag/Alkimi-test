import React, { Component } from 'react'
import { IRouteFunctions } from '../../Model/SysModal/sysEntiry';
import AuthenitcatedComponent, {AuthenitcatedComponentProps} from './AuthenitcatedComponent';

export interface AuthenticatedRouteComponentProps extends AuthenitcatedComponentProps, IRouteFunctions {}

export abstract class AuthenticatedRouteComponent<P extends AuthenticatedRouteComponentProps, S = {} , SS = {} > extends AuthenitcatedComponent<P, S, SS> {
    public abstract render(): React.ReactNode;
    constructor(props: P) {
        super(props);
    }
}

export default AuthenticatedRouteComponent