import React, { Component, ReactNode } from 'react';
import { IRolePageComponent } from '../../Model/SysModal/sysEntiry';
import AuthenticatedBaseComponent from './AuthenticatedBaseComponent';
import RoleAccess from '../../services/Authorization/RoleAccess';
import AuthService from '../../services/Users/auth.service';
import {
    Navigate 
  } from "react-router-dom";

export interface AuthenitcatedComponentProps {
    pageid : number
}

export abstract class AuthenitcatedComponent<P extends AuthenitcatedComponentProps ,
                                            S={},SS={}> 
    extends AuthenticatedBaseComponent<P, S,SS>{
    private readonly _rolePageComponent : IRolePageComponent;
    constructor(props: P){
        super(props);
        this._rolePageComponent = this.getPageComponent();
    }
    public abstract override  render(): ReactNode;

    public get PageComponent():IRolePageComponent{
        return this._rolePageComponent;
    }
    
    private getPageComponent() : IRolePageComponent {
       let roledata= RoleAccess.getComponentsForUser();
       return roledata.find(e=> e.id===this.props.pageid) !;
    }

    public redirectToDefaultPage():void{
        AuthService.logout();
        // let pageComponents = AuthService.getUserAuthMenu();
        // if(! pageComponents || pageComponents.length <=0){
        //     AuthService.logout();
        //     return;
        // }
        // let defaultpage = pageComponents.find(e=> e.id=== this.PageComponent.roleData.defaultpage);
        // if(!defaultpage || ! defaultpage.path ){
        //     AuthService.logout();
        //     return;
        // }
        // window.location.href =defaultpage.path;
    }
}
export default AuthenitcatedComponent