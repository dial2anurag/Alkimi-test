import React, { Component, ReactNode } from 'react';
import AuthenticatedRouteComponent, {AuthenticatedRouteComponentProps} from './AuthenticatedRouteComponent'
import {FrameworkEntity} from '../../Model/Framework/FrameworkEntity'

export interface FrameworkComponentProps extends AuthenticatedRouteComponentProps {
    framework : FrameworkEntity
}

export abstract class FrameworkComponent<P extends FrameworkComponentProps ,S={} ,SS={}> 
    extends AuthenticatedRouteComponent<P,S,SS> {
    constructor(props : P){
        super(props);
    }
    public abstract render() : ReactNode ;
}
export default FrameworkComponent