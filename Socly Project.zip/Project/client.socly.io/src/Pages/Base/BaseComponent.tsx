import React, { Component, ReactNode } from 'react';
import LogService from '../../services/Common/LogService';


export abstract class BaseComponent<P ={} , S ={} , SS={} > extends Component<P,S,SS> {
    constructor(props : any){
        super(props);
    }

    public abstract render() : ReactNode ;

    public writelog(message :any) :void {
        LogService.writelog(message);
    }

    public deepCopy<T>(obj:T) : T | undefined{
        return LogService.deepCopy<T>(obj);
    }
    
    componentDidCatch(error : Error , errorInfo : React.ErrorInfo){
          this.writelog(error.message);
    }
}
export default BaseComponent    
