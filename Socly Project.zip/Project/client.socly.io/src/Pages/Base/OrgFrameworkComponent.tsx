import React, { Component } from 'react';
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from './AuthenitcatedComponent';
import AuthenticatedRouteComponent ,{AuthenticatedRouteComponentProps} from './AuthenticatedRouteComponent';
import {FrameworkEntity} from '../../Model/Framework/FrameworkEntity';
import UserFrameworkService from '../../services/Framework/UserFrameworkService';
import {Tabs,Tab} from 'react-bootstrap';

export interface OrgFrameworkComponentProps extends AuthenticatedRouteComponentProps{}
export interface OrgFrameworkComponentState {
    selectedframework ? : FrameworkEntity
}

export abstract class OrgFrameworkComponent<P extends OrgFrameworkComponentProps , S extends OrgFrameworkComponentState , SS={}> 
        extends AuthenticatedRouteComponent<P,S,SS> {
  private _frameworkEntities : FrameworkEntity [];
  constructor(props: P){
      super(props);
      this._frameworkEntities = [];
  }

  componentDidMount(){
    let selframework=UserFrameworkService.loadData();
    this._frameworkEntities = UserFrameworkService.OrgFramwork;
    this.setState({selectedframework : selframework});
    if(this.onComponentDidMount) this.onComponentDidMount();
  }
  

  public get frameworkEntities(): FrameworkEntity [] {
    return this._frameworkEntities;
  } 

  public get userFrameWorkService(){return UserFrameworkService;}
  abstract renderComponent(framework : FrameworkEntity) :JSX.Element ;
  onComponentDidMount ?() : void;

  protected setSelectedFramework(key: string | null) :void{
    if(! key){
      return;
    }
    let selframework = UserFrameworkService.setFramework(parseInt(key));
    this.setState({selectedframework : selframework});
  }

  protected renderTabComponent(framework : FrameworkEntity){
    if(!this.state.selectedframework ||  this.state.selectedframework !== framework){
      return (<></>);
    }
    else{
      return this.renderComponent(this.state.selectedframework);
    }
  }

  render() {
    if(! this._frameworkEntities || this._frameworkEntities.length <=0 || 
      ! this.state.selectedframework){
      return (<></>);
    }
    else if(this._frameworkEntities.length ===1){
      return this.renderComponent(this._frameworkEntities[0]);
    }
    else{
      return (
        <div>
            <Tabs 
            key="frameworktabs"
            activeKey={this.state.selectedframework?.id}
            defaultActiveKey ={this.state.selectedframework?.id}
            className="mb-3"
            variant='pills'
            onSelect ={this.setSelectedFramework.bind(this)}
            >
                {
                    this._frameworkEntities.map((framework,index)=>{
                        return (
                            <Tab
                              key={`frameworktabs-${framework.id}_${framework.name}(${index})`}
                              eventKey={framework.id}
                              title={framework.name}
                            >
                              {this.renderTabComponent(framework)} 
                            </Tab>
                        )
                    })
                }
            </Tabs>
        </div>
      )
    }
  }
}

export default OrgFrameworkComponent