import React, { Component, ReactNode } from 'react';
import BaseComponent from './BaseComponent';
import AuthService from '../../services/Users/auth.service';

export abstract class AuthenticatedBaseComponent<P={} , S={} , SS={}> 
       extends BaseComponent<P,S,SS>{
    constructor(props: P){
        super(props);
        if(!AuthService.getCurrentUser()){
            AuthService.logout();
        }
    }
    public abstract override  render(): ReactNode;
    public get UserProfile () : any {
        return AuthService.getCurrentUser();
    }
}
export default AuthenticatedBaseComponent
