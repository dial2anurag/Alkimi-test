import React, { Component } from 'react'
import Button from '@mui/material/Button';
import * as Yup from "yup";
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import DesktopDatePicker from '@mui/lab/DesktopDatePicker';
import TextField from '@mui/material/TextField';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import AuditPeriodService from '../../services/Organization/AuditPeriodService';
import SpinnersComponent from '../../Components/SpinnersComponent';
import AuthService from '../../services/Users/auth.service';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';


type Auditstate = {
    audit_periods :any[],
    auditid: number | null,
    startDate: Date | null,
    endDate: Date | null,
    intDate: Date | null,
    period: string,
    status: "O" | "R" | null,
    frameworkid : number | null,
    type :"Type1" | "Type2" | null,
    showspinner :boolean
};

type AuditperiodProps = {
    orgData: any
}

export default class AuditPeriod extends AuthenticatedBaseComponent<AuditperiodProps, Auditstate> {
    private _registeredFramework : FrameworkEntity[];  
    constructor(props: AuditperiodProps) {
        super(props);
        this._registeredFramework=[];
        Array.prototype.forEach.call(this.props.orgData.frameworks,(e,index)=>{
            this._registeredFramework.push({id : e.id , name : e.name});
        })
        this.state = {
            audit_periods :[],
            auditid: null,
            startDate: null,
            endDate: null,
            intDate: null,
            status: "O",
            period: "",
            frameworkid : null,
            type :null,
            showspinner : false
        };
    }

    async componentDidMount() {
        this.setState({showspinner : true})
        let response = await AuditPeriodService.getActiveAuditPeriod(this.props.orgData.clientId);
        
        if (response.status === 200 && response.data.length > 0) {
            let auditDatalist = Array.prototype.filter.call(response.data,((e : any)=> e.status==="O"));
            if(auditDatalist.length > 0){
                this.setState({
                    showspinner : false,
                    audit_periods : auditDatalist,
                    auditid: auditDatalist[0].auditId,
                    startDate: new Date(auditDatalist[0].startDate),
                    endDate: new Date(auditDatalist[0].endDate),
                    period: auditDatalist[0].period,
                    status: auditDatalist[0].status,
                    frameworkid : auditDatalist[0].framework.id,
                    intDate: new Date(auditDatalist[0].auditInitiateDate)
                })
            }
            else{
                this.setState({showspinner : false});
            }
        }
        else{
            this.setState({showspinner : false});
        }
    }

    validationSchema() {
        return Yup.object().shape({
            date: Yup.date().required("This field is required!"),
            name: Yup.string()
                .test(
                    "len",
                    "The name must be between 3 and 50 characters.",
                    (val: any) =>
                        val &&
                        val.toString().length >= 3 &&
                        val.toString().length <= 50
                )
                .required("This field is required!"),
            description: Yup.string()
                .min(3).max(2000)
                .notRequired()
            
        })
    }

    handleStartDate = (date: any) => {
        this.setState({
            startDate: date
        });
    };

    handleEndDate = (date: any) => {
        this.setState({
            endDate: date

        });

    };
    handleInitiation = (date: any) => {
       let enddate : Date = new Date(date);
       enddate.setDate(date.getDate() -1); 
        this.setState({intDate: date , endDate : enddate})
    };

    handleDropChange = (event: any) => {
        this.setState({ status: event.target.value })
    }

    handleFrameworkDropChange = (event: any) => {
        let value : number = event.target.value;
        if(this.state.audit_periods && this.state.audit_periods.length >0){
            let val = Array.prototype.find.call(this.state.audit_periods,e=> e.framework.id === value);
            if(val){
                this.setState({
                    auditid: val.auditId,
                    startDate: new Date(val.startDate),
                    endDate: new Date(val.endDate),
                    period: val.period,
                    status: val.status,
                    frameworkid : val.framework.id,
                    intDate: new Date(val.auditInitiateDate)
                })
               return; 
            }
        }
        this.setState({ 
            frameworkid: value ,
            auditid : null,
            startDate :null,
            endDate :null,
            intDate :null,
            period :"",
            status : "O",
            type : null
        });
    }

    handleTypeDropChange = (event: any) => {
        this.setState({ type: event.target.value })
    }

    handleDescriptionChange = (event: any) => {
        this.setState({ period: event.target.value })
    }

    handleSubmitClick = async (event: any) => {
        event.preventDefault();
        if (this.state.period.trim().length > 0 &&
        this.state.startDate &&
        this.state.endDate && (this.state.endDate > this.state.startDate) &&
        this.state.intDate &&
        this.state.intDate > this.state.startDate &&
        this.state.status &&
        this.state.frameworkid ) {
            this.setState({showspinner : true})
            let update :boolean =false;
            let data: any = {
                orgId: this.props.orgData.clientId,
                status: this.state.status,
                period: this.state.period,
                startDate: this.state.startDate.toISOString().split('T')[0],
                endDate: this.state.endDate.toISOString().split('T')[0],
                auditInitiateDate: this.state.intDate.toISOString().split('T')[0],
                framework :{id : this.state.frameworkid}
            }
            let response : IRestResponseEntity ;
            if (this.state.auditid) {
                update =true;
                data["auditId"] = this.state.auditid;
                response= await AuditPeriodService.updateAuditPeriod(data);
            }
            else {
                response = await AuditPeriodService.insertAuditPeriod(data);
            }
            if(response.status ===200){
                let audit_periods = this.state.audit_periods;
                if(! audit_periods){
                    audit_periods =[];
                }
                if(update){
                    let auditperiodindex = audit_periods.findIndex(e=> e.auditId === response.data.auditId);
                    if(auditperiodindex >-1){
                        audit_periods.splice(auditperiodindex);
                    }
                }
                audit_periods.push(response.data);
                this.setState(
                    {
                        audit_periods : audit_periods, 
                        auditid : response.data.auditId
                    });
                alert("Audit Period saved successfully");
            }
            this.setState({showspinner : false})
        }
    }

    renderOrganization(){
        return(
            <div key="orgrow1" className='row no-gutters border border-dark border-start-0 border-top-0 border-end-0 pt-1 pb-2 mb-4'>
                <div key="orgrow1col1" className='col-md-6 text-left'>
                    <label key="lblorgname">Name</label> : {this.props.orgData.orgName}
                </div>
                <div key="orgrow1col2" className='col-md-6 text-right'>
                    <label key="lblorgdescription" >Description</label>:  {this.props.orgData.description}
                </div>
            </div>
        )
    }

    renderAuditPeriod(){
        return(
            <>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                <div key="auditperiodrow1" className='row no-gutters pb-2 mb-2'>
                    <div key="auditperiodrow1col1"  className='col text-left h5'>
                        Audit Period
                    </div>
                </div>
                <div key="auditperiodrow2" className='row no-gutters pb-2 mb-2'>
                    <div key="auditperiodrow2col1" className='col-md-3 text-left'>
                        <FormControl key="frmctrlframework">
                            <InputLabel key="lblframework" id="select-framework">Framework</InputLabel>
                            <Select
                                key="ddlframework"
                                labelId="select-framework"
                                label="Framework"
                                value={this.state.frameworkid}
                                onChange={this.handleFrameworkDropChange.bind(this)}
                                style={{ width: '10.5em' }}
                            >
                                {
                                    this._registeredFramework.map((itm,index)=>{
                                        return(
                                            <MenuItem key={`framework-${index}-${itm.id}`} value={itm.id}>{itm.name.toUpperCase()}</MenuItem>
                                        )
                                    })
                                }
                            </Select> 
                        </FormControl>
                    </div>
                    <div key="auditperiodrow2col2" className='col-md-3 text-left'>
                        {/* <FormControl key="frmctrltype">
                            <InputLabel key="lbltype" id="select-type">Type</InputLabel>
                            <Select
                                key="ddltype"
                                labelId="select-type"
                                label="Type"
                                value={this.state.type}
                                onChange={this.handleTypeDropChange.bind(this)}
                                style={{ width: '10.5em' }}
                            >
                                <MenuItem key={`type-type1`} value="Type1">Type1</MenuItem>
                                <MenuItem key={`type-type2`} value="Type2">Type2</MenuItem>
                            </Select> 
                        </FormControl> */}
                    </div>
                    <div key="auditperiodrow2col3" className='col-md-3 text-left'>
                        <TextField
                            id="description"
                            key="txtdescription"
                            label="Description"
                            variant="outlined"
                            style={{ width: '10.5em' }}
                            onChange={this.handleDescriptionChange.bind(this)}
                            value={this.state.period}
                        />                    
                    </div>
                    <div key="auditperiodrow2col4" className='col-md-3 text-left'>
                        <FormControl key="frmctrlstatus">
                            <InputLabel key="lblstatus" id="select-status">Status</InputLabel>
                            <Select
                                key="ddlstatus"
                                labelId="select-status"
                                label="Status"
                                value={this.state.status}
                                onChange={this.handleDropChange.bind(this)}
                                style={{ width: '10.5em' }}
                            >
                                <MenuItem key="select-status-option-O" value="O">Active</MenuItem><br />
                                <MenuItem key="select-status-option-C" value="C">Closed</MenuItem>
                            </Select>
                        </FormControl>
                    </div>
                </div>
                <div key="auditperiodrow3" className='row no-gutters pb-2 mb-2'>
                    <div key="auditperiodrow3col1" className='col-md-3 text-left'>
                        <DesktopDatePicker
                            key="dtstartdate"
                            label="Start Date"
                            inputFormat="dd/MM/yyyy"
                            value={this.state.startDate}
                            onChange={this.handleStartDate.bind(this)}
                            renderInput={(params) => 
                                <TextField 
                                    style={{ width: '10.5em' }} 
                                    sx={{ input: { textAlign: "center" } }} 
                                    {...params} />}
                        />               
                    </div>
                    <div key="auditperiodrow3col2" className='col-md-3 text-left'>
                        <DesktopDatePicker
                            key="dtinitdate"
                            label="Initiation Date"
                            inputFormat="dd/MM/yyyy"
                            value={this.state.intDate}
                            onChange={this.handleInitiation}
                            minDate={this.state.startDate ? (this.state.startDate < new Date() ? new Date() : this.state.startDate) : new Date()}
                            renderInput={(params) => 
                                <TextField 
                                    sx={{ input: { textAlign: "center" } }} 
                                    style={{ width: '10.5em' }}
                                    {...params} />}
                        />            
                    </div>
                    <div key="auditperiodrow3col3" className='col-md-3 text-left'>
                        <DesktopDatePicker
                            disabled = {true}
                            key="dtenddate"
                            label="End Date"
                            inputFormat="dd/MM/yyyy"
                            value={this.state.endDate}
                            onChange={this.handleEndDate.bind(this)}
                            minDate={this.state.startDate ? new Date(this.state.startDate) : new Date()}
                            renderInput={(params) => 
                                <TextField 
                                sx={{ input: { textAlign: "center" }}}
                                style={{ width: '10.5em' }}
                                {...params} />}
                        />            
                    </div>
                    <div key="auditperiodrow3col4" className='col-md-3 text-left'>
                        <Button
                            key="btnsubmit"
                            variant="contained"
                            style={{
                                width: '10.5em', alignItems: 'center',
                                marginTop: '10px', marginLeft: '20px', height: '3.5em'
                            }}
                            onClick={this.handleSubmitClick.bind(this)}
                        >Submit</Button>            
                    </div>
                </div>
                </LocalizationProvider>
            </>
        )
    }

    render() {
        return (
            <>
                <SpinnersComponent key="auditperiodspinnercomponent" showspinner={ this.state.showspinner }  />
                <div key="containerdiv" className='container border border-dark rounded'>
                    {this.renderOrganization()}
                    {this.renderAuditPeriod()}
                </div>

            </>
        )

    }
}