import React, { Component } from 'react';
import { ContentHeading, PageContainer } from '../../StyledComponents/ComponentWrapper';
import { ColDef, GridReadyEvent, ICellRendererComp, ICellRendererParams } from 'ag-grid-community';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { AgGridReact } from 'ag-grid-react';
import OrgRegistration from '../../services/Organization/OrgRegistration';
import { Button, Modal } from 'react-bootstrap'
import OrganisationRegistration from '../Registrations/Organisation/OrganisationRegistration'
import AuditPeriod from './AuditPeriod';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../Base/AuthenticatedRouteComponent';

type OrgListState = {
    orgList: any[],
    showModal: boolean,
    selectedOrg: any | null
}

export class OrgList extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, OrgListState> {
    protected gridInstance: GridReadyEvent | undefined;
    constructor(props: AuthenticatedRouteComponentProps) {
        super(props);
        this.state = {
            orgList: []
            , showModal: false
            , selectedOrg: null
        }

        this.onGridEditClick = this.onGridEditClick.bind(this);
    }

    async componentDidMount() {
        let response = await OrgRegistration.getOrganization()
        let orgs: any[] = [];
        if (response.status === 200) {
            this.setState({ orgList: response.data })
        }
        this.setAndRefreshGrid();
    }

    async handleClose(event: any) {
        this.setState({ showModal: false });
    }

    handleAddOrg(event: any) {
        this.setState({
            showModal: true,
            selectedOrg: null,
        })
    }

    gridColumnDef(): ColDef[] {
        return [{
            field: "orgName",
            headerName: "Name",
            wrapText: true,
            autoHeight: true,
            width: 100
        }, {
            field: "description",
            headerName: "Description",
            wrapText: true,
            autoHeight: true,
            width: 100
        }, {
            field: "registeredDateTime",
            headerName: "Registration Date",
            wrapText: true,
            autoHeight: true,
            width: 100,
            cellRenderer: (params) => {
                let dt = new Date(params.value);
                return `${dt.getDate()}-${dt.getMonth()}-${dt.getFullYear()}`
            }
        }, {
            field: "detailFilled",
            headerName: "SAAS Registered",
            wrapText: true,
            autoHeight: true,
            width: 100
        }, {
            field: "status",
            headerName: "Status",
            wrapText: true,
            autoHeight: true,
            width: 100
        },
        {
            field: "clientId",
            headerName: "Edit",
            filter: false,
            sortable: false,
            cellRendererFramework: (params: any) => {
                return (
                    <Button key={`Edit(${params.value})`}
                        className="btn-sm" variant='primary'
                        onClick={(e) => this.onGridEditClick(e, params)}>View</Button>
                )
            }
        }
        ]
    }

    defaultGridColumnsDef(): ColDef {
        return {
            sortable: true,
            resizable: true,
            filter: true,
            flex: 1
        }
    }

    onGridReady(params: GridReadyEvent) {
        this.gridInstance = params;
        this.setAndRefreshGrid();
    }



    setAndRefreshGrid() {
        if (this.gridInstance) {
            this.gridInstance.api.refreshCells();
        }
    }

    onGridEditClick(event: any, params: any) {
        let data = this.state.orgList.find(e => e.clientId === params.value);
        this.setState({selectedOrg: data, showModal :false})
    }

    handleBackClick(event: any){
        this.setState({selectedOrg : null , showModal :false})
    }

    renderOrgDetail(){
        return(
            <PageContainer key={"ChildPageContainer"}>
                <div key="Childcontainer" className='container'>
                    <div key="Childrow1" className='row'>
                        <div key="Childrow1col1" className='col div-export-button'>
                            <Button key="ChildorgdetailBack"
                                variant='primary'
                                onClick={this.handleBackClick.bind(this) }
                            >
                               <ArrowBackIosNewIcon fontSize='small' /> Back
                            </Button>
                        </div>
                    </div>
                    <div key="Childrow2" className='row'>
                        <div key="Childrow2col1" className='col'>
                            <AuditPeriod key={"ChildOrgdetailauditperiod"} orgData={this.state.selectedOrg} />
                        </div>
                    </div>
                </div>
            </PageContainer>)
    }

    renderModal() {
        if(!this.state.showModal){
            return (<></>)
        }

        return (
            <Modal
                key="Orgmodal"
                show={this.state.showModal} onHide={this.handleClose.bind(this)}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                backdrop={"static"}
                keyboard={false}
                centered>
                <Modal.Header closeButton>Organization Registration</Modal.Header>
                <Modal.Body><OrganisationRegistration pageid={this.props.pageid} handleModalClose={this.handleClose.bind(this)}  key={"orgRegistration"} /></Modal.Body>
            </Modal>
        )
    }

    renderComponent() {
        return (
            <PageContainer key={"PageContainer"}>
                <div key="container" className='container'>
                    <div key="row1" className='row'>
                        <div key="row1col1" className='col div-export-button'>
                            <Button key="aggridaddOrg"
                                variant='primary'
                                onClick={this.handleAddOrg.bind(this)}
                            >
                                Add Organization
                            </Button>
                        </div>
                    </div>
                    <div key="row2" className='row'>
                        <div key="row2col1" className='col'>
                            <div key="aggriddiv" className="ag-theme-alpine" style={{ height: 600, width: "100%", textAlign: "left" }}>
                                <AgGridReact
                                    key="aggrid"
                                    defaultColDef={this.defaultGridColumnsDef()}
                                    columnDefs={this.gridColumnDef()}
                                    enableCellChangeFlash={true}
                                    onGridReady={this.onGridReady.bind(this)}
                                    pagination={true}
                                    paginationPageSize={10}
                                    rowData={this.state.orgList}
                                >
                                </AgGridReact>
                            </div>
                        </div>
                    </div>
                </div>
            </PageContainer>
        )
    }

    render() {
       if(this.state.selectedOrg){
           return (<>{this.renderOrgDetail()}</>)
       }

        return (<>
            {this.renderComponent()}
            {this.renderModal()}
        </>)
    }
}
export default OrgList