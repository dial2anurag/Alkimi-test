import React, { Component } from 'react'
import { ContentHeading, PageContainer } from '../../StyledComponents/ComponentWrapper';
import AuthService from '../../services/Users/auth.service'
import OrgService from '../../services/Organization/OrgService'
import { ColDef, GridReadyEvent, ICellRendererComp, ICellRendererParams } from 'ag-grid-community';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { AgGridReact } from 'ag-grid-react';
import { RoleMappings } from '../../Data/SysData/roleMapping'
import {Button,Modal} from 'react-bootstrap';
import UserUpdate from '../Users/UserUpdate';
import UserRegistrationInt from '../Users/UserRegistrationInt';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../Base/AuthenticatedRouteComponent';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import OrganisationDetails from './OrganisationDetails';

type OrgUsersState = {
  usersList: any[],
  selectedUser: any|null,
  update: boolean,
  showModal:boolean,
  showOrgDetails: boolean
}
export class OrgUsers extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, OrgUsersState> {
  protected gridInstance: GridReadyEvent | undefined;
  protected _orgName : string ;
  constructor(props: AuthenticatedRouteComponentProps) {
    super(props);
    let user = AuthService.getCurrentUser();
    this._orgName = user.organization.orgName;
    this.state = {
      showModal:false,
      usersList: [],
      update:false,
      selectedUser:null,
      showOrgDetails: false
    }
  }

  async componentDidMount() {
    await this.getOrgUserList();
  }

  async getOrgUserList() {
    let response = await OrgService.getOrgUsers();
    if (response.status !== 200) {
      alert(response.message);
      return;
    }

    let roles: string[] = [];
    let users: any[] = [];
    Array.prototype.forEach.call(response.data, (itm, indx) => {
      roles = [];
      Array.prototype.forEach.call(itm.roles, (subitm, idx) => {
        roles.push(RoleMappings[subitm.name.toUpperCase()]);
      });
      itm["roles"] = roles;
      users.push(itm);
    })
    
    this.setState({ usersList: users});
    this.setAndRefreshGrid();
  }

  async handleClose(event: any) {
    this.setState({ showModal: false });
  }

  handleCallback = async (value:boolean) => {
    await this.getOrgUserList();
    if(value === true) {
      this.setState({showModal:false});
    } else {
      this.setState({showModal:true})
    }
  }

  handleAddUser(event: any) {
    this.setState({
        showModal: true,
        selectedUser: null,
    })
  }

  handleOrgDetails() {
    this.setState({showOrgDetails: true});
  }

  gridColumnDef(): ColDef[] {
    return [{
      field: "username",
      headerName: "Credential",
      width: 100,
    }, {
      field: "name",
      headerName: "Name",
      wrapText: true,
      autoHeight: true,
      width: 100
    }, {
      field: "email",
      headerName: "Email",
      wrapText: true,
      autoHeight: true,
      width: 100
    }, {
      field: "phone",
      headerName: "Phone",
      wrapText: true,
      autoHeight: true,
      width: 100
    }, {
      field: "roles",
      headerName: "Roles",
      wrapText: true,
      autoHeight: true,
      width: 300
    },
    {
      field: "status",
      headerName: "Status",
      wrapText: true,
      autoHeight: true,
      width: 300
    },
    {
      field: "username",
      headerName: "Edit",
      filter: false,
      sortable: false,
      cellRendererFramework: (params: any) => {
          return this.loadViewButton(params);
      }
  }]
  }
  
  loadViewButton(params : any){
    let userProfile = AuthService.getCurrentUser();
    if(params.value.toUpperCase() === userProfile.username.toUpperCase()){
      return (<></>)
    }
    else{
        return (
          <Button key={`Edit(${params.value})`}
              className="btn-sm" variant='primary'
              onClick={(e) => this.onGridEditClick(e, params)}>View</Button>
      )
    }
  }

  onGridEditClick(event: any, params: any) {
      let data = this.state.usersList.find(e => e.username === params.value);
      this.setState({selectedUser:data,showModal:true});
  }

  defaultGridColumnsDef(): ColDef {
    return {
      sortable: true,
      resizable: true,
      filter: true,
      flex: 1
    }
  }

  onGridReady(params: GridReadyEvent) {
    this.gridInstance = params;
    this.setAndRefreshGrid();
  }

  handleBackClick(event: any){
    this.setState({selectedUser: null})
  }

  handleBack(){
    this.setState({showOrgDetails: false})
  }

  setAndRefreshGrid() {
    if (this.gridInstance) {
      this.gridInstance.api.refreshCells();
    }
  }

  renderUpdateOrgDetail(){
    return(
        <PageContainer key={"ChildPageContainer"}>
            <div key="Childcontainer" className='container'>
                <div key="Childrow1" className='row'>
                    <div key="Childrow1col1" className='col div-export-button'>
                        <Button key="ChildorgdetailBack"
                            variant='primary'
                            onClick={this.handleBack.bind(this) }
                        >
                           <ArrowBackIosNewIcon fontSize='small' /> Back
                        </Button>
                    </div>
                </div>
                <div key="Childrow2" className='row'>
                    <div key="Childrow2col1" className='col'>
                        <OrganisationDetails key={"organisationDetails"} />
                    </div>
                </div>
            </div>
        </PageContainer>)
  }

  renderModal() {
    const {showModal, selectedUser} = this.state;
    if(!showModal){
        return (<></>)
    }
        if(selectedUser===null)
        {
        return (
        <Modal
            key="Usrmodal"
            show={showModal} onHide={this.handleClose.bind(this)}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            backdrop={"static"}
            keyboard={false}
            centered>
            <Modal.Header closeButton>User Registration</Modal.Header>
            <Modal.Body><UserRegistrationInt key={"orgRegistration"} handleCallback={(value: boolean) => this.handleCallback(value)} /></Modal.Body>
        </Modal>
    )
    }
  
    if(selectedUser!=null)
    {
    return (
      <Modal
        key="Orgmodal"
        show={showModal} onHide={this.handleClose.bind(this)}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        backdrop={"static"}
        keyboard={false}
        centered>
        <Modal.Header closeButton> User Update </Modal.Header>
        <Modal.Body><UserUpdate usrData={selectedUser} key={"UserUpdate"} handleCallback={(value:boolean)=>this.handleCallback(value)} /></Modal.Body>
    </Modal>
      )
    }
  }

  renderComponent() {
    return (
      <PageContainer>
          <div key="row1" className='row'>
            <div key="row1col1" className='col div-export-button'>
                <Button key="aggridaddOrg"
                    variant='primary'
                    onClick={this.handleAddUser.bind(this)}>
                    Add User
                </Button>
            </div>
        </div>
        <div>
          <ContentHeading className='text-anchor' onClick={this.handleOrgDetails.bind(this)}>{this._orgName}</ContentHeading>
          <div className="ag-theme-alpine" style={{ height: 400, width: "100%", textAlign: "left" }}>
            <AgGridReact
              defaultColDef={this.defaultGridColumnsDef()}
              columnDefs={this.gridColumnDef()}
              enableCellChangeFlash={true}
              onGridReady={this.onGridReady.bind(this)}
              pagination={true}
              paginationPageSize={10}
              rowData={this.state.usersList}
            >
            </AgGridReact>
          </div>
        </div>
      </PageContainer>
    )
  }
  render() {
    if(this.state.showOrgDetails){
        return (<>{this.renderUpdateOrgDetail()}</>)
    }

     return (<>
         {this.renderComponent()}
         {this.renderModal()}
     </>)
 }
 
}
export default OrgUsers