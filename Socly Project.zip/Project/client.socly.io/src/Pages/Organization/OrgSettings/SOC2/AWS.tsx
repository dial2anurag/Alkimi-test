
import AdditionalSettingChildComponent,{
    KeyData, 
    AdditionalSettingChildComponentProps,
    AdditionalSettingChildComponentState
} from '../Base/AdditionalSettingChildComponent';


interface Awsstate extends AdditionalSettingChildComponentState {
    arn: string 
}

export default class AWS extends 
        AdditionalSettingChildComponent<AdditionalSettingChildComponentProps, Awsstate>{
    constructor(props: any) {
        super(props)
        let arn : string ="";
        this.state = {
            arn: arn,
            showspinner :false
        }
        this.HeaderText="";
        this.Width=50;
    }

    override loadComponentData(data: any): void {
        if(data && data.length > 0){
            let arndata = Array.prototype.find.call(data, e=> e.name="ARN");
            if(arndata){
                this.setState({arn :arndata.configurationValue}) ;
            }
        }
    }

    override onButtonClick(event: any, keyData: KeyData): any[] {
        let arrData : any[]=[];
        if(this.state.arn.length > 0){
            arrData.push({
                saasId : this.props.keyData.saas,
                frameworkId : this.props.keyData.framework.id,
                name : "ARN",
                configurationValue : this.state.arn
            });
        }
        return arrData;
    }

    handleChange = (e: any) => {
        this.setState({ arn: e.target.value });
    };

    override renderComponent(): JSX.Element {
        const { arn } = this.state;
        return(<div key="awscontainer" className='container'>
                    <div key="awsrow1" className='row'>
                        <div key="awsrow1col1" className='col-md-3'>Multiple ARN'S</div>
                        <div key="awsrow1col2" className='col-md-9'>
                            <textarea 
                                placeholder="Enter multiple ARN's" 
                                value={arn} 
                                onChange={this.handleChange.bind(this)} />
                        </div>
                    </div>
                </div>)
    }
}