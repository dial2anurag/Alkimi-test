import AdditionalSettingChildComponent,{
    KeyData, 
    AdditionalSettingChildComponentProps,
    AdditionalSettingChildComponentState
} from '../Base/AdditionalSettingChildComponent';
import Stack from '@mui/material/Stack';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import DesktopDatePicker from '@mui/lab/DesktopDatePicker';
import TextField from '@mui/material/TextField';

interface BITBUCKETState extends AdditionalSettingChildComponentState {
    fromDate :Date
}

export class BITBUCKET extends AdditionalSettingChildComponent<AdditionalSettingChildComponentProps, BITBUCKETState> {
    constructor(props: any) {
        super(props)
        this.state = {
            showspinner :false,
            fromDate: new Date()
        }
        this.HeaderText="";
        this.Width=25;
    }

    override loadComponentData(data: any): void {
        if(data && data.length > 0){
            let fromDatedata = Array.prototype.find.call(data, e=> e.name="fromDate");
            if(fromDatedata){
                this.setState({fromDate :fromDatedata.configurationValue}) ;
            }
        }
    }

    override onButtonClick(event: any, keyData: KeyData): any {
        let arrData : any[]=[];
        if(this.state.fromDate){
            arrData.push({
                saasId : this.props.keyData.saas,
                frameworkId : this.props.keyData.framework.id,
                name : "fromDate",
                configurationValue : this.state.fromDate.toISOString().split('T')[0]
            });
        }
        return arrData;
    }

    handleDatechange(date:any){
        this.setState({fromDate :new Date(date)});
    }
    override renderComponent(): JSX.Element {
        return(<>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <Stack spacing={3}>
                        <DesktopDatePicker 
                        label="From Date" 
                        maxDate={new Date()} 
                        inputFormat="dd/MM/yyyy" 
                        value={this.state.fromDate}
                        onChange={this.handleDatechange.bind(this)}  
                        renderInput={(params) => <TextField {...params}  />} />
                    </Stack>
                </LocalizationProvider>
            </>)
    }   
}

export default BITBUCKET