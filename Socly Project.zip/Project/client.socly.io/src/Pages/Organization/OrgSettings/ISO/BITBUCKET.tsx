import React, { Component } from 'react';
import SOC2BITBUCKET from '../SOC2/BITBUCKET';

export class BITBUCKET extends SOC2BITBUCKET {
  constructor(props :any){
      super(props);
  }
}

export default BITBUCKET