import React, { Component } from 'react';
import SOC2AWS from '../SOC2/AWS';


export class AWS extends SOC2AWS {
  constructor(props:any){
      super(props);
  }
}
export default AWS