import React, { Component } from 'react'
import {
    Button , 
    Card
} from 'react-bootstrap';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import { FrameworkEntity } from '../../../../Model/Framework/FrameworkEntity';
import OrgSettingService from '../../../../services/Organization/OrgSettingService';
import AuthenticatedBaseComponent from '../../../Base/AuthenticatedBaseComponent';
import '../additionalsetting.css';

export type KeyData ={
    saas : string , 
    framework : FrameworkEntity
}

export interface AdditionalSettingChildComponentProps {
    keyData : KeyData
}

export interface AdditionalSettingChildComponentState {
    showspinner :boolean
}

export abstract class AdditionalSettingChildComponent<P extends AdditionalSettingChildComponentProps,
                                                      S extends AdditionalSettingChildComponentState,
                                                      SS={}> extends AuthenticatedBaseComponent<P,S,SS>
{
   public abstract renderComponent() : JSX.Element;
   public abstract onButtonClick(event:any, keyData : KeyData) : any[]
   public abstract loadComponentData(data :any) :void
   private _width : 25 | 50 |75 |100 ;
   protected get Width() : 25 | 50 |75 |100 {return this._width;} 
   protected set Width(value: 25 | 50 |75 |100) {this._width = value;} 
   
   private _headertext :string
   protected get HeaderText() :string  {return this._headertext;}
   protected set HeaderText(value :string) {this._headertext =value ;}

   constructor(props: P){
       super(props);
        this._width=50;
        this._headertext=""
   }

   async componentDidMount(){
        this.setState({showspinner :true})
        let response = await OrgSettingService.getOrgSetting(this.props.keyData.framework.id ,this.props.keyData.saas);
        if(response.status ===200){
            this.loadComponentData(response.data);
        }
        this.setState({showspinner :false})
   }
   
   async handleButtomClick(event: any){
        event.preventDefault();
        this.setState({showspinner : true});
        let dataarr = this.onButtonClick(event,this.props.keyData);
        if(!dataarr || dataarr.length<=0){
            this.setState({showspinner : false});
            return;
        }
        await OrgSettingService.saveOrgSetting({dataarr:dataarr,
            frameworkid:this.props.keyData.framework.id,
            saas: this.props.keyData.saas});
            
        this.setState({showspinner : false});
   }

    render(){
        return(
            <>
                <Card 
                    key={"Card-0"}
                    bg='light'
                    className={`w-${this._width} mt-3 card-style sticky-top`}
                >
                    <Card.Header key={"card-head-1"}>{this._headertext}</Card.Header>
                    <Card.Body key={"card-body-1"}>{this.renderComponent()}</Card.Body>
                    <Card.Footer key={"card-footer-1"}>
                        <Button 
                            key={"SaveButton"} 
                            variant="primary" 
                            className='px-4' 
                            type ="button" 
                            onClick={this.handleButtomClick.bind(this)}>
                                Submit
                        </Button>
                    </Card.Footer>
                </Card>
                <SpinnersComponent showspinner = {this.state.showspinner} key={"addsettingchildelespinnercomponent"}/>
            </>
        )
    }
}
export default AdditionalSettingChildComponent