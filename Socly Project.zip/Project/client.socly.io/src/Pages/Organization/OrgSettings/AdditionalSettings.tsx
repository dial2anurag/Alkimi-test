import React, { Component } from 'react'
import  './additionalsetting.css';
import OrgService from '../../../services/Organization/OrgService';
import AuthService from '../../../services/Users/auth.service';
import { KeyData } from './Base/AdditionalSettingChildComponent';
import { FrameworkEntity } from '../../../Model/Framework/FrameworkEntity';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../../Base/AuthenticatedRouteComponent';


type AdditionalSettingsState ={
  selectedframework :FrameworkEntity| null
  selectedsaas :string | null
}

export class AdditionalSettings extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps,AdditionalSettingsState> {
  private _saasProviders : any[];
  private _registeredFramework : any[];
  constructor(props: any){
    super(props);
    this._saasProviders=OrgService.getOrgSaasProviders();
    let userprofile= AuthService.getCurrentUser();
    this._registeredFramework = userprofile.organization.frameworks;
    this.state ={
        selectedframework :  null,
        selectedsaas :null
    }
  }

  async handleChange(event : any){
    switch(event.target.id){
      case "frameworkoption":{
        if(event.target.value.toUpperCase() === "Select".toUpperCase()){
          this.setState ({selectedframework : null});
        }
        else{
          let arr = event.target.value.split("~");
          this.setState ({selectedframework :  {id :  parseInt(arr[0]), name : arr.length > 0 ? arr[1] : ""}})
        }
        break;
      } 
      case "saasoption":{
        if(event.target.value.toUpperCase() === "Select".toUpperCase()){
          this.setState ({selectedsaas : null});
        }
        else{
          this.setState({selectedsaas : event.target.value});
        }
        break;
      }
    }
  }

  renderChildren(){
    let err :boolean=false;
    let Component : any;
    if(!this.state.selectedframework  || ! this.state.selectedsaas ){
      return (<></>);
    }
    else{
      try {
        Component = require(`./${this.state.selectedframework.name.toUpperCase()}/${this.state.selectedsaas}`).default;   
        if(!Component){
          err =true;
        }
      } catch (error) {
        err = true;
      }
    }
    if(err){
      return (<b> No OrgSetting exists for selected option</b>);
    }
    else{
      let keyData : KeyData = {framework : this.state.selectedframework! , saas : this.state.selectedsaas};
      return (<Component keyData = {keyData} />)
    }
  }

  render() {
    return (
      <div key="addsettingcontainer" className='parentdiv container'>
        <div key="addsettingcontainerrow1" className='row flex-row g-0'>
            <div key="addsettingcontainerrow1col1" className='col-md-2 text-start'>Framework :</div>
            <div key="addsettingcontainerrow1col2" className='col-md-3 text-start'>
                <select key="framework" title='Framework' id="frameworkoption" 
                className="form-select" onChange={this.handleChange.bind(this)}>
                  <option key="framework-select" value="Select">SELECT</option>
                    {
                      this._registeredFramework.map((itm,index)=>{
                        return(
                          <option key={`framework-${index}`} value={`${itm.id}~${itm.name.toUpperCase()}`}>{itm.name.toUpperCase()}</option>
                        )
                      })
                    }
                </select>
            </div>
            <div key="addsettingcontainerrow1col3" className='col-md-1 text-start'></div>
            <div key="addsettingcontainerrow1col4" className='col-md-2 text-start'>Service Provider :</div>
            <div key="addsettingcontainerrow1col5" className='col-md-3 text-start'>
              <select key="saas" title='SaasProvider' id="saasoption" 
              className="form-select" onChange={this.handleChange.bind(this)}>
                <option key="saas-select" value="Select">SELECT</option>
                  {
                    this._saasProviders.map((itm,index)=>{
                      return(
                        <option key={`saas-${index}`} value={itm.saasId.toUpperCase()}>{itm.saasId.toUpperCase()}</option>
                      )
                    })
                  }
              </select>
          </div>
          <div key="addsettingcontainerrow1col6" className='col-md-1 text-start'></div>
        </div>
        <div key="addsettingcontainerrow2" className='row flex-row g-0'>
          <div key="addsettingcontainerrow2col1" className='col'></div>
        </div>
        <div key="addsettingcontainerrow3" className='row flex-row g-0'>
             <div key="addsettingcontainerrow3col1" className='col'>
                  {this.renderChildren()}
             </div>     
        </div>
      </div>
    )
  }
}
export default AdditionalSettings