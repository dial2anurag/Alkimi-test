import React, { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import SpinnersComponent from '../../Components/SpinnersComponent';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import OrganisationDetailsWrapper from './organisationDetails.style';
import logo from '../../Assets/profile.png';
import ReactChips from "../../Components/ReactChips/ReactChips";
import OrgDetailsService from "../../services/Organization/OrgDetailsService";
import {APIData, OrgDetailsServiceEntity} from "../../Model/Organization/Org";


type OrganisationDetailsState ={
  showSpinner : boolean,
  selectedFile : any | null,
  founders: string[] | string,
  apiData: APIData[]
}

export default class OrganisationDetails extends AuthenticatedBaseComponent<any, OrganisationDetailsState> {
  private _uploadRef : React.RefObject<HTMLInputElement>;
  constructor(props: any) {
    super(props);
    let founders: string[] = [];
    let logo: string | null=null;
    let field = Array.prototype.find.call(this.UserProfile.organization.orgDetails, e => e.name === "founders");
    if(field) {
      let arr = field.value.split(',');
      arr.forEach((item: string) => {
        founders.push(item);
      });
    } 
    field = Array.prototype.find.call(this.UserProfile.organization.orgDetails, e => e.name === "logo");
    if(field) {
        logo = field.value;
    } 
    this.state ={showSpinner : false, selectedFile : logo, founders: founders.toString(), apiData: this.UserProfile.organization.orgDetails}
    this.handleReactChipOnchange = this.handleReactChipOnchange.bind(this);
    this._uploadRef = React.createRef<HTMLInputElement>();
  }
  
  componentDidMount() {
  }

  validationSchema() {
    return Yup.object().shape({
      email: Yup.string()
        .email("This is not a valid email.")
        .required("This field is required!"),
      phone: Yup.string().matches(new RegExp('[0-9]{10}'))
        .length(10)
        .typeError('you must specify a number with length 10')
        .required("This field is required!"),
      CEO: Yup.string()
        .test(
          "len",
          "The CEO name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      GstNo: Yup.string().matches(new RegExp(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/))
        .length(15)
        .typeError('you must specify a number with length 15')
        .required("This field is required!"),
      CINNo: Yup.string().matches(new RegExp(/^([L|U]{1})([0-9]{5})([A-Za-z]{2})([0-9]{4})([A-Za-z]{3})([0-9]{6})$/))
        .length(21)
        .typeError('you must specify a number with length 21')
        .required("This field is required!"),
      website: Yup.string()
        .test(
          "len",
          "The Website name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      CTO: Yup.string()
        .test(
          "len",
          "The CTO name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      CISO: Yup.string()
        .test(
          "len",
          "The CISO name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      Address1: Yup.string()
        .test(
          "len",
          "The Address1 name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      Address2: Yup.string()
        .test(
          "len",
          "The Address2 name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      city: Yup.string()
        .test(
          "len",
          "The City name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      state: Yup.string()
        .test(
          "len",
          "The State name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      country: Yup.string()
        .test(
          "len",
          "The Country name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      pincode: Yup.string().matches(new RegExp('[0-9]{6}'))
        .length(6)
        .typeError('you must specify a number with length 6')
        .required("This field is required!")
    });
  }

  async handleChange(event : any){
    let MAX_FILE_SIZE = 3 * 1024; // 3KB
    let uploadFile = event.target.files;
    if(uploadFile && uploadFile.length > 0){
        if (uploadFile[0].size > MAX_FILE_SIZE) {
            alert("File must not exceed 3 KB!");
            event.target.value = '';
            this.setState({selectedFile: null});
            return false;
        } else {
            this.getBase64(uploadFile[0]).then((data) => {
                this.setState({selectedFile: data});
            });
        }
    }
  }

  getBase64(file: any) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }
  

  preparedata(field:string, value: string) : APIData {
    let fld :APIData | undefined = this.state.apiData.find(e=>e.name=== field);
    if(!fld){
        fld= {orgId: this.UserProfile.organization.clientId, name: field, value: value}
    } else {
        fld.value =value;
    }
    return fld
  }

  preparefieldlist(values: OrgDetailsServiceEntity): APIData[]
  {
      let apiDataList :APIData[] = [];
      apiDataList.push(this.preparedata("email", values.email ));
      apiDataList.push(this.preparedata("website", values.website));
      apiDataList.push(this.preparedata("phone", values.phone));
      apiDataList.push(this.preparedata("GstNo", values.GstNo));
      apiDataList.push(this.preparedata("CINNo", values.CINNo));
      apiDataList.push(this.preparedata("founders", this.state.founders.toString()));
      apiDataList.push(this.preparedata("CEO", values.CEO));
      apiDataList.push(this.preparedata("CTO", values.CTO));
      apiDataList.push(this.preparedata("CISO", values.CISO));
      apiDataList.push(this.preparedata("Address1", values.Address1));
      apiDataList.push(this.preparedata("Address2", values.Address2));
      apiDataList.push(this.preparedata("city", values.city));
      apiDataList.push(this.preparedata("state", values.state));
      apiDataList.push(this.preparedata("country", values.country));
      apiDataList.push(this.preparedata("pincode", values.pincode));
      apiDataList.push(this.preparedata("logo", this.state.selectedFile));

      return apiDataList;
  }

  async handleRegister(values : OrgDetailsServiceEntity, event : any){
    let data: APIData[] = this.preparefieldlist(values);

    if(this.state.selectedFile === null) {
        alert("Please Choose your Organisation Logo.");
    } else if(this.state.founders.length < 1) {
        alert("Please Enter Founders.");
    } else {
        this.setState({showSpinner : true});
        if(await OrgDetailsService.registerOrgDetails(data) === 200){
            let userProfile = this.UserProfile;
            userProfile.organization["orgDetails"] = data;
            sessionStorage.setItem("userProfile", JSON.stringify(userProfile));
            alert("Org Details registered successfully"); 
            this.setState({apiData: data});
        }
        this.setState({showSpinner : false});
    }
  }

  handleReactChipOnchange(value: string[]):void {
      this.setState({ founders: value.toString()});
  }

  getDefaultFillValue(field: string): string {
      let orgDetails = this.state.apiData;
      let value = orgDetails.find(e => e.name === field);
      if(value) {
        return value.value;
      } else {
        return "";
      }
  }

  render() {
    const initialValues :OrgDetailsServiceEntity = {
        email: this.getDefaultFillValue("email"),
        website: this.getDefaultFillValue("website"),
        phone: this.getDefaultFillValue("phone"),
        GstNo: this.getDefaultFillValue("GstNo"),
        CINNo: this.getDefaultFillValue("CINNo"),
        founders: this.getDefaultFillValue("founders"),
        CEO: this.getDefaultFillValue("CEO"),
        CTO: this.getDefaultFillValue("CTO"),
        CISO: this.getDefaultFillValue("CISO"),
        Address1: this.getDefaultFillValue("Address1"),
        Address2: this.getDefaultFillValue("Address2"),
        city: this.getDefaultFillValue("city"),
        state: this.getDefaultFillValue("state"),
        country: this.getDefaultFillValue("country"),
        pincode: this.getDefaultFillValue("pincode"),
        logo: this.getDefaultFillValue("logo")
    };

    const {showSpinner} = this.state;
    return (
      <OrganisationDetailsWrapper>
        <SpinnersComponent key="extuserspinnercomponent" showspinner={showSpinner} />
        <Formik key="fomik1" initialValues={initialValues} validationSchema={this.validationSchema} onSubmit={this.handleRegister.bind(this)}>
          <Form key="form1">
            <div key="row1" className="row">
              <div key="row1col1" className="col-md-6">
                <label key="row1col1lable1" htmlFor="fieldemail" className="form-label">E-mail</label>
                <Field key="fieldemail" name="email" type="email" className="form-control" placeholder="E-mail" autoComplete="off"/>
                <ErrorMessage key="erremail" name="email" component="div" className="help-error"/>
              </div>
              <div key="row1col2" className="col-md-6">
                <label key="row1col2lable2" htmlFor="fieldWebsite" className="form-label">Website</label>
                <Field key="fieldWebsite" name="website" type="website" className="form-control" placeholder="Website"/>
                <ErrorMessage key="errWebsite" name="website" component="div" className="help-error" />
              </div>
            </div>
            <div key="row2" className="row">
              <div key="row2col1" className="col-md-6">
                <label key="row2col1lable1" htmlFor="fieldPhone" className="form-label">Contact number</label>
                <Field key="fieldPhone" name="phone" type="phone" className="form-control" placeholder="Contact number" maxLength={10}/>
                <ErrorMessage key="errPhone" name="phone" component="div" className="help-error"/>
              </div>
              <div key="row2col2" className="col-md-6">
                <label key="row2col2lable2" htmlFor="fieldGstNo" className="form-label">GST No</label>
                <Field key="fieldGstNo" name="GstNo" type="GstNo" className="form-control" placeholder="GST No" maxLength={15}/>
                <ErrorMessage key="errGstNo" name="GstNo" component="div" className="help-error"/>
              </div>
            </div>
            <div key="row3" className="row">
              <div key="row3col1" className="col-md-6">
                <label key="row3col1lable1" htmlFor="fieldCINNo" className="form-label">CIN No</label>
                <Field key="fieldCINNo" name="CINNo" type="CINNo" className="form-control" placeholder="CIN No"/>
                <ErrorMessage key="errCINNo" name="CINNo" component="div" className="help-error" />
              </div>
              <div key="row3col2" className="col-md-6">
                <label key="row3col2label2" htmlFor="fieldCEO" className="form-label">CEO</label>
                <Field key="fieldCEO" name="CEO" type="CEO" className="form-control" placeholder="CEO"/>
                <ErrorMessage key="errCEO" name="CEO" component="div" className="help-error" />
              </div>
            </div>
            <div key="row4" className="row">
              <div key="row4col1" className="col-md-6">
                <label key="row4col1label1" htmlFor="fieldCTO" className="form-label">CTO</label>
                <Field key="fieldCTO" name="CTO" type="CTO" className="form-control" placeholder="CTO" autoComplete="off"/>
                <ErrorMessage key="errCTO" name="CTO" component="div" className="help-error" />
              </div>
              <div key="row4col2" className="col-md-6">
                <label key="row4col2label2" htmlFor="fieldCISO" className="form-label">CISO</label>
                <Field key="fieldCISO" name="CISO" type="CISO" className="form-control" placeholder="CISO" autoComplete="off"/>
                <ErrorMessage key="errorCISO" name="CISO" component="div" className="help-error" />
              </div>
            </div>
            <div key="row5" className="row">
              <div key="row5col1" className="col-md-6">
                <label key="row5col1label1" htmlFor="fieldAddress1" className="form-label">Address line 1</label>
                <Field key="fieldAddress1" name="Address1" type="Address1" className="form-control" placeholder="Address line 1" autoComplete="off"/>
                <ErrorMessage key="errAddress1" name="Address1" component="div" className="help-error" />
              </div>
              <div key="row5col2" className="col-md-6">
                <label key="row5col2label2" htmlFor="fieldAddress2" className="form-label">Address line 2</label>
                <Field key="fieldAddress2" name="Address2" type="Address2" className="form-control" placeholder="Address line 2" autoComplete="off"/>
                <ErrorMessage key="errAddress2" name="Address2" component="div" className="help-error" />
              </div>
            </div>
            <div key="row6" className="row">
              <div key="row6col1" className="col-md-6">
                <label key="row6col1label1" htmlFor="fieldcountry" className="form-label">Country</label>
                <Field key="fieldcountry" name="country" type="country" className="form-control" placeholder="Country" autoComplete="off"/>
                <ErrorMessage key="errcountry" name="country" component="div" className="help-error" />
              </div>
              <div key="row6col2" className="col-md-6">
                <label key="row6col2label2" htmlFor="fieldstate" className="form-label">State</label>
                <Field key="fieldstate" name="state" type="state" className="form-control" placeholder="State" autoComplete="off"/>
                <ErrorMessage key="errstate" name="state" component="div" className="help-error" />
              </div>
            </div>
            <div key="row7" className="row">
              <div key="row7col1" className="col-md-6">
                <label key="row7col1label1" htmlFor="fieldcity" className="form-label">City</label>
                <Field key="fieldcity" name="city" type="city" className="form-control" placeholder="City" autoComplete="off"/>
                <ErrorMessage key="errcity" name="city" component="div" className="help-error" />
              </div>
              <div key="row7col2" className="col-md-6">
                <label key="row7col2label2" htmlFor="fieldpincode" className="form-label">Pincode</label>
                <Field key="fieldpincode" name="pincode" type="pincode" className="form-control" placeholder="Pincode" autoComplete="off" maxLength={6}/>
                <ErrorMessage key="errpincode" name="pincode" component="div" className="help-error" />
              </div>
            </div>
            <div key="row8" className="row">
              <div key="row8col1" className="col-md-6">
                <label key="row8col1label1" htmlFor="fieldpincode" className="form-label text-start">Organisation Logo</label>
                <div className="m-auto">
                  <div className="profile-image"><img className="img-fluid" src={this.state.selectedFile ? this.state.selectedFile : logo} /></div>
                  <input id="fileUpload" key={"fileUpload"} type="file" ref={this._uploadRef} name="logo"
                        accept="application/PDF , application/zip , image/gif, image/png , 	image/jpeg" onChange={this.handleChange.bind(this)} />
                </div>
              </div>
              <div key="row8col2" className="col-md-6">
                  <label key="row8col2label2" htmlFor="fieldfounders" className="form-label">Founders</label>
                  <ReactChips onChange={this.handleReactChipOnchange.bind(this)} value={this.state.founders} />
              </div>
            </div>
            <div className="row9">
              <div key="row9col2" className="col-md-3 ms-auto">
                <button key="btnsubmit" type="submit" className="btn btn-primary btn-block">Update</button>
              </div>
            </div>
          </Form>
        </Formik>
      </OrganisationDetailsWrapper>
    );
  }
}