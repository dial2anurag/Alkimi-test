import React, { Component } from 'react'
import { Navigate, NavLink } from 'react-router-dom' ;
import AuthService from '../../services/Users/auth.service';
import {AuthRoles} from '../../Data/SysData/roleAuth';
import { IRoleAuth, SectionComponent } from '../../Model/SysModal/sysEntiry';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';

type HomeState ={
    changePassword : boolean,
    roleBasedRoute : string
}
export class Home extends AuthenticatedBaseComponent<any,HomeState> {
    constructor(props : any){
        super(props);
        this.state ={
            changePassword :false,
            roleBasedRoute : ""
        }
    }

    navigate2Page(){
        if(this.state.roleBasedRoute && this.state.roleBasedRoute.trim().length >0){
            return (<Navigate to={this.state.roleBasedRoute} /> )
            // let navLink: <NavLink />
        }
        else{
            return (<></>)
        }
    }

    async componentDidMount(){
        let userprofile =AuthService.getCurrentUser();
        let roledata =AuthService.getUserAuthMenu(); 
        let roles :any[] =  userprofile.roles;
        let defaultid :number | null = null;
        let pagerole : IRoleAuth | undefined;
        let path : string = "";
        roles.forEach((role, index)=>{
            pagerole = AuthRoles.find(e=> e.role.toUpperCase() === role.name.toUpperCase());
            if(pagerole){
                if(! defaultid) defaultid  = pagerole.defaultpage
            }
        });

        if(! userprofile.detailsFilled){
            let val =roledata?.find(x=> x.id === 1);
            if(val) path = val.path ? val.path : path
        } 

        let tempRoleData = roledata?.filter(role=>role.section===SectionComponent.NavBar);
        tempRoleData?.sort((a, b) => (a.sequence > b.sequence) ? 1 : -1);
        if(!tempRoleData || tempRoleData.length <= 0) {
            path = "";
        } else if(!tempRoleData[0].path) {
            if(defaultid && tempRoleData){
                let val = tempRoleData.find(e=> e.id === defaultid);
                if(val){
                    path = val.path ? val.path : "" ;
                }
            }
        } else {
            path = tempRoleData[0].path;
        }

        this.setState({ roleBasedRoute : path });
    }

    render() {
        return (<>{this.navigate2Page()} </>);
    }
}

export default Home
