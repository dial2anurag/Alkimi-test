import styled from 'styled-components';

const UserWrapper = styled.div`
.col-md-6 {
    text-align: left;
    margin-bottom: 32px;
}
.form-label {
    font-family: 'ProductSansRegular';
    font-size: 18px;
    line-height: 29px;
    color: #02379C;
}
.form-control {
    background: #FFFFFF;
    height: 50px;
    border: 1px solid #938BFF;
    box-shadow: 0px 100px 80px rgba(41, 72, 152, 0.05), 0px 64.8148px 46.8519px rgba(41, 72, 152, 0.037963), 0px 38.5185px 25.4815px rgba(41, 72, 152, 0.0303704), 0px 20px 13px rgba(41, 72, 152, 0.025), 0px 8.14815px 6.51852px rgba(41, 72, 152, 0.0196296), 0px 1.85185px 3.14815px rgba(41, 72, 152, 0.012037);
    border-radius: 10px;
    font-family: 'ProductSansRegular';
    font-size: 18px;
    line-height: 29px;
    color: #02379C;
}
input:placeholder-shown, .inactive {
    color: #D7D7D7;
    opacity: 0.4;
}
select option {
    background: #FFFFFF;
    color: #02379C;
}
.btn-block {
    background: #1752C3;
    border-radius: 10px;
    font-family: 'ProductSansBold';
    font-size: 24px;
    line-height: 39px;
    color: #FFFFFF;
    width: 100%;
    margin-top: 20px;
    margin-bottom: 30px;
}
.help-error {
    color: red;
    font-family: 'ProductSansRegular';
    font-size: 14px;
    padding-top: 10px;
}
`;

export default UserWrapper;