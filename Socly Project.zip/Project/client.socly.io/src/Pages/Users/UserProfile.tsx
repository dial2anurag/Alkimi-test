import { display } from '@mui/system';
import * as React from 'react';
import { Component } from "react";
import AuthService from '../../services/Users/auth.service';
import {RoleMappings} from '../../Data/SysData/roleMapping'; 
import { ChangePassword } from '../Security/ChangePassword';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions } from '@mui/material';
import Grid from '@material-ui/core/Grid';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import DriveFileRenameOutlineIcon from '@mui/icons-material/DriveFileRenameOutline';
import AlternateEmailIcon from '@mui/icons-material/AlternateEmail';
import GroupsIcon from '@mui/icons-material/Groups';
import BusinessIcon from '@mui/icons-material/Business';
import PasswordIcon from '@mui/icons-material/Password';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import { Console } from 'console';

const style = {
    width: '100%',
    maxWidth: 360,
    bgcolor: 'background.paper'
  };

export type UserProfileState = {
    changePassword: boolean
}

export default class UserProfile extends AuthenticatedBaseComponent<any, UserProfileState>{
    private _userData : any ;
    constructor(props: any) {
        super(props);
        this._userData = AuthService.getCurrentUser();
        this.state = {changePassword: false}
        this.getUserDetails = this.getUserDetails.bind(this);
        this.userEmail = this.userEmail.bind(this);
        this.userOrg = this.userOrg.bind(this);
        this.userRole = this.userRole.bind(this);
        this.userPhone = this.userPhone.bind(this);
    }

    getUserDetails = () => {
        return (<div >{this._userData.name}</div>)
    }
    userEmail = () => {
        return (
            <div>{this._userData.email}</div>
        )
    }

    userPhone = () => {
        return (
            <div>{this._userData.phone}</div>
        )
    }

    userOrg = () => {
        return (
            <div>{this._userData.organizationName}</div>
        )
    }

    userRole = () => {
        let roles : string []=[];
        Array.prototype.forEach.call(this._userData.roles,(itm,indx)=>{
            roles.push(RoleMappings[itm.name]);
        });

        return (
            <div>{roles.join()}</div>
        )
    }
    onAfterChangePassword(value: boolean) {
        this.setState({ changePassword: false });
    }

    onChangePasswordClick() {
        this.setState({ changePassword: true });
    }

    onChangePassword() {
        if (this.state.changePassword) {
            return (<><ChangePassword onAfterChangePassword={this.onAfterChangePassword.bind(this)} showCloseOption={true} /></>)
        }
        else {
            return (<></>)
        }
    }
    renderComponent() {
        return (

            <Grid container spacing={2}>
                <Grid item md={4}></Grid>
                <Grid item md={4}>

                <Card sx={{ maxWidth: 400,border:1,}} style={{marginTop: 100}}>
                    <CardActionArea>
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div" >
                            Your Profile
                            </Typography>
                            <List component="nav" >
                                <br></br>
                                <ListItem >
                                    <DriveFileRenameOutlineIcon style={{ color: "#0275d8" }}/>&nbsp; Name &nbsp;: &nbsp;{this.getUserDetails()}
                                </ListItem>
                                <Divider />
                                <br></br>
                                <ListItem >
                                    <AlternateEmailIcon style={{ color: "#0275d8" }}/> &nbsp;Email &nbsp; : &nbsp; {this.userEmail()}
                                </ListItem>
                                <Divider  />
                                <br></br>
                                <ListItem >
                                    <PhoneIphoneIcon style={{ color: "#0275d8" }}/> &nbsp;Phone &nbsp; : &nbsp; {this.userPhone()}
                                </ListItem>
                                <Divider  />
                                <br></br>
                                <ListItem >
                                    <GroupsIcon style={{ color: "#0275d8" }}/> &nbsp;Role &nbsp; : &nbsp; {this.userRole()}
                                </ListItem>
                                <Divider  />
                                <br></br>
                                <ListItem >
                                    <BusinessIcon style={{ color: "#0275d8" }}/>&nbsp;Org &nbsp; :&nbsp; {this.userOrg()}
                                </ListItem>
                                <br></br>
                                <Divider  />
                            </List>
                        </CardContent>
                    </CardActionArea>
                    <CardActions style={{textAlign : "center", justifyContent : "center"}}>
                    <Button variant="contained" size="large"  onClick={this.onChangePasswordClick.bind(this)} startIcon={<PasswordIcon />}>
                        Change Password
                    </Button>
                    </CardActions>
                </Card>
              </Grid>
              <Grid item md={4}></Grid>
            </Grid>
        );
    }
    render() {
        return (<>
            {this.onChangePassword()}
            {this.renderComponent()}
        </>)
    }
}