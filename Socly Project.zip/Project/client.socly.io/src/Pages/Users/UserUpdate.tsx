import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import styled from 'styled-components'
import Users,{ IUserRegistration4Org } from "../../services/Users/Users";
import SpinnersComponent from "../../Components/SpinnersComponent";
import OrgRegistration from '../../services/Organization/OrgRegistration';
import { RoleMappings } from '../../Data/SysData/roleMapping';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import UserWrapper from './user.style';

type UserUpdateState = {
  showSpinner: boolean,
  roles: { id: number, name: string, display: string }[],
  status:"O"|"R"|null,
  phone:string,
  name:string,
  businessTitleValue: string
}

type UserUpdateProps = {
  usrData: any
  handleCallback :(value: boolean)=>void;
}

export default class UserUpdate extends AuthenticatedBaseComponent<UserUpdateProps, UserUpdateState> {
  constructor(props: UserUpdateProps) {
    super(props);
    this.state = {showSpinner: false, 
      name:this.props.usrData.name,
      roles: this.props.usrData.roles,
      status:this.props.usrData.status,
      phone:this.props.usrData.phone,
      businessTitleValue: ""
     }
  }

  async componentDidMount() {
    let roles: { id: number, name: string, display: string }[] = [];
    let response = await OrgRegistration.getRoles(true);
     if (response.status === 200 && response.data && response.data.length > 0) {
      Array.prototype.forEach.call(response.data, (item, index) => {
        roles.push({ id: item.id, name: item.name, display: RoleMappings[item.name] });
      })
    }
    this.setState({ roles: roles });
  }

  validationSchema() {
    return Yup.object().shape({
      phone: Yup.string().matches(new RegExp('[0-9]{10}'))
        .length(10)
        .required("This field is required!")
    });
  }

  handleDropChange = (event: any) => {
    this.setState({ status: event.target.value })
  }

  handlePhoneChange(event:any)
  {
    event.preventDefault();
    this.setState({phone:event.target.value});
  }

  async handleUpdate(values: IUserRegistration4Org, event: any) {
    this.setState({ showSpinner: true });
    let data:any = {
      status:this.state.status,
      phone:values.phone,
      role:values.businessTitle,
      username:this.props.usrData.username,
    }
    if (await Users.updateUser(data) === 200) {
      this.props.handleCallback(true);
      alert("User Updated Successfully");
    }
   event.resetForm(); 
   this.setState({ showSpinner: false });
  }

  handleChange(ev: any) {
    const {name, value} = ev.target;
    if(name === "businessTitle") {
      this.setState({businessTitleValue: value});
    }
  }

  render() {
    const initialValues: IUserRegistration4Org = {
      email: this.props.usrData.email,
      name: this.props.usrData.name,
      phone: this.props.usrData.phone,
      businessTitle: this.props.usrData.roles[0]
  };

  const {showSpinner, roles, businessTitleValue} = this.state;
    return (
      <UserWrapper>
        <SpinnersComponent key="usrupdtspinnercomponent" showspinner={showSpinner} />
        <Formik key="fomik1" initialValues={initialValues} validationSchema={this.validationSchema} onSubmit={this.handleUpdate.bind(this)}>
          <Form key="form1">
            <div key="row1" className="row mt-3">
              <div key="row1col1" className="col-md-6">
                <label key="row1col1lable1" htmlFor="fieldname" className="form-label">Name</label>
                <Field key="fieldname" name="name" type="name" className="form-control" placeholder="Name" autoComplete="off" readOnly={true} />
                <ErrorMessage key="errname" name="name" component="div" className="help-error" />
              </div>
              <div key="row1col2" className="col-md-6">
                <label key="row1col2lable2" htmlFor="ddlstatus" className="form-label">Status</label>
                <div className="w-100">
                <FormControl key="frmctrlstatus" className="w-100">
                    <Select
                        key="ddlstatus"
                        labelId="select-status"
                        id="select-status"
                        label="Status"
                        className="form-control"
                        defaultValue={this.state.status}
                        value={this.state.status}
                        onChange={this.handleDropChange.bind(this)}
                    >
                        <MenuItem key="select-status-option-O" value="Active">Active</MenuItem><br />
                        <MenuItem key="select-status-option-C" value="InActive">Inactive</MenuItem>
                    </Select>
                </FormControl>
                </div>
              </div>
            </div>
            <div key="row2" className="row">
              <div key="row2col1" className="col-md-6">
                <label key="row2col1label1" htmlFor="fieldbusinesstitle" className="form-label">Select a role</label>
                <Field key="fieldbusinesstitle" as="select" name="businessTitle" type="businessTitle" className={"form-control "+(businessTitleValue ? "active" : "inactive")} onClick={(ev: any)=>this.handleChange(ev)}> 
                  {
                    roles.map((item, index) => {
                      return (<option key={`${item.id}-${index}`} value={item.name}>{item.display}</option>)
                    })
                  }
                </Field>
                <ErrorMessage key="errbusinesstitle" name="businessTitle" component="div" className="help-error" />
              </div>
              <div key="row2col2" className="col-md-6">
                <label key="row2col2label2" htmlFor="fieldphone" className="form-label">Phone</label>
                <Field key="fieldphone" name="phone" type="phone" maxLength={10} className="form-control" placeholder="Phone" autoComplete="off" />
                <ErrorMessage key="errphone" name="phone" component="div" className="help-error" />
              </div>
            </div>
            <div key="row4" className="row">
              <div key="row4col1" className="col-md-3 mx-auto">
                <button key="btnsubmit" type="submit" className="btn btn-primary btn-block">Update</button>
              </div>
            </div>
          </Form>
        </Formik>
      </UserWrapper>
    );
  }
}