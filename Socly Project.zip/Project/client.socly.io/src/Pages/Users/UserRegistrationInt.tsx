import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import Users, { IUserRegistration4Org } from '../../services/Users/Users';
import SpinnersComponent from '../../Components/SpinnersComponent';
import OrgRegistration from '../../services/Organization/OrgRegistration';
import { RoleMappings } from '../../Data/SysData/roleMapping';
import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';
import UserWrapper from './user.style'

type UserRegistrationIntState = {
  showSpinner: boolean,
  roles: { id: number, name: string, display: string }[],
  businessTitleValue: string
}

type UserRegistrationProps = {
  handleCallback ?:(value:boolean)=>void;
}

export default class UserRegistrationInt extends AuthenticatedBaseComponent<UserRegistrationProps, UserRegistrationIntState> {
  constructor(props: UserRegistrationProps) {
      super(props);
      this.state = {showSpinner: false, roles: [], businessTitleValue: ""}
  }

  async componentDidMount() {
    let roles: { id: number, name: string, display: string }[] = [];
    let response = await OrgRegistration.getRoles(true);
    if (response.status === 200 && response.data && response.data.length > 0) {
      
      Array.prototype.forEach.call(response.data, (item, index) => {
        
        roles.push({ id: item.id, name: item.name, display: RoleMappings[item.name] });
      })
    }
    this.setState({ roles: roles });
  }

  validationSchema() {
    return Yup.object().shape({
      email: Yup.string()
        .email("This is not a valid email.")
        .required("This field is required!"),
      phone: Yup.string().matches(new RegExp('[0-9]{10}'))
        .length(10)
        .required("This field is required!"),
      name: Yup.string()
        .test(
          "len",
          "The name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      businessTitle: Yup.string()
        .test(
          "len",
          "The role must be selected.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!")
    });
  }

  async handleRegister(values: IUserRegistration4Org, event: any) {
    this.setState({ showSpinner: true });
    if (await Users.registerUser4Org(values) === 200) {
        if(this.props.handleCallback) {
            this.props.handleCallback(true);
        }
        alert("User registered successfully");
    }
    event.resetForm(); 
    this.setState({ showSpinner: false });
  }

  handleChange(ev: any) {
    const {name, value} = ev.target;
    if(name === "businessTitle") {
      this.setState({businessTitleValue: value});
    }
  }

  render() {
    const initialValues: IUserRegistration4Org = {
        email: "",
        name: "",
        phone: "",
        businessTitle: ""
    };

    const {showSpinner, roles, businessTitleValue} = this.state;
    return (
      <UserWrapper>
        <SpinnersComponent key="userregintspinnercomponent" showspinner={showSpinner}/>
        <Formik key="fomik1" initialValues={initialValues} validationSchema={this.validationSchema} onSubmit={this.handleRegister.bind(this)}>
          <Form key="form1">
            <div key="row1" className="row mt-3">
              <div key="row1col1" className="col-md-6">
                <label key="row1col1lable1" htmlFor="fieldname" className="form-label">Name</label>
                <Field key="fieldname" name="name" type="name" className="form-control" placeholder="Name" autoComplete="off" />
                <ErrorMessage key="errname" name="name" component="div" className="help-error" />
              </div>
              <div key="row1col2" className="col-md-6">
                <label key="row1col2lable2" htmlFor="fieldemail" className="form-label">E-mail</label>
                <Field key="fieldemail" name="email" type="email" className="form-control" placeholder ="E-mail"/>
                <ErrorMessage key="erremail" name="email" component="div" className="help-error" />
              </div>
            </div>
            <div key="row2" className="row">
              <div key="row2col1" className="col-md-6">
                <label key="row2col1label1" htmlFor="fieldphone" className="form-label">Phone</label>
                <Field key="fieldphone" name="phone" type="phone" maxLength={10} size={30} className="form-control" placeholder="Phone"/>
                <ErrorMessage key="errphone" name="phone" component="div" className="help-error" />
              </div>
              <div key="row2col2" className="col-md-6">
                <label key="row2col2label2" htmlFor="fieldbusinesstitle" className="form-label">Select a role</label>
                <Field key="fieldbusinesstitle" as="select" name="businessTitle" type="businessTitle" className={"form-control "+(businessTitleValue ? "active" : "inactive")} onClick={(ev: any)=>this.handleChange(ev)}>
                  <option key="businesstitleselectoption" value="" label="Select a role"/>
                  {
                    roles.map((item,index)=>{
                      return(<option key={`businesstitleselectoption-${item.name}`} value={item.name}>{item.display}</option>)
                    })
                  }
                </Field>
                <ErrorMessage key="errbusinesstitle" name="businessTitle" component="div" className="help-error" />
              </div>
            </div>
            <div key="row4" className="row">
              <div key="row4col1" className="col-md-3 mx-auto">
                <button key="btnsubmit" type="submit" className="btn btn-primary btn-block">Register</button>
              </div>
            </div>
          </Form>
        </Formik>
      </UserWrapper>
    );
  }
}