import React, { Component } from 'react';

import styled from 'styled-components';

import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../Base/AuthenticatedRouteComponent';

import {ContentHeading} from '../../StyledComponents/ComponentWrapper';

import policyCenterService from '../../services/Application/PolicyCenterService';

import SpinnersComponent from '../../Components/SpinnersComponent';

import RequestChangeWrapper, {
    GridCnt,
    MultiLineTxtBoxHldr,
    ModalBtnrHldr,
    SubmitBtn,

} from './RequestChange.Style';


interface PolicyCenterState {
    showspinner :boolean,

}



export class RequestChange extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, PolicyCenterState> {

    constructor(props: AuthenticatedRouteComponentProps) {

        super(props)

        this.state = {
            showspinner :false
        }

    }


    async componentDidMount() {

        this.setState({showspinner :true});

        const policies = await policyCenterService.getPolicies()

        this.setState({

            showspinner :false })

    }


    downloadPolicy = async (id: number) => {

        this.setState({showspinner :true});

          await policyCenterService.getPolicy(id)

            .then((response) => {

                const blob = new Blob([response.data], { type: 'application/pdf' })

                var URL = window.URL || window.webkitURL;

                const fileurl = window.URL.createObjectURL(blob);

                const pdfwindow= window.open(fileurl,"_blank");

            })

            this.setState({showspinner :false});

    }


    render() {




        return (

            <RequestChangeWrapper>

            <div>

                <SpinnersComponent key="policycenterspinnercomponent" showspinner={ this.state.showspinner} disablesection ={true} />

                <ContentHeading> Request Change </ContentHeading>

                <GridCnt>
                    <MultiLineTxtBoxHldr> 
                        <form>
                            <textarea className="form-control" rows={6}>
                            </textarea> 
                        </form>
                    </MultiLineTxtBoxHldr>

                    <ModalBtnrHldr>

                        <SubmitBtn>
                            <button
                            type="button" className="btn-primary rounded-1 shadow-none" 
                            > Submit </button>
                        </SubmitBtn>
                    </ModalBtnrHldr>

                </GridCnt>

            </div>

            </RequestChangeWrapper>

        )

    } 

}

export default RequestChange;

