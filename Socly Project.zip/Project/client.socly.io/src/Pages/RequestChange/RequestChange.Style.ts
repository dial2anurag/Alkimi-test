import styled from 'styled-components';


export const GridCnt = styled.div`
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border: solid 1px #F2F2F2;
`;

export const MultiLineTxtBoxHldr = styled.div`
    width: 100%;
    float: right;
    padding: 10px;
`;

export const ModalBtnrHldr = styled.div`
    width: 70%;
    float: right;
    padding: 10px;
    margin-top: 6%;
`;

export const SubmitBtn = styled.div`
    float: right;
`;

const RequestChangeWrapper = styled.div`

.cnt-hdlr {
  background-color:  #E7E7E7;

}

.input-text {
    width: 100%;
    border: 0px;
    background-color: #f0f2f0;
    font-size: 12px;
    z-index: -1;
    line-height: 40px;
}

.Search-btn {
    padding: 1px;
    line-height: 40px;
    color: #ffffff;
    cursor: pointer;
    top: 0px;
    z-index: 2;
    border-radius: 4px;
    background-color: #1752C3;
}

.input-text: Focus {
    border: 0px;
}


@media only screen and (max-width: 767.98px) {

.Grid {
    padding-bottom: 45px !important;
    border-bottom: solid 1px #dadce0;
    }
}

`;


export default RequestChangeWrapper;


