import BaseDocComponent , 
{
    BaseDocComponentState,
    BaseDocComponentProps
} from './BaseDocComponent';

interface SystemDescriptionState extends BaseDocComponentState{}

export class SystemDescription extends BaseDocComponent<BaseDocComponentProps,SystemDescriptionState> {
    constructor(props : BaseDocComponentProps){
        super(props,{
            component : "SystemDescription",
            title : "System Description"
        });
        this.state=this.getdefaultState();
    }
}

export default SystemDescription