import BaseDocComponent , 
{
    BaseDocComponentState,
    BaseDocComponentProps
} from './BaseDocComponent';

interface RiskRegisterState extends BaseDocComponentState{}

export class RiskRegister extends BaseDocComponent<BaseDocComponentProps,RiskRegisterState> {
    constructor(props : BaseDocComponentProps){
        super(props,{
            component : "RiskRegister",
            title : "Risk Register"
        });
        this.state=this.getdefaultState();
    }
}

export default RiskRegister