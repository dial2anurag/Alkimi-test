import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import AuthenticatedRouteComponent, { AuthenticatedRouteComponentProps } from '../../Base/AuthenticatedRouteComponent';
import SystemDescription from './SystemDescription';
import RiskRegister from './RiskRegister';

interface DocumentState {
    value: string
}


export default class Documentation extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, DocumentState> {
    // const [value, setValue] = React.useState('1');

    // const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    //     setValue(newValue);
    // };
    constructor(props: AuthenticatedRouteComponentProps) {
        super(props);
        this.state = {
            value: '1'
        }
    }
    handleChange = (event: React.SyntheticEvent, newValue: string) => {
        this.setState({ value: newValue });
    };
    render() {
        return (
            <Box sx={{ width: '100%', typography: 'body1' }}>
                <TabContext value={this.state.value}>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                        <TabList onChange={this.handleChange} aria-label="lab API tabs example">
                            <Tab label="System Description" value="1" />
                            <Tab label="Risk Register" value="2" />
                        </TabList>
                    </Box>
                    <TabPanel value="1"><SystemDescription pageid={this.props.pageid}   /></TabPanel>
                    <TabPanel value="2"><RiskRegister pageid={this.props.pageid} /></TabPanel>
                </TabContext>
            </Box>
        );
    }
}
