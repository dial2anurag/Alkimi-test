import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';
import Box from '@mui/material/Box';
import RichTextEditor from '../../../Components/RichTextEditor/RichTextEditor';
import SpinnersComponent from '../../../Components/SpinnersComponent';
import TemplateService,{ ORG_TEMPLATE, CONTENT_TYPE, DOC_TEMPLATE } from '../../../services/Application/Documentation/TemplateService';
import {  OrgDetailsEntity } from '../../../Model/Organization/Org';
import FileIOService from '../../../services/Common/FileIOService'
import PolicyMakerWrapper from '../PolicyCenter/PolicyMaker/policyMaker.style';
import { Modal } from 'react-bootstrap';
import { IRestResponseEntity } from '../../../Model/RestEntities';
import IconButton from '@mui/material/IconButton';
import LockResetIcon from '@mui/icons-material/LockReset';
import PreviewIcon from '@mui/icons-material/Preview';
import SaveIcon from '@mui/icons-material/Save';
import HTMLService from '../../../services/Common/HTMLService';
import RoleAccess from '../../../services/Authorization/RoleAccess';
import { AccessType } from '../../../Model/SysModal/sysEntiry';

export interface BaseDocConstructorParams {
    title : string,
    component : string
}

export interface  BaseDocComponentProps extends AuthenitcatedComponentProps{}

export interface BaseDocComponentState {
    showSpinner: boolean,
    content: string,
    showPreviewModal: boolean,
    mergedContent: string,
    disableButtons: boolean,
    editorReadonly: boolean
}

export abstract class BaseDocComponent<P extends BaseDocComponentProps,
                                       S extends BaseDocComponentState , SS = {}> 
extends AuthenitcatedComponent<P,S,SS>{
    private _orgTemplate: string;
    private _docTemplate : string;
    private _contentconstParams : BaseDocConstructorParams;
    constructor(props: any, params : BaseDocConstructorParams) {
        super(props);
        this._contentconstParams= params;
        this._orgTemplate = "";
        this._docTemplate = "";
    }

    protected onComponentDidMount ?() : Promise<void>; 
    protected getdefaultState(): BaseDocComponentState{
        let readonly: boolean = false;
        if(this.PageComponent.accessdata.accessType === AccessType.Read) {
            readonly = true;
        }
        return {
            content:"",
            disableButtons: readonly,
            mergedContent :"",
            showPreviewModal: false,
            showSpinner:false,
            editorReadonly: readonly
        }
    }

    async componentDidMount() {
        let content: string="";
        this.setState({showSpinner : true});

        let fileresponse = await this.fetchFile(ORG_TEMPLATE);
        if (fileresponse.status === 200) {
            this._orgTemplate = fileresponse.data;
        }

        fileresponse = await this.fetchFile(DOC_TEMPLATE);
        if(fileresponse.status === 200) {
            this._docTemplate  = fileresponse.data;
        }

        fileresponse = await this.fetchFile(this._contentconstParams.component);
        if(fileresponse.status === 200) {
            let htmlelement = HTMLService.getHTMLElement(fileresponse.data);
            htmlelement=HTMLService.setHtmlElement(htmlelement,"orgname",this.UserProfile.organization.orgName);
            content = htmlelement.outerHTML;
        }
        
        if(this.onComponentDidMount){
            this.onComponentDidMount();
        }
        this.setState({content: content, showSpinner : false});
    }
    
    fetchFile = async (filename: string,reset?:boolean): Promise<IRestResponseEntity> => {
        let response = await TemplateService.getTemplate(filename,reset);
        if (response.status !== 200) {
            alert("Error while fetching the file.");
        }
        return response;
    }

    handleTextEditorOnChange = (value: any) => {
        this.setState({ content: value });
    }
    async handleReset(event: any) {
        let content : string="";
        event.preventDefault();
        let fileresponse = await this.fetchFile(this._contentconstParams.component, true);
        if(fileresponse.status === 200) {
            content = fileresponse.data;
        }
        this.setState({ content: content });
    }

    handlePreview(event: any) {
        event.preventDefault();
        let apiData = this.UserProfile.organization.orgDetails;
        let ordata: OrgDetailsEntity = {
            logo: TemplateService.getFieldValue("logo", apiData),
            orgName: this.UserProfile.organization.orgName,
            Address1: TemplateService.getFieldValue("Address1", apiData),
            Address2: TemplateService.getFieldValue("Address2", apiData),
            city: TemplateService.getFieldValue("city", apiData),
            state: TemplateService.getFieldValue("state", apiData),
            pincode: TemplateService.getFieldValue("pincode", apiData),
            phone: TemplateService.getFieldValue("phone", apiData),
            website: TemplateService.getFieldValue("website", apiData),
            email: TemplateService.getFieldValue("email", apiData),
            CEO: TemplateService.getFieldValue("CEO", apiData),
            CINNo: TemplateService.getFieldValue("CINNo", apiData),
            country: TemplateService.getFieldValue("country", apiData),
            CISO: TemplateService.getFieldValue("CISO", apiData),
            CTO: TemplateService.getFieldValue("CTO", apiData),
            founders: TemplateService.getFieldValue("founders", apiData),
            GstNo: TemplateService.getFieldValue("GstNo", apiData),
            id:  this.UserProfile.organization.clientId
        }
        let orgTemplateData = HTMLService.setOrgHtmlFromOrgTemplate(this._contentconstParams.title,this._orgTemplate,ordata);
        let doctempplatedata = HTMLService.setDocHtmlFromDocTemplate(this._docTemplate,this._contentconstParams.title, {});
        let previewContent = TemplateService.mergeHtmlDivContent(orgTemplateData,this.state.content,doctempplatedata);
        this.setState({ showPreviewModal: true, mergedContent: previewContent });
    }
    onCloseHandler() {
        this.setState({ showPreviewModal: false });
    }

    async handleTextEditorOnSave(event: any){
        event.preventDefault();
        let file = FileIOService.WritetoFile(`${this._contentconstParams.component}.txt`, this.state.content, CONTENT_TYPE);
        let formData = new FormData();
        formData.append("file", file);
        let response = await TemplateService.saveTemplate(formData);
        if(response.status ===200){
            alert(`${this._contentconstParams.title} Saved Successfully`);
        }
    }
    renderTextEditor() {
        return (
            <div className='rich-text-style'>
                <RichTextEditor
                    onChange={this.handleTextEditorOnChange.bind(this)}
                    defaultcontent={this.state.content}
                    content={this.state.content}
                    // placeholder="Enter the content here"
                    height="31em"
                    option={{readonly: this.state.editorReadonly, disable: this.state.editorReadonly}}
                    // showSave={false}
                 />
            </div>
        )
    }
    renderPreviewTextEditor() {
        let { mergedContent } = this.state;
        return (
            <div className='rich-text-style'>
                <RichTextEditor
                    defaultcontent={mergedContent}
                    content={mergedContent}
                    option={{readonly: true, autoFocus: true}}
                    height="40em" />
            </div>
        )
    }

    renderTopSection() {
        const {disableButtons } = this.state;
        return (
            <div className="col-md-12 d-flex justify-content-end">
                <IconButton aria-label="reset" color="primary" className={disableButtons ? "d-none": ""}>
                    <LockResetIcon onClick={this.handleReset.bind(this)} fontSize="large" titleAccess='Reset' />
                </IconButton>
                <IconButton aria-label="preview" color="primary" className={disableButtons ? "": "mx-5"}>
                    <PreviewIcon onClick={this.handlePreview.bind(this)} fontSize="large" titleAccess='Preview' />
                </IconButton>
                <IconButton aria-label="save" color="primary" className={disableButtons ? "d-none": ""}>
                    <SaveIcon onClick={this.handleTextEditorOnSave.bind(this)} fontSize="large" titleAccess='Save' />
                </IconButton>
            </div>
        )
    }

    renderPreviewSection() {
        let { showPreviewModal } = this.state;
        if (!showPreviewModal) {
            return null;
        }
        return (
            <Modal size='lg' show={showPreviewModal}>
                <div className="text-center p-2">
                    <div className="modal-header">
                        <button type="button" className="btn-close" onClick={this.onCloseHandler.bind(this)}> </button>
                    </div>
                    {this.renderPreviewTextEditor()}
                </div>
            </Modal>
        )
    }

    render() {
        return (
            <PolicyMakerWrapper>
                <SpinnersComponent showspinner={this.state.showSpinner} />
                <div className='main-div'>
                    <Box
                        sx={{
                            boxShadow: 2,
                            width: '50rem',
                            height: '40rem',
                            bgcolor: (theme) => (theme.palette.mode === 'dark' ? '#101010' : '#fff'),
                            color: (theme) =>
                                theme.palette.mode === 'dark' ? 'grey.300' : 'grey.800',
                            p: 1,
                            m: 1,
                            borderRadius: 1,
                            textAlign: 'center',
                            fontSize: '0.875rem',
                            fontWeight: '700',
                        }}
                    >
                        {this.renderTopSection()}
                        {this.renderTextEditor()}
                    </Box>
                </div>
                {this.renderPreviewSection()}
            </PolicyMakerWrapper>
        )
    }

}
export default BaseDocComponent