import React, { Component } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions } from '@mui/material';
import { TextField } from '@material-ui/core'
import Grid from '@material-ui/core/Grid';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import SendIcon from '@mui/icons-material/Send';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import SubjectIcon from '@mui/icons-material/Subject';
import EmailIcon from '@mui/icons-material/Email';
import CategoryIcon from '@mui/icons-material/Category';
import SpinnersComponent from '../../Components/SpinnersComponent';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import ContactUsService from '../../services/Application/ContactUsService';

import AuthenticatedBaseComponent from '../Base/AuthenticatedBaseComponent';

type ContactusState = {
  subject: string,
  content: string,
  showSpinner: boolean,
  files?: Blob[],
  category: string
}

export class Contactus extends AuthenticatedBaseComponent<any, ContactusState> {
  private uploadRef: React.RefObject<HTMLInputElement>;
  constructor(props: any) {
    super(props);
    this.state = {
      subject: "",
      content: "",
      files: [],
      showSpinner: false,
      category: ""
    }
    this.handleChange = this.handleChange.bind(this);
    this.uploadRef = React.createRef<HTMLInputElement>();
  }

  handleChange(event: any) {
    let field: string = event.target.id;
    switch (field) {
      case "subject": {
        this.setState({ subject: event.target.value });
        break;
      }
      case "content": {
        this.setState({ content: event.target.value });
        break;
      }
      case "files": {
        this.setState({ files: event.target.files });
        break;
      }
    }
  }

  handleDropChange = (event: any) => {
    this.setState({ category: event.target.value })
  }

  async onSubmitClick(event: any) {
    event.preventDefault();
    if (this.state.subject && this.state.content) {
      this.setState({ showSpinner: true });
      let formData = new FormData();
      formData.append("subject", this.state.subject);
      formData.append("query", this.state.content);
      formData.append("category", this.state.category);
      if (this.state.files && this.state.files.length > 0) {
        Array.prototype.forEach.call(this.state.files,
          file => {
            formData.append("attachment", file);
          })
      }

      if (await ContactUsService.postContactUsService(formData) === 200) {
        alert('Request received, will contact you shortly')
        this.setState({
          showSpinner: false,
          content: "",
          files: [],
          subject: ""
        });

        if (null !== this.uploadRef.current) {
          this.uploadRef.current.value = "";
        }
      }
      else {
        this.setState({ showSpinner: false });
      }
    }
  }

  render() {
    return (
      <>
        <SpinnersComponent key={`spinnercomp1`}
          showspinner={this.state.showSpinner}
        />
        <Grid key={`grid1`} container spacing={2}>
          <Grid key={`grid2`} item sm={4}></Grid>
          <Grid key={`grid3`} item sm={4}>

            <Card key={`card1`} sx={{ maxWidth: 600, border: 1, }} style={{ marginTop: 100 }}>
              {/* <CardActionArea key={`cardactionarea1`}> */}
              <CardContent key={`cardcontent1`}>
                <Typography key={`typography1`} gutterBottom variant="h5" component="div" >
                  Contact Us
                </Typography>
                <List key={`list1`} component="nav" >
                  <br />
                  <ListItem key={`listlist1`} >
                    <CategoryIcon style={{ color: "#0275d8" }} />
                    <FormControl>
                      <InputLabel key="lblstatus" id="lblcategory">Category</InputLabel>
                      <Select
                        key="ddlstatus"
                        labelId="categorylbl"
                        id="category"
                        label="Category"
                        value={this.state.category}
                        onChange={this.handleDropChange.bind(this)}
                        style={{ width: '15em' }}
                      >
                        <MenuItem key="select-status-option-T" value={"Technical Support"}>Technical Support</MenuItem>
                        <MenuItem key="select-status-option-A" value={"Audit Support"}>Audit Support</MenuItem>
                        <MenuItem key="select-status-option-B" value={"Billing Support"}>Billing Support</MenuItem>
                        <MenuItem key="select-status-option-O" value={"Others"}>Others</MenuItem>

                      </Select> </FormControl>
                    <span key={`span1`} style={{ color: "red" }}>*</span>
                  </ListItem>
                  <br />
                  <ListItem key={`listlist2`} >
                    <SubjectIcon key={`subjecticon1`} style={{ color: "#0275d8" }} />
                    <TextField key={`text1`} id="subject" label="Subject" value={this.state.subject}
                      onChange={this.handleChange}
                      fullWidth variant="outlined"
                      autoComplete='off' />
                    <span key={`span1`} style={{ color: "red" }}>*</span>
                  </ListItem>
                  {/* <Divider key={`divider1`} /> */}
                  <br />
                  <ListItem key={`listlist3`}>
                    <EmailIcon style={{ color: "#0275d8" }} />
                    <TextField key={`text2`} id="content" label="Query" value={this.state.content}
                      onChange={this.handleChange}
                      fullWidth variant="outlined"
                      multiline={true}
                      autoComplete='off' />
                    <span key={`span2`} style={{ color: "red" }}>*</span>
                  </ListItem>
                  {/* <Divider key={`divider2`} /> */}
                  <br />
                  <ListItem key={`listlist4`} >
                    <AttachFileIcon style={{ color: "#0275d8" }} />
                    <div key={`div1`} className="file-field">
                      <a key={`ancor1`} className="btn-floating peach-gradient mt-0 float-left">
                        <i key={`i1`} className="fas fa-paperclip" aria-hidden="true"></i>
                        <input key={`inputupload`} id="files" type="file"
                          accept="application/PDF , image/gif, image/png ,image/jpeg "
                          multiple
                          ref={this.uploadRef}
                          onChange={this.handleChange} />
                      </a>
                    </div>
                  </ListItem>
                  {/* <Divider key={`divider3`} /> */}
                </List>
              </CardContent>
              {/* </CardActionArea> */}
              <CardActions key={`cardaction11`} style={{ textAlign: "center", justifyContent: "center" }}>
                <Button key={`button1`} variant="contained" size="large" onClick={this.onSubmitClick.bind(this)} startIcon={<SendIcon />}>
                  Submit
                </Button>
              </CardActions>
            </Card>
          </Grid>
          <Grid key={`grid4`} item md={4}></Grid>
        </Grid>
      </>
    )
  }
}

export default Contactus