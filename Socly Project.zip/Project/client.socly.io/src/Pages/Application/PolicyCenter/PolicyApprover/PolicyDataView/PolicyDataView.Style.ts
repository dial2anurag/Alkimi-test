import styled from 'styled-components';

const PolicyDataViewWrapper = styled.div`
.rich-text-style {
    font-weight: normal;
    padding: 10px 80px;
}
.policy-data-view {
    font-size: 16px; 
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 10px;
    padding: 24px;
    text-align: center;
}
.white-opacity-box {
    margin-bottom: 20px;
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgb(90 90 90 / 15%);
    border-radius: 7px;
    padding: 12px;
    margin-top: 12px;
    text-align: center;
    color: #272727;
    font-size: 18px;
    font-family: 'ProductSansMedium';
}
.btn {
    border-radius: 4px;
    font-size: 16px;
    margin-left: 15px;
    padding: 8px 40px;
}
`;

export default PolicyDataViewWrapper;

