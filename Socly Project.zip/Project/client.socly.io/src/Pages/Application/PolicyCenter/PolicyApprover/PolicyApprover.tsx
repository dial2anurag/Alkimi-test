import React, { Component } from 'react';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../../../Base/AuthenticatedRouteComponent';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import PolicyApproverWrapper from './PolicyApprover.Style';
import PolicyReviewComment from './PolicyReviewComment/PolicyReviewComment';
import { Button,Modal } from 'react-bootstrap';
import {ColDef , GridReadyEvent , ICellRendererComp, ICellRendererParams} from 'ag-grid-community';
import {AgGridReact } from 'ag-grid-react';
import PolicyDataView from './PolicyDataView/PolicyDataView';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import PolicyCenterService from '../../../../services/Application/PolicyCenterService';
import { OrgDetailsEntity } from '../../../../Model/Organization/Org';
import PolicyMakerService from '../../../../services/Application/PolicyMakerService';
import FileIOService from '../../../../services/Common/FileIOService';
import CommentIcon from '@mui/icons-material/Comment';
import IconButton from '@mui/material/IconButton';
import PageviewIcon from '@mui/icons-material/Pageview';
import HTMLService from '../../../../services/Common/HTMLService';
import TemplateService , { CONTENT_TYPE, DOC_TEMPLATE, ORG_TEMPLATE } from '../../../../services/Application/Documentation/TemplateService';

interface PolicyCenterState {
    policiesList: any[],
    selectedpolicy ?: any
    showspinner :boolean,
    isBack: boolean ,
    isViewed: boolean,
    isBackBtn: boolean,
    show: boolean,
    comments: string,
    policyContent: string,
    orgContent: string
}

export class PolicyApprover extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, PolicyCenterState> {
    private gridInstance :GridReadyEvent | undefined;
    private _orgContent: string;
    private _docTemplate : string;
    private _orgData: OrgDetailsEntity | undefined;
    constructor(props: AuthenticatedRouteComponentProps) {
        super(props)
        this.state = {
            policiesList: [],
            showspinner :false,
            isBack: false,
            isViewed: false,
            isBackBtn: false,
            show: false,
            comments: "",
            policyContent :"",
            orgContent :""
        }
        this._orgContent = "";
        this._docTemplate = "";
    }

    async componentDidMount() {
        let response = await TemplateService.getTemplate(ORG_TEMPLATE);
        if(response.status !== 200) {
            alert("Error while fetching the OrgTemplate");
        }
        this._orgContent = response.data;
        let orgDetails = this.UserProfile.organization.orgDetails; 
        this._orgData = {
            logo: TemplateService.getFieldValue("logo", orgDetails),
            orgName: this.UserProfile.organization.orgName,
            Address1: TemplateService.getFieldValue("Address1", orgDetails),
            Address2: TemplateService.getFieldValue("Address2", orgDetails),
            city: TemplateService.getFieldValue("city", orgDetails),
            state: TemplateService.getFieldValue("state", orgDetails),
            pincode: TemplateService.getFieldValue("pincode", orgDetails),
            phone: TemplateService.getFieldValue("phone", orgDetails),
            website: TemplateService.getFieldValue("website", orgDetails),
            email: TemplateService.getFieldValue("email", orgDetails),
            CEO: TemplateService.getFieldValue("CEO", orgDetails),
            CINNo: TemplateService.getFieldValue("CINNo", orgDetails),
            country: TemplateService.getFieldValue("country", orgDetails),
            CISO: TemplateService.getFieldValue("CISO", orgDetails),
            CTO: TemplateService.getFieldValue("CTO", orgDetails),
            founders: TemplateService.getFieldValue("founders", orgDetails),
            GstNo: TemplateService.getFieldValue("GstNo", orgDetails),
            id : 2
        }
        response = await TemplateService.getTemplate(DOC_TEMPLATE);
        if(response.status !== 200) {
            alert("Error while fetching the DocTemplate");
        }
        this._docTemplate  = response.data;
        this.prepareAgGridData();
    }
    async prepareAgGridData() {
        let policies: any[]=[];
        let response = await PolicyCenterService.getPoliciesOnStatus();
        if(response.status === 200) {
            Array.prototype.forEach.call(response.data, (policy)=>{
                policies.push({
                    id: policy.id,
                    name: PolicyCenterService.getPolicyName(policy),
                    createdBy: policy.createdBy ? policy.createdBy.name : "",
                    status: policy.policyStatus,
                    comments: policy.comments,
                    data: policy
                })
            })
            this.setState({ policiesList: policies});
            this.setAndRefreshGrid();
        }
    }
    gridColumnDef(): ColDef[] {
        return [{
          field: "name",
          headerName: "Policy Name",
          width: 100,
          cellRendererFramework: (params: any) => {
            return this.loadPolicyName(params);
          }
        }, {
          field: "createdBy",
          headerName: "Created by",
          width: 100
        }, {
          field: "status",
          headerName: "Status",
          width: 100
        }, {
          field: "comments",
          headerName: "Comments",
          filter: false,
            sortable: false,
            cellRendererFramework: (params: any) => {
                return this.reviewComments(params);
            }
        }, {
            field: "id",
            headerName: "View",
            filter: false,
            sortable: false,
            cellRendererFramework: (params: any) => {
                return this.loadViewButton(params);
            }
        }
    ]
    }
    reviewComments(params: any) {
        return (
            <IconButton aria-label="reset" color="primary">
                {params.value ? 
                    <CommentIcon onClick={()=> this.requestChangeHdlr(params)} fontSize="medium" titleAccess='Comment'/>
                : null }
            </IconButton>
          )
    }
    loadViewButton(params : any){
        // if(params.data.data.createdBy && 
        //     params.data.data.createdBy.username &&
        //     params.data.data.createdBy.username === this.UserProfile.username
        // ){ return null; }

        return (
            <IconButton aria-label="reset" color="primary">
                <PageviewIcon onClick={()=> this.requestViewHdlr(params)} fontSize="medium" titleAccess='View'/>
            </IconButton>
          )
    }

    loadPolicyName(params : any){
        return (
            <div 
                key={`policyname-${params.data.id}`}
                className='text-capitalize'>{params.value}</div>
          )
    }

    defaultGridColumnsDef(): ColDef {
        return {
            sortable: true,
            resizable: true,
            filter: true,
            flex: 1
        }
    }
    onGridReady(params: GridReadyEvent) {
        this.gridInstance = params;
        this.setAndRefreshGrid();
    }
    setAndRefreshGrid() {
        if (this.gridInstance) {
            this.gridInstance.api.refreshCells();
        }
    }
    async requestViewHdlr (param: any) {
        let policy = this.state.policiesList.find(e => e.id === param.value);
        if(!policy) {
            return ;
        }
        let response = await PolicyMakerService.getFileDetail(policy.name);
        if (response.status !== 200) {
            alert("Error while fetching the file.");
        }
        let orgContent = HTMLService.setOrgHtmlFromOrgTemplate(policy.name, this._orgContent, this._orgData!);
        let policyContent = await FileIOService.getContentfromFileStream(response.data.fileContent, policy.name, CONTENT_TYPE);
        this.setState({
            orgContent : orgContent,
            policyContent : policyContent,
            selectedpolicy: policy, 
            isViewed: true, isBack : true, isBackBtn : true})
    }
    requestBacklHdlr () {
        this.setState({ isBack : false, isViewed : false, isBackBtn : false, selectedpolicy: null});
    }
    requestChangeHdlr (param: any) {
        this.setState({show : !this.state.show, comments: param.value});
    }
    onSuccessSave () {
        this.setState({ isBack : false, isViewed : false, isBackBtn : false, selectedpolicy: null});
        this.prepareAgGridData();
    }

    render() {
        let {isViewed, isBack, isBackBtn, showspinner, policiesList, show, selectedpolicy, comments} = this.state;
        return (
            <PolicyApproverWrapper>
                <SpinnersComponent key="policycenterspinnercomponent" showspinner={showspinner} disablesection={true} />
                {isBackBtn ?
                    <div className="text-end mb-4">
                        <Button variant='primary' onClick={()=>this.requestBacklHdlr()}><ArrowBackIosNewIcon fontSize='small' />Back</Button>
                    </div>
                : null }
                {!isViewed ?
                    <div className='main-div'>
                        <div className="ag-theme-alpine" style={{ height: 400, width: "100%", textAlign: "left" }}>
                            <AgGridReact
                                defaultColDef={this.defaultGridColumnsDef()}
                                columnDefs={this.gridColumnDef()}
                                enableCellChangeFlash={true}
                                onGridReady={this.onGridReady.bind(this)}
                                pagination={true}
                                paginationPageSize={10}
                                rowData={policiesList}
                            />
                        </div>
                        <Modal show={show} >
                            <div className="text-center p-2">
                                <div className="modal-header">    
                                    <button type="button" className="btn-close" onClick={()=>this.setState({show: false})}> </button>
                                </div>
                                <PolicyReviewComment title='Review Comment' readonly={true} comments={comments} />
                            </div>
                        </Modal>
                    </div>
                : null }
                {isBack ? 
                    <PolicyDataView 
                    policy={selectedpolicy!} 
                    docTemplate ={this._docTemplate}
                    orgContent ={this.state.orgContent}
                    policyContent={this.state.policyContent}
                    onSuccessSave={this.onSuccessSave.bind(this)} />
                : null}
        </PolicyApproverWrapper>
        )
    }
}
export default PolicyApprover;



