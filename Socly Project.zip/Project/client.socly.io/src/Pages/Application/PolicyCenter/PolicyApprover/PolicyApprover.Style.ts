import styled from 'styled-components';

const PolicyApproverWrapper = styled.div`
.main-div {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 10px;
    padding: 24px;
}
`;

export default PolicyApproverWrapper;

