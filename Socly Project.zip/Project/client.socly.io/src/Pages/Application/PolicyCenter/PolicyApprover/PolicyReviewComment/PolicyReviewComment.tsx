import React, { Component } from 'react';
import AuthenticatedBaseComponent from '../../../../Base/AuthenticatedBaseComponent';
import {ContentHeading} from '../../../../../StyledComponents/ComponentWrapper';
import SpinnersComponent from '../../../../../Components/SpinnersComponent';
import PolicyReviewCommentWrapper from './PolicyReviewComment.Style';
import { PolicyStatus } from '../../../../../Model/Policy/PolicyStatus';
interface PolicyApproverState {
    showSpinner :boolean,
    comments: string
}
interface PolicyApproverProps {
    title: string,
    readonly: boolean,
    comments?: string,
    handlePolicyApproverContentSave?: (policyStatus: string, comments: string) => void
}
export class PolicyReviewComment extends AuthenticatedBaseComponent<PolicyApproverProps, PolicyApproverState> {
    constructor(props: PolicyApproverProps) {
        super(props);
        let comments: string = "";
        if(this.props.comments) {
            comments = this.props.comments;
        }
        this.state = {
            showSpinner :false,
            comments: comments
        }
    }
    handleSubmitComments() {
        let policyStatus = PolicyStatus[PolicyStatus.RequestChange];
        let comments = this.state.comments;
        if(this.props.handlePolicyApproverContentSave) {
            this.props.handlePolicyApproverContentSave(policyStatus, comments);
        }
    }
    render() {
        let {showSpinner, comments} = this.state;
        let {title, readonly} = this.props;
        return (
            <PolicyReviewCommentWrapper>
                <div>
                    <SpinnersComponent key="policycenterspinnercomponent" showspinner={showSpinner} disablesection={true} />
                    <ContentHeading>{title}</ContentHeading>
                    <div className='GridCnt'>
                        <div className='MultiLineTxtBoxHldr'> 
                            <form>
                                <textarea className="form-control" rows={6} value={comments} 
                                    readOnly={readonly} onChange={(event)=>this.setState({comments: event.target.value})}></textarea> 
                            </form>
                        </div>
                        {!readonly ? 
                            <div className='SubmitBtn'>
                                <button type="button" className="btn btn-primary" 
                                    onClick={this.handleSubmitComments.bind(this)}>Submit</button>
                            </div>
                        : null }
                    </div>
                </div>
            </PolicyReviewCommentWrapper>
        )
    } 
}
export default PolicyReviewComment;
