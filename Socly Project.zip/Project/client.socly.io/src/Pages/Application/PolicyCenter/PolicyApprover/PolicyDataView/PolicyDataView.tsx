import AuthenticatedBaseComponent from '../../../../Base/AuthenticatedBaseComponent';
import SpinnersComponent from '../../../../../Components/SpinnersComponent';
import PolicyDataViewWrapper from './PolicyDataView.Style';
import RichTextEditor from '../../../../../Components/RichTextEditor/RichTextEditor';
import PolicyMakerService from '../../../../../services/Application/PolicyMakerService';
import { PolicyStatus } from '../../../../../Model/Policy/PolicyStatus';
import { Modal } from 'react-bootstrap';
import PolicyReviewComment from '../PolicyReviewComment/PolicyReviewComment';
import HTMLService from '../../../../../services/Common/HTMLService';
import FileIOService from '../../../../../services/Common/FileIOService';
import TemplateService, { CONTENT_TYPE } from '../../../../../services/Application/Documentation/TemplateService';
import { DocumentSummeryEntity } from '../../../../../Model/Organization/Org';
interface PolicyApproverState {
    showspinner: boolean,
    showRequestChangeModal: boolean,
    comments: string
}
interface PolicyApproverProps {
    policy: any,
    policyContent: string,
    orgContent : string,
    docTemplate : string,
    onSuccessSave: () => void
}
export class PolicyDataView extends AuthenticatedBaseComponent<PolicyApproverProps, PolicyApproverState> {
    private _content : string;
    private _disableButton : boolean;
    constructor(props: PolicyApproverProps) {
        super(props);
        if(this.props.policy.data.createdBy &&
           this.props.policy.data.createdBy.username &&
           this.props.policy.data.createdBy.username === this.UserProfile.username
        ){
            this._disableButton=true;
        }
        else{
            this._disableButton=false;
        }
        let docsummery : DocumentSummeryEntity ={
            approvedBy : this.props.policy.data && this.props.policy.data.approvedBy 
                        && this.props.policy.data.approvedBy.name ? this.props.policy.data.approvedBy.name :"",
            approvedOn : this.props.policy.data && this.props.policy.data
                         && this.props.policy.data.approvedOn ?this.props.policy.data.approvedOn :undefined,
            createdBy : this.props.policy.data && this.props.policy.data
                        && this.props.policy.data.createdBy 
                        && this.props.policy.data.createdBy.name ? this.props.policy.data.createdBy.name :"",
            createdOn : this.props.policy.data && this.props.policy.data
                        && this.props.policy.data.createdOn ?this.props.policy.data.createdOn :undefined
        }

        let docContent = HTMLService.setDocHtmlFromDocTemplate(this.props.docTemplate ,"Policy",docsummery);
        this._content = TemplateService.mergeHtmlDivContent(this.props.orgContent,this.props.policyContent,docContent);
        this.state = {
            showspinner :false,
            showRequestChangeModal: false,
            comments: this.props.policy.comments ? this.props.policy.comments : "" ,
        }
    }
    async handlePolicyApproverContentSave(policyStatus: string, comment?: string) {
        this.setState({showspinner : true});
        let showmodal : boolean = this.state.showRequestChangeModal;
        let formData = new FormData();
        formData.append("id", this.props.policy.id);
        formData.append("policyStatus", policyStatus);
        if(comment) {
            formData.append("comments", comment);
        }
        let response = await PolicyMakerService.SavePolicyFile(formData);
        if(response.status === 200) {
            alert("Request Saved Successfully");
            showmodal=false;
            if(this.props.onSuccessSave) {
                this.props.onSuccessSave();
            }
        } 
        this.setState({showspinner : false,showRequestChangeModal: showmodal});
    }
    handleRequestChange(event: any): void {
        event.preventDefault();
        this.setState({showRequestChangeModal : true});
    }
    handleRejectPolicy(event: any): void {
        event.preventDefault();
        let policyStatus = PolicyStatus[PolicyStatus.Rejected];
        this.handlePolicyApproverContentSave(policyStatus);
    }

    async approveSave(file : File) : Promise<void>{
    }

    async handleApprovePolicy(event: any) {
        event.preventDefault();
        this.setState({showspinner : true});
        let policyStatus = PolicyStatus[PolicyStatus.Approved];
        let userProfile = this.UserProfile;
        let profile ={
            id: userProfile.id,
            username: userProfile.username,
            name: userProfile.name,
        };

        let policy = this.deepCopy<any>(this.props.policy.data);
        policy["approvedOn"]=new Date().toString();
        policy["approvedBy"]=profile;
        
        let docContent = HTMLService.setDocHtmlFromDocTemplate(this.props.docTemplate,"Policy",policy);
        let content = TemplateService.mergeHtmlDivContent(this.props.orgContent,this.props.policyContent,docContent );
        let file = FileIOService.WritetoFile(`${this.props.policy.name}.txt`, content, CONTENT_TYPE);

        let formData = new FormData();
        formData.append("id", this.props.policy.id);
        formData.append("policyStatus", policyStatus);
        formData.append("approved_policy_files", file);
        let reponse = await PolicyMakerService.SaveApprovedPolicy(formData);
        if (reponse === 200) {
            alert("Policy Approved Successfully");
            if(this.props.onSuccessSave) {
                this.props.onSuccessSave();
            }
        }
        this.setState({showspinner : false});
    }

    renderTopSection() {
        return (
            <div className="d-flex justify-content-between">
                <div className='col-md-4 white-opacity-box text-capitalize'>{this.props.policy.name}</div>
                <div className="mt-3">
                    <button type="button" className="btn btn-warning px-3" 
                        disabled={this._disableButton}
                        onClick={this.handleRequestChange.bind(this)}>Request Change</button>
                    <button type="button" className="btn btn-danger" 
                        disabled={this._disableButton}
                        onClick={this.handleRejectPolicy.bind(this)}>Reject</button>
                    <button type="button" className="btn btn-success"
                        disabled={this._disableButton}
                        onClick={this.handleApprovePolicy.bind(this)}>Approve</button>
                </div>
            </div>
        )
    }
    renderTextEditor() {
        return (
            <div className='rich-text-style'>
                <RichTextEditor 
                    height='31em'
                    option={{autoFocus : true , readonly: true}}
                    defaultcontent={this._content}
                    content={this._content}
                /> 
            </div>
        )
    }
    renderRequestChange() {
        let {showRequestChangeModal, comments} = this.state;
        if(!showRequestChangeModal) {
            return null;
        }
        return (
            <Modal show={showRequestChangeModal}>
                <div className="text-center p-2">
                    <div className="modal-header">    
                        <button type="button" className="btn-close" onClick={()=>this.setState({showRequestChangeModal: false})}> </button>
                    </div>
                    <PolicyReviewComment title='Request Change' readonly={false} comments={comments} handlePolicyApproverContentSave={this.handlePolicyApproverContentSave.bind(this)} />
                </div>
            </Modal>
        )
    }
    render() {
        return (
            <PolicyDataViewWrapper>
                <SpinnersComponent key="policyviewspinnercomponent" showspinner={this.state.showspinner} disablesection={true} />
                <div className='policy-data-view'>
                    {this.renderTopSection()}
                    {this.renderTextEditor()}
                </div>
                {this.renderRequestChange()}
            </PolicyDataViewWrapper>
        )
    }
}
export default PolicyDataView;

