import styled from 'styled-components';

const PolicyReviewCommentWrapper = styled.div`
.GridCnt {
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border: solid 1px #F2F2F2;
}
.SubmitBtn {
    float: right;
    margin-top: 5%;
    margin-bottom: 5%;
}
`;


export default PolicyReviewCommentWrapper;

