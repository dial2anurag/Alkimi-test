import styled from 'styled-components';

const PolicyMakerWrapper = styled.div`
.main-div {
    margin-left: 5em;
}
.rich-text-style {
    margin-top: 1em;
    font-weight: normal;
}
.top-section {
    margin-top: 2em;
}
.btn-block {
    background: #1752C3;
    border-radius: 10px;
    font-family: 'ProductSansBold';
    font-size: 16px;
    color: #FFFFFF;
    width: 100%;
    margin-left: 10px;
}
`;

export default PolicyMakerWrapper;