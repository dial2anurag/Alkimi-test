import React, { Component } from 'react';
import AuthenticatedRouteComponent, { AuthenticatedRouteComponentProps } from '../../../Base/AuthenticatedRouteComponent';
import Box from '@mui/material/Box';
import RichTextEditor, {RichTextEditorOptionEntity} from '../../../../Components/RichTextEditor/RichTextEditor';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import PolicyCenterService from '../../../../services/Application/PolicyCenterService';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import PolicyMakerService from '../../../../services/Application/PolicyMakerService';
import {APIData, DocumentSummeryEntity, OrgDetailsEntity} from '../../../../Model/Organization/Org';
import FileIOService from '../../../../services/Common/FileIOService'
import { PolicyStatus } from '../../../../Model/Policy/PolicyStatus';
import PolicyMakerWrapper from './policyMaker.style';
import { Modal } from 'react-bootstrap';
import { IRestResponseEntity } from '../../../../Model/RestEntities';
import IconButton from '@mui/material/IconButton';
import LockResetIcon from '@mui/icons-material/LockReset';
import PreviewIcon from '@mui/icons-material/Preview';
import SaveIcon from '@mui/icons-material/Save';
import RateReviewIcon from '@mui/icons-material/Grading';
import HTMLService from '../../../../services/Common/HTMLService';
import TemplateService , { ORG_TEMPLATE, CONTENT_TYPE,DOC_TEMPLATE } from '../../../../services/Application/Documentation/TemplateService';

interface PolicyMakerState {
    showSpinner: boolean,
    policiesList: string[],
    selectedpolicy?: { id: number, name: string, details: any },
    policyContent: string,
    showPreviewModal: boolean,
    mergedContent: string,
    disableButtons: boolean,
    editorReadonly: boolean
}

export class PolicyMaker extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, PolicyMakerState>{
    private _orgTemplate: string;
    private _orghtmlString: string;
    private _docTemplate : string;
    constructor(props: AuthenticatedRouteComponentProps) {
        super(props);
        this.state =
        {
            showSpinner: false,
            policiesList: [],
            policyContent: "",
            showPreviewModal: false,
            mergedContent: "",
            disableButtons: true,
            editorReadonly: false
        }
        this._orgTemplate = "";
        this._orghtmlString = "";
        this._docTemplate = "";
    }
    async componentDidMount() {
        let policiesList: string[] = [];
        let response = await PolicyCenterService.getPolicies();
        if (response.status === 200 && response.data && response.data.length > 0) {
            Array.prototype.forEach.call(response.data, (item, index) => {
                if(item.name.toLowerCase() !== ORG_TEMPLATE.toLowerCase()  
                && item.name.toLowerCase() !== DOC_TEMPLATE.toLowerCase())
                policiesList.push(item.name);
            })
        }
        // Fetch Org Template 
        let fileresponse = await this.fetchFile(ORG_TEMPLATE,true);
        if (fileresponse.status === 200) {
            this._orgTemplate = fileresponse.data;
        }

        fileresponse = await this.fetchFile(DOC_TEMPLATE,true);
        if(fileresponse.status === 200) {
            this._docTemplate  = fileresponse.data;
        }

        this.setState({
            policiesList: policiesList,
        });

    }

    fetchFile = async (filename: string,istemplate ? : boolean,reset?:boolean): Promise<IRestResponseEntity> => {
        let response : IRestResponseEntity;
        if(istemplate){
            response = await TemplateService.getTemplate(filename,reset);
        }
        else{
            response = await PolicyMakerService.getFileDetail(filename,reset);
        }
        if (response.status !== 200) {
            alert("Error while fetching the file.");
        }
        return response;
    }
    handleTextEditorOnChange = (value: any) => {
        if(!this.state.editorReadonly) {
            this.setState({ policyContent: value });
        }
    }
    async handleReset(event: any) {
        event.preventDefault();
        if (!this.state.selectedpolicy) {
            return
        }
        let response = await this.fetchFile(this.state.selectedpolicy.name,false,true);
        if (response.status !== 200) {
            alert("Error while fetching the file.");
            return;
        }
        let fileresponse= await FileIOService.getContentfromFileStream(response.data.fileContent, this.state.selectedpolicy.name, CONTENT_TYPE);
        this.setState({ policyContent: fileresponse });
        return {
            status: response.status,
            data: response.data
        }
    }
    handlePreview(event: any) {
        event.preventDefault();
        if (!this.state.selectedpolicy) {
            return
        }
        let apiData= this.UserProfile.organization.orgDetails;
        // Fetch Org Details
        let ordata: OrgDetailsEntity = {
            logo: TemplateService.getFieldValue("logo", apiData),
            orgName: this.UserProfile.organization.orgName,
            Address1: TemplateService.getFieldValue("Address1", apiData),
            Address2: TemplateService.getFieldValue("Address2", apiData),
            city: TemplateService.getFieldValue("city", apiData),
            state: TemplateService.getFieldValue("state", apiData),
            pincode: TemplateService.getFieldValue("pincode", apiData),
            phone: TemplateService.getFieldValue("phone", apiData),
            website: TemplateService.getFieldValue("website", apiData),
            email: TemplateService.getFieldValue("email", apiData),
            CEO: TemplateService.getFieldValue("CEO", apiData),
            CINNo: TemplateService.getFieldValue("CINNo", apiData),
            country: TemplateService.getFieldValue("country", apiData),
            CISO: TemplateService.getFieldValue("CISO", apiData),
            CTO: TemplateService.getFieldValue("CTO", apiData),
            founders: TemplateService.getFieldValue("founders", apiData),
            GstNo: TemplateService.getFieldValue("GstNo", apiData),
            id: this.UserProfile.organization.clientId
        }
        let orgTemplateData = HTMLService.setOrgHtmlFromOrgTemplate(this.state.selectedpolicy ? this.state.selectedpolicy.name : "", this._orgTemplate, ordata);
        let docsummery : DocumentSummeryEntity ={
            approvedBy : this.state.selectedpolicy && this.state.selectedpolicy.details 
                        && this.state.selectedpolicy.details.approvedBy 
                        && this.state.selectedpolicy.details.approvedBy.name ? this.state.selectedpolicy.details.approvedBy.name :"",
            approvedOn : this.state.selectedpolicy && this.state.selectedpolicy.details 
                         && this.state.selectedpolicy.details.approvedOn ?this.state.selectedpolicy.details.approvedOn :undefined,
            createdBy : this.state.selectedpolicy && this.state.selectedpolicy.details 
                        && this.state.selectedpolicy.details.createdBy 
                        && this.state.selectedpolicy.details.createdBy.name ? this.state.selectedpolicy.details.createdBy.name :"",
            createdOn : this.state.selectedpolicy && this.state.selectedpolicy.details 
                        && this.state.selectedpolicy.details.createdOn ?this.state.selectedpolicy.details.createdOn :undefined
        }
        let doctempplatedata = HTMLService.setDocHtmlFromDocTemplate(this._docTemplate,"Policy",docsummery);
        let previewContent = TemplateService.mergeHtmlDivContent(orgTemplateData, this.state.policyContent,doctempplatedata);
        this.setState({ showPreviewModal: true, mergedContent: previewContent });
    }
    
    onCloseHandler() {
        this.setState({ showPreviewModal: false });
    }
    handlePolicyMakerContentSave(content: string, policyStatus: string) {
        if (!this.state.selectedpolicy) {
            return;
        }
        let file = FileIOService.WritetoFile(`${this.state.selectedpolicy.name}.txt`, content, CONTENT_TYPE);
        let formData = new FormData();
        formData.append("id", ((this.state.selectedpolicy && this.state.selectedpolicy.id) ? this.state.selectedpolicy.id : 0).toString());
        formData.append("policyStatus", policyStatus);
        formData.append("unapproved_policy_files", file);

        PolicyMakerService.SavePolicyFile(formData).then((response) => {
            if (response.status === 200) {
                let selectedpolicy = this.state.selectedpolicy!;
                selectedpolicy.details = response.data;
                selectedpolicy.id = response.data.id;
                let editorReadonly: boolean = false;
                let disableButtons: boolean = false;
                if (policyStatus === PolicyStatus[PolicyStatus.SendToApproval]) {
                    editorReadonly = true;
                    disableButtons = true;
                }
                this.setState({ selectedpolicy: selectedpolicy, disableButtons: disableButtons, editorReadonly: editorReadonly });
                alert("Policy Saved Successfully");
            }
        });
    }
    handleTextEditorOnSave(event: any): void {
        event.preventDefault();
        let policyStatus = PolicyStatus[PolicyStatus.InProgress];
        this.handlePolicyMakerContentSave(this.state.policyContent, policyStatus);
    }
    handleSendtoReview(event: any): void {
        event.preventDefault();
        if (!this.state.selectedpolicy || this.state.policyContent === "") {
            return;
        }
        let content = this.state.policyContent;
        let policyStatus = PolicyStatus[PolicyStatus.SendToApproval];
        this.handlePolicyMakerContentSave(content, policyStatus);
    }
    handleDdlPolicyChange(event: any) {
        let policyName = event.target.value;
        let policy = this.state.policiesList.find(f => f === policyName);
        if (policy) {
            this.fetchFile(policy).then((response) => {
                if (response.status === 200) {
                    FileIOService.getContentfromFileStream(response.data.fileContent, policyName, CONTENT_TYPE)
                        .then((filestreamresponse) => {
                            let editorReadonly: boolean = false;
                            let disableButtons: boolean = false;
                            if (response.data.details && response.data.details.policyStatus === PolicyStatus[PolicyStatus.SendToApproval]) {
                                editorReadonly = true;
                                disableButtons = true;
                            }
                            this.setState({
                                selectedpolicy: { id: response.data.details ? response.data.details.id : 0, name: policyName, details: response.data.details },
                                policyContent: filestreamresponse,
                                disableButtons: disableButtons,
                                editorReadonly: editorReadonly
                            })
                        })
                }
            })
        }
    }
    renderTextEditor() {
        return (
            <div className='rich-text-style'>
                <RichTextEditor
                    onChange={this.handleTextEditorOnChange.bind(this)}
                    content={this.state.policyContent}
                    height="31em"
                    placeholder="Select the policy and edit"
                    option={{showSave : false , 
                            readonly :  this.state.editorReadonly,
                            disable : this.state.editorReadonly
                        }}
                    />
            </div>
        )
    }
    renderPreviewTextEditor() {
        let { mergedContent } = this.state;
        return (
            <div className='rich-text-style'>
                <RichTextEditor
                    defaultcontent={mergedContent}
                    content={mergedContent}
                    option={{autoFocus : true , readonly : true}}
                    height="40em">
                </RichTextEditor>
            </div>
        )
    }

    renderTopSection() {
        const { selectedpolicy, policiesList, disableButtons } = this.state;
        return (
            <div className="d-flex justify-content-between top-section">
                <div className='col-md-7'>
                    <FormControl key="frmctrlpolicy" className='w-100'>
                        <InputLabel key="lblpolicy" className='form-label' id="select-policy">Policy</InputLabel>
                        <Select
                            key="ddlpolicy"
                            labelId="selectpolicy"
                            label="Policy"
                            value={selectedpolicy?.name}
                            onChange={this.handleDdlPolicyChange.bind(this)}
                        >
                            {
                                policiesList.map((policy, index) => {
                                    return (
                                        <MenuItem key={`policy-${index}`} value={policy}>{policy}</MenuItem>
                                    )
                                })
                            }
                        </Select>
                    </FormControl>
                </div>
                <div className="col-md-5 d-flex justify-content-evenly">
                    <IconButton aria-label="reset" color="primary" disabled={disableButtons}>
                        <LockResetIcon onClick={this.handleReset.bind(this)} fontSize="large" titleAccess='Reset' />
                    </IconButton>
                    <IconButton aria-label="preview" color="primary" disabled={this.state.selectedpolicy ? false : true }>
                        <PreviewIcon onClick={this.handlePreview.bind(this)} fontSize="large" titleAccess='Preview'/>
                    </IconButton>
                    <IconButton aria-label="save" color="primary" disabled={disableButtons}>
                        <SaveIcon onClick={this.handleTextEditorOnSave.bind(this)} fontSize="large" titleAccess='Save' />
                    </IconButton>
                    <IconButton aria-label="sendtoreview" color="primary" disabled={disableButtons}>
                        <RateReviewIcon onClick={this.handleSendtoReview.bind(this)} fontSize="large" titleAccess='Send to Review' />
                    </IconButton>
                </div>
            </div>
        )
    }

    renderPreviewSection() {
        let { showPreviewModal } = this.state;
        if (!showPreviewModal) {
            return null;
        }
        return (
            <Modal size='lg' show={showPreviewModal}>
                <div className="text-center p-2">
                    <div className="modal-header">
                        <button type="button" className="btn-close" onClick={this.onCloseHandler.bind(this)}> </button>
                    </div>
                    {this.renderPreviewTextEditor()}
                </div>
            </Modal>
        )
    }

    render() {
        return (
            <PolicyMakerWrapper>
                <SpinnersComponent showspinner={this.state.showSpinner} />
                <div className='main-div'>
                    <Box
                        sx={{
                            boxShadow: 2,
                            width: '50rem',
                            height: '40rem',
                            bgcolor: (theme) => (theme.palette.mode === 'dark' ? '#101010' : '#fff'),
                            color: (theme) =>
                                theme.palette.mode === 'dark' ? 'grey.300' : 'grey.800',
                            p: 1,
                            m: 1,
                            borderRadius: 1,
                            textAlign: 'center',
                            fontSize: '0.875rem',
                            fontWeight: '700',
                        }}
                    >
                        {this.renderTopSection()}
                        {this.renderTextEditor()}
                    </Box>
                </div>
                {this.renderPreviewSection()}
            </PolicyMakerWrapper>
        )
    }

}
export default PolicyMaker