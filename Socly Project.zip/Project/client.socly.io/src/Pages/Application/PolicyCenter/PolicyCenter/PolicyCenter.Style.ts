import styled from 'styled-components';


const PolicyCenterWrapper = styled.div`

.cnt-hdlr {
  background-color:  #E7E7E7;

}

.input-text {
    width: 100%;
    border: 0px;
    background-color: #f0f2f0;
    font-size: 12px;
    line-height: 40px;
    padding-left: 15px;
}

.hdlr {
    line-height: 16px;
    z-index: 0 !important;
    margin-bottom: 15px;
}

.Search-btn {
    padding: 6px;
    cursor: pointer;
    line-height: 30px;
    z-index: 1 !important;
    border-radius: 0px 5px 5px 0px;
    background-color: #1752C3;
}

.input-text {

    border-color: none;


}


@media only screen and (max-width: 767.98px) {


.Grid {

    padding-bottom: 45px !important;

    border-bottom: solid 1px #dadce0;

    }


}

`;
export default PolicyCenterWrapper;

export const GridCnt = styled.div`
    padding: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border: solid 1px #F2F2F2;

`;
export const Searchbar = styled.div`
    background-color: #f0f2f0;
    border-radius: 5px;
    display: block;
`;

export const GridHandler = styled.div`
    padding: 10px;
    background-color: #ffffff;
`;

export const Hdlr = styled.div`
    width: 90%;
    float: left;
`;

export const SearchBtn = styled.div`
    width: 10%;
    float: right;
`;

export const Grid = styled.div`
    width: 100%;
    padding-top: 0px;
    padding-bottom: 25px;
    font-size: 18px;
    border-bottom: solid 1px #dadce0;
    border-radius: 5px;
`;


export const PolicyHandler = styled.div`
    padding: 2px;
    width: 100%;
`;

export const PolicyTextHdlr = styled.div`
    padding: 2px;
    width: 80%;
`;

export const PolicyName = styled.div`
    display: grid;
    width: 100%;
    text-align: left;
`;

export const CreatedBy = styled.div`
    padding-top: 5px;
    font-size: 12px;
    color: #ABABAB;
    float: left;
    text-align: left;
`;

export const Download = styled.div`
    width: 10%;
    float: right;
    cursor: pointer;
    padding-bottom:15px;
`;