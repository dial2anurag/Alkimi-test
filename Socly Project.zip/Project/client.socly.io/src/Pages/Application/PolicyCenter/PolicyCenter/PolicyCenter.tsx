import React, { Component } from 'react';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../../../Base/AuthenticatedRouteComponent';
import {ContentHeading} from '../../../../StyledComponents/ComponentWrapper';
import policyCenterService from '../../../../services/Application/PolicyCenterService';
import {PolicyStatus} from '../../../../Model/Policy/PolicyStatus';
import SpinnersComponent from '../../../../Components/SpinnersComponent';
import PolicyCenterWrapper ,{
    GridCnt , 
    Searchbar, 
    GridHandler,
    Hdlr,
    SearchBtn,
    Grid,
    PolicyHandler,
    PolicyTextHdlr,
    PolicyName,
    CreatedBy,
    Download
} from './PolicyCenter.Style';
import DownloadIcon from '../../../../Assets/Images/View.svg';
import Search from '../../../../Assets/Images/Search.svg';
import PolicyCenterService from '../../../../services/Application/PolicyCenterService';
import RichTextEditor from '../../../../Components/RichTextEditor/RichTextEditor';
import { Modal } from 'react-bootstrap';
import FileIOService from '../../../../services/Common/FileIOService';

interface PolicyCenterState {
    filter: string,
    policies :any[],
    showspinner :boolean,
    selectedPolicy ?: {policy: any , content : string},
    viewModal ? : boolean
}

export class PolicyCenter extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps, PolicyCenterState> {
    constructor(props: AuthenticatedRouteComponentProps) {
        super(props)
        this.state = {
            filter: "",
            policies: [],
            showspinner :false
        }
    }

    async componentDidMount() {
        this.setState({showspinner :true});
        let response = await policyCenterService.getPoliciesOnStatus(PolicyStatus[PolicyStatus.Approved]);
        if(response.status ===200){
            this.setState({
                policies: response.data,
                showspinner :false })
        }
    }


    viewPolicy = async (policy : any) => {
        this.setState({showspinner :true});
        let response = await policyCenterService.getPolicy(policy.id);
        if(response.status !==200){
            alert("Failed to download the policy . Please try again!!");
            return;
        }
        let content =await FileIOService.readFileContent(response.data);
        this.setState({
            selectedPolicy :{policy : policy,content : content},
            viewModal:true,
            showspinner: false
        });
    }


    searchTxt(e: any) {
        this.setState({ filter: e.target.value });
    };

    getPolicyuserInformation(policy :any) : string{
        let returnValue : string = `Created By: ${policy.createdBy.name} | Approved By: `;
        returnValue = `${returnValue} | ${policy.approvedBy ? policy.approvedBy.name : ""}`;
        let approvedon : string ="";
        if(policy.approvedOn){
            let dt = new Date(policy.approvedOn);
            approvedon = dt.toLocaleDateString('en-GB'); 
        }
        
        returnValue = `${returnValue} | Approved Date: ${approvedon}`
        return returnValue;
    }

    onCloseHandler() {
        this.setState({ viewModal: false });
    }

    renderPreviewSection() {
        let {viewModal} = this.state;
        if (!viewModal) {
            return null;
        }
        return (
            <Modal size='lg' show={viewModal}>
                <div className="text-center p-2">
                    <div className="modal-header">
                        <button type="button" className="btn-close" onClick={this.onCloseHandler.bind(this)}> </button>
                    </div>
                    {this.renderPreviewTextEditor()}
                </div>
            </Modal>
        )
    }

    renderPreviewTextEditor() {
        let {selectedPolicy} = this.state;
        return (
            <div className='rich-text-style'>
                <RichTextEditor
                    defaultcontent={selectedPolicy?.content}
                    content={selectedPolicy?.content}
                    option={{readonly: true, autoFocus : true}}
                    height="40em">
                </RichTextEditor>
            </div>
        )
    }

    render() {
        let { filter, policies } = this.state;
        let PolicySearch = policies.filter(policy => {
        return Object.keys(policy).some(key =>
            PolicyCenterService.getPolicyName(policy).toLowerCase().includes(filter.toLowerCase())
            //policy[key].toLowerCase().includes(filter.toLowerCase()))
        )});

        return (
            <PolicyCenterWrapper>
                <div>
                    <SpinnersComponent key="policycenterspinnercomponent" showspinner={ this.state.showspinner} disablesection ={true} />
                    <ContentHeading>Policies </ContentHeading>
                    <GridCnt>
                        <Searchbar>
                            <Hdlr className='hdlr'>
                                <input 
                                    value={filter}
                                    onChange={this.searchTxt.bind(this)}
                                    className="input-text" 
                                    type="text" 
                                    placeholder="Search" 
                                    aria-label="Search" 
                                />
                            </Hdlr>
                            <SearchBtn className='Search-btn' ><img src={Search} alt="Search" /></SearchBtn>
                        </Searchbar>
                        {
                            PolicySearch?.map((policy: any,index) => {
                                return (
                                    <GridHandler key={`gridhndler-${index}`}>   
                                        <Grid key={`gridhndler-grid-${index}`} className='Grid'>
                                            <PolicyHandler key={`gridhndler-grid-policyhndler-${index}`}>
                                                <PolicyTextHdlr key={`gridhndler-grid-policyhndler-txthndlr-${index}`}>
                                                    <PolicyName 
                                                    key={`gridhndler-grid-policyhndler-txthndlr-name-${index}`}
                                                    className="text-capitalize"
                                                    >
                                                        {PolicyCenterService.getPolicyName(policy)}
                                                    </PolicyName>
                                                    <CreatedBy key={`gridhndler-grid-policyhndler-txthndlr-createdby-${index}`}>
                                                        {this.getPolicyuserInformation(policy)}
                                                    </CreatedBy>
                                                </PolicyTextHdlr>
                                                <Download 
                                                key={`gridhndler-grid-policyhndler-download-${index}`}
                                                onClick={(e) => this.viewPolicy(policy)}>
                                                    <img 
                                                    key={`gridhndler-grid-policyhndler-download-img-${index}`}
                                                    src={DownloadIcon} alt="DownloadIcon" />
                                                </Download>
                                            </PolicyHandler>
                                        </Grid>
                                    </GridHandler>
                                )
                            })
                        }
                    </GridCnt>
                </div>
                {this.renderPreviewSection()}
            </PolicyCenterWrapper>
        )
    } 
}
export default PolicyCenter;
