import styled from 'styled-components';
import SigninBg from '../../Assets/Images/signinmobile.png'

const NewLoginWrapper = styled.div`
.login-layout {
    background: #F7F7F7;
    .left-img-style {
        height: 100vh;
    }
    .right-section {
        filter: drop-shadow(0px 4px 60px rgba(0, 0, 0, 0.2));
        background: rgba(255, 255, 255, 0.5);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 40px;
        .heading {
            font-family: "ProductSansBold";
            font-size: 36px;
            color: #4B4B4B;
            text-align: left;
            padding-top: 10px;
        }
        .input-style {
            text-align: left;
            margin-top: 20px;
            img {
                position: relative;
                top: 40px;
            }
            label {
                font-family: 'ProductSansRegular';
                font-size: 14px;
                line-height: 17px;
                color: #4B4B4B;
            }
            .form-control {
                font-family: 'ProductSansRegular';
                font-size: 14px;
                background: #F4F4F4;
                border-radius: 5px;
                height: 52px;
            }
            .form-check-input[type=checkbox] {
                border-radius: 3px;
            }
            .form-check-input {
                margin-right: 1rem;
                margin-top: -1px;
                width: 1.5em;
                height: 1.5em;
                border: 1px solid #D9D9D9;
            }
        }
        .button-style {
            font-family: 'ProductSansBold';
            font-size: 16px;
            line-height: 19px;
            color: #F7F7F7;
            background: linear-gradient(180deg, #82A7FF 0%, #2A69FF 100%);
            border-radius: 5px;
            width: 100%;
            height: 52px;
            margin-top: 25px;
        }
    }
}
.forgot-pwd {
    font-size: 14px;
    font-family: 'ProductSansRegular';
    line-height: 1.23;
    letter-spacing: 0.68px;
    text-align: right;
    color: #002260;
    margin-top: 10px;
}
.help-error {
    color: red;
    font-family: 'ProductSansRegular';
    font-size: 14px;
    padding-top: 10px;
}
@media only screen and (max-width: 767.98px) {
    .login-layout { 
        background: #FFF;
        .left-img-style {
            display: none;
        }
        .right-section {
            filter: none;
            background: url(${SigninBg}) no-repeat bottom left;
            backdrop-filter: none;
            border-radius: 0px;
            padding: 40px;
            margin-top: 0px;
            height: 100vh;
            .form-label {
                margin-left: 8px;
            }
            .form-control {
                margin-left: 8px;
            }
        }
    }
}
`;

export default NewLoginWrapper;