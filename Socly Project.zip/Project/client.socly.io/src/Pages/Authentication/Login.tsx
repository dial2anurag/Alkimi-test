import BaseComponent from '../Base/BaseComponent';
import NewLoginWrapper from './login.style'
import LeftSideBanner from '../../Assets/Images/signin.png'
import Logo from '../../Assets/Images/logo.svg'
import Briefcase from '../../Assets/Images/briefcase.svg'
import Lock from '../../Assets/Images/lock.svg'
import  AuthService from '../../services/Users/auth.service';
import {ChangePassword , ChangePasswordData} from '../Security/ChangePassword';
import Recaptcha from 'react-google-invisible-recaptcha';
import RoleAccess from '../../services/Authorization/RoleAccess';
import SpinnersComponent from '../../Components/SpinnersComponent';

type LoginProps = {
    setToken: (result: boolean) => void
}

type LoginState = {
    redirectToReferrer: boolean,
    username : string,
    password : string,
    submitted: boolean,
    passwordChange : boolean,
    showSpinner : boolean,
    userData ? : ChangePasswordData
}

export class Login extends BaseComponent<LoginProps, LoginState> {
    private recaptcha :any
    constructor(props: LoginProps) {
        super(props);
        AuthService.cleanSession();
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.state = {
            redirectToReferrer: false ,
            username : "",
            password : "" ,
            submitted: false,
            passwordChange : false,
            showSpinner : false
        };
        console.log(window.location.pathname);
        if(window.location.pathname.trim() !== "/"){
            window.location.pathname = "/";
        }
    }

    handleChange(event :any) {
        let field : string = event.target.id;
        switch(field){
            case "username":
                this.setState({"username" : event.target.value});
                break;
            case "password":
                this.setState({"password" : event.target.value});
                break;
        }
    }

    async getToken() {
        if(this.state.username && this.state.password){
            this.setState({showSpinner : true});
            let response = await AuthService.login(this.state.username,this.state.password);
            if(response[0] === 200){
                RoleAccess.getComponentsForUser();
                this.props.setToken(true);
            }
            else if(response[0]=== -5) // Change Password
            {
                this.setState({
                    passwordChange: true,
                    userData : {token : response[1].token , userProfile : response[1].profile}
                });
            }

            this.setState({
                password:"",
                username :"",
                showSpinner : false
            });
       }
    }

    async handleSubmit(event :any) {
        event.preventDefault();

        const { username, password } = this.state;
        this.setState({
            submitted: true
        });

        if (username !== "" && password !== "") {
            if(this.state.username.trim().length ===0 
                || this.state.password.trim().length ===0){
                this.recaptcha.reset();       
            }
            this.recaptcha.execute();
        } else {
            console.log("Error creating user");
        }
    }

    async onResolved() {
        //alert( 'Recaptcha resolved with response: ' + this.recaptcha.getResponse() );
        await this.getToken();
    }

    // async handleForgotPassword(event:any){
    //     event.preventDefault();
    //     await Users.forgotPassword({});
    // }
    handleChangePasswordModalClose():void {
        this.recaptcha.reset();
    }

    render() {
        if(this.state.passwordChange) {
            return(<>
                <ChangePassword 
                    showCloseOption={false} 
                    userdata= {this.state.userData}
                    onModalClose={this.handleChangePasswordModalClose.bind(this)}
                />
                {this.renderChildren()}
            </>)
        }
        else {
            return(<>
                {this.renderChildren()}
            </>)
        }
    }

    renderChildren() {
        const {submitted, username, password} = this.state;
        return (
            <NewLoginWrapper>
                <div className="login-layout">
                    <div className="container-fluid">
                        <SpinnersComponent showspinner={this.state.showSpinner} />
                        <div className="row align-items-center">
                            <div className="col-md-6 px-0 left-section">
                                <img className='img-fluid left-img-style' src={LeftSideBanner} alt="SignIn Banner" />
                            </div>
                            <div className="col-md-4 right-section mx-auto">
                                <img className='img-style' src={Logo} alt="Logo" />
                                <div className="heading">Sign In</div>
                                <form onSubmit ={this.handleSubmit}>
                                    <div className="row input-style">
                                        <div className="col-1"><img src={Briefcase} alt="Lock" /></div>
                                        <div className="col-11">
                                            <label htmlFor="username" className="form-label">Username</label>
                                            <input type="text" className="form-control" id="username" name="username" value={username} onChange={this.handleChange}/>
                                            {submitted && !username && (
                                                <div className='help-error'>Username is required</div>
                                            )}
                                        </div>
                                    </div>
                                    <div className="row input-style">
                                        <div className="col-1"><img src={Lock} alt="Lock" /></div>
                                        <div className="col-11">
                                            <label htmlFor="password" className="form-label">Password</label>
                                            <input type="password" className="form-control" id="password" name="password" value={password} onChange={this.handleChange}/>
                                            {submitted && !password && (
                                                <div className='help-error'>Password is required</div>
                                            )}
                                            {/* <div className="forgot-pwd">
                                                <a href='#' onClick={this.handleForgotPassword.bind(this)}>Forgot Password</a>
                                            </div> */}
                                        </div>
                                    </div>
                                    <div className="form-check input-style">
                                        <label className="form-check-label">
                                            <input className="form-check-input" type="checkbox" id="remember" name="remember" /> Remember Me
                                        </label>
                                    </div>
                                    <button type="submit" className="button-style btn btn-primary">Log in</button>
                                </form>
                            </div>
                        </div>
                        <Recaptcha
                            key="recaptcha"
                            ref={(ref:any)=>{this.recaptcha = ref}}
                            sitekey={process.env.REACT_APP_RECAPTCHA_SITEKEY}
                            onResolved={ this.onResolved.bind(this) } />
                    </div>
                </div>
            </NewLoginWrapper>
        )
    }
}

export default Login;
