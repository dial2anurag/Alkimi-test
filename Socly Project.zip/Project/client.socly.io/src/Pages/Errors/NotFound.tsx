import React, { Component } from 'react'
import  AuthService from '../../services/Users/auth.service';
import BaseComponent from '../Base/BaseComponent'

export class NotFound extends BaseComponent {
    constructor(props : any){
        super(props);
        AuthService.logout();
    }
    render() {
        return (
            <div>
            <p>Page Not Found</p>
            <a href="/" >Go to Login Page</a>
        </div>
        )
    }
}

export default NotFound