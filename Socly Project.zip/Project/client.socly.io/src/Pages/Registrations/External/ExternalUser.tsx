import { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import Users , {IUserRegistration} from '../../../services/Users/Users';
import SpinnersComponent from '../../../Components/SpinnersComponent';
import OrgRegistration from '../../../services/Organization/OrgRegistration';
import {RoleMappings} from '../../../Data/SysData/roleMapping';
import AuthenticatedRouteComponent,{AuthenticatedRouteComponentProps} from '../../Base/AuthenticatedRouteComponent';
import ExternalUserWrapper from './externalUser.style'

type ExternalUserState ={
  showSpinner : boolean,
  roles : {id: number , name : string , display : string}[],
  organizations : {clientId: number , orgName : string}[],
  businessTitleValue: string,
  organizationNameValue: string
}
export default class ExternalUser extends AuthenticatedRouteComponent<AuthenticatedRouteComponentProps,ExternalUserState> {
  constructor(props: AuthenticatedRouteComponentProps) {
    super(props);
    this.state ={showSpinner : false , roles :[] , organizations : [], businessTitleValue:"", organizationNameValue: ""}
  }

  async componentDidMount(){
    let roles :{id: number , name : string , display : string}[]=[];
    let orgs : {clientId: number , orgName : string}[]=[];
    let response = await OrgRegistration.getRoles(null);
    if(response.status === 200 && response.data && response.data.length >0){
        Array.prototype.forEach.call(response.data, (item,index)=>{
          roles.push({id: item.id , name : item.name , display : RoleMappings[item.name]});
        })
    }
    response = await OrgRegistration.getOrganization();
    if(response.status === 200 && response.data && response.data.length >0){
      Array.prototype.forEach.call(response.data, (item,index)=>{
        orgs.push({clientId: item.clientId , orgName : item.orgName});
      })
    }
    this.setState({roles : roles , organizations : orgs});
  }

  validationSchema() {
    return Yup.object().shape({
      username: Yup.string()
      .test(
        "len",
        "The Username must be between 3 and 50 characters.",
        (val: any) =>
          val &&
          val.toString().length >= 3 &&
          val.toString().length <= 50
      )
      .required("This field is required!"),
      email: Yup.string()
        .email("This is not a valid email.")
        .required("This field is required!"),
      phone: Yup.string().matches(new RegExp('[0-9]{10}'))
        .length(10)
        .typeError('you must specify a number with length 10')
        .required("This field is required!"),
      // password: Yup.string()
      // .matches(
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
      //   "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
      // )
      //   .required("This field is required!"),
        name: Yup.string()
        .test(
          "len",
          "The name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
        organizationName: Yup.string()
        .test(
          "len",
          "The name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
        businessTitle: Yup.string()
        .test(
          "len",
          "The role must be selected.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!")
    });
  }

  async handleRegister(values : IUserRegistration, event : any){
    this.setState({showSpinner : true});
    if(await Users.registerUser(values)  ===200){
        alert("User registered successfully"); 
    }
    event.resetForm();
    this.setState({showSpinner : false});
  }

  handleChange(ev: any) {
    const {name, value} = ev.target;
    if(name === "businessTitle") {
      this.setState({businessTitleValue: value});
    } else if(name === "organizationName") {
      this.setState({organizationNameValue: value});
    }
  }

  render() {
    const initialValues :IUserRegistration = {
        username: "",
        password : "",
        email: "",
        name: "",
        phone:  "",
        businessTitle:"",
        organizationName: ""
    };

    const {showSpinner, roles, organizations, businessTitleValue, organizationNameValue} = this.state;
    return (
      <ExternalUserWrapper>
        <SpinnersComponent key="extuserspinnercomponent" showspinner={showSpinner} />
        <Formik key="fomik1" initialValues={initialValues} validationSchema={this.validationSchema} onSubmit={this.handleRegister.bind(this)}>
          <Form key="form1">
            <div key="row1" className="row">
              <div key="row1col1" className="col-md-6">
                <label key="row1col1lable1" htmlFor="fieldusername" className="form-label">User Name</label>
                <Field key="fieldusername" name="username" type="username" className="form-control" placeholder="User Name"/>
                <ErrorMessage key="errmsgusername" name="username" component="div" className="help-error" />
              </div>
              <div key="row1col2" className="col-md-6">
                <label key="row1col2lable2" htmlFor="fieldname" className="form-label">Name</label>
                <Field key="fieldname" name="name" type="name" className="form-control" placeholder ="Name" autoComplete="off"/>
                <ErrorMessage key="errname" name="name" component="div" className="help-error" />
              </div>
            </div>
            <div key="row2" className="row">
              <div key="row2col1" className="col-md-6">
                <label key="row2col1label1" htmlFor="fieldemail" className="form-label">E-mail</label>
                <Field key="fieldemail" name="email" type="email" className="form-control" placeholder ="E-mail"/>
                <ErrorMessage key="erremail" name="email" component="div" className="help-error" />
              </div>
              <div key="row2col2" className="col-md-6">
                <label key="row2col2label2" htmlFor="fieldphone" className="form-label">Phone</label>
                <Field key="fieldphone" name="phone" type="phone" maxLength={10} size={30} className="form-control" placeholder="Phone"/>
                <ErrorMessage key="errphone" name="phone" component="div" className="help-error" />
              </div>
            </div>
            <div key="row3" className="row">
              <div key="row3col1" className="col-md-6">
                <label key="row3col1label1" htmlFor="fieldbusinesstitle" className="form-label">Select a role</label>
                <Field key="fieldbusinesstitle" as="select" name="businessTitle" type="businessTitle" className={"form-control "+(businessTitleValue ? "active" : "inactive")} onClick={(ev: any)=>this.handleChange(ev)}>
                  <option key="businesstitleselectoption" value="" label="Select a role"/>
                  {
                    roles.map((item,index)=>{
                      return(<option key={`businesstitleselectoption-${item.name}`} value={item.name}>{item.display}</option>)
                    })
                  }
                </Field>
                <ErrorMessage key="errbusinesstitle" name="businessTitle" component="div" className="help-error" />
              </div>
              <div key="row3col2" className="col-md-6">
                <label key="row3col2label2" htmlFor="fieldorgtitle" className="form-label">Select organization</label>
                <Field key="fieldorgtitle"  as="select" name="organizationName" type="organizationName" className={"form-control "+(organizationNameValue ? "active" : "inactive")} onClick={(ev: any)=>this.handleChange(ev)}>
                  <option key="optiontitleselect"  value="" label="Select organization"/>
                  {
                    organizations.map((item,index)=>{
                      return(<option key={`optiontitle${item.orgName}`} value={item.orgName}>{item.orgName}</option>)
                    })
                  }
                </Field>
                <ErrorMessage key="errorgname" name="organizationName" component="div" className="help-error" />
              </div>
            </div>
            <div key="row4" className="row">
              <div key="row4col1" className="col-md-3 mx-auto">
                <button key="btnsubmit" type="submit" className="btn btn-primary btn-block">Register</button>
              </div>
            </div>
          </Form>
        </Formik>
      </ExternalUserWrapper>
    );
  }
}