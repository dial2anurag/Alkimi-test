import { Component } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import OrgRegistrationService, { OrgRegistrationEntity } from '../../../services/Organization/OrgRegistration';
import SpinnersComponent from '../../../Components/SpinnersComponent';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import AuthenitcatedComponent,{AuthenitcatedComponentProps} from '../../Base/AuthenitcatedComponent';
import styled from 'styled-components';

export const Fields = styled.div`
    margin-top: 1rem;
`;

type OrganisationRegistrationState ={
  showSpinner : boolean,
  iso: boolean,
  soc2: boolean,
  disabled: boolean
}
interface OrganisationRegistrationProps extends AuthenitcatedComponentProps {
  handleModalClose ? : any
}
const theme = createTheme();


export default class OrganisationRegistration extends AuthenitcatedComponent<OrganisationRegistrationProps,OrganisationRegistrationState> {
  constructor(props: OrganisationRegistrationProps) {
    super(props);
    this.state = {
      showSpinner : false,
      iso: false,
      soc2: false,
      disabled: true
    }
  }

  validationSchema() {
    return Yup.object().shape({

      email: Yup.string()
        .email("This is not a valid email.")
        .required("This field is required!"),
      phone: Yup.string().matches(new RegExp('[0-9]{10}'))
        .length(10)
        .required("This field is required!"),
      description: Yup.string()
      .min(3).max(2000)
      .notRequired(),
      name: Yup.string()
        .test(
          "len",
          "The name must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!"),
      orgName: Yup.string()
        .test(
          "len",
          "The Organization must be between 3 and 50 characters.",
          (val: any) =>
            val &&
            val.toString().length >= 3 &&
            val.toString().length <= 50
        )
        .required("This field is required!")
    });
  }

  async handleRegister(values: any, event: any) {
    let selectedFramework: string[] = [];
    if(this.state.iso) {
      selectedFramework.push("iso")
    } 
    if(this.state.soc2) {
      selectedFramework.push("soc2")
    }
    this.setState({ showSpinner: true });
    let data: OrgRegistrationEntity = {
      orgName: values.orgName,
      description: values.description,
      name: values.name,
      phone: values.phone,
      email: values.email,
      frameworkSubscribed: selectedFramework
    }
    
    if(await OrgRegistrationService.registerOrg(data) ===200){
        alert("Orgnization registered successfully");
        this.props.handleModalClose(); 
        //event.resetForm();
    }
    this.setState({showSpinner : false});
  }

    handleChecked(event: any) {
    let currentId = event.target.id;
    let checked = event.target.checked;
    let disabled: boolean = true;

    if(checked) {
      disabled = false
      
    } else {
      if(currentId === "iso" && this.state.soc2) {
        disabled = false
      } else if(currentId === "soc2" && this.state.iso) {
        disabled = false
      }
    }
      this.setState({disabled: disabled})
      if (currentId === "iso") {
        this.setState({iso: checked})
      } else if (currentId === "soc2") {
        this.setState({soc2: checked})
      } 
  }

  render() {
    const initialValues :any = {
        clientId: 0,
        orgName: "",
        description: "",
        name: "",
        phone:  "",
        email : ""
    };

    return (
      <>
        <SpinnersComponent key="orgregspinnercomponent" showspinner={this.state.showSpinner} />
        <ThemeProvider theme={theme}>
          <Container component="main" maxWidth="xs">
            <CssBaseline />
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <Formik
                initialValues={initialValues}
                validationSchema={this.validationSchema}
                onSubmit={this.handleRegister.bind(this)}
              >
              <Form >
                <Box component="div"  sx={{ mt: 1,width: 300  }} className="box">
                  <div className="form">
                    <Fields>
                      <div className="form-group">
                        <Field name="orgName" type="orgName" className="form-control" placeholder="Organization"/>
                        <ErrorMessage name="orgName" component="div" className="alert alert-danger" />
                      </div>
                    </Fields>
                    <Fields>
                      <div className="form-group">
                        <Field name="description" type="description" className="form-control" placeholder="Description" />
                        <ErrorMessage name="description" component="div" className="alert alert-danger" />
                      </div>
                    </Fields>
                    <Fields>
                      <FormControlLabel
                        className="ms-1"
                        value="iso"
                        name="iso"
                        control={<Switch id="iso" /> }
                        label="ISO"
                        labelPlacement="start"
                        onChange={this.handleChecked.bind(this)}
                      />
                      <FormControlLabel
                        value="soc2"
                        name="soc2"
                        control={<Switch id="soc2" />}
                        label="SOC2"
                        labelPlacement="start"
                        onChange={this.handleChecked.bind(this)}
                      />
                      <div style={{color: "red", fontSize: "12px"}}>{this.state.disabled ? "Please select atleast one checkbox" : ''}</div>
                    </Fields>
                    <Fields>
                      <div className="form-group">
                        <Field name="name" type="Name" className="form-control"  placeholder="Admin Name" />
                        <ErrorMessage name="name" component="div" className="alert alert-danger" />
                      </div>
                    </Fields>
                    <Fields>
                      <div className="form-group">
                        <Field name="email" type="email" className="form-control" placeholder ="Admin E-mail" /> 
                        <ErrorMessage name="email" component="div" className="alert alert-danger" />
                      </div>
                    </Fields>
                    <Fields>
                      <div className="form-group">
                        <Field name="phone" type="phone" maxLength={10} size={30} className="form-control"  placeholder="Admin Phone"/>
                        <ErrorMessage name="phone" component="div" className="alert alert-danger"/>
                      </div>
                    </Fields>
                  
                    {/*<Fields>
                      <div className="form-group">
                        <Select
                          className="form-control" placeholder="Status"
                            style={{padding: "0.05px"}} label="Status"
                        >
                          <MenuItem value="0">Status</MenuItem>   
                          <MenuItem value={10}>Active</MenuItem>
                          <MenuItem value={20}>In Active</MenuItem>
              
                        </Select>
                      </div>
                    </Fields>*/}
                    <div className="form-group" style={{marginTop:'20px'}}>
                      <button type="submit" className={"btn btn-primary btn-block" + (this.state.disabled ? " disabled": "")}>Register</button>
                    </div>
                    </div>
                  </Box>
                </Form>
              </Formik>
            </Box>
          </Container>
        </ThemeProvider>
      </>
    );
  }
}