import styled from 'styled-components';

const DashboardWrapper = styled.div`
.dashboard-section {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 6px;
    padding: 20px 24px 60px;
    margin-top: 3rem;
    margin-bottom: 3rem;
    h3 {
        font-family: 'ProductSansBold';
        font-size: 28px;
        line-height: 34px;
        color: #212121;
        text-align: left;
        margin-bottom: 20px;
    }
}
`;

export default DashboardWrapper;