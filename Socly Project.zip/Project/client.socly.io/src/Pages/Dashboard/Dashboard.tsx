import React, { Component, Fragment } from 'react';
import BaseDashboardComponent,{BaseDashboardComponentProps,BaseDashboardComponentState} from './Base/BaseDashboardComponent';
import { Gauge , GaugeConfig } from '@ant-design/charts'
import SaasList from './ServiceProvider/SaasList';
import { IComplianceData } from '../../Model/Compliance/ComplianceEntity';
import DashboardWrapper from './dashboard.style'
import MonitorDashboardWrapper from './monitorDashboard.style';
import TotalTestsImg from '../../Assets/Total_Tests.svg';
import PassedTestsImg from '../../Assets/Passed_Tests.svg';
import FailedTestsImg from '../../Assets/Failed_Tests.svg';
import TotalAlertsImg from '../../Assets/Total_Alerts.svg';
import ProductionImg from '../../Assets/Production.svg';
import NonProductionImg from '../../Assets/Non_Production.svg';
import { PRODUCTION } from '../../services/Compliance/FrameworkComplianceService';

interface DashboardState extends BaseDashboardComponentState{
    totalAlerts : number,
    passedAlerts :number,
    failedAlerts :number,
    config : any,
    loadSaasItems : boolean,
    productionAlerts :number
}

export class Dashboard extends BaseDashboardComponent<BaseDashboardComponentProps,DashboardState> {
    private deafultRangeColor: string = "#000000";
    constructor(props:BaseDashboardComponentProps){
        super(props);
        this.state = {
            totalAlerts : 0,
            passedAlerts :0,
            failedAlerts : 0,
            productionAlerts :0,
            complianceList :[],
            failedCompliantList : [],
            saasList : [],
            loadSaasItems : false,
            showSpinner : true,
            config : {
                percent: 0, //0.75
                range: { color: this.deafultRangeColor },
                indicator: {
                  pointer: undefined,
                  pin: undefined
                },
                axis: {
                  label: {
                    formatter: function formatter(v: any) {
                      return Number(v) * 100;
                    },
                  },
                  subTickLine: { count: 3 },
                },
                statistic: {
                  content: {
                    formatter: function formatter(_ref: any) {
                      var percent = _ref.percent;
                      return (percent * 100).toFixed(0);
                    },
                    style: {
                      color: 'rgba(0,0,0)',
                      fontSize: '100px'
                    },
                  },
                }
            }
        }
    }

    getRangeColor(average: number) : string{
        let varient : string = this.deafultRangeColor;
        if(average <= 0) varient =this.deafultRangeColor;
        if(average > 0 && average < 30) varient = "#E76262";
        else if(average >=30 && average <60 ) varient = "#F9CF4A";
        else if(average >=60 && average <100 ) varient = "#31AFFC";
        else if(average ===100) varient ="#3ECE80";
        else varient= this.deafultRangeColor;
        return varient;
    }

    handleSaasItemResponse(complianceList :IComplianceData[]) :void{

    }

    protected implementData(): void {
        let total =0;
        let pass =0;
        let failed =0;
        this.state.complianceList.forEach((saas : IComplianceData) => {
            total = total + Number(saas.Data.totalCompliancePoint);
            pass = pass + Number(saas.Data.totalAcceptedComplianceScore);
            failed = failed + Number(saas.Data.totalRejectedComplianceScore);
        });
        let average = ((pass /total ));
        let config = this.state.config;
        config.percent = average;
        let rangeColor = this.getRangeColor(average*100);
        config.range = {color: rangeColor}

        let alerts :any[] =[] ;
        let productionalerts : number =0 ;
        
        this.state.complianceList.forEach((parent) => {
            if(!parent.Data.abstractResponse){ return ;}
            parent.Data.abstractResponse.forEach((child :any) => {
                alerts = child.entityCompliance.filter((a : any)=> a.complianceStatus.toString() === "FAILED");
                alerts.forEach((subchild :any) => {
                    if(subchild["environment"] && subchild["environment"] === PRODUCTION){
                        productionalerts = productionalerts +1; 
                    }
               });
            });
        });
        
        this.setState({
            totalAlerts : total,
            passedAlerts : pass,
            failedAlerts : failed,
            productionAlerts: productionalerts,
            config : config,
            loadSaasItems : true
        });  
    }

    renderSaasItems(){
        if(this.state.loadSaasItems){
            return(<SaasList 
                    complianceList={this.state.complianceList} 
                    framework={this.props.framework}
                    pageid={this.props.pageid}  />)
        }
        else{
            return(<></>)
        }
    }

    renderNavigateLink(type: "Moniter" | "Alert" | "Total"): JSX.Element{
        if(!this.props.onNavigate){
            return <></>;
        }
        switch (type) {
            case "Total":
                return (
                    this.props.onNavigate({to : '/monitor', className : "grey-box", key : `totaldashboardwrapper1div1row1col1${type}` },
                        <Fragment key={`totaldashboardwrapper1${type}Fragament`}>
                            <img key={`totaldashboardwrapper1div1row1col2${type}img1`} src={TotalTestsImg} alt="Monitor Icon" />
                            <div key={`totaldashboardwrapper1div1row1col2${type}div1`} className='text1'>Total Tests 
                                <br /> <span key={`totaldashboardwrapper1div1row1col2${type}span1`} className='blue-color'>{this.state.totalAlerts}</span> 
                            </div>
                        </Fragment>
                        )
                    )
            case "Moniter":
                return (
                    this.props.onNavigate({to : '/monitor', className : "grey-box", key : `monitordashboardwrapper1div1row1col1${type}` },
                        <Fragment key={`monitordashboardwrapper1${type}Fragament`}>
                            <img key={`monitordashboardwrapper1div1row1col2${type}img1`} src={PassedTestsImg} alt="Monitor Icon" />
                            <div key={`monitordashboardwrapper1div1row1col2${type}div1`} className='text1'>Passed Tests 
                                <br /> <span key={`monitordashboardwrapper1div1row1col2${type}span1`} className='green-color'>{this.state.passedAlerts}</span> 
                            </div>
                        </Fragment>
                        )
                    )
            case "Alert":
                return (
                    this.props.onNavigate({to : '/alert', className : "grey-box", key : `alertdashboardwrapper1div1row1col1${type}` },
                        <Fragment key={`alertdashboardwrapper1${type}Fragament`}>
                            <img key={`alertdashboardwrapper1div1row1col2${type}img1`} src={FailedTestsImg} alt="Monitor Icon" />
                            <div key={`alertdashboardwrapper1div1row1col2${type}div1`} className='text1'>Failed Tests
                                <br /> <span key={`alertdashboardwrapper1div1row1col2${type}span1`} className='red-color'>{this.state.failedAlerts}</span> 
                            </div>
                        </Fragment>
                        )
                    )
        }
    }

    override renderComponent() {
        return (
            <DashboardWrapper key="dashboardwrapper1">
                <div key="dashboardSection" className="dashboard-section">
                    <h3 key="dashboardwrapper1h3">Compliance Score</h3>
                    {/* <ChartContainer> */}
                    <Gauge key="gauge1" {...this.state.config}  height={300} 
                        width={300} gaugeStyle={{ lineCap: 'round' }} />
                    {/* </ChartContainer> */}
                </div>
                <MonitorDashboardWrapper key="monitordashboardwrapper1">
                    <div key="monitordashboardwrapper1div1" className="monitor-section">
                        <h3 key="monitordashboardwrapper1div1h3">Monitoring</h3>
                        <div key="monitordashboardwrapper1div1row1" className="row">
                            <div key="monitordashboardwrapper1div1row1col1" className="col-md-4">
                               {
                                    this.renderNavigateLink("Total")
                               }
                            </div>
                            <div key="monitordashboardwrapper1div1row1col2" className="col-md-4">
                                {
                                    this.renderNavigateLink("Moniter")
                                }
                            </div>
                            <div key="monitordashboardwrapper1div1row1col3" className="col-md-4">
                                {
                                    this.renderNavigateLink("Alert")
                                }
                            </div>
                        </div>
                    </div>
                    <div key="monitordashboardwrapper2div1" className="monitor-section">
                        <h3 key="monitordashboardwrapper2div1h3">Alerts</h3>    
                        <div key="monitordashboardwrapper2div1row1" className="row">
                            <div key="monitordashboardwrapper2div1row1col4" className="col-md-4">
                                <div key={`monitordashboardwrapper2div1row1col4div`} className="grey-box">
                                    <img key={`monitordashboardwrapper2div1row1col4divimg`} src={ProductionImg} alt="Monitor Icon" />
                                    <div key={`monitordashboardwrapper2div1row1col4divdiv1`} className='text1'>Failed Tests
                                        <br /> <span key={`monitordashboardwrapper2div1row1col4divdiv1span`} className='red-color'>{this.state.failedAlerts}</span> 
                                    </div>
                                </div>
                            </div>
                            <div key="monitordashboardwrapper3div1row1col4" className="col-md-4">
                                <div key={`monitordashboardwrapper3div1row1col4div`} className="grey-box">
                                    <img key={`monitordashboardwrapper3div1row1col4divimg`} src={TotalAlertsImg} alt="Monitor Icon" />
                                    <div key={`monitordashboardwrapper3div1row1col4divdiv1`} className='text1'>Production
                                        <br /> <span key={`monitordashboardwrapper3div1row1col4divdiv1span`} className='red-color'>{this.state.productionAlerts}</span> 
                                    </div>
                                </div>
                            </div>
                            <div key="monitordashboardwrapper4div1row1col4" className="col-md-4">
                                <div key={`monitordashboardwrapper4div1row1col4div`} className="grey-box">
                                    <img key={`monitordashboardwrapper4div1row1col4divimg`} src={NonProductionImg} alt="Monitor Icon" />
                                    <div key={`monitordashboardwrapper4div1row1col4divdiv1`} className='text1'>Non Production
                                        <br /> <span key={`monitordashboardwrapper4div1row1col4divdiv1span`} className='red-color'>{(this.state.failedAlerts - this.state.productionAlerts)}</span> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </MonitorDashboardWrapper>
                <div key="pagecontainerdiv3">
                    {this.renderSaasItems()}
                </div>
            </DashboardWrapper>
        )
    }
}
export default Dashboard