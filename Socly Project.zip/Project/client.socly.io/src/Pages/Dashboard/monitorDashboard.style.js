import styled from 'styled-components';

const MonitorDashboardWrapper = styled.div`
.monitor-section {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 6px;
    margin-bottom: 3rem;
    padding: 16px 24px 24px;
    h3 {
        font-family: 'ProductSansBold';
        font-size: 28px;
        line-height: 39px;
        color: #212121;
        text-align: left;
        margin-bottom: 20px;
    }
    .grey-box {
        background: #F3F3F3;
        box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.1);
        border-radius: 6px;
        padding: 12px 16px;
        display: flex;
        margin: 20px;
        text-decoration: none;
        .text1 {
            font-family: 'ProductSansRegular';
            font-size: 16px;
            line-height: 24px;
            color: #959595;
            margin-left: 25px;
            text-align: left;
        }
        span {
            font-family: 'ProductSansBold';
            font-size: 36px;
            line-height: 49px;
        }
        .blue-color {
            color: #31AFFC; 
        }
        .green-color {
            color: #00C895;
        }
        .red-color {
            color: #FF4A56;
        }
    }
}
@media only screen and (max-width: 1199.98px) {
    .monitor-section {
        padding: 16px 24px 40px;
        h3 {
            margin-bottom: 40px;
        }
        .grey-box {
            padding: 10px;
            margin: 0px;
            .text1 {
                margin-left: 20px;
            }
        }
    }
}
`;

export default MonitorDashboardWrapper;