import React, { Component } from 'react';
import BaseDashboardListComponent,{BaseDashboardListComponentState} from './Base/BaseDashboardListComponent';
import {BaseDashboardComponentProps} from './Base/BaseDashboardComponent';
import {ColDef} from 'ag-grid-community';
import { IComplianceData } from '../../Model/Compliance/ComplianceEntity';
import UploadEvidenceService from '../../services/Upload/UploadEvidenceService';
import TotalTestsImg from '../../Assets/Total_Tests.svg';
import PassedTestsImg from '../../Assets/Passed_Tests.svg';
import FailedTestsImg from '../../Assets/Failed_Tests.svg';
import MonitorDashboardWrapper from './monitorDashboard.style'


interface MonitorDashboardState extends BaseDashboardListComponentState{
    totalAlerts : number,
    passedAlerts :number,
    failedAlerts :number
}

export class MonitorDashboard extends BaseDashboardListComponent<BaseDashboardComponentProps,MonitorDashboardState> {
  constructor(props:BaseDashboardComponentProps){
      super(props);
      this.state = {
        totalAlerts : 0,
        passedAlerts :0,
        failedAlerts : 0,
        complianceList :[],
        gridList : [],
        failedCompliantList :[],
        saasList : [],
        showSpinner : true
    }
  }

  override async fillStateList(){
        let controlList : any[]=[];
        let compdata : any;
        let compid : string ="";
        let listresp = await new UploadEvidenceService(this.props.framework).getComplianceList();
        if(listresp.status ===200){
            controlList = listresp.data;
        }

        if(this.state.complianceList.length < 0) return;
        let alldata :any[]=[] //this.state.gridList;
        this.state.complianceList.forEach((parent) => {
            parent.Data.abstractResponse.forEach((child :any) => {
                child.entityCompliance.forEach((subchild:any) => {
                    if(subchild && subchild.complianceID){
                        compid =subchild.complianceID.replaceAll(' ','').toUpperCase();
                        compdata=controlList.find(e=> e.complianceId.toUpperCase() === compid);
                        if(compdata){
                            subchild["controlName"] = compdata.controlName;
                            subchild["compliancecontrolName"] = `(${compid}) ${compdata.controlName}` ;
                        }
                        else{
                            subchild["controlName"] =compid;
                            subchild["compliancecontrolName"]=compid;
                        }
                    }
                    else{
                        subchild["controlName"] ="";
                        subchild["compliancecontrolName"]="";
                    }
                    subchild["serviceProvider"] = parent.Key;
                    subchild["statusDate"]=new Date().toDateString();
                    alldata.push(subchild);
                });
            });
        });
        this.setState({gridList :alldata });
        if(this.gridInstance) this.gridInstance.api.refreshCells();
    }

    onImplementData(){
        let total =0;
        let pass =0;
        let failed =0;
        this.state.complianceList.forEach((saas : IComplianceData) => {
            total = total + Number(saas.Data.totalCompliancePoint);
            pass = pass + Number(saas.Data.totalAcceptedComplianceScore);
            failed = failed + Number(saas.Data.totalRejectedComplianceScore);
        });
        this.setState({
            totalAlerts : total,
            passedAlerts : pass,
            failedAlerts : failed
        });
    }

     override gridColumnDef() : ColDef[] {
         return [{
                field: "serviceProvider",
                headerName : "Service Provider",
                width : 6
           },{
                field: "compliancecontrolName",
                headerName : "Section" ,
                width : 6
            },{
                field: "complianceTitle",
                headerName : "Check",
                wrapText :true,
                autoHeight : true,
                width : 20
            },
            {
                field: "description",
                headerName : "Description",
                wrapText :true,
                autoHeight : true,
                width : 20
            },
            {
                 field: "environment",
                 headerName : "Environment",
                 wrapText :true,
                 autoHeight : true,
                 width : 20
            },
            this.showStatusColumn()
         ]
     }

    override defaultGridColumnsDef() : ColDef{
         return {
             sortable :true,
             flex :1,
             resizable : true,
             filter: true
         }
     }

     override renderTopSection() {
        return(
            <MonitorDashboardWrapper>
                <div className="monitor-section">
                    <h3>Summary</h3>
                    <div className="row">
                        <div className="col-md-4">
                            <div className="grey-box">
                                <img src={TotalTestsImg} alt="Alert Icon" />
                                <div className='text1'>Total Tests <br /> <span className='blue-color'>{this.state.totalAlerts}</span> </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="grey-box">
                                <img src={PassedTestsImg} alt="Alert Icon" />
                                <div className='text1'>Passed Tests <br /> <span className='green-color'>{this.state.passedAlerts}</span> </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="grey-box">
                                <img src={FailedTestsImg} alt="Alert Icon" />
                                <div className='text1'>Failed Tests <br /> <span className='red-color'>{this.state.failedAlerts}</span> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </MonitorDashboardWrapper>
        )
    }
}

export default MonitorDashboard