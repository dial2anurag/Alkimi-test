import React, { Component } from 'react'
import SaasItem from './SaasItem';
import { IComplianceData } from '../../../Model/Compliance/ComplianceEntity';
import FrameworkComponent,{FrameworkComponentProps} from '../../Base/FrameworkComponent';
import SaasListService from '../../../services/SaasProviders/SaasListService'
import SaasListWrapper from './saasList.style'
import { Saas } from '../../../Model/SaasProvider/saasConfigurationEntity';

interface SaasListState {
    saasProviders : Saas []
}

interface SaasListProps extends FrameworkComponentProps {
    complianceList : IComplianceData[]
} 

export class SaasList extends FrameworkComponent<SaasListProps,SaasListState> {
    constructor(props : any){
        super(props);
        this.state ={
            saasProviders : []
        }
    }

    componentDidMount(){
        let orgsaasList = SaasListService.getOrgRegisteredSaasList();
        this.setState({saasProviders : orgsaasList}) 
    }

    renderSaasItem(saas : Saas, index : number){
        let compliancedata : IComplianceData | undefined
        let total : number =-1 , passcount : number =0 , failCount : number =0;
        compliancedata = this.props.complianceList.find(e=> e.Key.toUpperCase() === saas.key.toUpperCase())
        if(compliancedata){
            total = Number(compliancedata.Data.totalCompliancePoint);
            passcount = Number(compliancedata.Data.totalAcceptedComplianceScore);
            failCount = Number(compliancedata.Data.totalRejectedComplianceScore);
        }

        return(
            <SaasItem
                key={`saasItem-${saas.key}(${index})`}
                Saas={saas} 
                totalRecord={total} 
                passedRecord={passcount}
                failedRecord ={failCount}  />
        )
    }

    override render(){
        return (
            <SaasListWrapper>
                <div className='justify-content-center text-center saasItems-main-div'>
                    <div key="saasitemdivcontainer" className="saasItems-section">
                        <h3>Service Providers</h3>
                        <div key="row1" className="row">
                            {
                                this.state.saasProviders.map((saas,index)=>{
                                    return this.renderSaasItem(saas,index);
                                })
                            }
                        </div>
                    </div>
                </div>
            </SaasListWrapper>
        )
    }
}
export default SaasList