import styled from 'styled-components';

const SaasListWrapper = styled.div`
.saasItems-section {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 6px;
    padding: 16px 24px 24px;
    margin-top: 3rem;
    h3 {
        font-family: 'ProductSansBold';
        font-size: 28px;
        line-height: 39px;
        color: #212121;
        text-align: left;
        margin-bottom: 20px;
    }
    .white-box {
        background: #FFFFFF;
        box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
        border-radius: 6px;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        margin-top: 15px;
        margin-bottom: 15px;
        .img-style {
            width: 7vw;
        }
        .progress {
            border-radius: 32px;
        }
        .bg-black {
            background: #000000;
        }
        .bg-red {
            background: #E76262;
        }
        .bg-yellow {
            background: #F9CF4A;
        }
        .bg-blue {
            background: #31AFFC;
        }
        .bg-green {
            background: #3ECE80;
        }
    }
}
@media only screen and (max-width: 1199.98px) {
    .monitor-section {
        padding: 16px 24px 40px;
        h3 {
            margin-bottom: 40px;
        }
        .white-box {
            padding: 10px;
            margin: 0px;
        }
    }
}
`;

export default SaasListWrapper;