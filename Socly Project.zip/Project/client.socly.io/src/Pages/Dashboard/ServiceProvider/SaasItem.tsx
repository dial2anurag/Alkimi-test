import React, { Component } from 'react';
import {ProgressBar} from 'react-bootstrap'
import { Saas } from '../../../Model/SaasProvider/saasConfigurationEntity';
import AuthenticatedBaseComponent from '../../Base/AuthenticatedBaseComponent';

interface SaasItemProps{
    Saas : Saas,
    totalRecord : number ,
    passedRecord : number,
    failedRecord : number
}

export class SaasItem extends AuthenticatedBaseComponent<SaasItemProps> {
    private deafultRangeColor: string = "black";
    constructor(props : any){
       super(props);
   }

   getSuccessPercentage(flag ?: boolean) : number {
       if(flag){
            if(this.props.totalRecord < 0){
                return 100;
            }
       }
       else{
            if(this.props.totalRecord < 0){
                return 0;
            }
       }
       return  Math.round((this.props.passedRecord / (this.props.totalRecord < 0 ? 0 : this.props.totalRecord ))*100);
   }

   getImageonSaasType(){
       return <img className='img-fluid img-style' src={this.props.Saas.img} alt={this.props.Saas.key.toUpperCase()} />
    }

    showProgressBarVarient() : string{
        let varient : string = this.deafultRangeColor;
        let successPercent =this.getSuccessPercentage();
        if(this.props.totalRecord <= 0) varient =this.deafultRangeColor;
        if(successPercent > 0 && successPercent < 30) varient = "red";
        else if(successPercent >=30 && successPercent <60 ) varient = "yellow";
        else if(successPercent >=60 && successPercent <100 ) varient = "blue";
        else if(successPercent ===100) varient ="green";
        else varient= this.deafultRangeColor;
        return varient;
    }

    render() {
        return (
            <div key="row1col1" className="col-md-6">
                <div key="row1col1box1" className="white-box">
                    <div key="row1col1box1col1" className="col-3 d-flex align-items-center">
                        <div key="row1col1box1col1img">{this.getImageonSaasType()}</div>
                    </div>
                    <div key="row1col1box1col2" className="col-9">
                        <div key="row1col1box1progressbar" className="progress-bar-style w-100">
                            <ProgressBar
                                key="progressbar"
                                now={this.getSuccessPercentage(true)}
                                label={`${this.getSuccessPercentage()}%`}
                                variant={this.showProgressBarVarient()}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default SaasItem;
