import React, { Component } from 'react';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import OrgFrameworkComponent , {OrgFrameworkComponentProps, OrgFrameworkComponentState} from '../Base/OrgFrameworkComponent';
import AlertDashboard from './AlertDashboard';
import Dashboard from './Dashboard';
import MonitorDashboard from './MonitorDashboard';

export interface OrgFrameworkProps extends OrgFrameworkComponentProps {
    component : 'Dashboard' | 'Alerts' | 'Monitor';
}

export class OrgFramework extends OrgFrameworkComponent<OrgFrameworkProps,OrgFrameworkComponentState>{
 constructor(props:OrgFrameworkProps){
     super(props);
 }

 override renderComponent(framework : FrameworkEntity): JSX.Element {
    if(!framework){
        return <></>;
    }
    
    let Module : any;
    switch(this.props.component){
        case "Dashboard":{
            Module = Dashboard;
            break;
        }
        case "Alerts" :{
            Module = AlertDashboard;
            break;
        }
        case "Monitor":{
            Module = MonitorDashboard;
            break;
        }
    }
    let props = {
        pageid : this.props.pageid,
        onNavigate :this.props.onNavigate,
        children : this.props.children,
        framework : framework
    }  
    return <Module {...props} />
  }
}
export default OrgFramework