import styled from 'styled-components';

const AlertDashboardWrapper = styled.div`
.white-box {
    background: #FFFFFF;
    box-shadow: 0px 4px 80px rgba(90, 90, 90, 0.15);
    border-radius: 10px;
    padding: 32px 20px;
    margin-right: 20px;
    .text1 {
        font-family: 'ProductSansBold';
        font-size: 24px;
        line-height: 36px;
        color: #707070;
    }
    .alert-count {
        font-family: 'ProductSansBold';
        font-size: 56px;
        line-height: 78px;
        padding-top: 24px;
        padding-bottom: 10px;
    }
    .green-color {
        color: #26C6DA; 
    }
    .red-color {
        color: #FC573B;
    }
    .orange-color {
        color: #FCAE3B;
    }
}
@media only screen and (max-width: 1199.98px) {
    .white-box {
        margin-right: 0px;
        .text1 {
            font-family: 'ProductSansBold';
            font-size: 20px;
            line-height: 36px;
            color: #707070;
        }
        .alert-count {
            font-size: 50px;
            padding-top: 20px;
            padding-bottom: 0px;
        }
    }
}
`;

export default AlertDashboardWrapper;