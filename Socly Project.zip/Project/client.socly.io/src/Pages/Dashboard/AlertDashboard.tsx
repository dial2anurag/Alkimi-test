import React, { Component } from 'react'
import BaseDashboardListComponent,{BaseDashboardListComponentState} from './Base/BaseDashboardListComponent';
import {BaseDashboardComponentProps} from './Base/BaseDashboardComponent';
import {ColDef } from 'ag-grid-community';
import UploadEvidenceService from '../../services/Upload/UploadEvidenceService';
import ProductionImg from '../../Assets/Production.svg';
import TotalAlertsImg from '../../Assets/Total_Alerts.svg';
import NonProductionImg from '../../Assets/Non_Production.svg';
import AlertDashboardWrapper from './alertDashboard.style';

import {
    Button,
    Container as BootstrapContainer,
    Row,
    Col,
    Card,
} from 'react-bootstrap';

import { IComplianceData } from '../../Model/Compliance/ComplianceEntity';
import { PRODUCTION } from '../../services/Compliance/FrameworkComplianceService';


interface AlertDashboardState extends BaseDashboardListComponentState{
    totalAlerts : number,
    productionAlerts :number
}

export class AlertDashboard extends BaseDashboardListComponent<BaseDashboardComponentProps,AlertDashboardState> {
    constructor(props:BaseDashboardComponentProps){
        super(props);
        this.state = {
            totalAlerts : 0,
            productionAlerts :0,
            complianceList :[],
            gridList : [] ,
            failedCompliantList :[],
            saasList :[],
            showSpinner : true       
        }
    }  

    override gridColumnDef() : ColDef[] {
        return [{
               field: "serviceProvider",
               headerName : "Service Provider",
               width : 6
          },{
               field: "compliancecontrolName",
               headerName : "Section" ,
               width : 6
           },{
               field: "complianceTitle",
               headerName : "Check",
               wrapText :true,
               autoHeight : true,
               width : 20
           },
           {
               field: "description",
               headerName : "Description",
               wrapText :true,
               autoHeight : true,
               width : 20
           },
           {
                field: "environment",
                headerName : "Environment",
                wrapText :true,
                autoHeight : true,
                width : 20
           }, 
           this.showStatusColumn(),
           {
                field : "recommended_Remediation",
                headerName : "Remediation",
                filter : false,
                sortable : false,
                cellRendererFramework : (params: any) => { 
                    let disabled : boolean = true;
                    let linkData : string ="#" ;
                    let linkArray : string[] =[];
                    if(params.value && params.value.trim().length >0){
                        disabled =false;
                        linkArray = params.value.trim().split(";")
                    }
                    if(disabled){
                        return(<></>)
                    }
                    else{
                            return(<>
                            { linkArray.map((itm,indx)=>{
                                return (
                                    <Button key={`Remediate(${indx})`}
                                    className="btn-sm" variant='primary'
                                    onClick={(e)=>window.open(itm.trim().length > 0 ? itm.trim() : "#")}>Remediate</Button>
                                )
                            }) }
                            </>)    
                    }
                }
           }
        ]
    }

    override defaultGridColumnsDef() : ColDef{
        return {
            sortable :true,
            flex :1,
            resizable : true,
            filter: true,
            minWidth :100
        }
    }

    override async fillStateList()
     {
        if(this.state.complianceList.length < 0) return;
        let alertdata : any[] =[] //this.state.gridList;
        let alerts :any[] =[] ;
        let controlList : any[]=[];
        let compdata : any;
        let compid : string ="";
        let productionalerts : number =0 ;
        let listresp = await new UploadEvidenceService(this.props.framework).getComplianceList();
        if(listresp.status ===200){
            controlList = listresp.data;
        }
        
        this.state.complianceList.forEach((parent) => {
            if(!parent.Data.abstractResponse){ return ;}
            parent.Data.abstractResponse.forEach((child :any) => {
                alerts = child.entityCompliance.filter((a : any)=> a.complianceStatus.toString() === "FAILED");
                alerts.forEach((subchild :any) => {
                    if(subchild && subchild.complianceID){
                        compid =subchild.complianceID.replaceAll(' ','').toUpperCase();
                        compdata=controlList.find(e=> e.complianceId.toUpperCase() === compid);
                        if(compdata){
                            subchild["controlName"] = compdata.controlName;
                            subchild["compliancecontrolName"] = `(${compid}) ${compdata.controlName}` ;
                        }
                        else{
                            subchild["controlName"] =compid;
                            subchild["compliancecontrolName"]=compid;
                        }
                    }
                    else{
                        subchild["controlName"] ="";
                        subchild["compliancecontrolName"]="";
                    }
                    subchild["serviceProvider"] = parent.Key;
                    subchild["statusDate"]=new Date().toDateString();
                    if(subchild["environment"] && subchild["environment"] === PRODUCTION){
                        productionalerts = productionalerts +1; 
                    }
                    alertdata.push(subchild);
               });
            });
        });
        this.setState({gridList :alertdata , productionAlerts : productionalerts });
     }

    override onImplementData(){
        let total : number =0;
        this.state.complianceList.forEach((saas : IComplianceData) => {
            total = total + Number(saas.Data.totalRejectedComplianceScore);    
        });
        this.setState({totalAlerts : total}); 
    }

    override renderTopSection() {
        return(
            <AlertDashboardWrapper>
                <div className="alert-section">
                    <div className="row">
                        <div className="col-md-4">
                            <div className="white-box">
                                <img src={TotalAlertsImg} alt="Alert Icon" />
                                <div className='alert-count green-color'>{this.state.totalAlerts}</div>
                                <div className='text1'>Total Alerts</div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="white-box">
                                <img src={ProductionImg} alt="Alert Icon" />
                                <div className='alert-count red-color'>{this.state.productionAlerts}</div>
                                <div className='text1'>Production</div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="white-box">
                                <img src={NonProductionImg} alt="Alert Icon" />
                                <div className='alert-count orange-color'>{(this.state.totalAlerts - this.state.productionAlerts )}</div>
                                <div className='text1'>Non Production</div>
                            </div>
                        </div>
                    </div>
                </div>
            </AlertDashboardWrapper>
        )
    }
}
export default AlertDashboard