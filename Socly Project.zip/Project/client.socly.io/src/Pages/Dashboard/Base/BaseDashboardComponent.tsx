import React, { Component, ReactNode } from 'react';
import SpinnersComponent from '../../../Components/SpinnersComponent';
import { IRestResponseEntity } from '../../../Model/RestEntities';
import {IComplianceData} from '../../../Model/Compliance/ComplianceEntity';
import FrameworkComponent , {FrameworkComponentProps} from '../../Base/FrameworkComponent';
import FrameworkComplianceService from '../../../services/Compliance/FrameworkComplianceService';

export interface BaseDashboardComponentState {
    complianceList : IComplianceData[],
    saasList : string[],
    failedCompliantList : string[]
    showSpinner : boolean
}

export interface BaseDashboardComponentProps extends FrameworkComponentProps {}

export abstract class BaseDashboardComponent<P extends BaseDashboardComponentProps,
                                    S extends BaseDashboardComponentState, SS={}> 
extends FrameworkComponent<P,S,SS> {
    constructor(props:P){
        super(props);
  }
  
  protected abstract renderComponent() : ReactNode;
  protected abstract implementData() : void ;
  protected onComponentDidMount ?()  : void; 
  protected afterDataLoad ? () : void;
    async loadSaasData(){
        let response : [string[],string[],IComplianceData[]]= await FrameworkComplianceService.getCompliances(this.props.framework);
        this.setState({
            saasList : response[0],
            failedCompliantList : response[1],
            complianceList : response[2]
        })
        if( this.afterDataLoad) this.afterDataLoad();
        this.hideSpinner(response[0],response[2],response[1]);
    }

    hideSpinner(saasList : string[] , compList : IComplianceData[],failedCompList : string[]) : boolean{
        if(saasList.length <=0 || ( saasList.length === (compList.length + failedCompList.length)))
        {
            this.implementData();
            this.setState({showSpinner : false});
            return true;
        }
        else{
            return false;
        }
    }

    componentDidMount(){
        this.loadSaasData();
        if(this.onComponentDidMount){
            this.onComponentDidMount();
        }
    }

    render() {
        return (
            <div>
                <SpinnersComponent key="basedashboardspinnercomponent" showspinner={ this.state.showSpinner} disablesection ={true}/>
                {this.renderComponent()}
            </div>
        )
    }
}
export default BaseDashboardComponent;