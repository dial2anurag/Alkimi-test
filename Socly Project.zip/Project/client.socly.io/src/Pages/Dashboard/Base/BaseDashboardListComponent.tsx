import React, { Component, ReactNode } from 'react';
import BaseDashboardComponent , {BaseDashboardComponentProps, BaseDashboardComponentState} from './BaseDashboardComponent';
import { PageContainer, ContentHeading } from '../../../StyledComponents/ComponentWrapper'
import {ColDef , GridReadyEvent , ICellRendererComp, ICellRendererParams} from 'ag-grid-community';
import {AgGridReact } from 'ag-grid-react';
import {Button} from 'react-bootstrap'
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CancelIcon from '@mui/icons-material/Cancel';
import './dashboard.css';

export interface BaseDashboardListComponentState extends BaseDashboardComponentState{
    gridList : any []
}

export abstract class BaseDashboardListComponent<P extends BaseDashboardComponentProps, 
                                        S extends BaseDashboardListComponentState , SS ={}> 
                extends BaseDashboardComponent<P,S,SS>  {
    constructor(props :P){
        super(props);
    }
    protected gridInstance :GridReadyEvent | undefined;
    protected abstract fillStateList() :void;
    protected abstract renderTopSection() :ReactNode ;
    protected abstract defaultGridColumnsDef() : ColDef ;
    protected abstract gridColumnDef() :ColDef [] ;
    protected abstract onImplementData () :void;
    
    override afterDataLoad(){
        this.setAndRefreshGrid();
    }

    onaggridExport2CSV(event :any){
        if(! this.gridInstance){
            return;
        }
        this.gridInstance.api.exportDataAsCsv();
    }

    setAndRefreshGrid(){
        if(this.gridInstance){
            this.gridInstance.api.refreshCells();
        }
    }

    override implementData()
    {
        this.fillStateList();
        if(this.onImplementData){
            this.onImplementData();
        }
    }

    onGridReady(params:GridReadyEvent){
        this.gridInstance = params ;
        this.setAndRefreshGrid();
     }

     protected showStatusColumn() :ColDef{
         return {
                field : "complianceStatus",
                headerName : "Status",
                filter : false,
                sortable : false,
                cellRendererFramework : (params: any) => { 
                    if(params.value.trim() === "PASSED"){
                        return(<CheckCircleOutlineIcon fontSize='small' style={{color : "green"}} />);
                    }
                    else{
                        return(<CancelIcon fontSize='small' style={{color : "red"}} />);
                    }
                }
         }
     }

     override renderComponent() {
        return(
            <div>
                <PageContainer>
                    <div>
                        {this.renderTopSection()}   
                    </div>
                    <div>
                        <ContentHeading></ContentHeading>
                        <div className='container'>
                            <div className='row'>
                                <div className='col div-export-button'>
                                    <Button key="aggridExport" 
                                            variant='primary' 
                                            onClick={this.onaggridExport2CSV.bind(this)}>
                                        Export To CSV
                                    </Button>
                                </div>
                           </div>
                            <div className='row'>
                                <div className='col'>
                                    <div className="ag-theme-alpine" style={{height: 800, width:"100%",textAlign :"left"}}>
                                        <AgGridReact
                                            defaultColDef = {this.defaultGridColumnsDef()}
                                            columnDefs = {this.gridColumnDef()}
                                            enableCellChangeFlash ={true}
                                            onGridReady ={this.onGridReady.bind(this)}
                                            pagination ={true}
                                            paginationPageSize ={10}
                                            rowData ={this.state.gridList}
                                        >
                                        </AgGridReact>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </PageContainer>
            </div>
        )
    }
}

export default BaseDashboardListComponent