import * as React from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import {Modal } from 'react-bootstrap'
import SpinnersComponent from '../../Components/SpinnersComponent';
import UsersServices from '../../services/Users/Users';
import AuthService from '../../services/Users/auth.service';

type PasswordChange = {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
  acceptTerms: boolean;
};

export type ChangePasswordData = {
  userProfile : any, 
  token : string
}

type ChangePasswordProps = {
  onAfterChangePassword ?: (value : boolean) => void,
  onModalClose ? : ()=> void,
  showCloseOption ?: boolean, 
  userdata ? : ChangePasswordData
}

export const ChangePassword: React.FC<ChangePasswordProps> = (props: ChangePasswordProps) =>   {
 const theme = createTheme();
 const [showModal, setshowModal] = React.useState(true);
 const [showSpinner, setshowSpinner] = React.useState(false);

const schema = Yup.object().shape({
    oldPassword: Yup.string().required("Old Password is required"),
    newPassword: Yup.string()
    .required('password is required')
    // .notOneOf([Yup.ref("oldPassword")], "Old Password Shouldn't be same as New Password")
    .test(
      'Same Password',
      'Old and New Passwords cannot be the same.',
      function(newPassword) {
        const { oldPassword } = this.parent;
        if (oldPassword === newPassword) {
          return false;
        }
        return true;
      }
    )
    
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
      "Must contain atleast 8 Characters, One Uppercase, One Lowercase, One Number & One Special Character."
    ),
    confirmPassword: Yup.string()
      .required("Confirm Password is required")
      .oneOf([Yup.ref("newPassword"), null], "Confirm Password does not match"),
    acceptTerms: Yup.bool().oneOf([true], "Accept Terms is required")
  });
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<PasswordChange>({
    resolver: yupResolver(schema)
  });

  const onSubmit = async (data: PasswordChange) => {
    setshowSpinner(true);
    let dataset ={
      newPassword : data.newPassword,
      oldPassword : data.oldPassword
    }
    let response : number =0;
    if(props.userdata){
      response = await UsersServices.changePasswordWithoutAuth(dataset,props.userdata);
    }
    else{
      response = await UsersServices.changePassword(dataset);
    }

    if(response ===200){
        setshowModal(false);
        if(props.onAfterChangePassword) {
          props.onAfterChangePassword(true);
        }
        alert("Password Changed Sucessfully!!");
        AuthService.logout();
        window.location.href = "/"
    }
    reset();
    setshowSpinner(false);
  };

  const handleClose = (event :any) =>{
    if(props.onAfterChangePassword) {
      props.onAfterChangePassword(false);
    }
    setshowModal(false);
    if(props.onModalClose){
      props.onModalClose();
    }
  }
  
  
  return (
    <>
    <SpinnersComponent key="chngpwdspinnercomponent" showspinner ={showSpinner} />
    <Modal show={showModal} onHide={handleClose.bind(this)}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            backdrop ={"static"}
            keyboard={false}
            centered>
              <Modal.Header closeButton ={(props.showCloseOption ? true : false)} />
             <Modal.Body>
                {/* <ThemeProvider theme={theme}> */}
                <Container component="main" maxWidth="xs" style={{top :'.2em'}}>
                  <CssBaseline />
                  <Box
                    sx={{
                      marginTop: 1,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center"
                    }}
                  >
                    <Avatar sx={{ m: 1, bgcolor: "secondary.main" }} />
                    <Typography component="h1" variant="h5">
                      Change Password
                    </Typography>
                    <Box
                      component="form"
                      onSubmit={handleSubmit(onSubmit)}
                      noValidate
                      // sx={{ mt: 1 }}
                    >
                      <TextField
                        margin="normal"
                        required
                        fullWidth
                        label="Old Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        {...register("oldPassword")}
                        className={`form-control ${
                          errors.oldPassword ? "is-invalid" : ""
                        }`}
                        helperText={errors.oldPassword?.message}
                      />

                      <TextField
                        margin="normal"
                        required
                        fullWidth

                        label="New Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        {...register("newPassword")}
                        className={`form-control ${
                          errors.newPassword ? "is-invalid" : ""
                        }`}
                        helperText={errors.newPassword?.message}
                      />
                      <TextField
                        margin="normal"
                        required
                        fullWidth

                        label="Confirm Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        {...register("confirmPassword")}
                        className={`form-control ${
                          errors.confirmPassword ? "is-invalid" : ""
                        }`}
                        helperText={errors.confirmPassword?.message}
                      />

                     <Box textAlign='center'>
                      <Button
                        type="submit"
                        // fullWidth
                        variant="contained"
                       >
                        Submit
                      </Button></Box>
                      
                    </Box>
                  </Box>
                </Container>
              {/* </ThemeProvider> */}
          </Modal.Body>
    </Modal>
    </>
  );
}
