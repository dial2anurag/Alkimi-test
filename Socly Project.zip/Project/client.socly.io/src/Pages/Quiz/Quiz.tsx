import AuthenitcatedComponent, {
  AuthenitcatedComponentProps,
} from "../Base/AuthenitcatedComponent";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { Button, CardActionArea } from "@mui/material";
import AuthService from "../../services/Users/auth.service";
import { questions } from "../../Data/Application/QuizData";
import "./style.css";
import QuizService, { QuizDataEntity } from "../../services/Quiz/QuizService";


interface QuestionState {
  currentQuestion: number;
  currentAnswer: number;
  showScore: boolean;
  score: number;
  questionText: string | null;
  answerOptions: string[];
  isCorrect: boolean;
  currentPage: number;
  checkedRadio: boolean;
  scoreList: number[];
  showSubmitButton: boolean;
  showNextButton: boolean;
  showPreviousButton: boolean;
  showQuestionDiv: boolean;
  showIntroDiv: boolean;
  remeberChoice: string[];
}

export default class Quiz extends AuthenitcatedComponent<
  AuthenitcatedComponentProps,
  QuestionState> {
  private _userData: any;
  constructor(props: any) {
    super(props);
    this._userData = AuthService.getCurrentUser();

    this.state = {
      currentQuestion: 0,
      currentAnswer: 0,
      showScore: false,
      score: 0,
      questionText: null,
      answerOptions: [],
      isCorrect: false,
      currentPage: 0,
      checkedRadio: false,
      scoreList: [],
      showSubmitButton: false,
      showNextButton: false,
      showPreviousButton: false,
      showQuestionDiv: false,
      showIntroDiv: true,
      remeberChoice: [],
    };
  }

  onRadiochecked = (selectedval: boolean, indexval: number) => {
    let { currentQuestion, score, scoreList } = this.state;

    let remeberChoice = [...this.state.remeberChoice];
    remeberChoice[currentQuestion] =
      questions[currentQuestion].answerOptions[indexval].answerText;
    this.setState({
      remeberChoice,
    });

    if (selectedval) {

      let ScoreList = [...this.state.scoreList];
      scoreList[currentQuestion] = 1;
    } else {
      let ScoreList = [...this.state.scoreList];
      ScoreList[currentQuestion] = 0; //new value
      this.setState({ scoreList });
    }
  };

  nextQuestionOnClick = () => {
    let { currentQuestion } = this.state;
    if (currentQuestion + 1 < questions.length) {
      this.setState({
        currentQuestion: currentQuestion + 1,
      });
    }
    if (currentQuestion + 1 < questions.length) {
      this.setState({
        showSubmitButton: false,
        showNextButton: true,
        showPreviousButton: true,
      });
    }
    if (currentQuestion + 2 === questions.length) {

      this.setState({
        showSubmitButton: true,
        showNextButton: false,
      });
    }
  };
  previousQuestionOnClick = () => {
    let { currentQuestion } = this.state;
    if (currentQuestion - 1 >= 0) {
      this.setState({ currentQuestion: currentQuestion - 1 });
    }
    if (currentQuestion < questions.length && currentQuestion <= 1) {
      this.setState({
        showPreviousButton: false,
      })
    } else if (currentQuestion < questions.length) {
      this.setState({
        showSubmitButton: false,
        showNextButton: true,
        showPreviousButton: true,
      });
    }

  };
  submitAnswers = async (event: any) => {
    event.preventDefault();
    let { scoreList } = this.state;
    this.setState({
      showQuestionDiv: false,
      showSubmitButton: false,
      showScore: true,
    });
    let sum = 0;
    for (let num of scoreList) {
      if (num === undefined) {
        num = 0;
        sum = sum + num;
      } else {
        sum = sum + num;
      }
    }
    let pass: boolean;
    if (sum > 12) {
      pass = true;
      alert('You have passed in Quiz');
    } else {
      pass = false;
      alert('You have scored less than cut off, Better luck next time!');
    }
    this.setState({
      score: sum,
    });
    let data: QuizDataEntity = {
      score: sum,
      pass: pass

    }
    let response = await QuizService.SaveQuizData(data);
    if (response !== 200) {
      alert("Error in saving quiz");
    }
    return {
      status: response
    }
  };

  startQuiz = () => {
    this.setState({
      showIntroDiv: false,
      showQuestionDiv: true,
      showNextButton: true,
      showPreviousButton: false,
    });
  };

  render() {
    let { currentQuestion, score, remeberChoice } = this.state;

    return (
      <div>
        {this.state.showIntroDiv ? (
          <div>
            <Card>
              <CardActionArea>
                <CardContent>
                  <h2>
                    Hello!!,{this._userData.name} Welcome to the compliance Quiz
                  </h2>
                </CardContent>
              </CardActionArea>
              <CardActionArea>
                <Button
                  variant="contained"
                  size="large"
                  onClick={() => this.startQuiz()}
                >
                  Start Quiz
                </Button>
              </CardActionArea>
            </Card>
          </div>
        ) : null}

        <Card>
          {this.state.showQuestionDiv ? (
            <div>
              <h4 className="question-header">
                {currentQuestion + 1} .{" "}
                {questions[currentQuestion].questionText}
              </h4>
              <hr></hr>
              <div className="answer-section">
                {questions[currentQuestion].answerOptions.map(
                  (answerOption, index) => (
                    <p>
                      <label className="radioleft">
                        {" "}
                        <input
                          type="radio"
                          checked={
                            remeberChoice[currentQuestion] ===
                            answerOption.answerText
                          }
                          onChange={() =>
                            this.onRadiochecked(answerOption.isCorrect, index)
                          }
                          name={questions[currentQuestion].questionText}
                          value={answerOption.answerText}
                        />
                        &nbsp;&nbsp;&nbsp; {answerOption.answerText}{" "}
                      </label>
                    </p>
                  )
                )}
              </div>
              {this.state.showPreviousButton ? (
                <Button
                  id="quiz-btn"
                  variant="contained"
                  size="medium"
                  onClick={() => this.previousQuestionOnClick()}
                >
                  Previous
                </Button>
              ) : null}
              &nbsp;&nbsp;&nbsp;
              {this.state.showNextButton ? (
                <Button
                  id="quiz-btn"
                  variant="contained"
                  size="medium"
                  onClick={() => this.nextQuestionOnClick()}
                >
                  Next
                </Button>
              ) : null}
              &nbsp;&nbsp;&nbsp;
              {this.state.showSubmitButton ? (
                <Button
                  id="quiz-btn"
                  variant="contained"
                  size="medium"
                  onClick={(event) => this.submitAnswers(event)}
                >
                  Submit
                </Button>
              ) : null}
            </div>
          ) : null}

          {this.state.showScore ? (
            <div>
              <p> The total score is </p>
              <h2>{score}</h2>
            </div>
          ) : null}
        </Card>
      </div>
    );
  }
}

