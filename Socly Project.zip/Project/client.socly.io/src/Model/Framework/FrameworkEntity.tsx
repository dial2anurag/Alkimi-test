
export interface FrameworkEntity{
    id: number,
    name : string
} 