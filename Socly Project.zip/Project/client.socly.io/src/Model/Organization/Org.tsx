export interface IOrgRegistration {
    clientId : number,
    orgName : string,
    description : string
}

export type APIData = {
    id?: number,
    orgId: number,
    name: string,
    value: string
}

export interface OrgDetailsServiceEntity {
    email: string,
    website: string,
    phone: string,
    GstNo: string,
    CINNo: string,
    founders: string[] | string,
    CEO: string,
    CTO: string,
    CISO: string,
    Address1: string,
    Address2: string,
    city: string,
    state: string,
    country: string,
    pincode: string,
    logo: string
};

export interface OrgDetailsEntity extends OrgDetailsServiceEntity{
    id : number,
    orgName : string
}

export interface DocumentSummeryEntity {
    createdOn ?: string,
    approvedOn ? : string,
    createdBy ?: string,
    approvedBy ?: string,
    versionno ?: string
}