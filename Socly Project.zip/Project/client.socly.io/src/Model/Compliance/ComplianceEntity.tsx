export interface IComplianceData{
    Key : string ,
    Data : any
}