export interface IAccountDetail{
    id?:BigInteger
    account:string
}