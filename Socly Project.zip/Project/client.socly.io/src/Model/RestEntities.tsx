import {AxiosRequestConfig} from "axios";

export interface IRestResponseEntity  {
    status : number ,
    data : any ,
    message : string
}

export interface IRestServiceParams {
    key : string,
    value: string
};

export interface IRestRequestEntity {
    endPoint : string ,
    data :any | null,
    axiosConfig ?: AxiosRequestConfig,
    setAuthentication : boolean
}
