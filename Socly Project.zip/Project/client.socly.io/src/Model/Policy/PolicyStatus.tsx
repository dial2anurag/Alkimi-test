export enum PolicyStatus {
    InProgress,
    SendToApproval,
    Approved,
    Rejected,
    RequestChange
 }