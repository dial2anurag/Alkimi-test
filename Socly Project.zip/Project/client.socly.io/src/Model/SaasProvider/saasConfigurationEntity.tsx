import BaseFrameworkSaasService from "../../services/SaasProviders/BaseFrameworkSaasService";
import { FrameworkEntity } from "../Framework/FrameworkEntity";
import { SaasType } from "./saasProviderEntity"

export interface IComplianceSaasService {
    getBaseFrameworkSaasServiceInstance(framework : FrameworkEntity ) : BaseFrameworkSaasService; 
}

export type Saas = {
    key : string,
    img : string,
    active:boolean,
    saasType : SaasType,
    width?: number,
    classInstance ?: IComplianceSaasService
}