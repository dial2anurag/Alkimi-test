
export enum SaasType {
    Cloud,
    HrTools,
    IdentityProviders,
    OtherProviders,
    ProjectTrackings,
    VersionControls
}
