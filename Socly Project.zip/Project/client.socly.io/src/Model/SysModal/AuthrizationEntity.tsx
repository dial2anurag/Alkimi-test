
export enum Role {
   SUPER_ADMIN,
   ORG_BUSINESS_ADMIN,
   ORG_BUSINESS_OPS,
   EMPLOYEES,
   AUDITOR
}

export interface PageAccess {
    name : string,
    path : String,
    title :string,
    
}
export interface AuthEntity {
    role : Role,
    access : PageAccess []
}