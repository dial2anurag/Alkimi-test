import {
    LinkProps 
  } from "react-router-dom";

export enum SectionComponent {
    NavBar,
    RoleView ,
    HelpSection,
    ProfileSection,
    None
}

export enum ComponentType {
    ClassComponent ,
    FunctionalComponent ,
    Function,
    None
}

export enum AccessType {
    Read=0,
    FullAccess=1,
    CustomAccess=2
}

export enum IconType {
    PIC = 0,
    ICONS = 1
}

export type CustomAccess ={
    access :{[key : string] : AccessType},
    customData ?:any
}

export type AccessData={
    accessType : AccessType ,
    customAccess ?:CustomAccess
}

export interface IRouteFunctions {
    onNavigate ? : (propsParam: LinkProps & React.RefAttributes<HTMLAnchorElement>, childElement : JSX.Element) => JSX.Element
}

export interface IconComponent {
    iconType  : IconType,
    iconIndex :  number,
    iconProps ? : any,
}

export interface IPageComponent {
    id :number
    title : string,
    componentIndex : number | null
    sequence : number,
    section : SectionComponent,
    componentType : ComponentType,
    path ?: string,
    icon  ?: IconComponent
    parentid ? : number | null,
    componentProps ? : any,
}


export interface IRolePageComponent extends IPageComponent {
    accessdata : AccessData,
    roleData : IBaseRoleAuth 
}

export interface IRolePage {
    pageid :number ,
    accessdata : AccessData,
}

export interface IBaseRoleAuth {
    role : string,
    defaultpage : number | null 
}

export interface IRoleAuth extends IBaseRoleAuth {
    pages : IRolePage []
}

export interface IRoleAccess {
    rolePage : IRolePage,
    pageComponent : IPageComponent | undefined
}