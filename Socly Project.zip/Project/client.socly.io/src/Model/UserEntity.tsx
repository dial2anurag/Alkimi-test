
export interface IUserEntity  {
    userid:string
    username : string,
    loggedinDate : Date,
    name : string
}



