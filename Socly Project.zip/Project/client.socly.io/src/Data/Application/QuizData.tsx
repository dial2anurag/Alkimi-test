export const questions = [
    {
        questionText: "Did you go through your internal Security policies and finish the security training?",
        answerOptions: [
            { answerText: "Yes", isCorrect: true },
            { answerText: "No", isCorrect: false },
        ]
    },
    {
        questionText: "Which of the following is a weak password?",
        answerOptions: [
            { answerText: "123456", isCorrect: false },
            { answerText: "P@ssw0rd", isCorrect: false },
            { answerText: "ILoveYou123", isCorrect: false },
            { answerText: "All of the above", isCorrect: true }
        ]
    },
    {
        questionText: "What should I do after I learn about a data breach of a  third party website? Choose the best answer.",
        answerOptions: [
            { answerText: "Nothing", isCorrect: false },
            { answerText: "Change the password of my account for that website", isCorrect: false },
            { answerText: "Change the password for my account for that website and of all other websites where I use that same password", isCorrect: true },
        ]
    },
    {
        questionText: "If you receive a suspicious email, should you?",
        answerOptions: [
            { answerText: "Reply to it", isCorrect: false },
            { answerText: "Open the attachments", isCorrect: false },
            { answerText: "Click the links", isCorrect: false },
            { answerText: "Report it as phishing", isCorrect: true }
        ]
    },
    {
        questionText: "Which of the following statements are correct?",
        answerOptions: [
            { answerText: "Phishing is a form of social engineering.", isCorrect: false },
            { answerText: "Phishing is a so called 'spray and pray' technique in which an attacker sends out the same email to hundreds of potential targets.", isCorrect: true },
            { answerText: "All of the above", isCorrect: false },
        ]
    },
    {
        questionText: "Which is a good practice.",
        answerOptions: [
            { answerText: "To connect your Office device to an Open WiFi", isCorrect: false },
            { answerText: "To leave your Device Open for a minute to get coffee", isCorrect: false },
            { answerText: "To share login credentials with your teammate to send an urgent mail that can lead huge profit for the company", isCorrect: false },
            { answerText: "All of the above", isCorrect: false },
            { answerText: "None of the above", isCorrect: true }
        ]
    },
    {
        questionText: "What is the correct way to use credentials/keys in the your code?",
        answerOptions: [
            { answerText: "Directly store them in local variables and use them", isCorrect: false },
            { answerText: "Store them in JSON files and use them", isCorrect: false },
            { answerText: "Store them in Config files ", isCorrect: true },
        ]
    },
    {
        questionText: "What is the best way to store customer API Keys/Credentials?",
        answerOptions: [
            { answerText: "Store them in cache", isCorrect: false },
            { answerText: "Store them in transactional databases", isCorrect: false },
            { answerText: "Store them in variables", isCorrect: false },
            { answerText: "Store them in Key Vault with restricted access.", isCorrect: true }
        ]
    },
    {
        questionText: "Steps to be followed while posting queries in public forums like Stackoverflow etc?",
        answerOptions: [
            { answerText: "Do not directly copy and paste code", isCorrect: false },
            { answerText: "Remove any environment specific URLs", isCorrect: false },
            { answerText: "Remove any keys or credentials", isCorrect: false },
            { answerText: "Scrub the client data if any", isCorrect: false },
            { answerText: "All of the above", isCorrect: true }
        ]
    },
    {
        questionText: "What do you do in an event of a security incident?",
        answerOptions: [
            { answerText: "Ignore it", isCorrect: false },
            { answerText: "Check the issue and if you do not understand it then ignore it", isCorrect: false },
            { answerText: "Report the issue to the ISM (Information Security Manager) or CxOs", isCorrect: true }
        ]
    },
    {
        questionText: "What is the best way to submit code or documents?",
        answerOptions: [
            { answerText: "Just finish it and submit", isCorrect: false },
            { answerText: "Just finish the work and check once to submit", isCorrect: false },
            { answerText: "Finish the work,cross check your work and send it to peer review.", isCorrect: true }
        ]
    },
    {
        questionText: "What is a good practice?",
        answerOptions: [
            { answerText: "Get the requirements in call and start working", isCorrect: false },
            { answerText: "Discuss the requirements with the lead and start developing", isCorrect: false },
            { answerText: "Discuss the requirements over call, Create a task ticket with requirements and keep updating as the task progress happens", isCorrect: true }
        ]
    },
    {
        questionText: "Are code comments or comments in work in progress documents helpful?",
        answerOptions: [
            { answerText: "No they are not relevant", isCorrect: false },
            { answerText: "They increase the overall line of code", isCorrect: false },
            { answerText: "They help in code maintenance and better understandability.", isCorrect: true },
        ]
    },
    {
        questionText: "What is the best way to merge code?",
        answerOptions: [
            { answerText: "Take the production branch into your local, make changes and commit", isCorrect: false },
            { answerText: "Take the dev branch,make changes and commit", isCorrect: false },
            { answerText: "Create a feature branch from Production and make changes and merge it with production", isCorrect: false },
            { answerText: "Create a feature branch for the latest code from Dev/Integration branch. Make the changes in local repo and push it to feature branch. Create a pull request to merge the feature branch with the Dev branch post a review by the Team leads.", isCorrect: true }
        ]
    },
    {
        questionText: "How to access to SaaS environments?",
        answerOptions: [
            { answerText: "Share your teammate's credentials", isCorrect: false },
            { answerText: "Create common credentials like dev for all the team members", isCorrect: false },
            { answerText: "Request the team lead to create user specific user for better logging, monitoring and audit logs.", isCorrect: true },
        ]
    }
];

