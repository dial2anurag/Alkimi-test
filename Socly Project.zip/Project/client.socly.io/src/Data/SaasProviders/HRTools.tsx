import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import bamboohr from '../../Assets/bamboohr.svg';
import gerytHr from '../../Assets/greythr.svg';
import keka from '../../Assets/Keka.svg';
import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';

export const HRToolList : Saas[] = [
    {
        key: 'bamboohr',
        img: bamboohr,
        active:false,
        width: 200,
        saasType : SaasType.HrTools
    },
    {
        key: 'gerytHr',
        img: gerytHr,
        active:false,
        width: 150,
        saasType : SaasType.HrTools

    },
    {
        key: 'keka',
        img: keka,
        active:false,
        width: 150,
        saasType : SaasType.HrTools

    }]