import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import github from '../../Assets/github.svg';
import bitbucket from '../../Assets/bitbucket.svg';
import gitlab from '../../Assets/gitlab.svg';
import GithubSecretService from '../../services/GitHub/GithubSecretService';
import BitBucketSecretService from '../../services/BitBucket/BitBucketSecretService';
import GitLabSecretService from '../../services/GitLab/GitLabSecretService';

export const VersionControlList: Saas[] = [
    {
        key: 'github',
        img: github,
        active: true,
        width: 150,
        saasType: SaasType.VersionControls,
        classInstance : GithubSecretService
    },
    {
        key: 'bitbucket',
        img: bitbucket,
        active: true,
        width: 200,
        saasType: SaasType.VersionControls,
        classInstance : BitBucketSecretService
    }, {
        key: 'gitlab',
        img: gitlab,
        active: false,
        width: 150,
        saasType: SaasType.VersionControls,
        classInstance : GitLabSecretService
    }
]