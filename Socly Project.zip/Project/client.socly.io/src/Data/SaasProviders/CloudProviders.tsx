import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import aws from '../../Assets/aws.svg'
import azure from '../../Assets/azure.svg'
import gcp from '../../Assets/gcp.svg'
import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import AWSSecretService from '../../services/AWS/AWSSecretService';

export const CloudProviderList: Saas[] = [
    {
        key: 'aws',
        img: aws,
        active:true,
        width: 150,
        saasType : SaasType.Cloud,
        classInstance: AWSSecretService
    }
    ,{
        key: 'azure',
        img: azure,
        active:false,
        width: 150,
        saasType : SaasType.Cloud
    }
    ,{
        key: 'gcp',
        img: gcp,
        active:false,
        width: 150,
        saasType : SaasType.Cloud
    }
]