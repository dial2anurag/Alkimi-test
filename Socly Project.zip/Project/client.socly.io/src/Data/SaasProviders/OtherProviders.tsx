import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import slack from '../../Assets/slack.svg';
import jamf from '../../Assets/jamf.svg';
import MicrosoftIntune from '../../Assets/Microsoft-Intunes.svg';

export const OtherProviderList : Saas[] = [
    {
        key: 'slack',
        img: slack,
        active:false,
        width: 150,
        saasType : SaasType.OtherProviders

    },
    {
        key: 'jamf',
        img: jamf,
        active:false,
        width: 150,
        saasType : SaasType.OtherProviders

    },
    {
        key: 'MicrosoftIntune',
        img: MicrosoftIntune,
        active:false,
        width: 200,
        saasType : SaasType.OtherProviders
    }
]