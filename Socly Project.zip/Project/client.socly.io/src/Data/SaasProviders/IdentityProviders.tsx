import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import gsuite from '../../Assets/gsuite.svg';
import office from '../../Assets/m365.svg';
import okta from '../../Assets/okta.svg';
import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import GsuiteComplianceService from '../../services/GSUITE/GsuiteComplianceService';
import GsuiteSecretService from '../../services/GSUITE/GsuiteSecretService';


export const IdentityProviderList : Saas[] = [
    {
        key: 'gsuite',
        img: gsuite,
        active:true,
        width: 150,
        saasType : SaasType.IdentityProviders,
        classInstance : GsuiteSecretService
    },
    {
        key: 'office',
        img: office,
        active:false,
        saasType : SaasType.IdentityProviders
    }, {
        key: 'okta',
        img: okta,
        active:false,
        width: 150,
        saasType : SaasType.IdentityProviders
    }
    //,{
    //     key: 'zoho',
    //     img: zoho,
    //     active:true,
     //   saasType : SaasType.IdentityProviders
    // },
    // {
    //     key: 'godaddy',
    //     img: godaddy,
    //     active:true,
     //   saasType : SaasType.IdentityProviders
    // }
]