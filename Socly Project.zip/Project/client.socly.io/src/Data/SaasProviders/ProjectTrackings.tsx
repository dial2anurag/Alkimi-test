import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import { SaasType } from '../../Model/SaasProvider/saasProviderEntity';
import jira from '../../Assets/jira.svg';
import zoho from '../../Assets/zoho.svg';
import devops from '../../Assets/devops.svg';

export const ProjectTrackingList : Saas[] = [
    {
        key: 'jira',
        img: jira,
        active:false,
        width: 120,
        saasType : SaasType.ProjectTrackings
    },
    {
        key: 'zoho',
        img: zoho,
        active:false,
        width: 150,
        saasType : SaasType.ProjectTrackings
    },
    {
        key: 'devops',
        img: devops,
        active:false,
        width: 150,
        saasType : SaasType.ProjectTrackings
    }
]