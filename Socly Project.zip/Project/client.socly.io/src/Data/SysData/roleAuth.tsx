import { IRoleAuth, AccessType } from '../../Model/SysModal/sysEntiry';
export const AuthRoles: IRoleAuth[] = [
    {
        role: "SUPER_ADMIN",
        defaultpage: 12,
        pages: [
            { pageid: 12, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 13, accessdata: { accessType: AccessType.FullAccess } },
        ]
    },
    {
        role: "ORG_BUSINESS_ADMIN",
        defaultpage: 2,
        pages: [
            { pageid: 1, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 2, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 4, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 3, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 7, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 8, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 9, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 10, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 11, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 14, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 15, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 16, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 17, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 18, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 19, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 20, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 21, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 22, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 23, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 24, accessdata: { accessType: AccessType.FullAccess } }
        ]
    },
    {
        role: "ORG_BUSINESS_OPS",
        defaultpage: 2,
        pages: [
            { pageid: 2, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 4, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 3, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 7, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 8, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 11, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 18, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 23, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 24, accessdata: { accessType: AccessType.FullAccess } }
        ]
    },
    {
        role: "AUDITOR",
        defaultpage: 5,
        pages: [
            { pageid: 5, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 10, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 18, accessdata: { accessType: AccessType.FullAccess } },
            { pageid: 21, accessdata: { accessType: AccessType.Read } },
            { pageid: 22, accessdata: { accessType: AccessType.FullAccess } }
        ]
    }
]