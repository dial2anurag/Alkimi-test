
export const RoleMappings : {[key: string]: string}={
    SUPER_ADMIN : "SUPER_ADMIN",
    ORG_BUSINESS_ADMIN : "ADMIN",
    ORG_BUSINESS_OPS : "USER",
    AUDITOR : "AUDITOR",
    LEADER : "LEADER",
    EMPLOYEES : "EMPLOYEES"
}
