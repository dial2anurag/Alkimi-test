import QuizIcon from '@mui/icons-material/Quiz';
import Dashboard from '../../Assets/Images/dashboard.svg'
import Tools from '../../Assets/Images/tools.svg'
import Monitoring from '../../Assets/Images/monitoring.svg'
import Alert from '../../Assets/Images/alert.svg'
import Auditor from '../../Assets/Images/auditor.svg'
import DocEngine from '../../Assets/Images/docengine.svg'
import PolicyMaker from '../../Assets/Images/policymaker.svg'
import PolicyApprover from '../../Assets/Images/policyapprover.svg'
import Documentation from '../../Assets/Images/documentation.svg'
import UserWorkflow from '../../Assets/Images/userworkflow.svg'
import PolicyCenter from '../../Assets/Images/policycenter.svg'
import TrainingModule from '../../Assets/Images/trainingmodule.svg'
import Organization from '../../Assets/Images/organization.svg'
import UserRegistration from '../../Assets/Images/userregistration.svg'
import OrgDetails from '@mui/icons-material/ManageAccounts';
import OrgSettings from '@mui/icons-material/AppSettingsAlt';


export const IConComponents: { [key: number]: any } = {
    0:Tools,
    1: Dashboard,
    2: Alert,
    3: Monitoring,
    4: Auditor,
    5: DocEngine,
    6: OrgDetails,
    7: OrgSettings,
    8: Organization,
    9: UserRegistration,
    10: UserWorkflow,
    11: PolicyMaker,
    12: PolicyApprover,
    13: Documentation,
    14: PolicyCenter,
    15: TrainingModule,
    16: QuizIcon
}