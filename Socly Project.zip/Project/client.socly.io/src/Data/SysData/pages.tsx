import { IPageComponent, SectionComponent, ComponentType, IconType } from '../../Model/SysModal/sysEntiry';

export const pageComponents: IPageComponent[] = [
  {
    id: 1,
    title: "Tools",
    componentIndex: 0,
    path: "/tools",
    icon : {iconType: IconType.PIC, iconIndex: 0 },
    componentType: ComponentType.ClassComponent,
    sequence: 4,
    section: SectionComponent.NavBar
  },
  {
    id: 2,
    title: "Dashboard",
    componentIndex: 1,
    path: "/dashboard",
    icon : {iconType: IconType.PIC, iconIndex: 1 },
    componentType: ComponentType.ClassComponent,
    sequence: 0,
    section: SectionComponent.NavBar,
    componentProps: { component: "Dashboard" }
  },
  {
    id: 3,
    title: "Alerts",
    componentIndex: 1,
    path: "/alert",
    icon : {iconType: IconType.PIC, iconIndex: 2 },
    componentType: ComponentType.ClassComponent,
    sequence: 2,
    section: SectionComponent.NavBar,
    componentProps: { component: "Alerts" }
  },
  {
    id: 4,
    title: "Monitoring",
    componentIndex: 1,
    path: "/monitor",
    icon : {iconType: IconType.PIC, iconIndex: 3 },
    componentType: ComponentType.ClassComponent,
    sequence: 1,
    section: SectionComponent.NavBar,
    componentProps: { component: "Monitor" }
  },
  {
    id: 5,
    title: "Auditor's View",
    componentIndex: 4,
    path: "/auditorview",
    icon : {iconType: IconType.PIC, iconIndex: 4 },
    componentType: ComponentType.ClassComponent,
    section: SectionComponent.NavBar,
    sequence: 5,
    componentProps: { view: "Auditor", framework: { id: 2, name: "SOC2" } }
  },
  {
    id: 6,
    title: "FAQ",
    componentIndex: null,
    path: "",
    componentType: ComponentType.None,
    sequence: 8,
    section: SectionComponent.HelpSection
  },
  {
    id: 7,
    title: "AuditEngine",
    componentIndex: null,
    path: "",
    icon : {iconType: IconType.PIC, iconIndex: 5 },
    componentType: ComponentType.None,
    sequence: 3,
    section: SectionComponent.NavBar
  },
  {
    id: 8,
    title: "Evidence View",
    componentIndex: 2,
    path: "/evidence",
    icon : {iconType: IconType.PIC, iconIndex: 4 },
    componentType: ComponentType.ClassComponent,
    sequence: 1,
    section: SectionComponent.NavBar,
    componentProps: { view: "User" },
    parentid: 7
  },
  {
    id: 9,
    title: "Organization Details",
    componentIndex: 11,
    path: "/orgdetail",
    componentType: ComponentType.ClassComponent,
    sequence: 11,
    icon : {iconType: IconType.ICONS, iconIndex: 6 },
    section: SectionComponent.ProfileSection
  },
  {
    id: 10,
    title: "DocEngine",
    componentIndex: null,
    path: "",
    icon : {iconType: IconType.PIC, iconIndex: 5 },
    componentType: ComponentType.None,
    sequence: 5,
    section: SectionComponent.NavBar
  },
  {
    id: 11,
    title: "Settings",
    componentIndex: 12,
    path: "/orgsetting",
    componentType: ComponentType.ClassComponent,
    icon : {iconType: IconType.ICONS, iconIndex: 7 },
    sequence: 12,
    section: SectionComponent.ProfileSection
  },
  {
    id: 12,
    title: "Organizations",
    componentIndex: 5,
    path: "/orgs",
    icon : {iconType: IconType.PIC, iconIndex: 8 },
    componentType: ComponentType.ClassComponent,
    sequence: 8,
    section: SectionComponent.NavBar
  },
  {
    id: 13,
    title: "User Registration",
    componentIndex: 6,
    path: "/extuser",
    icon : {iconType: IconType.PIC, iconIndex: 9 },
    componentType: ComponentType.ClassComponent,
    sequence: 9,
    section: SectionComponent.NavBar
  },
  {
    id: 14,
    title: "GSuite Concent",
    componentIndex: 7,
    path: "/gsuiteconcent",
    componentType: ComponentType.FunctionalComponent,
    sequence: 0,
    section: SectionComponent.None
  },
  {
    id: 15,
    title: "GSuiteProcessConcent",
    componentIndex: 8,
    path: "/gsuiteprocess",
    componentType: ComponentType.ClassComponent,
    sequence: 0,
    section: SectionComponent.None
  },
  {
    id: 16,
    title: "Gitthub Concent",
    componentIndex: 9,
    path: "/gitconcent",
    componentType: ComponentType.FunctionalComponent,
    sequence: 0,
    section: SectionComponent.None
  },
  {
    id: 17,
    title: "GithubProcessConcent",
    componentIndex: 10,
    path: "/gitprocess",
    componentType: ComponentType.ClassComponent,
    sequence: 0,
    section: SectionComponent.None
  },
  {
    id: 18,
    title: "UserEngine",
    componentIndex: null,
    path: "",
    icon : {iconType: IconType.PIC, iconIndex: 10 },
    componentType: ComponentType.None,
    sequence: 6,
    section: SectionComponent.NavBar
  },
  {
    id: 19,
    title: "Policy Maker",
    componentIndex: 17,
    path: "/policymaker",
    icon : {iconType: IconType.PIC, iconIndex: 11 },
    componentType: ComponentType.ClassComponent,
    sequence: 1,
    section: SectionComponent.NavBar,
    parentid: 10
  },
  {
    id: 20,
    title: "Policy Approver",
    componentIndex: 14,
    path: "/policyapprover",
    icon : {iconType: IconType.PIC, iconIndex: 12 },
    componentType: ComponentType.ClassComponent,
    sequence: 2,
    section: SectionComponent.NavBar,
    parentid: 10
  },
  {
    id: 21,
    title: "Documentation",
    componentIndex: 19,
    path: "/Documentation",
    icon : {iconType: IconType.PIC, iconIndex: 13 },
    componentType: ComponentType.ClassComponent,
    sequence: 3,
    section: SectionComponent.NavBar,
    parentid: 10
  },
  {
    id: 22,
    title: "Policy Center",
    componentIndex: 13,
    path: "/policycenter",
    icon : {iconType: IconType.PIC, iconIndex: 14 },
    componentType: ComponentType.ClassComponent,
    sequence: 1,
    section: SectionComponent.NavBar,
    parentid: 18
  },
  {
    id: 23,
    title: "Training Module",
    componentIndex: null,
    path: "",
    icon : {iconType: IconType.PIC, iconIndex: 15 },
    componentType: ComponentType.None,
    sequence: 2,
    section: SectionComponent.NavBar,
    parentid: 18
  },
  {
    id: 24,
    title: "Tests",
    componentIndex: 16,
    path: "/quiz",
    icon : {iconType: IconType.ICONS , iconIndex: 16 },
    componentType: ComponentType.ClassComponent,
    sequence: 1,
    section: SectionComponent.NavBar,
    parentid: 23
  },
  {
    id: 25,
    title: "Test Page",
    componentIndex: 15,
    path: "/testpage",
    icon : {iconType: IconType.PIC, iconIndex: 15 },
    componentType: ComponentType.ClassComponent,
    sequence: 7,
    section: SectionComponent.NavBar
  },
]
