import { Component } from 'react';
import Tools from '../../Pages/SaasRegistration/Tools/Tools';
import OrgFramework from '../../Pages/Dashboard/OrgFramework';
import OrgAuditCompliances from '../../Pages/Audit/OrgAuditCompliances';
import ExternalUser from "../../Pages/Registrations/External/ExternalUser";
import GSUITEConcent from "../../Pages/SaasRegistration/Identity/GSUITE/GSUITEConcent";
import GSuiteProcessConcent from "../../Pages/SaasRegistration/Identity/GSUITE/ProcessConcent";
import GitConcent from "../../Pages/SaasRegistration/Version/GitHub/GitConcent";
import GitProcess from "../../Pages/SaasRegistration/Version/GitHub/GitProcess";
import OrgUsers from '../../Pages/Organization/OrgUsers';
import OrgList from '../../Pages/Organization/OrgList';
import OrgSetting from '../../Pages/Organization/OrgSettings/AdditionalSettings';
import PolicyCenter from '../../Pages/Application/PolicyCenter/PolicyCenter/PolicyCenter';
import PolicyApprover from '../../Pages/Application/PolicyCenter/PolicyApprover/PolicyApprover';
import ComplianceData from '../../Pages/Audit/ComplianceData';
import TestComponent from '../../Pages/Test/TestComponent';
import PolicyMaker from '../../Pages/Application/PolicyCenter/PolicyMaker/PolicyMaker';
import Quiz from '../../Pages/Quiz/Quiz';
import Documentation from '../../Pages/Application/Documentation/Documentation'
import SystemDescription from '../../Pages/Application/Documentation/SystemDescription';
export const PageComponents: { [key: number]: any } = {
    0: Tools,
    1: OrgFramework,
    2: OrgAuditCompliances,
    4: ComplianceData,
    5: OrgList,
    6: ExternalUser,
    7: GSUITEConcent,
    8: GSuiteProcessConcent,
    9: GitConcent,
    10: GitProcess,
    11: OrgUsers,
    12: OrgSetting,
    13: PolicyCenter,
    14: PolicyApprover,
    15: TestComponent,
    16: Quiz,
    17: PolicyMaker,
    19: Documentation
}