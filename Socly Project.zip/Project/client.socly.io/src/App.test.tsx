import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('1=1', () => {
  render(<App />);
  expect(1).toEqual(1);
});
// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });
