import { Component } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Pages/Authentication/Login';
import MainRoute from './Pages/Routes/MainRoute';

type AppState ={
  token:boolean
}

export class App extends Component<any,AppState> {
  constructor(props:any){
    super(props);
    this.state={token:false};
    console.log(process.env.REACT_APP_ENV, process.env.REACT_APP_API_URL, process.env.REACT_APP_NAME);
  }

  handleLoginSetToken(result:boolean):void{
    this.setState({token:result});
  }

  rendersubComponent(){
    if(!sessionStorage.getItem("accessToken")){
      return <Login setToken ={this.handleLoginSetToken.bind(this)} />
    }
    else{
      return <MainRoute />;
    }
  }

  render() {
    window.history.forward();  
    return (
      <div className="App">{this.rendersubComponent()}</div>
    )
  }
}
export default App