import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';

class AuditPeriodService extends APIBaseService {
    
    public async getActiveAuditPeriod(clientId : number) : Promise<IRestResponseEntity>{
        this.endPoint =`audit/audit_period/fetch?orgId=${clientId}`
        return this.restService.getMethod({
            data:null,
            endPoint : this.endPoint,
            setAuthentication : true
      });
    }
    
    public async updateAuditPeriod(data :any) : Promise<IRestResponseEntity>{
        this.endPoint="audit/audit_period/update";
        let response = await this.restService.putMethod({
            data : data,
            endPoint : this.endPoint,
            setAuthentication : true
        })
        if(response.status !==200){
            alert("Failed to save . Please try again !!");
        }
        return response;
    }

    public async insertAuditPeriod(data :any) : Promise<IRestResponseEntity>{
        this.endPoint="audit/audit_period/save";
        let response = await this.restService.postMethod({
            data : data,
            endPoint : this.endPoint,
            setAuthentication : true
        })
        if(response.status !==200){
            alert("Failed to save . Please try again !!");
        }
        return response;
    }
}

export default new AuditPeriodService();