import React, { Component } from 'react'
import APIBaseService from '../Base/APIBaseService';
import {APIData} from '../../Model/Organization/Org';

export class OrgDetailsService extends APIBaseService {

    public async registerOrgDetails(data : APIData[]) : Promise<number>{
        this.endPoint = "organization/update/details";
        let response = await this.restService.putMethod({
            endPoint : this.endPoint,
            data : data,
            setAuthentication : true
        });

        if(response.status !==200){
            alert("Failed , Please try again ");
        }
        return response.status;
    }

}

export default new OrgDetailsService();