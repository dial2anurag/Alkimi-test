import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';



class OrgSettingService extends APIBaseService {
    public constructor(){
        super();
    }

    public async getOrgSetting(framework : number, saas:string ):Promise<IRestResponseEntity>{
        this.endPoint = `saas/config/get?saasId=${saas}&frameworkId=${framework}`;
        return this.restService.getMethod({
            endPoint : this.endPoint,
            data:null,
            setAuthentication : true
        });
    }

    public async saveOrgSetting(payload:{dataarr:any[],frameworkid :number,saas :string}):Promise<number>{
        this.endPoint = `saas/config/save`;
        let response = await this.restService.postMethod({
            setAuthentication : true,
            endPoint : this.endPoint,
            data : payload.dataarr
        });
        if(response.status !=200){
            alert(`(${response.status}) ${response.message}`);
        }
        else{
            alert("Record Saved Successfully !!");
        }
        return response.status;
    }
}
export default new OrgSettingService();