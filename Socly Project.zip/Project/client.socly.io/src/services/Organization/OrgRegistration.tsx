import React from 'react';
import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';

export type OrgRegistrationEntity = {
    orgName: string,
    frameworkSubscribed: string[],
    description: string,
    name:string,
    email: string,
    phone: string
    //status: "ACTIVE" | "INACTIVE",
   // parentId :number | null
  };

export interface IOrgUserRegistration{
    username : string,
    password : string | "abc123",
    email: string,
    phone :string,
    name : string,
    businessTitle : string
}

class OrgRegistration extends APIBaseService {

    public async registerOrg(data : OrgRegistrationEntity) : Promise<number>{
        this.endPoint = "organization/register";
        let response = await this.restService.postMethod({
            endPoint : this.endPoint,
            data : data,
            setAuthentication : true
        });

        if(response.status !==200){
            alert("Failed , Please try again ");
        }
        return response.status;
    }

    public async getOrganization(status : "active" | "inactive" = "active"): Promise<IRestResponseEntity> {
        this.endPoint = "organization/all/on/status";
        if(status === "active"){
            this.endPoint =this.endPoint +  "?status=active";
        }
        else if(status === "inactive"){
            this.endPoint =this.endPoint +  "?status=inactive";
        }

        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true,
            data :null
        });
    }

    public async getRoles(orgview : boolean | null) : Promise<IRestResponseEntity> {
        this.endPoint = `role/get${orgview ? `?orgView=${orgview}` : ""}`;
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true,
            data :null
        });
    }
}

export default new OrgRegistration();
