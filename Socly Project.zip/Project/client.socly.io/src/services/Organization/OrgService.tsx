import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService' ; 
import AuthService from '../Users/auth.service'

class OrgService extends APIBaseService
{
    public async fetchOrgSaasProviders(orgName :string) : Promise<number>{
        this.endPoint = `active/saasintegrations?active=yes&orgName=${orgName}` ;
        let response = await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null  
        });
        if (response.status ===200){
            sessionStorage.setItem("saasProviders",JSON.stringify(response.data));
        }
        else{
            sessionStorage.setItem("saasProviders",JSON.stringify([]));
        }
        return response.status;
    }
    
    public getOrgSaasProviders(): any[]{
        //return sessionStorage.getItem("saasProviders") ? JSON.parse(sessionStorage.getItem("saasProviders") !) : null;
        let userProfile = AuthService.getCurrentUser();
        if(!userProfile){
            this.restService.logoff();
            return [];
        }
        return userProfile.organization.saasMasters;
    }

    public addSaasInOrgList(saas : string) : boolean{
        let saasList = this.getOrgSaasProviders();
        if(! saasList) saasList =[];
        if(! saasList.find(f=> f.saasId.toUpperCase() === saas.toUpperCase())){
            saasList.push({saasId : saas.toUpperCase()});
        }
        return true;
    }

    public async getOrgUsers(): Promise<IRestResponseEntity> {
        this.endPoint = "users/organization";
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true,
            data :null
        });
    }
}
export default new OrgService();