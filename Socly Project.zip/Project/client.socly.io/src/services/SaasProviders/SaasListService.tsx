import  {CloudProviderList} from '../../Data/SaasProviders/CloudProviders';
import  {HRToolList} from '../../Data/SaasProviders/HRTools';
import  {IdentityProviderList} from '../../Data/SaasProviders/IdentityProviders';
import  {OtherProviderList} from '../../Data/SaasProviders/OtherProviders';
import  {ProjectTrackingList} from '../../Data/SaasProviders/ProjectTrackings';
import  {VersionControlList} from '../../Data/SaasProviders/VersionControls';
import OrgService from '../Organization/OrgService';
import BaseService from '../Base/BaseService';
import { Saas } from '../../Model/SaasProvider/saasConfigurationEntity';
import BaseFrameworkSaasService from './BaseFrameworkSaasService';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';

class SaasListService extends BaseService {
    private static _saasList : Saas[];
    public constructor(){
        super();
        SaasListService._saasList =[];  
    }
    public getSaasList (): Saas[]{
        if(SaasListService._saasList && SaasListService._saasList.length>0){
            return SaasListService._saasList;
        }
        let saasList : Saas[]=[];
        CloudProviderList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });

        HRToolList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });

        IdentityProviderList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });

        ProjectTrackingList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });
        
        VersionControlList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });

        OtherProviderList.filter(e=> e.active===true).forEach((item)=>{
            saasList.push(item);
        });

        SaasListService._saasList = saasList;
        return saasList;
    }

    public getOrgRegisteredSaasList() : Saas[] {
        let saasList = this.getSaasList();
        let registeredsaasList = OrgService.getOrgSaasProviders();
        let resultlist : Saas [] =[];
        
        registeredsaasList.forEach(item=>{
            let saas = saasList.find(e=> e.key.toUpperCase() === item.saasId.toUpperCase());
            if(saas){
                resultlist.push(saas);
            }
        });
        return resultlist;
    }

    public getSaasItem(key: string) : Saas | undefined {
        let saasList = this.getSaasList();
        return saasList.find(e=> e.key.toUpperCase() === key.toUpperCase());
    }

    public getSaasService(key:string, framework : FrameworkEntity) : BaseFrameworkSaasService | null{
        let service : BaseFrameworkSaasService |  null =null;
        let saasitem = this.getSaasItem(key);
        if(saasitem && saasitem.classInstance){
            service=saasitem.classInstance.getBaseFrameworkSaasServiceInstance(framework);
        }
        return service;
    }
}
export default new SaasListService();
