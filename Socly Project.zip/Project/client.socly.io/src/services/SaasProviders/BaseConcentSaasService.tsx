import { IRestResponseEntity } from '../../Model/RestEntities';
import BaseSaasService from './BaseSaasService';


export default abstract class BaseConcentSaasService extends BaseSaasService{
    public constructor() {
        super();
    }
    public abstract override saveSecretKey(data: any): Promise<number> ;
    public abstract setConcent(data:any):  Promise<IRestResponseEntity>;
}