import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import { IComplianceSaasService } from '../../Model/SaasProvider/saasConfigurationEntity';
import APIBaseService from '../Base/APIBaseService';
import BaseFrameworkSaasService from './BaseFrameworkSaasService';

export default abstract class  BaseSaasService extends APIBaseService 
                               implements IComplianceSaasService
 {
    public constructor() {
        super();
    }
    public abstract saveSecretKey(data :any) :  Promise<number>;
    public abstract getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService;
}


