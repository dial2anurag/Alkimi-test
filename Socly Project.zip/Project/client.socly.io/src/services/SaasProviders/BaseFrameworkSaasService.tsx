import { IRestResponseEntity } from '../../Model/RestEntities';
import BaseFrameworkService from '../Framework/BaseFrameworkService';
import {FrameworkEntity} from '../../Model/Framework/FrameworkEntity';

export default abstract class BaseFrameworkSaasService extends BaseFrameworkService {
    public constructor(framework : FrameworkEntity) {
        super(framework);
    }
    public abstract getCompliances() : Promise<IRestResponseEntity>;
}