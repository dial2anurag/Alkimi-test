import React, { Component } from 'react';
import BaseService from '../Base/BaseService';


class LogService extends BaseService {
    public writelog(message: any): void {
        super.writelog(message);
    }
}
export default new LogService();
