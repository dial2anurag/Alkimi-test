import BaseService from '../Base/BaseService';

class FileIOService extends BaseService{

    public async readFileContent(file : Blob){
        return await file.text();
    }

    public async getContentfromFileStream(filestream: string,filename:string,filetype : string): Promise<string> {
        let bstr= atob(filestream);
        let n= bstr.length;
        let u8arr= new Uint8Array(n);
        while(n --){
            u8arr[n]= bstr.charCodeAt(n);
        }
        let file = new File([u8arr],filename,{type :filetype});
        let returnvalue = await file.text();
        return returnvalue;
    }

    public WritetoFile(fileName: string, content: string, filetype : string): File {
        let blob = new Blob([content], {type: filetype});
        let file = new File([blob], fileName, {type: filetype})
        return file;
    }

    // async writeFileContent (text : string,filename : string) : Blob {
    //     //fs.writeFile()
    //     return new Blob();
    // }
}

export default new FileIOService();

