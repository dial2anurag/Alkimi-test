import BaseService from '../Base/BaseService';
import jsPDF, { HTMLWorker }  from 'jspdf';
import {OrgDetailsEntity} from '../../Model/Organization/Org';

class RichTextEditorService extends BaseService {
    
    public htmlStringMainTagForPDF(content : string) : string{
      return `
      <html>
        <body>
          <div style='width: 600px;padding-left: 40px;padding-right:40px; padding-top : 30px; padding-bottom: 20px'>
            ${content}
          </div>
        </body>
      </html>`
    }

    public async generatePDFfromHTMLContent(htmlstring:string,pdffilename: string):Promise<void>{
      let doc = new jsPDF("p","pt","a4");
      let htmlworker=doc.html(htmlstring,{
        autoPaging: true,
        filename:pdffilename, 
        html2canvas : {
          allowTaint : true,
          async: false,
          foreignObjectRendering:true,
          imageTimeout :0,
          letterRendering:true,
          removeContainer:true,
          svgRendering:true,
          taintTest:true,
          useCORS :true
        }
      });
      await htmlworker.save(pdffilename);
  }

    public generatePDFFilefromHTMLContent(htmlContent:string, filename: string,callbackfn: (file:File)=>void):void {
      let doc = new jsPDF("p","pt","a4");
      let flname =`${filename}.pdf`;
      doc.html(htmlContent,{
        autoPaging: true,
        filename:flname, 
        html2canvas : {
          allowTaint : true,
          async: false,
          foreignObjectRendering:true,
          imageTimeout :0,
          letterRendering:true,
          removeContainer:true,
          svgRendering:true,
          taintTest:true,
          useCORS :true
        } , 
        callback : (pdfdoc)=>{
        let file = new File([pdfdoc.output("blob")],flname,{type:'application/pdf'});
        if(callbackfn) callbackfn(file);
      }})
    }
}

export default new RichTextEditorService();