import { DocumentSummeryEntity, OrgDetailsEntity } from '../../Model/Organization/Org';
import BaseService from '../Base/BaseService';

class HTMLService extends BaseService{

      public setDocHtmlFromDocTemplate (docTemplate : string,docType : string,data: DocumentSummeryEntity): string{
          let dt :Date;
          let createdOn:string="", approvedon : string ="";
          let createdby : string="", approvedby : string="";
          if(data.createdOn){
              dt = new Date(data.createdOn);
              createdOn = dt.toLocaleDateString('en-GB'); 
          }
          if(data.approvedOn){
              dt = new Date(data.approvedOn);
              approvedon = dt.toLocaleDateString('en-GB'); 
          }
          if(data.createdBy){
            createdby=data.createdBy;
          }
          if(data.approvedBy){
            approvedby =data.approvedBy;
          }
          if(!data.versionno) data.versionno="1.0";

          let htmlElement = this.getHTMLElement(docTemplate);
          this.setHtmlElement(htmlElement,"versionno",data.versionno );
          this.setHtmlElement(htmlElement,"doctype",docType);
          this.setHtmlElement(htmlElement,"author",createdby);
          this.setHtmlElement(htmlElement,"creationdate",createdOn);
          this.setHtmlElement(htmlElement,"reviewedby",approvedby);
          this.setHtmlElement(htmlElement,"releasedate",approvedon);
          return htmlElement.outerHTML;
      }

      public setOrgHtmlFromOrgTemplate(title : string, orgtemplate : string , orgdata : OrgDetailsEntity) : string{
        let htmlElement = this.getHTMLElement(orgtemplate);
        //Set Logo Image
        let collection = htmlElement.getElementsByClassName("orgLogo");
        Array.prototype.forEach.call(collection , (logo,index)=>{
          logo.src= orgdata.logo;
          logo.alt=orgdata.orgName
        });
        this.setHtmlElement(htmlElement,"orgName",orgdata.orgName);
        this.setHtmlElement(htmlElement,"orgAddress",`${orgdata.Address1} ${orgdata.Address2}`);
        this.setHtmlElement(htmlElement,"orgCity",orgdata.city);
        this.setHtmlElement(htmlElement,"orgState",orgdata.state);
        this.setHtmlElement(htmlElement,"orgPincode",orgdata.pincode);
        this.setHtmlElement(htmlElement,"orgPhone",orgdata.phone);
        this.setHtmlElement(htmlElement,"orgWebsite",orgdata.website);
        this.setHtmlElement(htmlElement,"orgEmail",orgdata.email);
        this.setHtmlElement(htmlElement,"policyTitle",title);
        return htmlElement.outerHTML;
      }

      public getHTMLElement(htmlcontent:string) :HTMLElement{
        let htmlElement : HTMLElement=document.createElement("div")
        htmlElement.innerHTML=htmlcontent;
        return htmlElement;
      }

    public setHtmlElement(htmlElement :HTMLElement ,htmlClassname : string, value : string):HTMLElement{
        let collection = htmlElement.getElementsByClassName(htmlClassname);
        Array.prototype.forEach.call(collection , (element,index)=>{
          element.innerHTML = value;
        });
        return htmlElement; 
      }
}

export default new HTMLService();