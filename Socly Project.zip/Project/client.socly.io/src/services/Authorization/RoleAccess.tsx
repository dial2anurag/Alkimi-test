import React, { Component } from 'react'
import { IPageComponent, IRoleAuth , IBaseRoleAuth, IRolePageComponent } from '../../Model/SysModal/sysEntiry';
import {AuthRoles} from '../../Data/SysData/roleAuth';
import {pageComponents} from '../../Data/SysData/pages';
import BaseService from '../Base/BaseService';
import AuthService from '../Users/auth.service'

class RoleAccessService extends BaseService {
    public getComponentsForUser() : IRolePageComponent[] {
        let roledata =AuthService.getUserAuthMenu(); 
        let localpageComponents : IRolePageComponent [];
        if(!roledata)
        {
          localpageComponents=[];
          let userProfile = AuthService.getCurrentUser();
          let localpageComponent  : IRolePageComponent | undefined ;
          let pageComponent  : IPageComponent ;
          let roleAuth : IRoleAuth | undefined  ;
          let baseroleAuth : IBaseRoleAuth;
          if(userProfile){
              Array.prototype.forEach.call(userProfile.roles,(role :any,index: number)=>{
                roleAuth = AuthRoles.find(e=> e.role.toLowerCase() === role.name.toLowerCase());
                if(roleAuth){
                  baseroleAuth ={defaultpage : roleAuth.defaultpage , role :  roleAuth.role};
                  roleAuth.pages.forEach((e)=>{
                    localpageComponent = localpageComponents.find(x=> x.id === e.pageid);
                    if(localpageComponent){
                        if(e.accessdata.accessType > localpageComponent.accessdata.accessType){
                            localpageComponent.accessdata = e.accessdata;
                            localpageComponent.roleData=baseroleAuth;
                        }
                    }
                    else{
                          pageComponent = pageComponents.find(z=> z.id === e.pageid)!;
                          if(pageComponent){
                              localpageComponent={ 
                                  id : pageComponent.id ,
                                  title :pageComponent.title,
                                  sequence :pageComponent.sequence,
                                  section : pageComponent.section,
                                  componentType :pageComponent.componentType,
                                  path : pageComponent.path,
                                  componentIndex : pageComponent.componentIndex,
                                  icon : pageComponent.icon,
                                  parentid :pageComponent.parentid,
                                  componentProps : pageComponent.componentProps,
                                  accessdata : e.accessdata,
                                  roleData : baseroleAuth
                                }
                            localpageComponents.push(localpageComponent);
                          }
                    }
                  })
                }
              })
              AuthService.setUserAuthMenu(localpageComponents);
            }
        }
        else{
          localpageComponents =roledata;    
        }
        return localpageComponents;
    }
}
export default new RoleAccessService();