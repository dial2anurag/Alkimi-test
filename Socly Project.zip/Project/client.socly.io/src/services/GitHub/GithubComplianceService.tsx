import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import BaseFrameworkSaas from '../SaasProviders/BaseFrameworkSaasService'
export default class GithubComplianceService extends BaseFrameworkSaas{
    public constructor(framework : FrameworkEntity){
        super(framework)
    }

    public override async getCompliances(): Promise<IRestResponseEntity> {
        this.endPoint = `api/v1/scm/${this.framework.name.toLowerCase()}/github/all`;
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null    
        })
    }
}

