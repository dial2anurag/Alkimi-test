import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import {IRestResponseEntity } from '../../Model/RestEntities';
import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import BaseSaasService from '../SaasProviders/BaseSaasService';
import GithubComplianceService from './GithubComplianceService';

class GithubSecretService extends BaseSaasService {
    public constructor(){
        super();
    }

    public override async saveSecretKey(data: any): Promise<number> {
        this.endPoint = `api/v2.0/github/credentials${data.params}`;
        var responseCode = -1;
        let response =await this.restService.postMethod({
            endPoint : this.endPoint, 
            setAuthentication : true,
            data :data.secret
        });
        if(response.status === 200){
            responseCode = response.status;
        }
        else{
            responseCode = response.status;
            alert("Invalid secret key! Please enter valid information");
        }
        return responseCode;
    }

    public override getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService {
        return new GithubComplianceService(framework);   
    }
}
export default new GithubSecretService();
