import APIBaseService from '../Base/APIBaseService' ;  
import  UsersServices from './Users';
import {IRolePageComponent} from '../../Model/SysModal/sysEntiry';
import {AxiosRequestConfig, AxiosRequestHeaders} from "axios";

class AuthService extends APIBaseService {
  public async login(username:string,password:string) : Promise<[number,any]>{
    this.endPoint = "users/authenticate";
    let loginData : any ={};
    let user : any= {
      username: username,
      password: password
    }
    let responseCode = -1;
    let profile : any = {};
    let axiosConfig : AxiosRequestConfig ={};
    let axiosheader : AxiosRequestHeaders ={}
    let uniqueid= `${this.endPoint.replaceAll("/","_")}_${username}`;
    axiosheader["x-api-key"] = uniqueid;
    axiosConfig.headers = axiosheader;

    let response = await this.restService.postMethod({
       endPoint : this.endPoint,
       data:user,
       axiosConfig : axiosConfig,
       setAuthentication : false});
    
       if(response.status === 200 && response.data.token ){
        loginData = response.data;
        sessionStorage.setItem("accessToken", loginData.token);
          let profileresponse = await UsersServices.getUserProfile(username)
          if(profileresponse.status === 200 ){
            profile = profileresponse.data;
            if(! profileresponse.data.passwordChanged) // Check If Password needs to be changed
            {
              sessionStorage.removeItem("accessToken"); 
              responseCode = -5;
              return [responseCode,{profile : profile , token : loginData.token }];
            }
            sessionStorage.setItem("userProfile",JSON.stringify( profile));
            //await OrgService.fetchOrgSaasProviders(profileresponse.data.organizationName);
            responseCode = profileresponse.status;
          }
          else{
            responseCode = profileresponse.status * -1;
            alert("Invalid Username or Password! Please try again");
          }
       }
       else{
        responseCode =response.status ;
        alert("Invalid Username or Password! Please try again");
       }
   return [responseCode,profile];
  }

  logout =() : boolean=>  this.restService.logoff();
  
  cleanSession =() :boolean => this.restService.cleanSession();
  

  getCurrentUser() {
      return sessionStorage.getItem("userProfile") ? JSON.parse(sessionStorage.getItem("userProfile") !) : null;
    }
  
  setUserAuthMenu(data : IRolePageComponent[]){
    sessionStorage.setItem("userAuthMenu",JSON.stringify( data));
  }

  getUserAuthMenu() : IRolePageComponent[] | null{
      if(! sessionStorage.getItem("userAuthMenu")){
        return null;
      }
      let roleAccess : IRolePageComponent [] = JSON.parse(sessionStorage.getItem("userAuthMenu") !);
      return roleAccess;
  }
}
export default new AuthService();
