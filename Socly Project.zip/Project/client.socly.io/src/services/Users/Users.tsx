import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import APIBaseService from '../Base/APIBaseService';

export interface IUserRegistration4Org {
    email: string,
    phone: string,
    name: string,
    businessTitle: string
}

export interface IUserRegistration extends IUserRegistration4Org {
    organizationName: string,
    username: string,
    password: string,
}


class UserService extends APIBaseService {
    public async getUserProfile(username: string) {
        this.endPoint = "users/data";
        let axiosConfig: AxiosRequestConfig = {};
        let axiosheader: AxiosRequestHeaders = {}
        let uniqueid = `${this.endPoint.replaceAll("/", "_")}_${username}`;
        axiosheader["x-api-key"] = uniqueid;
        axiosConfig.headers = axiosheader;

        return this.restService.getMethod({
            endPoint: this.endPoint,
            data: null,
            axiosConfig: axiosConfig,
            setAuthentication: true
        })
    }

    public async forgotPassword(data: any) {
        this.endPoint = "forgotpassword/send-otp";

        return await this.restService.postMethod({
            endPoint: this.endPoint,
            data: data,
            setAuthentication: true
        });
    }
    public async verifyotp(data: any): Promise<Number> {
        this.endPoint = "forgotpassword/verify-otp";

        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            data: data,
            setAuthentication: true
        });

        if (response.status === 200) {
            alert("password sent to registered e-mail address");
        }
        else {
            alert("please enter valid otp");
        }
        return response.status;
    }

    public async changePasswordWithoutAuth(data: any, userData: any): Promise<number> {
        this.endPoint = "users/change/password";
        let responseCode: number = -1;
        let axiosheader: AxiosRequestHeaders = {};
        let axiosConfig: AxiosRequestConfig = {};
        axiosheader["Access-Control-Allow-Credentials"] = 'true';
        axiosheader["Authorization"] = "Bearer ".concat(userData.token);
        let uniqueid = `${this.endPoint.replaceAll("/", "_")}_${userData.userProfile.username}`;
        axiosheader["x-api-key"] = uniqueid;
        axiosConfig.headers = axiosheader;

        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            setAuthentication: false,
            axiosConfig: axiosConfig,
            data: data
        });
        responseCode = response.status;
        if (response.status !== 200) {
            alert(response.message || "Issue with Password Change . Please try again!!");
        }
        return responseCode;
    }

    public async changePassword(data: any): Promise<number> {
        this.endPoint = "users/change/password";
        let responseCode: number = -1;
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data
        });
        responseCode = response.status;
        if (response.status !== 200) {
            alert(response.message || "Issue with Password Change . Please try again!!");
        }
        return responseCode;
    }

    public async registerUser(data: IUserRegistration): Promise<number> {
        this.endPoint = "users/register";
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            data: data,
            setAuthentication: true
        });

        if (response.status !== 200) {
            alert("Failed , Please try again ");
        }
        return response.status;
    }

    public async registerUser4Org(data: IUserRegistration4Org): Promise<number> {
        this.endPoint = "users/adminRegisteredUser";
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            data: data,
            setAuthentication: true
        });

        if (response.status !== 200) {
            alert("Failed , Please try again ");
        }
        return response.status;
    }

    public async updateUser(data: any): Promise<number> {
        this.endPoint = "users/update";
        let response = await this.restService.putMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data
        });
        if (response.status !== 200) {
            alert(`Unable to update  ${response.message}`);
        }
        return response.status;
    }


}
export default new UserService();