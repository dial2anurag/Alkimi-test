import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import BaseFrameworkSaas from '../SaasProviders/BaseFrameworkSaasService'

export default class GsuiteComplianceService extends BaseFrameworkSaas{
    public constructor(framework : FrameworkEntity){
        super(framework)
    }
    public override async getCompliances(){
        this.endPoint = `api/v1/${this.framework.name.toLowerCase()}/gsuite/data`;
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null   
        });
    }
}