import { IRestResponseEntity } from '../../Model/RestEntities';
import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import BaseConcentSaasService from '../SaasProviders/BaseConcentSaasService';
import ExternalAPIService from '../Server/ExternalAPIService';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import GsuiteComplianceService from './GsuiteComplianceService';
import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';

class GsuiteSecretService  extends BaseConcentSaasService{
    public constructor(){
        super();
    }

    public async getToken(queryParams : URLSearchParams) : Promise<IRestResponseEntity>{
        let currentHost =`${window.location.protocol}//${window.location.host}`;
        let redirectUrl=`${currentHost}/gsuiteconcent`
        if(!sessionStorage.getItem("GSuitSecrets")){
            return {
                data :null ,
                message : "invalid Secret Data . Please try again",
                status :-1
            };
        }
        let filedata = JSON.parse(sessionStorage.getItem("GSuitSecrets")!);
        let data ={
            grant_type :"authorization_code",
            code : queryParams.get("code")!.toString(),
            client_id : filedata.web.client_id,
            client_secret : filedata.web.client_secret,
            redirect_uri : redirectUrl
        }
        let externalRestCall : ExternalAPIService = new ExternalAPIService(process.env.REACT_APP_GSUITE_URL!);
        let response = await externalRestCall.postMethod({
            endPoint : "/o/oauth2/token",
            data : data,
            setAuthentication :false
        });
        if(response.status !==200){
            return response;
        }
        let returnval= await this.setConcent({state : queryParams.get("state")!.toString() , data : response.data});
        sessionStorage.removeItem("GSuitSecrets");
        return returnval;
    }

    public override async saveSecretKey(data:any) : Promise<number>{
        this.endPoint = "client/gsuite/uploadCredentials";
        let msg :string;
        var responseCode = -3;
        let axiosheader : AxiosRequestHeaders ={} ;
        let axiosConfig : AxiosRequestConfig = {};
        axiosheader["Content-Type"] = "multipart/form-data";
        axiosConfig.headers = axiosheader;
        let response = await this.restService.postMethod({
            setAuthentication : true,
            endPoint : this.endPoint,
            data : data,
            axiosConfig :axiosConfig
        });
        responseCode = response.status;
        if( response.status !== 200){
            alert("Invalid secret key! Please enter valid information");
        }
        return responseCode;
    }

    public override async setConcent(data :{state:string,data : any}) : Promise<IRestResponseEntity>{
        this.endPoint = `gsuite/data?state=${data.state}`;
        let response = await this.restService.postMethod({
            setAuthentication : true,
            endPoint : this.endPoint,
            data : data.data
        });
        return response;
    }

    public override getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService {
        return new GsuiteComplianceService(framework);   
    }
}
export default new GsuiteSecretService();
