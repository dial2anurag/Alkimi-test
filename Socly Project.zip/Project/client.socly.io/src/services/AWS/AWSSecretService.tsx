import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import BaseSaasService from '../SaasProviders/BaseSaasService';
import AWSComplianceService from './AWSComplianceService';
class AWSSecretService extends BaseSaasService {
    public override async saveSecretKey(data: any): Promise<number> {
        this.endPoint = "aws/credentials" ;
        var responseCode = -1;
        let response = await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true,
            data :data
        });
        
        responseCode = response.status;
        if(response.status === 200){
                alert("Record Saved!");
        }
        else{
            alert("Invalid secret key! Please enter valid information");
        }
        return responseCode;
    }
    
    public override getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService {
        return new AWSComplianceService(framework);   
    }
}
export default new AWSSecretService();