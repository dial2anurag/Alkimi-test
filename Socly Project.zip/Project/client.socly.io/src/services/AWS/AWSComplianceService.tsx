import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';


export default class AWSComplianceService extends BaseFrameworkSaasService  {
    public constructor(framework : FrameworkEntity){
        super(framework);
    }
    
    public override async getCompliances(): Promise<IRestResponseEntity> {
        this.endPoint = `aws/${this.framework.name.toLowerCase()}/compliance`;
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null    
        })
    }
}

