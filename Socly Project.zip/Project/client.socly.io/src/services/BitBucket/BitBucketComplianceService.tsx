import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';

export default class BitBucketComplianceService extends BaseFrameworkSaasService  {
    public constructor(framework : FrameworkEntity){
        super(framework);
    }

    public override async getCompliances(): Promise<IRestResponseEntity> {
        this.endPoint = `api/v1/scm/${this.framework.name.toLowerCase()}/bitbucket/all`;
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null  
        })
    }
}