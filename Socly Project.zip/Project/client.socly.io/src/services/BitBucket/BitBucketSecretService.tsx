import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import BaseSaasService from '../SaasProviders/BaseSaasService';
import BitBucketComplianceService from './BitBucketComplianceService';

class BitBucketSecretService extends BaseSaasService {
    public constructor(){
        super();
    }

    public override async saveSecretKey(data: any): Promise<number> {
        this.endPoint = "api/v1/scm/bitbucket/credentials" ;

        var responseCode = -1;
        let response = await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true,
            data :data
        });
        responseCode = response.status;
        if(response.status === 200){
                alert("Record Saved!");
        }
        else{
            alert("Invalid secret key! Please enter valid information");
        }

        return responseCode;
    }

    public override getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService {
        return new BitBucketComplianceService(framework);   
    }
}
export default new BitBucketSecretService();
