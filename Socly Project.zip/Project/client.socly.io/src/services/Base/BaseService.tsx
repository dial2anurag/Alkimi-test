export default abstract class BaseService 
{
    protected  writelog(message :any /* JSON Parsed enabled objects */):void
    {
        let logmessage : string="";
        if(typeof message === "string"  ||  typeof message ==="boolean" 
        || typeof message === "bigint"){
            logmessage = message.toString();
        }
        else{
            try {
                logmessage = JSON.stringify(message);
            } catch (error) {
                logmessage="";
            }   
        }
        /*  */
    }

    public deepCopy<T>(obj: T) : T | undefined{
        let strobj : string;
        try{
            strobj= JSON.stringify(obj);
            return JSON.parse(strobj);
        }
        catch{
            return undefined;
        }
    }
}
