import APIService from '../Server/APIService' ;
import BaseService from './BaseService'

export default abstract class APIBaseService extends BaseService {
    private _endPoint : string;
    private _restService : APIService ;
    public constructor(){
        super();
        this._endPoint="";
        this._restService = new APIService();
    }
    public get endPoint() {return this._endPoint ;}
    public set endPoint(value :string) {this._endPoint = value;}

    public get restService() {return this._restService ;}
}