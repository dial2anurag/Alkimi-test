import {FrameworkEntity} from '../../Model/Framework/FrameworkEntity';
import APIBaseService from '../Base/APIBaseService';

export default abstract class BaseFrameworkService extends APIBaseService{
    private readonly _framework : FrameworkEntity
    public constructor(framework : FrameworkEntity) {
        super();
        this._framework =  framework;
    }
    public get framework() {return this._framework ;}
}
