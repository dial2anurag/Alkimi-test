import BaseService from '../Base/BaseService';
import {FrameworkEntity} from '../../Model/Framework/FrameworkEntity'
import AuthService from '../Users/auth.service';

class UserFrameworkService extends BaseService{
    private static _selectedframework : FrameworkEntity;
    private static _orgframeworks : FrameworkEntity[];
    public constructor(){
        super();
   }

    public loadData() : FrameworkEntity{
        let userProfile =AuthService.getCurrentUser();
        if(! userProfile){
            AuthService.logout();
        }

        if( ! UserFrameworkService._orgframeworks 
            || UserFrameworkService._orgframeworks.length <=0){
            UserFrameworkService._orgframeworks =[];
            let orgframeworks : FrameworkEntity [] = [];
            Array.prototype.map.call(userProfile.organization.frameworks,(framework,index)=>{
                orgframeworks.push({id:framework.id,name:framework.name.toUpperCase()});
            });

            if(orgframeworks.length <= 0){
                alert("No Framework registered !!");
                AuthService.logout();
            }

            UserFrameworkService._orgframeworks = orgframeworks.sort((a,b)=> a.id - b.id);
            if(! UserFrameworkService._selectedframework && UserFrameworkService._orgframeworks.length >0){
                UserFrameworkService._selectedframework = UserFrameworkService._orgframeworks[0]; 
            }
        }
        if(!UserFrameworkService._selectedframework){
            AuthService.logout();
        }
        return UserFrameworkService._selectedframework ;
    }

    public get SelectedFramework (): FrameworkEntity{
        return UserFrameworkService._selectedframework;
    }

    public set SelectedFramework(value : FrameworkEntity){
        UserFrameworkService._selectedframework = value;
    }

    public get OrgFramwork():FrameworkEntity[]{
        return UserFrameworkService._orgframeworks;
    }

    public getFramework(id:number) : FrameworkEntity{
        return UserFrameworkService._orgframeworks.find(e=> e.id === id)!;
    }

    public setFramework(id:number): FrameworkEntity{
        let framwork =UserFrameworkService._orgframeworks.find(e=> e.id === id); 
        if(!framwork){
            AuthService.logout();
        }
        UserFrameworkService._selectedframework=framwork!;
        return framwork!;
    }
}
export default new UserFrameworkService();
