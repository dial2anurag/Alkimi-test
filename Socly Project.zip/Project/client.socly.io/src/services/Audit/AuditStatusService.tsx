import BaseService from '../Base/BaseService'
export enum AuditFlag {
    NotYetEvaluate =0,
    Approved =1 ,
    Rejected=2
}

class AuditServiceService extends BaseService {
    public getAuditFlag(value : string | null) : AuditFlag{
        switch(value){
            case "A" : {
                return AuditFlag.Approved ;
                break;
            }
            case "R" : {
                return AuditFlag.Rejected;
                break;
            }
            default : {
                return  AuditFlag.NotYetEvaluate;
                break;

            }
        }
    }

    public getAuditStatusValue(auditFlag : AuditFlag) : string{
        switch(auditFlag){
            case AuditFlag.Approved : {
                return "A" ;
                break;
            }
            case AuditFlag.Rejected : {
                return "R";
                break;
            }
            case AuditFlag.NotYetEvaluate :{
                return "N";
                break;
            }
        }
    }
}

export default new AuditServiceService();