import APIBaseService from '../Base/APIBaseService';

class ComplianceService extends APIBaseService {
    public constructor(){
        super();
    }

    public async GetCompliancesForPrincipal(principalId :number){
        this.endPoint = `principles/complianceinfo/${principalId}`;
        return this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null
        });
    }

    public async SaveAuditCompliance(data : any) : Promise<number>{
        this.endPoint = "audit/compliance";
        let responseCode : number = -1;
        let response =await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :data
        });
        responseCode = response.status;
        if(response.status !==200){
            alert(`Unable to save the Compliance  ${response.message}`);
        }
        return responseCode;
    }
}
export default new ComplianceService();