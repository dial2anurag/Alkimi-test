import APIBaseService from '../Base/APIBaseService';
import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';

class FileService extends APIBaseService {
    public constructor(){
        super();
    }

    public async DownloadEvidanceFile(framework : FrameworkEntity ,  fileName : string){
        //this.endPoint =`file/download?filename=${fileName}`;
        this.endPoint =`file/${framework.name.toLowerCase()}/download?filename=${fileName}`;
        let axiosConfig : AxiosRequestConfig = {
            responseType :'blob'
        }
        return this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null ,
            axiosConfig :  axiosConfig 
        });
    }

    public async GetComplianceFiles(complianceid :string, principalid : number){
        this.endPoint =`file/list?complianceId=${complianceid}&principleId=${principalid}`
        return this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null
        });
    }

    public async SaveAuditFile(data : any) : Promise<number>{
        this.endPoint = "audit/file_approval/save";
        let responseCode : number = -1;
        let response =await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :data
        });
        responseCode = response.status;
        if(response.status !==200){
            alert(`Unable to save the file  ${response.message}`);
        }
        
        return responseCode;
    }

}
export default new FileService();
