import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';

class PrincipalService extends APIBaseService {
    public constructor(){
        super();
    }

    public async GetPrincipals(framework : FrameworkEntity){
        this.endPoint = `principles/active/on/framework/${framework.name}`;
        return this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null
        });
    }

    public async SaveAuditPrincipal(data : any) : Promise<IRestResponseEntity>{
        this.endPoint = "audit/principle";
        let response =await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :data
        });
        if(response.status !==200){
            alert(`Unable to save the Principal  ${response.message}`);
        }
        return response;
    }

    public async GetPrincipalByCompliance(complianceid :string){
        this.endPoint =`principles/active/${complianceid}`
        return  this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null
        });
    }
}

export default new PrincipalService();