import {AxiosRequestConfig, AxiosRequestHeaders, AxiosResponse} from "axios";
import {IRestResponseEntity , IRestRequestEntity } from '../../Model/RestEntities';
import BaseService from '../Base/BaseService';

export default abstract class RestConfiguration extends BaseService {
    protected readonly _apiUrl :string;
    public constructor(apiUrl : string){
        super();
        this._apiUrl = apiUrl;
    }

     /* Optional override method */
     protected setAxiosConfiguration ? (request : IRestRequestEntity,currentconfig : AxiosRequestConfig)  : AxiosRequestConfig ;
     protected setAdditionalAxiosHeaders ? (request : IRestRequestEntity, currentheader : AxiosRequestHeaders)  : AxiosRequestHeaders ;
     protected setAdditionalResponse ? (request : IRestRequestEntity , response : IRestResponseEntity) : IRestResponseEntity ;
 

    /* concatinate endpoint with API url */
    protected getUrl (endPoint : string) : string {
        return `${this._apiUrl}${endPoint}`; 
    }

    /* set  Axios Configuration */
    protected setAxiosConfig (request : IRestRequestEntity) : AxiosRequestConfig{
        let headers =this.setAxiosHeaders(request);
        if(!request.axiosConfig){
            request.axiosConfig ={};
        }
        request.axiosConfig.headers =headers;
        if(this.setAxiosConfiguration) {
            request.axiosConfig=this.setAxiosConfiguration(request, request.axiosConfig);
        }
        return request.axiosConfig;
    }

    /* get X-API-Key for each request */
    private getXAPIKey (request : IRestRequestEntity ) :string | null{
        if(!sessionStorage.getItem("userProfile")) return null;
        let userProfile= JSON.parse(sessionStorage.getItem("userProfile")!)
        let arr = request.endPoint.replaceAll("/","_") .split('?');
        let xapikey=`${arr[0]}_${userProfile.username}`;
        return xapikey;
    }

    
     /* set  Axios Header Configuration */
    protected setAxiosHeaders(request : IRestRequestEntity ) {
        let axiosheader : AxiosRequestHeaders ={} ;
        if (! request.axiosConfig || ! request.axiosConfig.headers ){
            axiosheader = {};
        }
        else{
            axiosheader = request.axiosConfig.headers;
        }

        if(! axiosheader["Content-Type"]){
            axiosheader["Content-Type"] = 'application/json'; //;
        }
        if( request.setAuthentication){
            axiosheader["Access-Control-Allow-Credentials"] = 'true';
            if(! axiosheader["x-api-key"] && sessionStorage.getItem("userProfile")){
                let xapikey=this.getXAPIKey(request);
                if(xapikey){
                    axiosheader["x-api-key"] = xapikey ;
                }
            }
        }
        
        if(this.setAdditionalAxiosHeaders){
            axiosheader=this.setAdditionalAxiosHeaders(request,axiosheader);
        }

        return axiosheader;
    }
    /* set Axios Response to IRestResponseEntity */
    protected async getRestResponse (axiosResponse : Promise<AxiosResponse<any>>, request: IRestRequestEntity) :Promise<IRestResponseEntity>{
        let restResponse : IRestResponseEntity={
            data :null,
            status:-1,
            message :""
        };
        await axiosResponse.then((response) => {
           restResponse = {
               data : response.data,
               status : response.status,
               message : response.statusText
           }
        }).catch((error) => {
            console.error(error);
            let status  : number;
            let message : string ;
            if (error.response) {
                status = error.response.status;
                message = `${error.response.data.error}-${error.response.data.message}(${error.response.status})`
            } 
            else {
                message = error.message
                status = -2
            }

            restResponse = {
                data :error,
                status: status,
                message:`(${status}) ${message}`
            }
        });

        if(this.setAdditionalResponse){
            restResponse = this.setAdditionalResponse(request,restResponse);
        }

        return restResponse;
    }
}
