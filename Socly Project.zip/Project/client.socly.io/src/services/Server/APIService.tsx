import { IRestRequestEntity, IRestResponseEntity } from '../../Model/RestEntities';
import { AxiosRequestHeaders} from 'axios';
import RestCallService from './RestCallService';

export default class APIService extends RestCallService{
    public constructor(){
        super(process.env.REACT_APP_API_URL!);
    }

    override setAdditionalAxiosHeaders(request : IRestRequestEntity , currentheader : AxiosRequestHeaders)  : AxiosRequestHeaders{
        if(request.setAuthentication && sessionStorage.getItem("accessToken")){
            currentheader["Authorization"] ="Bearer ".concat(sessionStorage.getItem("accessToken")!);
        }
        return currentheader;
    }

    override setAdditionalResponse(request : IRestRequestEntity , response : IRestResponseEntity) : IRestResponseEntity{
        if( request.setAuthentication && response.status=== 401 ){ // UnAuthorize
            this.cleanSession();
            alert("Unauthorize user .Please login again");
            window.location.href = '/';
        }
        return response;
    }

    public cleanSession() : boolean{
        if(sessionStorage.getItem("accessToken")) sessionStorage.removeItem("accessToken");
        if(sessionStorage.getItem("userProfile"))sessionStorage.removeItem("userProfile");
        if(sessionStorage.getItem("saasProviders"))sessionStorage.removeItem("saasProviders");
        if(sessionStorage.getItem("userAuthMenu")) sessionStorage.removeItem("userAuthMenu");
        return true
    }

    public logoff() : boolean {
        this.cleanSession();
        window.location.href = '/';
        return true
    }
}
