import { IRestRequestEntity, IRestResponseEntity } from '../../Model/RestEntities';
import Axios from 'axios';
import RestCallService from './RestCallService';

export default class ExternalAPIService extends RestCallService {
    public constructor(apiUrl : string){
        super(apiUrl);
    }
}
