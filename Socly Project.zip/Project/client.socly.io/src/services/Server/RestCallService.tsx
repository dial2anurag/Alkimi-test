import Axios , {AxiosRequestConfig, AxiosRequestHeaders, AxiosResponse} from "axios";
import {IRestResponseEntity , IRestRequestEntity } from '../../Model/RestEntities';
import RestConfiguration from './RestConfiguration';

export default abstract class RestCallService extends RestConfiguration {
    public constructor(apiUrl : string){
        super(apiUrl);
    }

    /* Optional override method */
    protected override setAxiosConfiguration ? (request : IRestRequestEntity,currentconfig : AxiosRequestConfig)  : AxiosRequestConfig ;
    protected override setAdditionalAxiosHeaders ? (request : IRestRequestEntity, currentheader : AxiosRequestHeaders)  : AxiosRequestHeaders ;
    protected override setAdditionalResponse ? (request : IRestRequestEntity , response : IRestResponseEntity) : IRestResponseEntity ;

    /* public methods */

    public async getMethod(request :IRestRequestEntity) : Promise<IRestResponseEntity>{
        return await this.getRestResponse(
            Axios.get(this.getUrl(request.endPoint) ,
            this.setAxiosConfig(request)
            ),request);
    }

    public async postMethod(request: IRestRequestEntity): Promise<IRestResponseEntity> {
        return await this.getRestResponse(
            Axios.post(this.getUrl(request.endPoint) ,
            request.data,
            this.setAxiosConfig(request)
            ),request);
    }

    public async putMethod(request: IRestRequestEntity): Promise<IRestResponseEntity> {
        return await this.getRestResponse(
            Axios.put(this.getUrl(request.endPoint) ,
            request.data,
            this.setAxiosConfig(request)
            ),request);
    }

    public async deleteMethod(request: IRestRequestEntity): Promise<IRestResponseEntity> {
        return await this.getRestResponse(
            Axios.delete(this.getUrl(request.endPoint),
            this.setAxiosConfig(request)
            ),request);
    }
}
