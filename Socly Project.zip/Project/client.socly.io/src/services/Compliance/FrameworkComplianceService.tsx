import BaseService from '../Base/BaseService';
import { IComplianceData } from '../../Model/Compliance/ComplianceEntity';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import ComplianceService from './ComplianceService';

export const PRODUCTION = "PRODUCTION";

class FrameworkComplianceService extends BaseService{
    private static _complianceService :{[key : number]: ComplianceService}
    public constructor(){
        super();
        FrameworkComplianceService._complianceService={};
    }

    private getComplianceService(framework : FrameworkEntity) : ComplianceService{
        if(! FrameworkComplianceService._complianceService[framework.id]){
            FrameworkComplianceService._complianceService[framework.id]=new ComplianceService(framework);
        }
        return FrameworkComplianceService._complianceService[framework.id];
    }
    
    public async getCompliances(framework :FrameworkEntity) : Promise< [string[],string[],IComplianceData[]]>{
        let complianceService = this.getComplianceService(framework);
        return await complianceService.GetOrgCompliance();
    }
    
    // public getServicesExists(framework : FrameworkEntity) : SaasReturnType[]{
    //     let complianceService = this.getComplianceService(framework);
    //     return complianceService.getServicesExists();
    // }
}
export default new FrameworkComplianceService();

