import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import { IRestResponseEntity } from '../../Model/RestEntities';
import OrgService from '../Organization/OrgService';
import BaseFrameworkService from '../Framework/BaseFrameworkService';
import { IComplianceData } from '../../Model/Compliance/ComplianceEntity';
import SaasListService from '../SaasProviders/SaasListService';

class ComplianceService extends BaseFrameworkService {
    private _complianceList : IComplianceData[];
    private _failedcomplianceList : string[]
    constructor(framework :FrameworkEntity){
        super(framework);
        this._complianceList=[];
        this._failedcomplianceList=[];
    }

    public CleanList(){
        this._complianceList=[];
    }

    public get ComplianceList() : IComplianceData[] {
        return this._complianceList;
    }

    public async getCompliances(key : string , indexLength : number): 
        Promise<[string , number,IRestResponseEntity]> {
        let service = SaasListService.getSaasService(key,this.framework);
        if(service){
             let response = await service.getCompliances();
             return [key.toUpperCase() , indexLength , response];
        }
        else{
            throw new Error("Service not registered");
        }
    }

    public async GetOrgCompliance() :Promise< [string[],string[],IComplianceData[]]>{
        let saasList1 : any [] = OrgService.getOrgSaasProviders();
        let saasList : string[]=[]; 
        saasList1.forEach((saas) => {
            saasList.push(saas.saasId);
        })
        if(! saasList || saasList.length <=0 ) {
            return [[],[],[]];
        }else if(saasList.length ===this._complianceList.length){
            return [saasList,this._failedcomplianceList,this._complianceList];
        }
        
        let saasarray  =saasList.filter((item)=>{
            return ! this._complianceList.find(e=> e.Key.toUpperCase() === item.toUpperCase())
        });
        if(saasarray.length >0){
            let responsePromiseArray :Promise<void> []=[];
            for (let i =0;i < saasarray.length ; i++) {   
                responsePromiseArray.push(this.onComplianceResponse(this.getCompliances(saasarray[i],i)));
            }
            return await this.onAllPromiseSettled(Promise.allSettled(responsePromiseArray),saasList);
        }
        else{
            let returnValue : [string[],string[],IComplianceData[]]=[[],[],[]];
            returnValue[0]=saasList;
            returnValue[1]=this._failedcomplianceList;
            returnValue[2]=this._complianceList;
            return returnValue;
        }
    }

    private async onComplianceResponse(request : Promise<[string , number,IRestResponseEntity]>) : Promise<void>{
        let response = await request;
        this.fillList(response[0],response[2]);
    }

    public fillList(saas : string, response : IRestResponseEntity) :IComplianceData[] {
        let keyData: IComplianceData | undefined = this._complianceList.find(item=> item.Key.toUpperCase() ===  saas.toUpperCase());
        if(response.status === 200 && response.data){
            if(keyData){
                keyData.Data = response.data;
            }
            else{
                keyData = {
                    Key : saas.toUpperCase(),
                    Data : response.data
                }
                this._complianceList.push(keyData);
                OrgService.addSaasInOrgList(saas);
            }
        }
        else{
            if(keyData){
                let indx = this._complianceList.findIndex(x=> x.Key === saas.toUpperCase());
                if(indx > -1) this._complianceList.splice(indx);
            }
            let failedData=this._failedcomplianceList.find(e=> e.toUpperCase() ===saas.toUpperCase());
            if(!failedData){
                this._failedcomplianceList.push(saas.toUpperCase());
            }
        }
        return this._complianceList;
    }

    private async onAllPromiseSettled(request : Promise<PromiseSettledResult<void>[]>
                                        ,saasList : string[]) : Promise<[string[],string[],IComplianceData[]]>
    {
        await request;
        let returnValue : [string[],string[],IComplianceData[]]=[[],[],[]];
        returnValue[0]=saasList;
        returnValue[1]=this._failedcomplianceList;
        returnValue[2]=this._complianceList;
        return returnValue;
    }
}
export default  ComplianceService;
