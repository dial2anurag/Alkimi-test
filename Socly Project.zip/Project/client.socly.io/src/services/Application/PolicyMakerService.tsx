import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import { APIData } from '../../Model/Organization/Org';
import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';

class PolicyMakerService extends APIBaseService {
    public async getFileDetail(filename: string,reset ?: boolean): Promise<IRestResponseEntity> {
        this.endPoint = `policy/file?fileName=${filename}.txt`;
        if(reset){
            this.endPoint= `${this.endPoint}&reset=${reset}`;
        }

        return await this.restService.getMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: null
        });
    }

    public async SavePolicyFile(data: any): Promise<IRestResponseEntity> {
        this.endPoint = "policy/unapproved/save";

        let axiosheader: AxiosRequestHeaders = {};
        let axiosConfig: AxiosRequestConfig = {};

        axiosheader["Content-Type"] = "multipart/form-data";
        axiosConfig.headers = axiosheader;

        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data,
            axiosConfig: axiosConfig
        });
        if (response.status !== 200) {
            alert(`Unable to save the file  ${response.message}`);
        }

        return response;
    }

    public async SaveApprovedPolicy(data: any): Promise<number> {
        this.endPoint = "policy/approve/save";

        let axiosheader: AxiosRequestHeaders = {};
        let axiosConfig: AxiosRequestConfig = {};

        axiosheader["Content-Type"] = "multipart/form-data";
        axiosConfig.headers = axiosheader;

        let responseCode: number = -1;
        let response = await this.restService.putMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data,
            axiosConfig: axiosConfig
        });
        responseCode = response.status;
        if (response.status !== 200) {
            alert(`Unable to save the file  ${response.message}`);
        }

        return responseCode;
    }

    
  

}
export default new PolicyMakerService();
