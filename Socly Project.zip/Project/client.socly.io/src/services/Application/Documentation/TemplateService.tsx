import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import { APIData } from '../../../Model/Organization/Org';
import { IRestResponseEntity } from '../../../Model/RestEntities';
import APIBaseService from '../../Base/APIBaseService';


export const ORG_TEMPLATE: string = "OrgTemplate";
export const DOC_TEMPLATE : string ="DocumentSummary"
export const CONTENT_TYPE: string = "text/plain";


class TemplateService extends APIBaseService {
    public async getTemplate(filename: string,reset ?: boolean): Promise<IRestResponseEntity> {
        this.endPoint = `template?filename=${filename}.txt`;
        if(reset){
            this.endPoint= `${this.endPoint}&reset=${reset}`;
        }
        return await this.restService.getMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: null
        });
    }

    public async saveTemplate(data: any): Promise<IRestResponseEntity> {
        this.endPoint = "organization/file/save";
        let axiosheader: AxiosRequestHeaders = {};
        let axiosConfig: AxiosRequestConfig = {};

        axiosheader["Content-Type"] = "multipart/form-data";
        axiosConfig.headers = axiosheader;
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data,
            axiosConfig: axiosConfig
        });
        if (response.status !== 200) {
            alert(`Unable to save the file  ${response.message}`);
        }
        return response;
    }

    public getFieldValue(field: string, apiData: APIData[]): string {
        let value = apiData.find(e => e.name === field);
        if(value) {
          return value.value;
        } else {
          return "";
        }
    }
    
    public mergeHtmlDivContent(orghtmldivcontent : string , htmldivcontent : string,dochtmlContent : string ) : string{
        let orgStyle : string ="padding-bottom: 5px;";
        let docStyle : string = "padding-bottom: 50px;";
        let contentStyle : string = "padding-top: 80px; padding-bottom: 30px;";
        return `
                  <div>
                      <div style='${orgStyle}'>
                          ${orghtmldivcontent}
                      </div>
                      ${dochtmlContent ? 
                        `<div style='${docStyle}'>
                            ${dochtmlContent}
                         </div>
                        `:""}
                      <div style='${contentStyle}'>
                          ${htmldivcontent}
                      </div>
                  </div>
                `
      }
}
export default new TemplateService();