import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import APIBaseService from '../Base/APIBaseService';

class ContactUsService extends APIBaseService {

    public async postContactUsService(data: any) {
        this.endPoint = "contactus/sendemail";

        let responseCode: number = -2;
        let axiosheader: AxiosRequestHeaders = {};
        let axiosConfig: AxiosRequestConfig = {};
        
        axiosheader["Content-Type"] = "multipart/form-data";
        axiosConfig.headers = axiosheader;
        
        let response = await this.restService.postMethod({
            data: data,
            endPoint: this.endPoint,
            setAuthentication: true,
            axiosConfig: axiosConfig
        })
        responseCode = response.status;
        
        if (response.status !== 200) {
            alert(response.message);
        }
        return responseCode;
    }
}
export default new ContactUsService();