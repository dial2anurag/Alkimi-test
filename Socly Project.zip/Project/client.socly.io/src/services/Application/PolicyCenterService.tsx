import { AxiosRequestConfig } from 'axios';
import { IRestResponseEntity } from '../../Model/RestEntities';
import APIBaseService from '../Base/APIBaseService';

class PolicyCenterService extends APIBaseService {
    public async getPolicies() : Promise<IRestResponseEntity>{
        this.endPoint = "policies/";
       return this.restService.getMethod({
            endPoint : this.endPoint,
            data : null,
            setAuthentication : true})
    }

    public async getPoliciesOnStatus(status ?: string) : Promise<IRestResponseEntity>{
        this.endPoint = "policies/by/status";
        if(status){
            this.endPoint = this.endPoint + `?status=${status}`
        }
       return this.restService.getMethod({
            endPoint : this.endPoint,
            data : null,
            setAuthentication : true})
    }

    public async getPolicy(id: number): Promise<IRestResponseEntity> {
        this.endPoint = `policy/file/download/${id}`;
        let axiosConfig : AxiosRequestConfig = {};
        axiosConfig.responseType ="blob";
        return this.restService.getMethod({
            endPoint: this.endPoint,
            data: null,
            setAuthentication: true,
            axiosConfig : axiosConfig
        })
    }

    public getPolicyName(policy :any): string{
        let name: string = policy.filename ? policy.filename : "";
        let indexOf = name.lastIndexOf(".");
        if(indexOf > -1) {
            name = name.substring(0, indexOf);
        }
        return name;
    }
}
export default new PolicyCenterService();