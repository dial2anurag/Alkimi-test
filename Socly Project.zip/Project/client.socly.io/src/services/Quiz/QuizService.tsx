import APIBaseService from '../Base/APIBaseService';


export type QuizDataEntity = {
    score: number,
    pass: boolean,

}
class QuizService extends APIBaseService {

    public async SaveQuizData(data: QuizDataEntity): Promise<number> {
        this.endPoint = "quiz/save";
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            data: data,
            setAuthentication: true,
        });
        if (response.status !== 200) {
            alert("Failed , Please try again ");
        }
        return response.status;
    }
}

export default new QuizService();
