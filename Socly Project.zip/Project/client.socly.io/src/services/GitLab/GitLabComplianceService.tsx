import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import { IRestResponseEntity } from '../../Model/RestEntities';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';

export default class GitLabComplianceService extends BaseFrameworkSaasService {
    public constructor(framework: FrameworkEntity) {
        super(framework);
    }

    public override async getCompliances(): Promise<IRestResponseEntity> {
        this.endPoint = `api/v2.0/gitlab/${this.framework.name.toLowerCase()}/all`;
        return await this.restService.getMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: null
        })
    }
}