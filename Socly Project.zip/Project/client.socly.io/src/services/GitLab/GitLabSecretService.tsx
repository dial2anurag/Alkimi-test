import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';
import BaseFrameworkSaasService from '../SaasProviders/BaseFrameworkSaasService';
import BaseSaasService from '../SaasProviders/BaseSaasService';
import GitLabComplianceService from './GitLabComplianceService';

class GitLabSecretService extends BaseSaasService {
    public constructor() {
        super();
    }

    public override async saveSecretKey(data: any): Promise<number> {
        this.endPoint = "api/v2.0/gitlab/credentials";

        var responseCode = -1;
        let response = await this.restService.postMethod({
            endPoint: this.endPoint,
            setAuthentication: true,
            data: data
        });
        responseCode = response.status;
        if (response.status === 200) {
            alert("Record Saved!");
        }
        else {
            alert("Invalid secret key! Please enter valid information");
        }

        return responseCode;
    }

    public override getBaseFrameworkSaasServiceInstance(framework: FrameworkEntity): BaseFrameworkSaasService {
        return new GitLabComplianceService(framework);   
    }
}
export default new GitLabSecretService();
