import BaseFrameworkService from '../Framework/BaseFrameworkService';
import { AxiosRequestConfig, AxiosRequestHeaders } from 'axios';
import { FrameworkEntity } from '../../Model/Framework/FrameworkEntity';

export default class UploadEvidenceService extends BaseFrameworkService  {
    public constructor(framework:FrameworkEntity){
        super(framework);
    }
    
    public async getComplianceList(){
        this.endPoint = "metrics/allactivemetrics";
        return await this.restService.getMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :null
        })
    }

    public async uploadFile(data : any) : Promise<number>{
        this.endPoint = "file/upload";
        let axiosheader : AxiosRequestHeaders ={} ;
        let axiosConfig : AxiosRequestConfig = {};

        axiosheader["Content-Type"] = "multipart/form-data";
        
        axiosConfig.headers = axiosheader;
        let responseCode : number = -1;
        let response =await this.restService.postMethod({
            endPoint : this.endPoint,
            setAuthentication : true ,
            data :data  ,
            axiosConfig : axiosConfig
        });
        responseCode = response.status;
        if(response.status ===200){
            alert("Record Saved !!");
        }
        else{
            alert(response.message);
        }
        return responseCode;
    }

    async getUniqueComplianceId() : Promise<any[]> {
        let complianceList : any[]=[];
        await  this.getComplianceList().then((response)=>{
                if(response.status === 200){
                    complianceList=response.data;
           }
        });
        return complianceList;
    }
}

