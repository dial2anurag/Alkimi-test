import styled from 'styled-components'

export const MainDiv = styled.div`
    min-height: 100vh;
    display: grid;
`;

export const LinkStyleNormal = {
    textDecoration: 'none',
    color: 'black'
}

export const LinkStyleClicked = {
    textDecoration: 'none',
    color: '#20a7e8'
}

export const PageContainer = styled.div`
    margin: 3rem 0rem;
    background-color: #ffffff;
`;

export const ContentHeading = styled.div`
    font-size: 20px;
    font-weight: 600;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.21;
    letter-spacing: normal;
    text-align: left;
    color: #00153d;
    margin-top: 2rem;
    text-align : center;
    padding-bottom : 2rem;
`;
